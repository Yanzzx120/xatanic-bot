require('./src/bot');
