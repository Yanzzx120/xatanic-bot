'use strict';
// RICH MD V7 — dependency verification for Pterodactyl (CommonJS)
// No source / session data is altered by this script.
const cp = require('child_process');
const fs = require('fs');
const path = require('path');
const ROOT = path.resolve(__dirname, '..');
const required = [
  '@whiskeysockets/baileys',
  'node-telegram-bot-api',
  'axios', 'chalk', 'dotenv', 'pino', 'fs-extra',
  'moment-timezone', 'ffmpeg-static', 'sharp', 'jszip', 'form-data'
];
const log = (msg) => console.log(`[RICHMD-FIX] ${msg}`);

function getMissing() {
  return required.filter((name) => {
    try { require.resolve(name, {paths: [ROOT]}); return false; }
    catch (e) { if (e && e.code === 'MODULE_NOT_FOUND') return true; throw e; }
  });
}

function verifyBaileys() {
  let baileys;
  try { baileys = require(require.resolve('@whiskeysockets/baileys', {paths: [ROOT]})); }
  catch (e) {
    throw new Error(`Baileys gagal dimuat: ${e.code || e.message}. ${e.message}`);
  }
  const makeWASocket = baileys.makeWASocket || baileys.default;
  if (typeof makeWASocket !== 'function' || typeof baileys.useMultiFileAuthState !== 'function') {
    throw new Error('Baileys terinstal, tetapi ekspor CommonJS tidak cocok dengan src/services.js');
  }
  log('Baileys CommonJS OK; makeWASocket/useMultiFileAuthState tersedia.');
}
function verifyManifest() {
  const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'),'utf8'));
  if (pkg.dependencies['@whiskeysockets/baileys'] !== '6.7.18' ||
      pkg.overrides?.libsignal !== '6.0.0') {
    throw new Error('package.json belum memakai patch yang sesuai (versi Baileys / override libsignal).');
  }
  log('Manifest OK: Baileys 6.7.18 + override libsignal 6.0.0.');
}
function npmBinary() {
  const execpath = process.env.npm_execpath;
  if (execpath && fs.existsSync(execpath)) {
    return {command:process.execPath, head:[execpath]};
  }
  return {command: process.platform === 'win32' ? 'npm.cmd' : 'npm', head:[]};
}
function repair() {
  const npm = npmBinary();
  log('Menginstal dependency dari npm registry, tanpa dependency Git.');
  const args = [...npm.head, 'install', '--no-audit', '--no-fund', '--legacy-peer-deps'];
  const result = cp.spawnSync(npm.command, args, {
    cwd: ROOT, stdio:'inherit', env:{...process.env, npm_config_allow_git:'none'},
    timeout: 180000, maxBuffer: 1024 * 1024,
  });
  if (result.error) throw new Error(`npm install gagal: ${result.error.message}`);
  if (result.status !== 0) {
    throw new Error(`npm install gagal (exit ${result.status ?? 'unknown'}, signal ${result.signal || 'none'}). Cek log npm tepat di atas.`);
  }
}
try {
  log(`Node ${process.version} | root ${ROOT}`);
  verifyManifest();
  const missing = getMissing();
  if (missing.length) {
    log(`Belum ada: ${missing.join(', ')}`);
    repair();
  } else {
    log('Dependency utama terdeteksi. Memeriksa Baileys...');
  }
  const stillMissing = getMissing();
  if (stillMissing.length) throw new Error(`Setelah instalasi masih hilang: ${stillMissing.join(', ')}`);
  verifyBaileys();
  log('SUCCESS — dependency utama siap, bot akan dimulai.');
} catch (e) {
  console.error(`[RICHMD-FIX] GAGAL — ${e.message}`);
  console.error('[RICHMD-FIX] Bot tidak dijalankan agar error asli tidak tertutup. Kirim log mulai [RICHMD-FIX].');
  process.exit(1);
}
