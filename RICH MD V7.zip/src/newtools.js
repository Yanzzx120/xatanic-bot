const JSZip = require('jszip');
const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs-extra');
const os = require('os');
const path = require('path');
const MIME_BY_EXT = { jpg:'image/jpeg', jpeg:'image/jpeg', png:'image/png', webp:'image/webp', gif:'image/gif', mp4:'video/mp4', webm:'video/webm' };
function guessMime(filename='') { const ext=String(filename).split('.').pop().toLowerCase(); return MIME_BY_EXT[ext] || 'application/octet-stream'; }
const { spawn } = require('child_process');

const TEXT_EXT = /\.(?:js|cjs|mjs|json|jsonc|env|txt|md|html?|css|scss|sass|less|xml|svg|yml|yaml|toml|ini|conf|config|properties|sh|bash|zsh|py|php|java|kt|ts|tsx|jsx|vue|svelte|astro|sql|go|rs|rb|swift|dart|dockerfile|gitignore)$/i;
const SKIP_RE = /(^|\/)(?:node_modules|\.git|\.next|dist|build|coverage|vendor)(\/|$)/i;
const DOMAIN_RE = /(?:(?:https?:\/\/|wss?:\/\/)?)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)+(?::\d{1,5})?)/gi;

function isTextFile(name, data) {
  if (SKIP_RE.test(name)) return false;
  if (TEXT_EXT.test(name) || /(^|\/)Dockerfile$/i.test(name)) return true;
  const sample = data.slice(0, Math.min(data.length, 4096));
  for (const b of sample) if (b === 0) return false;
  return true;
}

function normalizeHost(value='') {
  let v=String(value).trim().replace(/^['"`]+|['"`]+$/g,'');
  v=v.replace(/^[a-z]+:\/\//i,'').split('/')[0].split('?')[0].split('#')[0];
  return v.replace(/\.$/,'').toLowerCase();
}

function normalizeDomainInput(value='') {
  const v=normalizeHost(value);
  if (!v || v.length > 253) return '';
  const portMatch=v.match(/:(\d{1,5})$/);
  const port=portMatch ? Number(portMatch[1]) : null;
  const host=v.replace(/:\d{1,5}$/,'');
  if (port !== null && (port < 1 || port > 65535)) return '';
  if (!host.includes('.') || host.length > 253) return '';
  const labels=host.split('.');
  if (labels.some(x=>!x || x.length>63 || !/^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i.test(x))) return '';
  return port === null ? host : `${host}:${port}`;
}

function domainVariants(value='') {
  const host=normalizeHost(value);
  const port=(host.match(/:(\d+)$/)||[])[1] || '';
  const bare=host.replace(/:\d+$/,'');
  return [...new Set(port ? [host, bare] : [bare])];
}

async function readZipTextEntries(buffer) {
  const zip=await JSZip.loadAsync(buffer);
  const entries=[];
  for (const [name,entry] of Object.entries(zip.files)) {
    if (entry.dir || SKIP_RE.test(name)) continue;
    const data=await entry.async('nodebuffer');
    if (!isTextFile(name,data)) continue;
    entries.push({zip,name,data,text:data.toString('utf8')});
  }
  return {zip,entries};
}

async function extractDomainsFromZip(buffer) {
  const {entries}=await readZipTextEntries(buffer);
  const set=new Set();
  for (const item of entries) {
    DOMAIN_RE.lastIndex=0;
    let m;
    while ((m=DOMAIN_RE.exec(item.text))) {
      const host=normalizeHost(m[1]);
      if (!host || /^(?:example\.com|example\.org|example\.net)$/i.test(host)) continue;
      if (/\.(?:png|jpe?g|gif|webp|mp4|mp3|zip|rar|7z)$/i.test(host)) continue;
      if (!normalizeDomainInput(host)) continue;
      set.add(host);
    }
  }
  return [...set].sort((a,b)=>a.localeCompare(b)).slice(0,100);
}

async function findDomainInZip(buffer, oldDomain) {
  const target=normalizeDomainInput(oldDomain);
  if (!target) throw new Error('Domain lama tidak valid. Contoh: api.example.com');
  const variants=domainVariants(target).sort((a,b)=>b.length-a.length);
  const {entries}=await readZipTextEntries(buffer);
  const files=[];
  let occurrences=0;
  const boundary=(v)=>new RegExp(`(^|[^a-z0-9_-])${v.replace(/[.*+?^${}()|[\\]\\\\]/g,'\\\\$&')}(?=$|[^a-z0-9_-])`,'i');
  for (const item of entries) {
    let count=0;
    for (const v of variants) {
      const re=boundary(v);
      const matches=item.text.match(re);
      if (matches) {
        const escaped=v.replace(/[.*+?^${}()|[\\]\\\\]/g,'\\\\$&');
        const all=item.text.match(new RegExp(`(^|[^a-z0-9_-])${escaped}(?=$|[^a-z0-9_-])`,'gi')) || [];
        count += all.length;
      }
    }
    if (count) { files.push({name:item.name,count}); occurrences += count; }
  }
  return {domain:target, files, occurrences, found:occurrences>0};
}

function replaceExact(text, variants, target) {
  let out=text;
  for (const v of variants.sort((a,b)=>b.length-a.length)) {
    const escaped=v.replace(/[.*+?^${}()|[\\]\\\\]/g,'\\\\$&');
    const re=new RegExp(`(^|[^a-z0-9_-])${escaped}(?=$|[^a-z0-9_-])`,'gi');
    out=out.replace(re,(_m,prefix)=>`${prefix}${target}`);
  }
  return out;
}

async function replaceDomainInZip(buffer, oldDomain, newDomain, newPort='') {
  const oldHost=normalizeDomainInput(oldDomain);
  const newHost=normalizeDomainInput(newDomain);
  if (!oldHost || !newHost) throw new Error('Domain lama atau domain baru tidak valid.');
  const newBare=newHost.replace(/:\d+$/,'');
  const port=String(newPort||'').trim();
  if (port && (!/^\d{1,5}$/.test(port) || Number(port)<1 || Number(port)>65535)) throw new Error('Port baru tidak valid.');
  const target=port ? `${newBare}:${port}` : newBare;
  const variants=domainVariants(oldHost);
  const {zip,entries}=await readZipTextEntries(buffer);
  let changedFiles=0, replacements=0;
  for (const item of entries) {
    const text=replaceExact(item.text,variants,target);
    if (text!==item.text) {
      zip.file(item.name,Buffer.from(text,'utf8'));
      changedFiles++;
      for (const v of variants) {
        const escaped=v.replace(/[.*+?^${}()|[\\]\\\\]/g,'\\\\$&');
        replacements += (item.text.match(new RegExp(`(^|[^a-z0-9_-])${escaped}(?=$|[^a-z0-9_-])`,'gi'))||[]).length;
      }
    }
  }
  if (!changedFiles) throw new Error(`Domain ${oldHost} tidak ditemukan di dalam file teks ZIP.`);
  return zip.generateAsync({type:'nodebuffer',compression:'DEFLATE',compressionOptions:{level:6}});
}

async function findPortInZip(buffer, oldPort) {
  const port=String(oldPort||'').trim();
  if (!/^\d{1,5}$/.test(port) || Number(port)<1 || Number(port)>65535) throw new Error('Port lama tidak valid.');
  const {entries}=await readZipTextEntries(buffer);
  const patterns=[
    new RegExp(`:(?:${port})(?=[^0-9]|$)`,'g'),
    new RegExp(`(?:PORT|port|PANEL_PORT|panel_port)\\s*[=:]\\s*["']?${port}(?!\\d)`,'g')
  ];
  const files=[]; let occurrences=0;
  for (const item of entries) {
    let count=0;
    for (const re of patterns) count += (item.text.match(re)||[]).length;
    if (count) { files.push({name:item.name,count}); occurrences += count; }
  }
  return {port,files,occurrences,found:occurrences>0};
}

async function replacePortInZip(buffer, oldPort, newPort) {
  const oldP=String(oldPort||'').trim(), newP=String(newPort||'').trim();
  if (!/^\d{1,5}$/.test(oldP) || Number(oldP)<1 || Number(oldP)>65535) throw new Error('Port lama tidak valid.');
  if (!/^\d{1,5}$/.test(newP) || Number(newP)<1 || Number(newP)>65535) throw new Error('Port baru tidak valid.');
  const {zip,entries}=await readZipTextEntries(buffer);
  const patterns=[
    new RegExp(`:(?:${oldP})(?=[^0-9]|$)`,'g'),
    new RegExp(`((?:PORT|port|PANEL_PORT|panel_port)\\s*[=:]\\s*["']?)${oldP}(?!\\d)`,'g')
  ];
  let changedFiles=0;
  for (const item of entries) {
    let text=item.text;
    text=text.replace(patterns[0],`:${newP}`);
    text=text.replace(patterns[1],`$1${newP}`);
    if (text!==item.text) { zip.file(item.name,Buffer.from(text,'utf8')); changedFiles++; }
  }
  if (!changedFiles) throw new Error(`Port ${oldP} tidak ditemukan di dalam file teks ZIP.`);
  return zip.generateAsync({type:'nodebuffer',compression:'DEFLATE',compressionOptions:{level:6}});
}

async function uploadToProvider(provider, buffer, filename='photo.jpg') {
  provider=String(provider).toLowerCase();
  if (provider==='catbox') {
    let lastError;
    const userhash=String(process.env.CATBOX_USERHASH||'').trim();
    for (let attempt=1; attempt<=2; attempt++) {
      let retryable=false;
      try {
        if (!Buffer.isBuffer(buffer) || !buffer.length) throw new Error('File kosong atau tidak valid.');
        const form=new FormData();
        form.append('reqtype','fileupload');
        if (userhash) form.append('userhash',userhash);
        form.append('fileToUpload',buffer,{filename,contentType:guessMime(filename),knownLength:buffer.length});
        const headers={
          ...form.getHeaders(),
          'User-Agent':'MELLSTECUU-MD/6.1',
          'Accept':'text/plain,*/*'
        };
        const r=await axios.post('https://catbox.moe/user/api.php',form,{
          headers,
          timeout:120000,
          maxBodyLength:200*1024*1024,
          maxContentLength:20*1024*1024,
          validateStatus:()=>true
        });
        const body=typeof r.data==='string'
          ? r.data.trim()
          : String(r.data?.url||r.data?.data?.url||'').trim();
        if(r.status>=200&&r.status<300&&/^https?:\/\/(?:files\.)?catbox\.moe\//i.test(body)) return body;
        retryable = r.status===408 || r.status===429 || r.status>=500;
        throw new Error(`Catbox HTTP ${r.status}: ${body.slice(0,240)||'response kosong'}`);
      }catch(e){
        lastError=e;
        const code=String(e?.code||'');
        retryable = retryable || ['ECONNRESET','ETIMEDOUT','ECONNABORTED','EAI_AGAIN','ENETUNREACH','EHOSTUNREACH'].includes(code);
        if(attempt<2 && retryable) await new Promise(r=>setTimeout(r,1500));
        else break;
      }
    }
    const detail=lastError?.message||'Catbox upload gagal.';
    throw new Error(`${detail}\nCatbox tidak membutuhkan API key untuk upload anonymous; jika ini terus terjadi, cek koneksi outbound Pterodactyl ke catbox.moe atau gunakan provider Auto.`);
  }
  if(provider==='0x0'){
    const form=new FormData();form.append('file',buffer,{filename,contentType:guessMime(filename)});
    const r=await axios.post('https://0x0.st',form,{headers:{...form.getHeaders(),'User-Agent':'MELLSTECUU-MD/6.1'},timeout:60000,maxBodyLength:20*1024*1024,maxContentLength:20*1024*1024,validateStatus:()=>true});
    const url=String(r.data||'').trim();
    if(r.status>=200&&r.status<300&&/^https?:\/\//i.test(url))return url;
    throw new Error(`0x0.st HTTP ${r.status}: ${url.slice(0,160)||'response kosong'}`);
  }
  if(provider==='litterbox'){
    const form=new FormData();form.append('reqtype','fileupload');form.append('time','1h');form.append('fileToUpload',buffer,{filename,contentType:guessMime(filename)});
    const r=await axios.post('https://litterbox.catbox.moe/resources/internals/api.php',form,{headers:{...form.getHeaders(),'User-Agent':'MELLSTECUU-MD/6.1'},timeout:60000,maxBodyLength:20*1024*1024,maxContentLength:20*1024*1024,validateStatus:()=>true});
    const url=String(r.data||'').trim();
    if(r.status>=200&&r.status<300&&/^https?:\/\//i.test(url))return url;
    throw new Error(`Litterbox HTTP ${r.status}: ${url.slice(0,160)||'response kosong'}`);
  }
  if(provider==='uguu'){
    const form=new FormData();form.append('files[]',buffer,{filename,contentType:guessMime(filename)});
    let r=await axios.post('https://uguu.se/upload',form,{headers:{...form.getHeaders(),'User-Agent':'MELLSTECUU-MD/6.1'},timeout:60000,maxBodyLength:20*1024*1024,maxContentLength:20*1024*1024,validateStatus:()=>true});
    let url=r.data?.files?.[0]?.url;
    if(!url&&r.status>=200&&r.status<300&&typeof r.data==='string'){const m=r.data.match(/https?:\/\/[^\s"']+/i);if(m)url=m[0];}
    if(!url){
      const form2=new FormData();form2.append('files[]',buffer,{filename,contentType:guessMime(filename)});
      r=await axios.post('https://uguu.se/upload.php',form2,{headers:{...form2.getHeaders(),'User-Agent':'MELLSTECUU-MD/6.1'},timeout:60000,maxBodyLength:20*1024*1024,maxContentLength:20*1024*1024,validateStatus:()=>true});
      url=r.data?.files?.[0]?.url;
    }
    if(url&&/^https?:\/\//i.test(String(url)))return String(url);
    throw new Error(`Uguu HTTP ${r.status}: ${typeof r.data==='string'?r.data.slice(0,160):'response tidak berisi URL'}`);
  }
  throw new Error('Provider tidak dikenal.');
}

async function uploadToProviderWithFallback(provider, buffer, filename='photo.jpg') {
  const requested=String(provider||'auto').toLowerCase();
  const order=requested==='auto'?['uguu','catbox','litterbox','0x0']:[requested,...['uguu','catbox','litterbox','0x0'].filter(x=>x!==requested)];
  const errors=[];
  for(const name of order){
    try{return {provider:name,url:await uploadToProvider(name,buffer,filename),fallback:name!==requested};}
    catch(e){errors.push(`${name}: ${e?.message||'gagal'}`);}
  }
  throw new Error(`Semua provider TOURL gagal.\\n${errors.join('\\n')}`);
}

async function resolveVercelTeam(token, headers) {
  const explicitId=String(process.env.VERCEL_TEAM_ID || '').trim();
  if (explicitId) return { id: explicitId, source: 'VERCEL_TEAM_ID' };

  // Screenshot/account setup shows the user's default team as "nafz".
  // Allow an override, but resolve the real team ID through the API because
  // Vercel API calls for team-owned resources require the team ID, not slug.
  const wanted=String(process.env.VERCEL_TEAM_SLUG || 'nafz').trim().toLowerCase();
  if (!wanted) return null;

  const r=await axios.get('https://api.vercel.com/v2/teams',{
    headers, timeout:30000, params:{limit:100}
  });
  const teams=Array.isArray(r.data?.teams) ? r.data.teams : [];
  const exact=teams.find(t=>String(t.slug||'').toLowerCase()===wanted || String(t.name||'').toLowerCase()===wanted);
  if (!exact) {
    throw new Error(`Team Vercel "${wanted}" tidak ditemukan atau token tidak memiliki akses ke team tersebut.`);
  }
  return { id:String(exact.id), slug:String(exact.slug||''), name:String(exact.name||exact.slug||wanted), source:'team-slug' };
}

function buildApiQuery(teamId='') {
  return teamId ? `?teamId=${encodeURIComponent(teamId)}` : '';
}

function cleanHost(value='') {
  let v=String(value||'').trim();
  if (!v) return '';
  v=v.replace(/^https?:\/\//i,'').split('/')[0].replace(/\.$/,'');
  return v;
}

async function getProject(token, headers, teamId, projectName) {
  const q=buildApiQuery(teamId);
  try {
    const r=await axios.get(`https://api.vercel.com/v9/projects/${encodeURIComponent(String(projectName))}${q}`,{headers,timeout:30000});
    return r.data || null;
  } catch (e) {
    if (e.response?.status !== 404) throw e;
    return null;
  }
}

async function ensureVercelProject(token, headers, teamId, projectName) {
  let project=await getProject(token,headers,teamId,projectName);
  if (project) return project;
  const q=buildApiQuery(teamId);
  try {
    const r=await axios.post(`https://api.vercel.com/v11/projects${q}`,{
      name:projectName,
      framework:null,
      buildCommand:null,
      devCommand:null,
      installCommand:null,
      outputDirectory:null
    },{headers,timeout:30000});
    project=r.data || null;
  } catch (e) {
    // A concurrent deployment may have created it between GET and POST.
    if (e.response?.status !== 409) throw e;
    project=await getProject(token,headers,teamId,projectName);
  }
  if (!project) throw new Error('Project Vercel tidak dapat dibuat/ditemukan. Pastikan token memiliki akses ke Team yang dipilih.');
  return project;
}

async function waitForDeployment(token, headers, teamId, deploymentId, timeoutMs=180000) {
  const q=buildApiQuery(teamId);
  const started=Date.now();
  let last=null;
  while (Date.now()-started < timeoutMs) {
    const r=await axios.get(`https://api.vercel.com/v13/deployments/${encodeURIComponent(String(deploymentId))}${q}`,{headers,timeout:30000});
    const d=r.data || {};
    last=d;
    const state=String(d.readyState || d.status || '').toUpperCase();
    if (state==='READY' || d.ready) return d;
    if (['ERROR','CANCELED','CANCELLED'].includes(state)) {
      const reason=d.error?.message || d.errorMessage || d.readyState || state;
      throw new Error(`Deployment Vercel gagal (${state}): ${reason}`);
    }
    await new Promise(r=>setTimeout(r,2500));
  }
  throw new Error(`Deployment belum READY setelah ${Math.round(timeoutMs/1000)} detik. Status terakhir: ${last?.readyState || last?.status || 'UNKNOWN'}.`);
}

async function listDeploymentAliases(token, headers, teamId, deploymentId) {
  const q=buildApiQuery(teamId);
  try {
    const r=await axios.get(`https://api.vercel.com/v2/deployments/${encodeURIComponent(String(deploymentId))}/aliases${q}`,{headers,timeout:30000});
    return Array.isArray(r.data?.aliases) ? r.data.aliases.map(x=>typeof x==='string'?x:x?.alias).filter(Boolean) : [];
  } catch (_) { return []; }
}

async function assignAlias(token, headers, teamId, deploymentId, alias) {
  const q=buildApiQuery(teamId);
  try {
    const r=await axios.post(`https://api.vercel.com/v2/deployments/${encodeURIComponent(String(deploymentId))}/aliases${q}`,{alias},{headers,timeout:30000});
    return r.data?.alias || alias;
  } catch (e) {
    const code=e.response?.data?.error?.code || e.response?.status;
    // 409 can mean the alias is already assigned to this deployment; verify instead of failing.
    if (code===409 || code==='conflict') return alias;
    throw e;
  }
}

async function promoteProduction(token, headers, teamId, projectId, deploymentId) {
  if (!projectId || !deploymentId) return false;
  const q=buildApiQuery(teamId);
  try {
    await axios.post(`https://api.vercel.com/v10/projects/${encodeURIComponent(String(projectId))}/promote/${encodeURIComponent(String(deploymentId))}${q}`,{}, {headers,timeout:30000});
    return true;
  } catch (e) {
    // If the deployment is already production, promotion may be rejected; that is harmless.
    const msg=String(e.response?.data?.error?.message || e.message || '').toLowerCase();
    if (/already|current|production/.test(msg) || [400,409].includes(e.response?.status)) return false;
    throw e;
  }
}

async function probePublicUrl(url) {
  try {
    const r=await axios.get(url,{timeout:15000,maxRedirects:5,validateStatus:()=>true,headers:{'User-Agent':'NAFZ-Vercel-Deploy-Check/1.0'}});
    return {status:r.status,ok:r.status>=200 && r.status<400};
  } catch (e) {
    return {status:0,ok:false,error:e.message};
  }
}

async function getProductionUrl({token, headers, teamId, projectId, projectName, deployment}) {
  const apiQuery=buildApiQuery(teamId);
  const candidates=[];
  const add=(v, source)=>{ const host=cleanHost(v); if(host) candidates.push({host,source}); };

  for (const a of (Array.isArray(deployment?.alias) ? deployment.alias : [])) add(a,'deployment.alias');

  let project=null;
  const ids=[projectId, projectName].filter(Boolean);
  for (const id of ids) {
    try {
      const r=await axios.get(`https://api.vercel.com/v9/projects/${encodeURIComponent(String(id))}${apiQuery}`,{headers,timeout:30000});
      project=r.data; break;
    } catch (_) {}
  }
  if (project) for (const a of (Array.isArray(project.alias) ? project.alias : [])) add(a,'project.alias');

  if (project) {
    try {
      const r=await axios.get(`https://api.vercel.com/v9/projects/${encodeURIComponent(String(project.id||projectName))}/domains${apiQuery}`,{headers,timeout:30000});
      const domains=Array.isArray(r.data?.domains) ? r.data.domains : [];
      for (const d of domains) add(typeof d==='string'?d:d?.name,'project.domain');
    } catch (_) {}
  }

  if (projectId || project?.id) {
    try {
      const r=await axios.get('https://api.vercel.com/v6/deployments',{headers,timeout:30000,params:{projectId:String(projectId||project.id),target:'production',limit:10,...(teamId?{teamId}: {})}});
      for (const d of (Array.isArray(r.data?.deployments)?r.data.deployments:[])) {
        for (const a of (Array.isArray(d.alias)?d.alias:[])) add(a,'production-deployment.alias');
        const u=cleanHost(d.url||'');
        if(u && projectName && u.toLowerCase()===`${projectName}.vercel.app`.toLowerCase()) add(u,'production-deployment.url');
      }
    } catch (_) {}
  }

  const preferred=`${String(project?.name||projectName).toLowerCase()}.vercel.app`;
  const unique=[...new Map(candidates.map(x=>[x.host.toLowerCase(),x])).values()];
  const exact=unique.find(x=>x.host.toLowerCase()===preferred);
  if(exact) return {url:`https://${exact.host}`,source:exact.source,project};
  const custom=unique.find(x=>!x.host.toLowerCase().endsWith('.vercel.app'));
  if(custom) return {url:`https://${custom.host}`,source:custom.source,project};
  const safeGenerated=unique.find(x=>x.host.toLowerCase().endsWith('.vercel.app') && !looksLikeDeploymentHost(x.host, projectName));
  if(safeGenerated) return {url:`https://${safeGenerated.host}`,source:safeGenerated.source,project};
  if(projectName) return {url:`https://${projectName}.vercel.app`,source:'project-name-fallback',project};
  return {url:'',source:'none',project};
}

function normalizeZipEntries(zip) {
  const names=Object.keys(zip.files).filter(n=>!zip.files[n].dir && !SKIP_RE.test(n));
  if(!names.length) return [];
  const top=names.map(n=>n.split('/')[0]).filter(Boolean);
  const common=top.length && top.every(x=>x===top[0]) ? top[0] : '';
  const hasRootIndex=names.some(n=>/^(index\.html|package\.json|vercel\.json|vite\.config\.|next\.config\.)$/i.test(n.split('/').pop()||'') && !n.includes('/'));
  return names.map(name=>{
    const normalized=(common && !hasRootIndex && name.startsWith(common+'/')) ? name.slice(common.length+1) : name;
    return {source:name,file:normalized};
  }).filter(x=>x.file && !x.file.startsWith('../'));
}

function runVercelCli(args, cwd, timeoutMs = 240000) {
  return new Promise((resolve, reject) => {
    const localBin = path.join(process.cwd(), 'node_modules', '.bin', process.platform === 'win32' ? 'vercel.cmd' : 'vercel');
    const command = fs.existsSync(localBin) ? localBin : 'npx';
    const finalArgs = fs.existsSync(localBin) ? args : ['--yes', 'vercel', ...args];
    const child = spawn(command, finalArgs, {
      cwd,
      env: { ...process.env, CI: '1', VERCEL_CLI_FORCE_NO_TELEMETRY: '1' },
      stdio: ['ignore', 'pipe', 'pipe']
    });
    let stdout = '', stderr = '';
    child.stdout.on('data', d => { stdout += d.toString(); });
    child.stderr.on('data', d => { stderr += d.toString(); });
    const timer = setTimeout(() => {
      try { child.kill('SIGTERM'); } catch {}
      reject(new Error(`Vercel CLI timeout setelah ${Math.round(timeoutMs / 1000)} detik.`));
    }, timeoutMs);
    child.on('error', e => { clearTimeout(timer); reject(e); });
    child.on('close', code => {
      clearTimeout(timer);
      if (code !== 0) {
        const detail = (stderr || stdout).trim().slice(-5000) || `exit code ${code}`;
        return reject(new Error(`Vercel CLI gagal (exit ${code}): ${detail}`));
      }
      resolve({ stdout, stderr });
    });
  });
}

function extractCliDeploymentUrl(output) {
  const lines = String(output || '').split(/\r?\n/).map(x => x.trim()).filter(Boolean);
  const urls = [];
  for (const line of lines) {
    const m = line.match(/https:\/\/[^\s`"'<>]+\.vercel\.app/gi);
    if (m) urls.push(...m);
  }
  const unique = [...new Set(urls.map(cleanHost).filter(Boolean))];
  return unique.find(h => !looksLikeDeploymentHost(h, '')) || unique[unique.length - 1] || '';
}

async function materializeZip(buffer) {
  const zip = await JSZip.loadAsync(buffer);
  const entries = normalizeZipEntries(zip);
  if (!entries.length) throw new Error('ZIP website kosong.');
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'nafz-vercel-'));
  for (const item of entries) {
    const dest = path.join(root, item.file);
    if (!dest.startsWith(root + path.sep)) throw new Error('ZIP memiliki path yang tidak aman.');
    await fs.ensureDir(path.dirname(dest));
    const data = await zip.files[item.source].async('nodebuffer');
    if (data.length > 8 * 1024 * 1024) throw new Error(`File ${item.file} terlalu besar.`);
    await fs.writeFile(dest, data);
  }
  return root;
}

async function deployWithCli(buffer, token, projectName, team) {
  const root = await materializeZip(buffer);
  try {
    const safeName = String(projectName).replace(/[^a-z0-9-]/gi, '-').toLowerCase().replace(/^-+|-+$/g, '').replace(/-{2,}/g, '-').slice(0, 52) || 'telegram-deploy';
    const project = await ensureVercelProject(token, { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }, team?.id || '', safeName);
    const dotVercel = path.join(root, '.vercel');
    await fs.ensureDir(dotVercel);
    const link = { projectId: String(project.id) };
    if (team?.id) link.orgId = String(team.id);
    await fs.writeJson(path.join(dotVercel, 'project.json'), link, { spaces: 2 });

    const args = ['--prod', '--yes', '--force', '--token', token];
    if (team?.slug) args.push('--scope', team.slug);
    const result = await runVercelCli(args, root, 300000);
    const cliUrl = extractCliDeploymentUrl(result.stdout) || extractCliDeploymentUrl(result.stderr);
    const deploymentUrl = cliUrl ? `https://${cliUrl}` : '';

    // Ask the API for the current production deployment and stable project domain.
    const headers = { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' };
    const q = buildApiQuery(team?.id || '');
    const projectAfter = await getProject(token, headers, team?.id || '', safeName);
    const deployments = await axios.get(`https://api.vercel.com/v6/deployments${q}`, {
      headers, timeout: 30000,
      params: { projectId: String(projectAfter?.id || project.id), target: 'production', limit: 10 }
    });
    const ready = (deployments.data?.deployments || []).find(d => String(d.readyState || '').toUpperCase() === 'READY') || {};
    const deploymentId = ready.id || ready.uid;
    if (!deploymentId) throw new Error('CLI deploy selesai, tetapi deployment Production tidak ditemukan melalui API.');

    const resolved = await getProductionUrl({
      token, headers, teamId: team?.id || '', projectId: projectAfter?.id || project.id,
      projectName: safeName, deployment: ready
    });
    const finalUrl = resolved.url || deploymentUrl;
    if (!finalUrl) throw new Error('Production URL tidak ditemukan setelah deployment CLI.');

    let probe = await probePublicUrl(finalUrl);
    if (!probe.ok) {
      await new Promise(r => setTimeout(r, 5000));
      probe = await probePublicUrl(finalUrl);
    }
    if (!probe.ok) {
      const aliases = await listDeploymentAliases(token, headers, team?.id || '', deploymentId);
      throw new Error(`Deployment CLI selesai tetapi Production URL mengembalikan HTTP ${probe.status || 'network error'}. Deployment=${deploymentId}; aliases=${aliases.join(', ') || '-'}. Jika semua alias dan URL deployment ikut 404 NOT_FOUND, masalahnya berada di routing Vercel, bukan tombol bot.`);
    }

    return {
      url: finalUrl,
      name: safeName,
      id: deploymentId,
      projectId: projectAfter?.id || project.id,
      teamId: team?.id || null,
      teamName: team?.name || null,
      target: 'production',
      alias: finalUrl.replace(/^https?:\/\//i, ''),
      aliasSource: resolved.source || 'vercel-cli',
      protection: 'unchanged',
      protectionConfigured: false,
      projectFound: true,
      verified: true,
      httpStatus: probe.status,
      aliases: await listDeploymentAliases(token, headers, team?.id || '', deploymentId),
      method: 'vercel-cli'
    };
  } finally {
    await fs.remove(root).catch(() => {});
  }
}

async function deployToVercel(buffer, filename, token, projectName='telegram-deploy') {
  if (!token) throw new Error('VERCEL_TOKEN belum diisi.');
  const headers = { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' };
  let team = null;
  try { team = await resolveVercelTeam(token, headers); }
  catch (e) { if (process.env.VERCEL_USE_PERSONAL_SCOPE === 'true') team = null; else throw e; }

  // Use the official Vercel CLI as the primary deployment path. It performs the
  // same supported production flow used by CI/CD and avoids the stale edge
  // routing state we observed with the previous raw REST deployment path.
  try {
    return await deployWithCli(buffer, token, projectName, team);
  } catch (cliError) {
    // Keep a REST fallback for environments where the CLI package cannot start.
    // The fallback is still fully verified before a success message is returned.
    const cliMsg = String(cliError?.message || 'CLI deployment failed');
    console.warn('[Vercel] CLI deployment failed, trying REST fallback:', cliMsg);

    const zip = await JSZip.loadAsync(buffer);
    const entries = normalizeZipEntries(zip);
    const files = [];
    for (const item of entries) {
      const data = await zip.files[item.source].async('nodebuffer');
      if (data.length > 4 * 1024 * 1024) throw new Error(`File ${item.file} terlalu besar untuk deployment langsung.`);
      files.push({ file: item.file, data: data.toString('base64'), encoding: 'base64' });
      if (files.length > 500) throw new Error('ZIP memiliki terlalu banyak file (maksimal 500).');
    }
    if (!files.length) throw new Error('ZIP website kosong.');

    const safeName = String(projectName).replace(/[^a-z0-9-]/gi, '-').toLowerCase().replace(/^-+|-+$/g, '').replace(/-{2,}/g, '-').slice(0, 52) || 'telegram-deploy';
    const teamId = team?.id || '';
    const apiQuery = buildApiQuery(teamId);
    const project = await ensureVercelProject(token, headers, teamId, safeName);
    const r = await axios.post(`https://api.vercel.com/v13/deployments${apiQuery}&forceNew=1`, {
      name: safeName,
      project: project.id,
      target: 'production',
      files,
      projectSettings: { framework: null }
    }, { headers, timeout: 180000, maxContentLength: 25 * 1024 * 1024, maxBodyLength: 25 * 1024 * 1024 });
    let deployment = await waitForDeployment(token, headers, teamId, r.data?.id || r.data?.uid, 180000);
    const deploymentId = deployment.id || deployment.uid;
    await promoteProduction(token, headers, teamId, project.id, deploymentId).catch(() => {});
    const resolved = await getProductionUrl({ token, headers, teamId, projectId: project.id, projectName: safeName, deployment });
    const finalUrl = resolved.url || `https://${safeName}.vercel.app`;
    const probe = await probePublicUrl(finalUrl);
    if (!probe.ok) throw new Error(`REST fallback juga gagal diverifikasi (HTTP ${probe.status || 'network error'}). CLI: ${cliMsg}`);
    return {
      url: finalUrl, name: safeName, id: deploymentId, projectId: project.id,
      teamId: teamId || null, teamName: team?.name || null, target: 'production',
      alias: finalUrl.replace(/^https?:\/\//i, ''), aliasSource: resolved.source,
      protection: 'unchanged', protectionConfigured: false, projectFound: true,
      verified: true, httpStatus: probe.status, aliases: await listDeploymentAliases(token, headers, teamId, deploymentId),
      method: 'rest-fallback'
    };
  }
}

function looksLikeDeploymentHost(host, projectName='') {
  const h=String(host||'').toLowerCase().replace(/^https?:\/\//,'').split('/')[0];
  const base=String(projectName||'').toLowerCase();
  if(!h.endsWith('.vercel.app')) return false;
  const prefix=h.slice(0,-'.vercel.app'.length);
  return prefix !== base && prefix.startsWith(`${base}-`);
}

async function extractWhatsAppChannelInfo(input, sock) {
  const raw=String(input||'').trim();
  const match=raw.match(/(?:https?:\/\/)?(?:www\.)?whatsapp\.com\/channel\/([A-Za-z0-9_-]+)/i);
  const inviteCode=match?.[1] || null;
  const jid=raw.match(/(\d{5,}@newsletter)/)?.[1] || (raw.endsWith('@newsletter') ? raw : null);
  if(!inviteCode&&!jid)throw new Error('Link tidak dikenali. Gunakan https://whatsapp.com/channel/...');
  if(sock&&typeof sock.newsletterMetadata==='function'){
    try{
      const meta=jid?await sock.newsletterMetadata('jid',jid):await sock.newsletterMetadata('invite',inviteCode);
      return {name:meta?.name?.text||meta?.name||meta?.threadMetadata?.name||'-',id:meta?.id||jid||'-',inviteCode,status:meta?'FOUND':'NOT_FOUND',source:'whatsapp'};
    }catch{}
  }
  if(inviteCode){
    try {
      const url=`https://www.whatsapp.com/channel/${encodeURIComponent(inviteCode)}`;
      const r=await axios.get(url,{headers:{'User-Agent':'Mozilla/5.0 (compatible; MELLSTECUU/6.1)'},timeout:30000,maxContentLength:5*1024*1024,validateStatus:()=>true});
      if(r.status>=200&&r.status<300){
        const html=String(r.data||'');
        const title=(html.match(/<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)/i)?.[1]||html.match(/<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:title["']/i)?.[1]||html.match(/<title[^>]*>([^<]+)<\/title>/i)?.[1]||'').trim();
        const id=(html.match(/(?:newsletterJid|newsletter_jid|channelId|channel_id|newsletterId|newsletter_id)["'\s:=]+["']?(\d{5,}@newsletter)/i)?.[1]||html.match(/(\d{10,}@newsletter)/i)?.[1]||jid||null);
        if(title||id)return {name:title||'-',id:id||'-',inviteCode,status:'FOUND',source:'public'};
      }
    } catch {}
  }
  return {name:'-',id:jid||'-',inviteCode,status:'FOUND',source:'public',note:'Metadata publik WhatsApp tidak menampilkan ID internal pada saat ini. Invite code tetap berhasil dibaca tanpa sesi WhatsApp.'};
}

module.exports={extractDomainsFromZip,findDomainInZip,replaceDomainInZip,findPortInZip,replacePortInZip,uploadToProvider,uploadToProviderWithFallback,deployToVercel,extractWhatsAppChannelInfo};
