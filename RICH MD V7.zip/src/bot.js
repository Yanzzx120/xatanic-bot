const TelegramBot = require('node-telegram-bot-api');
const axios = require('axios');
require('dotenv').config();
const { spawn } = require('child_process');
const ffmpegPath = require('ffmpeg-static');
const https = require('https');
const chalk = require('chalk');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const JSZip = require('jszip');
const moment = require('moment-timezone');
const c = require('../ryngtg');
const {
  readState,
  upsertUser,
  upsertChat,
  getUserSenders,
  getGroupMembers,
  addGroupMember,
  markGroupMemberInactive,
  isNewUser,
  claimStartNotification,
  markStartNotificationSent,
  getAmPremiumUsage,
  consumeAmPremiumQuota,
  banUser,
  unbanUser,
  isUserBanned,
  getRewards,
  addReward,
  removeReward,
  getActiveCode,
  getAllActiveCodes,
  setActiveCode,
  getAllUsers,
  getAllChats,
  incrementDailyTests,
  getDailyTests,
  addTesfuncStat,
  getTesfuncStats,
  claimCode,
  removeActiveCode,
  getAllBannedUsers,
  getForceSubWarning,
  recordForceSubWarning,
  markForceSubJoined,
  incrementTests,
  setSenderPassword,
 getSenderPassword,
 removeSenderPassword,
  getGroupSettings,
  getGroupFilters,
  setGroupFilter,
  removeGroupFilter,
  clearGroupFilters,
  setGroupSettings,
  getAssistantState,
  setAssistantState,
  getAssistantProvider,
  setAssistantProvider,
  isAssistantEnabled,
  setAssistantEnabled,
  setRichMessage,
  getRichMessage,
  removeRichMessage,
  getAllRichMessages,
  createFeatureRequest,
  getFeatureRequest,
  answerFeatureRequest,
  getFeatureRequests,
  getChannelMonitor,
  getChannelMonitors,
  getUserChannelMonitors,
  setChannelMonitor,
  removeChannelMonitor,
  getModerationRecord,
  recordModerationWarning,
  markModerationPermanent,
  resetModerationRecord
} = require('./store');
const {
  htmlEscape,
  runtime,
  normalizeNumber,
  parseCommandArgs,
  isLikelyJsFunction,
  compileFunction,
  getReplyJsCode,
  safeEdit,
  safeDelete,
  safeSendMessage,
  sendMenuPhoto: legacySendMenuPhoto,
  tidyMenuKeyboard,
  encBasic,
  encMedium,
  encArab,
  encInvisible,
  encHard,
  encUltra
} = require('./helpers');
const {
  extractDomainsFromZip,
  findDomainInZip,
  replaceDomainInZip,
  findPortInZip,
  replacePortInZip,
  uploadToProvider,
  uploadToProviderWithFallback,
  deployToVercel,
  extractWhatsAppChannelInfo
} = require('./newtools');
const {
  initializeWhatsAppConnections,
  startWhatsAppConnection,
  getSocket,
  getAllSenderStatuses,
  checkFixError,
  downloadTikTok,
  downloadInstagram,
  searchSongs,
  getAudioFromYoutube,
  downloadPinterest,
  playSoundCloud,
  generateTTS,
  normalizeMarketSymbol,
  getMarketQuote,
  getMarketQuotes,
  getMarketHistory
} = require('./services');
const {
  sendLink: amSendLink,
  verifyAndActivate: amVerifyAndActivate,
  bulkGenerate: amBulkGenerate,
  extractLink: amExtractLink
} = require('./am-premium');
const { configReady: mediaFireReady, requiredConfigNames: mediaFireConfigNames, uploadToMediaFire } = require('./mediafire');
const {
  createAppleLivePhotoBundle,
  createAndroidMotionPhoto,
  getVideoDurationSeconds
} = require('./live-photo');


// ======================================= //
// 🤖 AI ASISTEN — MULTI AI (Gemini / OpenRouter + Pixazo)
// NOTE: /richmessage intentionally uses GEMINI ONLY; normal AI features keep their provider selection.
// ======================================= //
const AI_CONFIG = {
  pixazoKey: process.env.PIXAZO_API_KEY || '',
  pixazoImageEditUrl: process.env.PIXAZO_IMAGE_EDIT_URL || 'https://gateway.pixazo.ai/pixelforge-v3/v1/image-to-image/editing',
  pixazoVideoEditUrl: process.env.PIXAZO_VIDEO_EDIT_URL || 'https://gateway.pixazo.ai/hunyuan-video-video-to-video/v1/hunyuan-video-video-to-video-request',
  pixazoPollMs: Math.max(3000, Math.min(15000, Number(process.env.PIXAZO_POLL_MS || 5000))),
  pixazoTimeoutMs: Math.max(60000, Math.min(600000, Number(process.env.PIXAZO_TIMEOUT_MS || 300000))),
  geminiKey: process.env.GEMINI_API_KEY || '',
  geminiModel: process.env.GEMINI_MODEL || 'gemini-3.5-flash-lite',
  geminiImageModel: process.env.GEMINI_IMAGE_MODEL || 'gemini-3.1-flash-image',
  openrouterKey: process.env.OPENROUTER_API_KEY || '',
  openrouterModel: process.env.OPENROUTER_MODEL || 'openrouter/free',
  maxOutputTokens: Math.max(256, Math.min(4096, Number(process.env.AI_MAX_OUTPUT_TOKENS || process.env.GEMINI_MAX_OUTPUT_TOKENS || 768))),
  thinkingLevel: process.env.GEMINI_THINKING_LEVEL || 'minimal',
  userCooldownMs: Math.max(0, Number(process.env.AI_USER_COOLDOWN_MS || process.env.GEMINI_USER_COOLDOWN_MS || 2500)),
  maxConcurrent: Math.max(1, Math.min(6, Number(process.env.AI_MAX_CONCURRENT || process.env.GEMINI_MAX_CONCURRENT || 2))),
  maxQueue: Math.max(1, Math.min(100, Number(process.env.AI_MAX_QUEUE || process.env.GEMINI_MAX_QUEUE || 20)))
};
const AI_MODEL_LABELS = {
  gemini:'Gemini',
  openrouter:'OpenRouter',
  pixazo:'Pixazo Studio',
  auto:'Auto Fallback'
};
const AI_PROVIDERS = ['gemini','openrouter'];
const RICH_AI_TIMEOUT_MS = Math.max(30000, Math.min(90000, Number(process.env.RICH_AI_TIMEOUT_MS || 60000)));
const RICH_AI_PROVIDER = 'gemini';
const RICH_AI_LAYOUT_TYPES = Object.freeze([
  'product','service','package','pricing','promo','offer','stock','order','payment','download',
  'announcement','update','status','warning','info','event','giveaway','membership','contact',
  'portfolio','review','comparison','faq','steps','tutorial','schedule','market','changelog','news'
]);
const RICH_AI_EMOJI_KEYS = Object.freeze([
  'fire','star','gift','money','info','check','warning','link','phone','user','id','stats','chart',
  'tools','box','folder','download','globe','group','crown','shield','flash','chat','share','image',
  'video','movie','web','clock','pin','bot','ai','party','heart','speaker','market','refresh','key',
  'lock','hourglass','clipboard','ruler','eyes','next','tiktok','wink'
]);
const RICH_AI_SCHEMA = Object.freeze({
  type: 'object',
  additionalProperties: false,
  properties: {
    layout: { type: 'string', enum: RICH_AI_LAYOUT_TYPES },
    title: { type: 'string' },
    description: { type: 'string' },
    summary: { type: 'string' },
    quote: { type: 'string' },
    emoji: {
      type: 'object', additionalProperties: false,
      properties: {
        title: { type: 'string', enum: RICH_AI_EMOJI_KEYS },
        description: { type: 'string', enum: RICH_AI_EMOJI_KEYS },
        table: { type: 'string', enum: RICH_AI_EMOJI_KEYS },
        quote: { type: 'string', enum: RICH_AI_EMOJI_KEYS },
        footer: { type: 'string', enum: RICH_AI_EMOJI_KEYS }
      },
      required: ['title','description','table','quote','footer']
    },
    table: {
      type: 'object', additionalProperties: false,
      properties: {
        headers: { type: 'array', items: { type: 'string' }, minItems: 2, maxItems: 2 },
        rows: {
          type: 'array', maxItems: 8,
          items: {
            type: 'object', additionalProperties: false,
            properties: {
              label: { type: 'string' }, value: { type: 'string' },
              emoji: { type: 'string', enum: RICH_AI_EMOJI_KEYS }
            },
            required: ['label','value','emoji']
          }
        }
      },
      required: ['headers','rows']
    },
    details: {
      type: 'array', maxItems: 5,
      items: { type: 'object', additionalProperties: false, properties: { title:{type:'string'}, text:{type:'string'} }, required:['title','text'] }
    },
    buttons: {
      type: 'array', maxItems: 4,
      items: { type:'object', additionalProperties:false, properties:{text:{type:'string'},url:{type:'string'}}, required:['text','url'] }
    },
    footer: { type: 'string' }
  },
  required: ['layout','title','description','summary','quote','emoji','table','details','buttons','footer']
});
const aiLastRequest = new Map();
const aiQueue = [];
let aiActive = 0;

function sleepMs(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
function aiProviderLabel(provider) { return AI_MODEL_LABELS[provider] || 'Gemini'; }
function normalizeAiProvider(value) { const v=String(value); return (AI_PROVIDERS.includes(v)||v==='auto') ? v : 'gemini'; }
function providerKey(provider) {
  return ({
    gemini:AI_CONFIG.geminiKey,
    openrouter:AI_CONFIG.openrouterKey
  })[provider] || '';
}
function providerModel(provider) {
  return ({
    gemini:AI_CONFIG.geminiModel,
    openrouter:AI_CONFIG.openrouterModel
  })[provider];
}
function setPendingAiAction(userId, chatId, mode) {
  const key = String(userId);
  pendingAiAction.set(key, { chatId, mode, createdAt: Date.now() });
  setTimeout(() => { const cur=pendingAiAction.get(key); if(cur && Date.now()-cur.createdAt>=10*60*1000) pendingAiAction.delete(key); }, 10*60*1000);
}
function getAiPersonality(userId) { return aiPersonality.get(String(userId)) || 'friendly'; }
function aiPersonalityLabel(userId) { const p=getAiPersonality(userId); return ({friendly:'Friendly',professional:'Professional',funny:'Santai/Funny',expert:'Expert'})[p] || 'Friendly'; }
function buildAiTaskPrompt(mode, prompt, userId) {
  const personality=getAiPersonality(userId);
  const style={friendly:'Gunakan gaya ramah, natural, jelas, dan tidak kaku.',professional:'Gunakan gaya profesional, terstruktur, ringkas, dan sopan.',funny:'Gunakan gaya santai dan ringan, boleh menyisipkan humor secukupnya tanpa mengganggu isi.',expert:'Gunakan gaya ahli: akurat, terstruktur, dan jelaskan alasan teknis bila diperlukan.'}[personality];
  const tasks={chat:'Jawab pertanyaan pengguna secara langsung dan praktis.',summarize:'Ringkas teks menjadi poin utama tanpa mengarang.',rewrite:'Tulis ulang agar jelas, natural, dan enak dibaca dengan makna tetap.',translate:'Terjemahkan teks. Jika bahasa tujuan disebutkan, ikuti; jika tidak, gunakan konteks bahasa yang paling masuk akal.',code:'Bantu kebutuhan coding. Berikan kode siap pakai dan penjelasan singkat.',study:'Jelaskan materi seperti tutor: konsep inti, contoh, lalu ringkasan.',image:'Analisis gambar yang diberikan dengan hati-hati dan tandai hal yang tidak pasti.'};
  return `${tasks[mode]||tasks.chat}\n${style}\n\nPermintaan pengguna:\n${String(prompt||'').slice(0,5000)}`;
}
function aiFeatureKeyboard() { return {inline_keyboard:[
  [{text:'💬 Chat AI',callback_data:'ai_feature_chat'},{text:'📝 Ringkas',callback_data:'ai_feature_summarize'}],
  [{text:'✍️ Rewrite',callback_data:'ai_feature_rewrite'},{text:'🌐 Translate',callback_data:'ai_feature_translate'}],
  [{text:'💻 Coding',callback_data:'ai_feature_code'},{text:'📚 Study',callback_data:'ai_feature_study'}],
  [{text:'🖼️ Analisis Gambar',callback_data:'ai_feature_image'}],
  [{text:'🎨 Pixazo Foto',callback_data:'ai_feature_pixazo_photo'},{text:'🎬 Pixazo Video',callback_data:'ai_feature_pixazo_video'}],
  [{text:'🖼️➡️🎬 Foto ke Video',callback_data:'ai_feature_pixazo_i2v'}],
  [{text:'🎭 Personality',callback_data:'ai_personality'}],[{text:'🤖 Pilih AI',callback_data:'ai_providers'}],
  [{text:'↩️ Menu AI',callback_data:'ai_menu'}]
]}; }
function aiPersonalityKeyboard() { return {inline_keyboard:[
  [{text:'😊 Friendly',callback_data:'ai_personality_friendly'},{text:'💼 Professional',callback_data:'ai_personality_professional'}],
  [{text:'😄 Santai',callback_data:'ai_personality_funny'},{text:'🧠 Expert',callback_data:'ai_personality_expert'}],
  [{text:'🤖 Menu AI',callback_data:'ai_menu'}]
]}; }
function aiProviderKeyboard(chatId) {
  const current=normalizeAiProvider(getAssistantProvider(chatId));
  return {inline_keyboard:[
    [{text:`${current==='gemini'?'✅ ':'🔵 '}Gemini`,callback_data:'ai_provider_gemini'},
     {text:`${current==='openrouter'?'✅ ':'🌐 '}OpenRouter`,callback_data:'ai_provider_openrouter'}],
    [{text:'🎨 Pixazo Studio',callback_data:'ai_provider_pixazo'}],
    [{text:'🔄 Auto Fallback',callback_data:'ai_provider_auto'}],
    [{text:'↩️ Menu AI',callback_data:'ai_menu'}]
  ]};
}
function pixazoReady() { return Boolean(AI_CONFIG.pixazoKey); }
function pixazoHeaders() { return { 'Content-Type':'application/json', 'Cache-Control':'no-cache', 'Ocp-Apim-Subscription-Key': AI_CONFIG.pixazoKey }; }
function extractPixazoMediaUrl(data) {
  const seen=new Set();
  function walk(v, depth=0) {
    if (!v || depth>6) return '';
    if (typeof v === 'string' && /^https?:\/\//i.test(v) && /\.(?:png|jpe?g|webp|gif|mp4|webm)(?:[?#].*)?$/i.test(v)) return v;
    if (typeof v !== 'object' || seen.has(v)) return '';
    seen.add(v);
    for (const key of ['media_url','video_url','image_url','url','download_url','output_url']) {
      const x=v[key];
      if (typeof x==='string' && /^https?:\/\//i.test(x)) return x;
    }
    for (const key of ['output','result','data','media','images','videos']) {
      const x=v[key];
      const found=walk(x,depth+1); if(found)return found;
    }
    if (Array.isArray(v)) for(const x of v){const found=walk(x,depth+1);if(found)return found;}
    return '';
  }
  return walk(data);
}
function pixazoRequestId(data) { return data?.request_id || data?.requestId || data?.id || ''; }
async function pollPixazoJob(requestId, pollingUrl) {
  const deadline=Date.now()+AI_CONFIG.pixazoTimeoutMs;
  let url=pollingUrl || `https://gateway.pixazo.ai/v2/requests/status/${encodeURIComponent(requestId)}`;
  while(Date.now()<deadline){
    const res=await axios.get(url,{timeout:30000,headers:{'Ocp-Apim-Subscription-Key':AI_CONFIG.pixazoKey}});
    const data=res.data||{};
    const status=String(data.status||data.state||'').toUpperCase();
    if(['COMPLETED','SUCCEEDED','SUCCESS','DONE'].includes(status)){
      const media=extractPixazoMediaUrl(data);
      if(!media) throw new Error('Pixazo selesai tetapi URL hasil tidak ditemukan.');
      return media;
    }
    if(['FAILED','ERROR','CANCELLED','CANCELED'].includes(status)){
      throw new Error(data.error?.message || data.error || 'Proses Pixazo gagal.');
    }
    await sleepMs(AI_CONFIG.pixazoPollMs);
  }
  throw new Error('Pixazo timeout. Coba lagi dengan file lebih kecil atau tunggu beberapa saat.');
}
async function pixazoImageEditFromUrl(imageUrl,prompt){
  if(!pixazoReady()) throw new Error('PIXAZO_API_KEY belum diisi di .env.');
  if(!prompt || prompt.trim().length<2) throw new Error('Prompt edit foto wajib diisi.');
  const res=await axios.post(AI_CONFIG.pixazoImageEditUrl,{prompt:prompt.trim().slice(0,2000),image_url:imageUrl},{timeout:60000,headers:pixazoHeaders()});
  const direct=extractPixazoMediaUrl(res.data);
  if(direct && !pixazoRequestId(res.data)) return direct;
  const id=pixazoRequestId(res.data);
  if(!id) throw new Error(res.data?.error?.message || 'Pixazo tidak mengembalikan request_id.');
  return pollPixazoJob(id,res.data?.polling_url);
}
async function pixazoVideoEditFromUrl(videoUrl,prompt){
  if(!pixazoReady()) throw new Error('PIXAZO_API_KEY belum diisi di .env.');
  if(!prompt || prompt.trim().length<2) throw new Error('Prompt edit video wajib diisi.');
  const res=await axios.post(AI_CONFIG.pixazoVideoEditUrl,{prompt:prompt.trim().slice(0,2000),video_url:videoUrl,aspect_ratio:'16:9',resolution:'720p',strength:0.7},{timeout:60000,headers:pixazoHeaders()});
  const direct=extractPixazoMediaUrl(res.data);
  if(direct && !pixazoRequestId(res.data)) return direct;
  const id=pixazoRequestId(res.data);
  if(!id) throw new Error(res.data?.error?.message || 'Pixazo tidak mengembalikan request_id.');
  return pollPixazoJob(id,res.data?.polling_url);
}
async function pixazoImageToVideoFromUrl(imageUrl,prompt){
  if(!pixazoReady()) throw new Error('PIXAZO_API_KEY belum diisi di .env.');
  if(!prompt || prompt.trim().length<2) throw new Error('Prompt animasi video wajib diisi.');
  const url='https://gateway.pixazo.ai/ltx-video/v1/image-to-video';
  const res=await axios.post(url,{prompt:prompt.trim().slice(0,2000),image_url:imageUrl},{timeout:60000,headers:pixazoHeaders()});
  const direct=extractPixazoMediaUrl(res.data);
  if(direct && !pixazoRequestId(res.data)) return direct;
  const id=pixazoRequestId(res.data);
  if(!id) throw new Error(res.data?.error?.message || 'Pixazo LTX tidak mengembalikan request_id.');
  return pollPixazoJob(id,res.data?.polling_url);
}
async function analyzeImageWithGemini(imageBuffer,mimeType,prompt,userId){
  if(!AI_CONFIG.geminiKey) throw new Error('GEMINI_API_KEY belum diisi.');
  const res=await axios.post('https://generativelanguage.googleapis.com/v1/interactions',{model:AI_CONFIG.geminiModel,input:[{type:'text',text:buildAiTaskPrompt('image',prompt||'Jelaskan isi gambar ini.',userId)},{type:'image',mime_type:mimeType||'image/jpeg',data:imageBuffer.toString('base64')}],generation_config:{max_output_tokens:AI_CONFIG.maxOutputTokens,thinking_level:AI_CONFIG.thinkingLevel,thinking_summaries:'none'}},{timeout:120000,headers:{'x-goog-api-key':AI_CONFIG.geminiKey,'Content-Type':'application/json'}});
  const answer=extractInteractionText(res.data); if(!answer) throw new Error(res.data?.error?.message||'Gemini tidak mengembalikan jawaban.'); return answer;
}
function trimAiHistory(chatId){const key=String(chatId);const h=aiHistory.get(key)||[];if(h.length>8)aiHistory.set(key,h.slice(-8));return aiHistory.get(key)||[];}
function extractInteractionText(data){if(typeof data?.output_text==='string'&&data.output_text.trim())return data.output_text.trim();const parts=[];for(const step of(data?.steps||[]))for(const block of(step?.content||[])){if(block?.type==='text'&&block?.text)parts.push(String(block.text));if(block?.type==='model_output'&&Array.isArray(block?.content))for(const c of block.content)if(c?.type==='text'&&c?.text)parts.push(String(c.text));}return parts.join('\n').trim();}
function enqueueAi(task){if(aiQueue.length>=AI_CONFIG.maxQueue)return Promise.reject(new Error('Antrean AI sedang penuh. Coba lagi beberapa detik lagi.'));return new Promise((resolve,reject)=>{aiQueue.push({task,resolve,reject});drainAiQueue();});}
function drainAiQueue(){while(aiActive<AI_CONFIG.maxConcurrent&&aiQueue.length){const item=aiQueue.shift();aiActive++;Promise.resolve().then(item.task).then(item.resolve,item.reject).finally(()=>{aiActive--;drainAiQueue();});}}
function parseRetryAfter(e, fallback=3000){const h=e?.response?.headers?.['retry-after'];const n=Number(h);if(Number.isFinite(n)&&n>0)return Math.min(n*1000,30000);return fallback;}
function isRetryableStatus(status){return [408,409,429,500,502,503,504].includes(Number(status));}
function providerError(e, provider){const status=e?.response?.status;const msg=e?.response?.data?.error?.message||e?.response?.data?.error?.error?.message||e?.message||'Request gagal';return new Error(`${aiProviderLabel(provider)} (${status||'ERR'}): ${String(msg).slice(0,500)}`);}
function extractProviderText(data){return String(data?.choices?.[0]?.message?.content||data?.choices?.[0]?.text||'').trim();}
async function requestProvider(provider,input){
  const key=providerKey(provider); if(!key) throw new Error(`${aiProviderLabel(provider)} API key belum diisi.`);
  const model=providerModel(provider);
  for(let attempt=0;attempt<3;attempt++){
    try{
      if(provider==='gemini'){
        const res=await axios.post('https://generativelanguage.googleapis.com/v1/interactions',{model,input,system_instruction:'Kamu adalah AI Asisten pribadi yang ramah, akurat, ringkas, membantu, dan menjawab dalam Bahasa Indonesia kecuali pengguna meminta bahasa lain. Jangan mengaku sebagai manusia.',generation_config:{max_output_tokens:AI_CONFIG.maxOutputTokens,thinking_level:AI_CONFIG.thinkingLevel,thinking_summaries:'none'}},{timeout:120000,headers:{'x-goog-api-key':key,'Content-Type':'application/json'}});const out=extractInteractionText(res.data);if(!out)throw new Error('Gemini tidak mengembalikan jawaban.');return out;
      }
      if(provider==='openrouter'){
        const res=await axios.post('https://openrouter.ai/api/v1/chat/completions',{
          model,
          messages:[
            {role:'system',content:'Kamu adalah AI Asisten yang akurat, ramah, natural, membantu, dan menjawab Bahasa Indonesia kecuali diminta lain.'},
            {role:'user',content:input}
          ],
          max_tokens:AI_CONFIG.maxOutputTokens,
          stream:false
        },{timeout:120000,headers:{
          Authorization:`Bearer ${key}`,
          'Content-Type':'application/json',
          'HTTP-Referer':process.env.OPENROUTER_SITE_URL || 'https://t.me/',
          'X-Title':process.env.OPENROUTER_APP_NAME || 'MELLSTECUU AI Assistant'
        }});
        const out=extractProviderText(res.data);if(!out)throw new Error('OpenRouter tidak mengembalikan jawaban.');return out;
      }
    }catch(e){if(isRetryableStatus(e?.response?.status)&&attempt<2){await sleepMs(parseRetryAfter(e,2000*(attempt+1)));continue;}throw providerError(e,provider);}
  }
  throw new Error(`${aiProviderLabel(provider)} gagal.`);
}
async function callAI(chatId,prompt,preferred){
  let provider=normalizeAiProvider(preferred||getAssistantState(chatId));
  const key=String(chatId);const now=Date.now();const last=aiLastRequest.get(key)||0;const remaining=AI_CONFIG.userCooldownMs-(now-last);if(remaining>0)await sleepMs(remaining);aiLastRequest.set(key,Date.now());
  const history=trimAiHistory(key);const compact=history.slice(-4).map(x=>`${x.role==='assistant'?'Asisten':'Pengguna'}: ${String(x.content).slice(0,1200)}`).join('\n');const input=`${String(prompt).slice(0,5000)}${compact?'\n\nKonteks percakapan sebelumnya:\n'+compact:''}`;
  const candidates=provider==='auto'?['gemini','openrouter']:[provider];
  return enqueueAi(async()=>{let lastErr=null;for(const p of candidates){if(!providerKey(p))continue;try{const answer=await requestProvider(p,input);aiHistory.set(key,[...history,{role:'user',content:prompt},{role:'assistant',content:answer}].slice(-8));if(provider==='auto')setAssistantState(chatId,p);return {answer,provider:p};}catch(e){lastErr=e;if(provider!=='auto')throw e;}}
    if(lastErr)throw lastErr;throw new Error('Belum ada API key AI yang diisi. Isi minimal satu API key di .env.');});
}
async function callGeminiAI(chatId,prompt){const r=await callAI(chatId,prompt,'gemini');return r.answer;}
async function requestRichProvider(provider, input) {
  const key = providerKey(provider);
  if (!key) throw new Error(`${aiProviderLabel(provider)} API key belum diisi.`);
  const model = providerModel(provider);
  const system = 'Kamu adalah generator Rich Message Telegram. Keluarkan HANYA JSON yang sesuai schema. Jangan memberi penjelasan, markdown, atau kalimat pembuka. Pertahankan fakta dari teks pengguna.';
  const timeout = RICH_AI_TIMEOUT_MS;
  try {
    if (provider === 'gemini') {
      const res = await axios.post('https://generativelanguage.googleapis.com/v1/interactions', {
        model,
        input: `${system}\n\n${input}`,
        response_format: { type: 'text', mime_type: 'application/json', schema: RICH_AI_SCHEMA },
        generation_config: { max_output_tokens: Math.min(AI_CONFIG.maxOutputTokens, 1200), thinking_level: 'minimal', thinking_summaries: 'none' }
      }, { timeout, headers: { 'x-goog-api-key': key, 'Content-Type': 'application/json' } });
      const out = extractInteractionText(res.data);
      if (!out) throw new Error('Gemini tidak mengembalikan JSON.');
      return out;
    }
    if (provider === 'openrouter') {
      const res = await axios.post('https://openrouter.ai/api/v1/chat/completions', {
        model,
        messages: [{ role: 'system', content: system }, { role: 'user', content: input }],
        max_tokens: Math.min(AI_CONFIG.maxOutputTokens, 1200),
        stream: false,
        response_format: { type: 'json_schema', json_schema: { name: 'rich_message', strict: true, schema: RICH_AI_SCHEMA } }
      }, { timeout, headers: {
        Authorization: `Bearer ${key}`,
        'Content-Type': 'application/json',
        'HTTP-Referer': process.env.OPENROUTER_SITE_URL || 'https://t.me/',
        'X-Title': process.env.OPENROUTER_APP_NAME || 'MELLSTECUU AI Assistant'
      } });
      const out = extractProviderText(res.data);
      if (!out) throw new Error('OpenRouter tidak mengembalikan JSON.');
      return out;
    }
    throw new Error(`Provider Rich Message tidak dikenal: ${provider}`);
  } catch (e) {
    throw providerError(e, provider);
  }
}

async function callRichMessageAI(chatId, prompt) {
  const key = String(chatId);
  const now = Date.now();
  const last = aiLastRequest.get(key) || 0;
  const remaining = AI_CONFIG.userCooldownMs - (now - last);
  if (remaining > 0) await sleepMs(remaining);
  aiLastRequest.set(key, Date.now());

  // Rich Message intentionally uses Gemini only.
  // Normal /ai and assistant features use Gemini/OpenRouter.
  const input = String(prompt || '').slice(0, 9000);
  if (!AI_CONFIG.geminiKey) {
    throw new Error('GEMINI_API_KEY belum diisi di .env. Rich Message hanya menggunakan Gemini.');
  }

  return enqueueAi(async () => {
    try {
      const answer = await requestRichProvider(RICH_AI_PROVIDER, input);
      const parsed = parseRichAiJson(answer);
      if (!parsed || typeof parsed !== 'object') throw new Error('Gemini menghasilkan JSON kosong/tidak valid.');
      if (!String(parsed.title || '').trim()) throw new Error('Gemini menghasilkan JSON tanpa title.');
      if (!parsed.table || !Array.isArray(parsed.table.rows)) throw new Error('Gemini menghasilkan struktur tabel yang tidak valid.');
      aiHistory.set(key, [{ role: 'user', content: prompt }, { role: 'assistant', content: JSON.stringify(parsed) }].slice(-8));
      return { answer: JSON.stringify(parsed), data: parsed, provider: RICH_AI_PROVIDER };
    } catch (e) {
      console.warn('[RICH AI] Gemini gagal:', e?.message || e);
      throw e;
    }
  });
}

function extractGeminiImage(data) {
  if (data?.output_image?.data) return Buffer.from(data.output_image.data, 'base64');
  for (const step of (data?.steps || [])) for (const block of (step?.content || [])) {
    if (block?.type === 'image' && block?.data) return Buffer.from(block.data, 'base64');
  }
  return null;
}

async function editImageWithGemini(imageBuffer, mimeType, prompt) {
  if (!AI_CONFIG.geminiKey) throw new Error('GEMINI_API_KEY belum diisi di file .env.');
  const res = await axios.post('https://generativelanguage.googleapis.com/v1/interactions', {
    model: AI_CONFIG.geminiImageModel,
    input:[{type:'text',text:prompt},{type:'image',mime_type:mimeType||'image/jpeg',data:imageBuffer.toString('base64')}],
    response_format:{type:'image',image_size:process.env.GEMINI_IMAGE_SIZE||'1K'}
  }, {timeout:180000,headers:{'x-goog-api-key':AI_CONFIG.geminiKey,'Content-Type':'application/json'}});
  const out=extractGeminiImage(res.data);
  if(!out) throw new Error(res.data?.error?.message || 'Gemini tidak mengembalikan gambar.');
  return out;
}

function parseVideoPrompt(prompt) {
  const p = String(prompt || '').toLowerCase();
  const out = {};
  const speed = p.match(/(?:speed|kecepatan|percepat|dipercepat)\s*(?:x|jadi)?\s*(\d+(?:\.\d+)?)/i);
  if (speed) out.speed = Math.max(0.25, Math.min(4, Number(speed[1])));
  if (/slow.?motion|slowmo|perlambat|diperlambat/i.test(p)) out.speed = out.speed || 0.5;
  if (/mute|hapus suara|tanpa suara/i.test(p)) out.mute = true;
  const trim = p.match(/(?:potong|trim)\s*(?:dari)?\s*(\d+(?:\.\d+)?)\s*(?:s|detik)?\s*(?:sampai|hingga|-|to)\s*(\d+(?:\.\d+)?)\s*(?:s|detik)?/i);
  if (trim) { out.start = Number(trim[1]); out.end = Number(trim[2]); }
  const res = p.match(/(?:1080p|full\s*hd|hd)/i);
  if (res) out.size = /1080p|full\s*hd/i.test(res[0]) ? '1920:1080' : '1280:720';
  return out;
}

function runFfmpeg(args) {
  return new Promise((resolve, reject) => {
    const proc = spawn(ffmpegPath, ['-y', '-hide_banner', '-loglevel', 'error', ...args]);
    let stderr = '';
    proc.stderr.on('data', d => { stderr += d.toString(); });
    proc.on('error', reject);
    proc.on('close', code => code === 0 ? resolve() : reject(new Error(stderr.trim() || `FFmpeg exit ${code}`)));
  });
}

async function editVideoFromPrompt(inputBuffer, prompt, extension='mp4') {
  if (!ffmpegPath) throw new Error('FFmpeg tidak tersedia.');
  const opts = parseVideoPrompt(prompt);
  if (!Object.keys(opts).length) throw new Error('Prompt video belum dikenali. Gunakan contoh: "percepat 1.5x, mute, 1080p, potong 0 sampai 10 detik".');
  const tmp = path.join(require('os').tmpdir(), `ai-video-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`);
  const input = `${tmp}.${extension.replace(/[^a-z0-9]/gi,'') || 'mp4'}`;
  const output = `${tmp}-out.mp4`;
  fs.writeFileSync(input, inputBuffer);
  const args = ['-i', input];
  if (opts.start != null) args.unshift('-ss', String(opts.start));
  if (opts.end != null && opts.start != null) args.push('-t', String(Math.max(0.1, opts.end - opts.start)));
  if (opts.speed) {
    const s = opts.speed;
    const pts = (1 / s).toFixed(6);
    args.push('-filter_complex', `[0:v]setpts=${pts}*PTS[v]`, '-map', '[v]');
    if (!opts.mute) {
      const atempo = [];
      let x = s;
      while (x < 0.5) { atempo.push('0.5'); x *= 2; }
      while (x > 2) { atempo.push('2.0'); x /= 2; }
      atempo.push(x.toFixed(6));
      args.push('-map', '0:a?', '-af', `atempo=${atempo.join(',')}`);
    }
  } else if (!opts.mute) {
    args.push('-map', '0:v:0', '-map', '0:a?');
  }
  if (opts.mute) args.push('-an');
  if (opts.size) args.push('-vf', `scale=${opts.size}:force_original_aspect_ratio=decrease,pad=${opts.size}:(ow-iw)/2:(oh-ih)/2`);
  args.push('-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-c:a', 'aac', '-movflags', '+faststart', output);
  try {
    await runFfmpeg(args);
    const out = fs.readFileSync(output);
    return out;
  } finally {
    try { fs.unlinkSync(input); } catch {}
    try { fs.unlinkSync(output); } catch {}
  }
}

// ======================================= //
// 💎 PREMIUM EMOJI
// ======================================= //
const E = {
  lock: `<tg-emoji emoji-id="5197288647275071607">🔒</tg-emoji>`,
  wave: `<tg-emoji emoji-id="5053073150238000952">👋</tg-emoji>`,
  check: `<tg-emoji emoji-id="5857044938755149915">✅</tg-emoji>`,
  hourglass: `<tg-emoji emoji-id="5854722989240619332">⏳</tg-emoji>`,
  cross: `<tg-emoji emoji-id="5787672755839176187">❌</tg-emoji>`,
  warning: `<tg-emoji emoji-id="5787656288934564517">⚠️</tg-emoji>`,
  empty: `<tg-emoji emoji-id="5253742260054409879">📭</tg-emoji>`,
  speaker: `<tg-emoji emoji-id="6280632094003564609">📢</tg-emoji>`,
  music: `<tg-emoji emoji-id="5463107823946717464">🎵</tg-emoji>`,
  phone: `<tg-emoji emoji-id="5805287967203266378">📱</tg-emoji>`,
  stats: `<tg-emoji emoji-id="5231200819986047254">📊</tg-emoji>`,
  info: `<tg-emoji emoji-id="5440660757194744323">❗</tg-emoji>`,
  user: `<tg-emoji emoji-id="5082413149873767213">🆔</tg-emoji>`,
  Name: `<tg-emoji emoji-id="5902335789798265487">👤</tg-emoji>`,
  id: `<tg-emoji emoji-id="6068610874522735901">🆔</tg-emoji>`,
  sender: `<tg-emoji emoji-id="5015158828216353769">📱</tg-emoji>`,
  ai: `<tg-emoji emoji-id="5931415565955503486">🤖</tg-emoji>`,
  sticker: `<tg-emoji emoji-id="5764899533565729469">🎨</tg-emoji>`,
  ig: `<tg-emoji emoji-id="4918159650420950146">📸</tg-emoji>`,
  shield: `<tg-emoji emoji-id="6258259403200270844">🛡️</tg-emoji>`,
  group: `<tg-emoji emoji-id="5942877472163892475">👥</tg-emoji>`,
  crown: `<tg-emoji emoji-id="5217822164362739968">👑</tg-emoji>`,
  flash: `<tg-emoji emoji-id="5456140674028019486">⚡</tg-emoji>`,
  clipboard: `<tg-emoji emoji-id="5197269100878907942">📋</tg-emoji>`,
  wrench: `<tg-emoji emoji-id="4904936030232117798">🔧</tg-emoji>`,
  tools: `<tg-emoji emoji-id="4904936030232117798">🧰</tg-emoji>`,
  download: `<tg-emoji emoji-id="5443127283898405358">📥</tg-emoji>`,
  green: `<tg-emoji emoji-id="5416081784641168838">🟢</tg-emoji>`,
  red: `<tg-emoji emoji-id="5411225014148014586">🔴</tg-emoji>`,
  pin: `<tg-emoji emoji-id="5397782960512444700">📌</tg-emoji>`,
  link: `<tg-emoji emoji-id="5271604874419647061">🔗</tg-emoji>`,
  mute: `<tg-emoji emoji-id="6084711203676883391">🔇</tg-emoji>`,
  kick: `<tg-emoji emoji-id="5395695537687123235">👢</tg-emoji>`,
  add: `<tg-emoji emoji-id="5397916757333654639">➕</tg-emoji>`,
  bot: `<tg-emoji emoji-id="5931415565955503486">🤖</tg-emoji>`,
  market: `<tg-emoji emoji-id="5370766297341603902">📈</tg-emoji>`,
  chart: `<tg-emoji emoji-id="5440759124062814858">📊</tg-emoji>`,
  search: `<tg-emoji emoji-id="5397782960512444700">🔎</tg-emoji>`,
  refresh: `<tg-emoji emoji-id="5409049347264539786">🔄</tg-emoji>`,

  lock2: `<tg-emoji emoji-id="5472308992514464048">🔐</tg-emoji>`,
  box: `<tg-emoji emoji-id="5194986875516893740">📦</tg-emoji>`,
  ruler: `<tg-emoji emoji-id="5996812868308177363">📏</tg-emoji>`,
  key: `<tg-emoji emoji-id="5352761996624292287">🔑</tg-emoji>`,
  watch: `<tg-emoji emoji-id="5235564897600807979">⏱</tg-emoji>`,
  globe: `<tg-emoji emoji-id="6280543321324523370">🌍</tg-emoji>`,
  eyes: `<tg-emoji emoji-id="5210956306952758910">👀</tg-emoji>`,
  heart: `<tg-emoji emoji-id="5330482884568441762">❤️</tg-emoji>`,
  chat: `<tg-emoji emoji-id="5443038326535759644">💬</tg-emoji>`,
  share: `<tg-emoji emoji-id="6005843436479975944">🔁</tg-emoji>`,
  next: `<tg-emoji emoji-id="5190493570926127964">⏭️</tg-emoji>`,
  party: `<tg-emoji emoji-id="5863985154933919695">🎉</tg-emoji>`,
  star: `<tg-emoji emoji-id="6039626107337053562">⭐</tg-emoji>`,
  movie: `<tg-emoji emoji-id="5456523926844757382">🎬</tg-emoji>`,
  tv: `<tg-emoji emoji-id="5839354140261619193">📺</tg-emoji>`,
  web: `<tg-emoji emoji-id="5447410659077661506">🌐</tg-emoji>`,
  folder: `<tg-emoji emoji-id="5778505852520501441">📁</tg-emoji>`,
  fire: `<tg-emoji emoji-id="5424972470023104089">🔥</tg-emoji>`,
  tiktok: `<tg-emoji emoji-id="5474131686440584294">🥺</tg-emoji>`,
  gift: `<tg-emoji emoji-id="4958699241137505132">🎁</tg-emoji>`,
  gpt: `<tg-emoji emoji-id="6149863405130879277">👈</tg-emoji>`,
  tgl: `<tg-emoji emoji-id="5249045975309245331">🎰</tg-emoji>`,
  jam: `<tg-emoji emoji-id="5787488119490088755">✏️</tg-emoji>`,
  respon: `<tg-emoji emoji-id="4985545282113503960">🏆</tg-emoji>`,
  info2: `<tg-emoji emoji-id="5440660757194744323">⚡</tg-emoji>`,
  awan: `<tg-emoji emoji-id="4956461073550017373">🥰</tg-emoji>`,
  search: `<tg-emoji emoji-id="4958587679361991667">😭</tg-emoji>`,
  qr: `<tg-emoji emoji-id="6039706801182610086">🤣</tg-emoji>`,
  masjid: `<tg-emoji emoji-id="6170130728735479315">🤧</tg-emoji>`,
  lonceng: `<tg-emoji emoji-id="5336970608762707085">🥶</tg-emoji>`,
  image: `<tg-emoji emoji-id="5267139375447159076">🔥</tg-emoji>`,
  video: `<tg-emoji emoji-id="5323608798001131201">🗑️</tg-emoji>`,
  wink: `<tg-emoji emoji-id="5208748315805499400">💸</tg-emoji>`,
  L: `<tg-emoji emoji-id="5411101963335003783">🗿</tg-emoji>`,
  A: `<tg-emoji emoji-id="5413619638804175279">🤧</tg-emoji>`,
  V: `<tg-emoji emoji-id="5411434084566068319">🔞</tg-emoji>`,
  EN: `<tg-emoji emoji-id="5413505762041288495">🙃</tg-emoji>`,
  N: `<tg-emoji emoji-id="5411298591232780818">🥲</tg-emoji>`,
  D: `<tg-emoji emoji-id="5411558582783075401">😂</tg-emoji>`,
  R: `<tg-emoji emoji-id="5411551955648539537">🚬</tg-emoji>`
};


const bot = new TelegramBot(c.BOT, {
  polling: { allowed_updates: ['message','edited_message','callback_query','chat_member','my_chat_member','channel_post','edited_channel_post'] },
  request: { timeout: 60000, agent: new https.Agent({ keepAlive: true }) }
});


// Telegram Bot API 10.3 exposes sendLivePhoto. node-telegram-bot-api 0.64 may
// not have a wrapper for the newer method, so use the official Bot API endpoint
// directly for Apple Live Photo delivery. This is Telegram transport, not a
// third-party Photo Live API.
async function sendTelegramLivePhoto(chatId, photoBuffer, videoBuffer, options = {}) {
  const FormData = require('form-data');
  const form = new FormData();
  form.append('chat_id', String(chatId));
  form.append('photo', photoBuffer, { filename: 'live-photo.jpg', contentType: 'image/jpeg' });
  form.append('live_photo', videoBuffer, { filename: 'live-photo.mov', contentType: 'video/quicktime' });
  if (options.caption) form.append('caption', String(options.caption));
  if (options.parse_mode) form.append('parse_mode', String(options.parse_mode));
  if (options.reply_markup) form.append('reply_markup', JSON.stringify(options.reply_markup));
  if (options.reply_parameters) form.append('reply_parameters', JSON.stringify(options.reply_parameters));
  const response = await axios.post(`https://api.telegram.org/bot${c.BOT}/sendLivePhoto`, form, {
    headers: form.getHeaders(),
    timeout: 180000,
    maxContentLength: Infinity,
    maxBodyLength: Infinity
  });
  if (!response.data?.ok) throw new Error(response.data?.description || 'Telegram gagal mengirim Live Photo.');
  return response.data.result;
}

// Reliable in-memory document sender. Some node-telegram-bot-api versions
// are picky about Buffer uploads; using the official multipart Bot API keeps
// bulk.text delivery independent from that wrapper.
async function sendDocumentBufferReliable(chatId, buffer, options = {}, file = {}) {
  const FormData = require('form-data');
  const form = new FormData();
  form.append('chat_id', String(chatId));
  form.append('document', buffer, {
    filename: file.filename || 'file.bin',
    contentType: file.contentType || 'application/octet-stream'
  });
  if (options.caption != null) form.append('caption', String(options.caption));
  if (options.parse_mode) form.append('parse_mode', String(options.parse_mode));
  if (options.reply_markup) form.append('reply_markup', JSON.stringify(options.reply_markup));
  if (options.reply_parameters) form.append('reply_parameters', JSON.stringify(options.reply_parameters));
  if (options.reply_to_message_id) form.append('reply_to_message_id', String(options.reply_to_message_id));
  const response = await axios.post(`https://api.telegram.org/bot${c.BOT}/sendDocument`, form, {
    headers: form.getHeaders(),
    timeout: 180000,
    maxContentLength: Infinity,
    maxBodyLength: Infinity
  });
  if (!response.data?.ok) throw new Error(response.data?.description || 'Telegram gagal mengirim file.');
  return response.data.result;
}
  
const pendingConnect = new Map();
const pendingRinem = new Map();
const chessGames = new Map();
const songCache = new Map();
const pendingWelcomeSetup = new Map();
const pendingTesfunc = new Map(); // chatId:userId -> { targetNumber, code, msgId }
const pinterestCache = new Map();
const ttsCache = new Map();
const pendingHadiahLimit = new Map();
const pendingEnc = new Map(); // chatId:userId -> { level, promptMsgId, createdAt }
const pendingRedeemInput  = new Map();
const pendingMarketSearch = new Map();
const pendingPhotoPrompt = new Map();
const pendingVideoPrompt = new Map();
const aiHistory = new Map();
const pendingAiAction = new Map(); // userId -> {chatId, mode, createdAt}
const aiPersonality = new Map(); // userId -> personality
const activeTesfuncMap = new Map();
const pendingCelah = new Map();
const controlledBots = new Map();
const pendingPasswordInput = new Map();
const pendingTesfuncPw = new Map();
const activeControl = new Map();
const pendingComboFunc = new Map();
const pendingSendAgain  = new Map();
let _sendAgainCounter = 0;
const pendingWink = new Map();
const pendingWeather = new Map(); // userId -> { chatId, mode, createdAt }
const pendingLivePhoto = new Map(); // userId -> { chatId, mode, createdAt }
const pendingOsint = new Map(); // userId -> { chatId, createdAt }
const pendingEmojiId = new Map(); // userId -> { chatId, createdAt }

const pendingRelaxSearch = new Map(); // userId -> { chatId, type, createdAt }
const pendingRelaxNote = new Map(); // userId -> { chatId, createdAt }
const relaxCounters = new Map(); // userId -> count
const devErrorLog = [];
const activityLog = [];
let v6LastBackup = null;
function recordActivity(type, detail='') {
  activityLog.push({ time: new Date().toISOString(), type: String(type).slice(0,80), detail: String(detail).slice(0,220) });
  if (activityLog.length > 80) activityLog.shift();
}
function recordDevError(type, error) {

  const message = String(error?.stack || error?.message || error || 'Unknown error').slice(0, 1200);
  devErrorLog.push({ time: new Date().toISOString(), type, message });
  if (devErrorLog.length > 30) devErrorLog.shift();
}
const pendingQC = new Map(); // userId -> { chatId, createdAt }
const pendingRichMessage = new Map(); // userId -> { chatId, expiresAt }
const pendingRichPhotoChoice = new Map(); // userId -> { chatId, rendered, photoFileId, replyToMsgId, expiresAt }
const quranPageCache = new Map(); // juz:page -> cached page
const quranJuzCache = new Map(); // juz -> full juz data
const npmCache = new Map(); // id -> { chatId, result }
const pendingDomainRename = new Map(); // userId -> flow state
const pendingTourl = new Map(); // userId -> flow state
const pendingDownloader = new Map(); // userId -> { chatId, type, createdAt }
const pendingDeploy = new Map(); // userId -> flow state
const pendingWaChannel = new Map(); // userId -> flow state
let _npmCacheCounter = 0;
const privateLinks = new Map(); // token -> { chatId, targetUsername, inviteLink, createdBy, createdAt, expireAt }
const floodTracker = new Map(); // "chatId:userId" -> { count, firstMsgTime }
const spamTracker = new Map(); // "chatId:userId" -> { count, firstMsgTime } (antispam, terpisah dari antiflood)
const slowmodeTracker = new Map(); // chatId:userId -> last message timestamp
const moderationStrikeTracker = new Map(); // in-process cache; persistent count lives in store
const stickerSafetyCache = new Map(); // file_unique_id -> {adult, checkedAt}
const mediaSafetyCache = new Map(); // file_unique_id -> {categories, checkedAt}
const MEDIA_SAFETY_TTL_MS = 12 * 60 * 60 * 1000;
const MEDIA_SAFETY_MAX_BYTES = 15 * 1024 * 1024;
const MODERATION_FAIL_CLOSED = /^(1|true|yes|on)$/i.test(String(process.env.MODERATION_FAIL_CLOSED || 'false'));
const MOD_MUTE_AFTER = 4; // 1/3, 2/3, 3/3 = warning; 4/4 = permanent mute

function registerModerationStrike(chatId, userId, category) {
  const key = `${chatId}:${userId}:all`;
  const now = Date.now();
  const record = recordModerationWarning(chatId, userId);
  const strike = { count: Number(record.warnings || 0), firstAt: now, lastAt: now, category };
  moderationStrikeTracker.set(key, strike);
  return strike;
}

function clearAllModerationStrikes(chatId, userId) {
  const prefix = `${chatId}:${userId}:all`;
  for (const key of moderationStrikeTracker.keys()) {
    if (key.startsWith(prefix)) moderationStrikeTracker.delete(key);
  }
}

function moderationActionKeyboard(chatId, userId) {
  return { inline_keyboard: [[
    { text: '🔇 Mute Manual', callback_data: `mod_mute:${chatId}:${userId}`, style: 'danger' },
    { text: '↻ Reset Warn', callback_data: `mod_reset:${chatId}:${userId}`, style: 'success' }
  ]] };
}

async function sendModerationRich(chatId, text, userId, messageId = null) {
  return sendRichMenu(chatId, text, moderationActionKeyboard(chatId, userId), null, messageId);
}

async function permanentlyMuteMember(chatId, userId) {
  await bot.restrictChatMember(chatId, userId, {
    permissions: {
      can_send_messages: false,
      can_send_polls: false,
      can_send_other_messages: false,
      can_add_web_page_previews: false,
      can_send_audios: false,
      can_send_documents: false,
      can_send_photos: false,
      can_send_videos: false,
      can_send_video_notes: false,
      can_send_voice_notes: false
    },
    until_date: 0
  });
}

async function applyModerationAction(chatId, userId, strike, category, mention, messageId) {
  const label = category === 'antiporno' ? 'konten 18+/porno' :
    category === 'antipromosi' ? 'promosi' :
    category === 'antitoxic' ? 'toxic' :
    category === 'antiforward' ? 'forward' :
    category === 'antisticker' ? 'stiker' :
    category === 'antifoto' ? 'foto' :
    category === 'antivideo' ? 'video' :
    category === 'antidrugs' ? 'konten narkoba' :
    category === 'antilink' ? 'link' : category;

  const record = getModerationRecord(chatId, userId);
  if (record.permanent || strike.count >= MOD_MUTE_AFTER) {
    try {
      await permanentlyMuteMember(chatId, userId);
      if (!record.permanent) markModerationPermanent(chatId, userId);
      clearAllModerationStrikes(chatId, userId);
      return await sendModerationRich(
        chatId,
        `<blockquote>🔒 <b>AUTO MUTE PERMANEN — 4/4</b></blockquote>\n\n` +
        `${mention} melakukan pelanggaran <b>${htmlEscape(label)}</b> sebanyak <b>${strike.count}/4</b>.\n\n` +
        `Batas pelanggaran tercapai. Member sekarang <b>mute permanen</b> dan tidak dapat mengirim pesan sampai admin melakukan unmute manual.`,
        userId
      );
    } catch (e) {
      return await sendModerationRich(
        chatId,
        `<blockquote>⚠️ <b>AUTO MUTE PERMANEN GAGAL</b></blockquote>\n\n` +
        `${mention} sudah mencapai <b>${strike.count}/4</b> pelanggaran, tetapi Telegram menolak mute otomatis.\n` +
        `Pastikan bot memiliki izin <b>Restrict Members</b>.\n\n` +
        `<code>${htmlEscape(e?.message || 'Telegram menolak aksi mute.')}</code>`,
        userId
      );
    }
  }

  const warningText = `Peringatan <b>${strike.count}/3</b>. Pesan dihapus.`;
  return await sendModerationRich(
    chatId,
    `<blockquote>⚠️ <b>PERINGATAN ${strike.count}/3</b></blockquote>\n\n` +
    `${mention} dilarang mengirim <b>${htmlEscape(label)}</b>.\n` +
    `${warningText}\n\n` +
    `<i>Jika mencapai pelanggaran ke-4, bot akan menerapkan <b>mute permanen otomatis</b>.</i>`,
    userId
  );
}
const pendingLapor = new Map(); // userId -> true (menunggu teks laporan)
const pendingFeatureRequest = new Map(); // userId -> { chatId, createdAt }
const pendingFeatureReply = new Map(); // developerId -> requestId
const pendingBroadcast = new Map(); // userId -> true (menunggu isi broadcast, owner only)
const pendingForceSub = new Map(); // userId -> { chatId, createdAt }
const pendingChannelMonitor = new Map(); // userId -> { chatId, createdAt }
const pendingMediaFire = new Map(); // userId -> { chatId, createdAt }
const dmMuteList = new Map(); // "chatId:userId" -> untilTimestamp (dmuser: mute + auto-delete pesan)
const tebakKataSessions = new Map(); // chatId -> { word, hint, startedBy, startedAt }
const quizSessions = new Map();
const mathSessions = new Map();
const tttSessions = new Map();
const partySessions = new Map();
const quizPartySessions = new Map();
const partyScores = new Map();
const memoryGameSessions = new Map();
const scrambleSessions = new Map();
const higherLowerSessions = new Map();
const reactionSessions = new Map();
const duelSessions = new Map();
const mpGameSessions = new Map(); // chatId -> {type,host,players,max,question,options,answer,answers,scores,createdAt}
const amPremiumSessions = new Map(); // userId -> { chatId, step, email, createdAt, processing }
// ======================================= //
// 📡 CONTROL MODE COMMANDS
// ======================================= //
// ======================================= //
// 🛠 HELPER — Ambil isi kode dari reply
// ======================================= //
const MASA_DEPAN_LIST = [
  'Kamu akan mendapatkan rezeki tak terduga dari arah yang tidak pernah kamu sangka',
  'Sebuah pertemuan tak sengaja akan mengubah hidupmu menjadi lebih baik',
  'Kamu akan menemukan passion baru yang akan menjadi sumber penghasilan utamamu',
  'Seseorang diam-diam menyukaimu dan akan segera mengungkapkan perasaannya',
  'Kamu akan mendapat kabar gembira yang sudah lama kamu tunggu-tunggu',
  'Perjalanan jauh menunggumu dan akan memberikan pengalaman luar biasa',
  'Sebuah ide geniusmu akan diakui banyak orang dan membawa keberhasilan',
  'Kamu akan bertemu seseorang yang menjadi teman seumur hidup',
  'Rejeki nomplok datang dalam bentuk yang tidak pernah kamu bayangkan',
  'Kamu akan menyelesaikan sebuah proyek besar yang membuatmu bangga',
  'Hubungan yang sempat renggang akan kembali harmonis',
  'Kamu akan mendapatkan promosi atau kenaikan jabatan yang selama ini kamu impikan',
  'Sebuah bakat tersembunyi akan muncul dan mengagumkan orang-orang di sekitarmu',
  'Kamu akan pindah ke tempat baru yang jauh lebih nyaman dari sekarang',
  'Seseorang akan meminta maaf kepadamu atas kesalahan yang pernah dilakukan',
  'Kamu akan berhasil melewati masa sulit dan keluar sebagai pribadi yang lebih kuat',
  'Investasi atau tabunganmu akan berkembang pesat melebihi ekspektasi',
  'Kamu akan membuat keputusan besar yang ternyata adalah pilihan terbaik hidupmu',
  'Orang yang kamu sayangi akan memberikan kejutan yang membuatmu terharu',
  'Sebuah peluang bisnis besar akan datang menghampirimu',
  'Kamu akan berhasil mewujudkan impian yang sudah lama tersimpan di hati',
  'Keberuntungan berpihak padamu dalam sebuah kompetisi atau tantangan',
  'Kamu akan menemukan solusi atas masalah yang sudah lama mengganggumu',
  'Seseorang yang kamu kagumi ternyata juga mengagumi dirimu',
  'Kamu akan mendapat undangan ke acara penting yang membuka banyak koneksi',
  'Usahamu selama ini akan mulai membuahkan hasil yang signifikan',
  'Kamu akan menerima hadiah atau bonus yang sangat mengejutkan',
  'Sebuah keahlian teknismu akan sangat dibutuhkan dan dihargai tinggi',
  'Kamu akan menemukan kembali semangat yang sempat hilang',
  'Orang-orang di sekitarmu akan mulai memandangmu dengan lebih hormat',
  'Kamu akan berhasil melepaskan kebiasaan buruk yang selama ini menghambatmu',
  'Sebuah kesempatan emas datang tepat saat kamu paling membutuhkannya',
  'Kamu akan membuka babak baru dalam hidupmu yang penuh warna',
  'Pertemanan lama akan kembali hadir dan membawa kebahagiaan',
  'Kamu akan mendapatkan pengakuan atas kerja keras yang selama ini tidak terlihat',
  'Sebuah proyek sampinganmu akan berkembang menjadi sesuatu yang besar',
  'Kamu akan mendapat berita baik dari luar kota atau luar negeri',
  'Hubungan asmaramu akan memasuki fase yang lebih serius dan indah',
  'Kamu akan menemukan tempat makan favorit baru yang bikin ketagihan',
  'Sebuah masalah kesehatan yang mengkhawatirkan ternyata tidak separah yang dibayangkan',
  'Kamu akan berhasil menabung jumlah yang selama ini terasa mustahil',
  'Seseorang akan merekomendasikanmu untuk sebuah posisi atau peluang penting',
  'Kamu akan merasa sangat bersyukur atas hidup yang kamu jalani',
  'Sebuah mimpimu yang tertunda akan segera terwujud dengan cara yang indah',
  'Kamu akan mendapat pelanggan atau klien baru yang membawa keuntungan besar',
  'Sebuah perjalanan spontan akan menjadi kenangan terindah dalam hidupmu',
  'Kamu akan menemukan cara baru untuk menghasilkan uang dari hobi',
  'Seseorang akan memperkenalkanmu kepada orang yang mengubah hidupmu',
  'Kamu akan berhasil menyelesaikan studi atau kursus yang selama ini tertunda',
  'Keberanian mengambil risiko kecil akan berbuah hasil yang luar biasa',
  'Kamu akan mendapat kepercayaan untuk memimpin sesuatu yang penting',
  'Sebuah aset atau barang berharga akan jatuh ke tanganmu',
  'Kamu akan merasakan ketenangan batin yang sudah lama kamu cari',
  'Sebuah kolaborasi dengan orang baru akan menghasilkan karya luar biasa',
  'Kamu akan mendapat kabar baik yang membuat satu keluarga bahagia',
  'Tekadmu yang kuat akan mengalahkan semua rintangan yang ada',
  'Kamu akan menemukan buku, video, atau konten yang mengubah cara pandangmu',
  'Sebuah aplikasi atau tool yang kamu buat akan dipakai banyak orang',
  'Kamu akan mendapat penawaran yang terlalu bagus untuk ditolak',
  'Orang yang selama ini meragukan kemampuanmu akan terkejut melihat pencapaianmu',
  'Kamu akan berhasil memenangkan sesuatu yang sudah lama kamu perjuangkan',
  'Sebuah keputusan spontan akan membawamu ke arah yang jauh lebih baik',
  'Kamu akan mendapat mentor atau guru yang tepat di waktu yang tepat',
  'Sebuah pekerjaan atau tugas besar akan selesai lebih cepat dari perkiraan',
  'Kamu akan mendapatkan pengalaman kerja di luar negeri atau tempat impian',
  'Seseorang yang sudah lama hilang kontak akan kembali menghubungimu',
  'Kamu akan berhasil membuat orang yang kamu sayangi bahagia',
  'Sebuah ide kreatifmu akan viral dan dibicarakan banyak orang',
  'Kamu akan menemukan komunitas yang benar-benar memahami dirimu',
  'Sebuah hutang atau masalah finansial yang mengganggu akan segera terselesaikan',
  'Kamu akan mendapat rezeki dari arah yang tidak pernah kamu prediksi',
  'Sebuah skill yang kamu pelajari diam-diam akan sangat berguna',
  'Kamu akan berhasil mencapai target yang ditetapkan bahkan lebih',
  'Seseorang akan memberikan nasihat yang mengubah hidupmu selamanya',
  'Kamu akan menemukan cara hidup yang lebih hemat tapi tetap berkualitas',
  'Sebuah proyek impianmu akan akhirnya mendapat dukungan yang dibutuhkan',
  'Kamu akan mendapat kepercayaan ekstra dari orang-orang terdekatmu',
  'Sebuah tantangan yang terlihat mustahil akan berhasil kamu taklukkan',
  'Kamu akan bertemu jodoh atau mempererat hubungan dengan orang istimewa',
  'Sebuah usaha lama yang terbengkalai akan kembali berkembang',
  'Kamu akan mendapat informasi penting yang mengubah keputusanmu',
  'Sebuah pertemanan baru akan terasa seperti sudah kenal seumur hidup',
  'Kamu akan berhasil mewujudkan sesuatu yang membuat orang tuamu bangga',
  'Sebuah peluang yang hampir kamu lewatkan ternyata adalah yang terbaik',
  'Kamu akan mendapat giliran keberuntungan setelah masa penantian panjang',
  'Sebuah keputusan susah yang kamu ambil ternyata adalah yang paling benar',
  'Kamu akan merasakan kebahagiaan sederhana yang selama ini terlupakan',
  'Sebuah bonus tak terduga datang saat kamu paling membutuhkannya',
  'Kamu akan mendapat pengakuan internasional atas karya atau prestasimu',
  'Sebuah hubungan yang hampir putus akan kembali kuat lebih dari sebelumnya',
  'Kamu akan berhasil membuktikan bahwa kepercayaan dirimu tidak sia-sia',
  'Sebuah pelajaran hidup pahit akan ternyata menjadi berkah terbesarmu',
  'Kamu akan mendapat kesempatan kedua untuk sesuatu yang pernah gagal',
  'Sebuah perubahan kecil dalam rutinitas akan memberi dampak besar',
  'Kamu akan berhasil menjadi versi terbaik dari dirimu sendiri',
  'Sebuah hal yang kamu anggap biasa ternyata sangat berharga bagi orang lain',
  'Kamu akan mendapat dukungan luar biasa di saat-saat paling kritis',
  'Sebuah mimpi buruk berubah menjadi kisah sukses yang menginspirasi banyak orang'
];

const masaDepanCache = new Map(); // nama_lowercase -> { fortune, days }

function getMasaDepan(nama) {
  const key = nama.toLowerCase().trim();
  if (masaDepanCache.has(key)) return masaDepanCache.get(key);
  // Hash nama untuk hasil konsisten
  let hash = 5381;
  for (let i = 0; i < key.length; i++) {
    hash = ((hash << 5) + hash) + key.charCodeAt(i);
    hash = hash & 0x7FFFFFFF;
  }
  const idx   = hash % MASA_DEPAN_LIST.length;
  const days  = 60 + (hash % 306); // 60-365 hari
  const result = { fortune: MASA_DEPAN_LIST[idx], days };
  masaDepanCache.set(key, result);
  return result;
}

function getMasaDepanBotMsg(nama, days) {
  const msgs = [
    `✨ Masa depanmu sudah tertulis, ${nama}. Tetap semangat dan percayai prosesnya!`,
    `🌟 Ini bukan kebetulan, ${nama}. Alam semesta sudah menyiapkan ini untukmu.`,
    `💫 Sabar ya ${nama}, hal-hal terbaik selalu datang tepat waktu, bukan lebih awal.`,
    `🔮 Percayalah ${nama}, setiap langkahmu hari ini sedang membangun masa depan itu.`,
    `⚡ ${nama}, tinggal ${days} hari lagi. Jangan menyerah sekarang!`,
    `🎯 Takdir tidak bisa dibohongi, ${nama}. Yang kamu tanam sekarang akan kamu tuai nanti.`,
    `🌈 Keep going ${nama}! Yang terbaik belum datang, tapi sudah dalam perjalanan.`,
    `🚀 Bersiaplah ${nama}, perubahan besar sedang menuju ke arahmu!`
  ];
  let h = 0;
  for (const c of nama.toLowerCase()) h = (h * 31 + c.charCodeAt(0)) & 0x7FFFFFFF;
  return msgs[h % msgs.length];
}

// ---- Pure code fixer (tanpa AI) ----
function _pureFixCode(code, ext = 'js') {
  let fixed = code.replace(/^\uFEFF/, '').replace(/\r\n/g, '\n').replace(/\r/g, '\n');
  // Fix double semicolons
  fixed = fixed.replace(/;;+/g, ';');
  // Remove trailing whitespace per line
  fixed = fixed.split('\n').map(l => l.trimEnd()).join('\n');
  // Balance braces/brackets/parens
  const opens = {'(':')', '[':']', '{':'}'};
  const closesSet = new Set([')', ']', '}']);
  const stack = [];
  let inStr = false, strChar = '', inComment = false, inBlockComment = false;
  for (let i = 0; i < fixed.length; i++) {
    const c = fixed[i], n = fixed[i+1] || '';
    const pr = i > 0 ? fixed[i-1] : '';
    if (inBlockComment) { if (c === '*' && n === '/') inBlockComment = false; continue; }
    if (inComment) { if (c === '\n') inComment = false; continue; }
    if (!inStr) {
      if (c === '/' && n === '/') { inComment = true; continue; }
      if (c === '/' && n === '*') { inBlockComment = true; continue; }
      if (c === '"' || c === "'" || c === '`') { inStr = true; strChar = c; continue; }
      if (opens[c]) stack.push(opens[c]);
      else if (closesSet.has(c) && stack.length && stack[stack.length-1] === c) stack.pop();
    } else {
      if (c === strChar && pr !== '\\') inStr = false;
    }
  }
  for (let i = stack.length - 1; i >= 0; i--) fixed += '\n' + stack[i];
  // Remove more than 3 consecutive blank lines
  fixed = fixed.replace(/\n{4,}/g, '\n\n\n');
  return fixed.trim();
}

function _detectCodeIssues(code) {
  const issues = [];
  if (/;;/.test(code)) issues.push('semicolon ganda');
  const opens = (code.match(/\{/g)||[]).length, closes = (code.match(/\}/g)||[]).length;
  if (opens !== closes) issues.push(`kurung kurawal tidak seimbang (${opens} buka, ${closes} tutup)`);
  const po = (code.match(/\(/g)||[]).length, pc = (code.match(/\)/g)||[]).length;
  if (po !== pc) issues.push(`kurung biasa tidak seimbang`);
  return issues;
}

// ---- Pure code cleaner / formatter (tanpa AI) ----
function _pureCleanCode(code) {
  let lines = code.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');
  lines = lines.map(l => l.trimEnd());
  let indent = 0;
  const IND = '  ';
  const result = [];
  for (const rawLine of lines) {
    const line = rawLine.trim();
    if (!line) { result.push(''); continue; }
    // Dedent for closing brackets
    const dedentCount = (line.match(/^[}\])]*/)?.[0] || '').length;
    indent = Math.max(0, indent - dedentCount);
    result.push(IND.repeat(indent) + line);
    // Indent for opening brackets at end (not comments)
    if (!line.startsWith('//') && !line.startsWith('*')) {
      const openCount = (line.match(/[{[(]/g) || []).length;
      const closeCount = (line.match(/[}\])]/g) || []).length;
      indent = Math.max(0, indent + openCount - closeCount + dedentCount);
    }
  }
  // Max 2 consecutive blank lines
  let cleaned = result.join('\n').replace(/\n{3,}/g, '\n\n');
  return cleaned.trim();
}

// ---- Pure Dart analyzer (tanpa AI) ----
function _analyzeDart(code) {
  const lines = code.split('\n');
  const errors = [], warnings = [], suggestions = [];
  // Bracket balance
  let braces = 0, parens = 0, brackets = 0;
  for (const line of lines) {
    braces    += (line.match(/\{/g)||[]).length - (line.match(/\}/g)||[]).length;
    parens    += (line.match(/\(/g)||[]).length - (line.match(/\)/g)||[]).length;
    brackets  += (line.match(/\[/g)||[]).length - (line.match(/\]/g)||[]).length;
  }
  if (braces !== 0)   errors.push(`Kurung kurawal {} tidak seimbang (sisa: ${braces > 0 ? '+' : ''}${braces})`);
  if (parens !== 0)   errors.push(`Kurung biasa () tidak seimbang (sisa: ${parens > 0 ? '+' : ''}${parens})`);
  if (brackets !== 0) errors.push(`Kurung siku [] tidak seimbang (sisa: ${brackets > 0 ? '+' : ''}${brackets})`);
  // Check for common issues
  lines.forEach((line, i) => {
    const ln = i + 1;
    if (/\.toString\(\s*\)/.test(line) && /int |double /.test(lines[i-1] || ''))
      suggestions.push(`Baris ${ln}: toString() mungkin tidak diperlukan pada tipe numerik`);
    if (/print\(/.test(line))
      warnings.push(`Baris ${ln}: print() ditemukan — hapus sebelum release build`);
    if (/TODO|FIXME|HACK/i.test(line))
      warnings.push(`Baris ${ln}: Komentar TODO/FIXME ditemukan`);
    if (/var\s+\w/.test(line) && !/final|const/.test(line))
      suggestions.push(`Baris ${ln}: Pertimbangkan menggunakan 'final' atau tipe eksplisit`);
    if (/!\./.test(line))
      warnings.push(`Baris ${ln}: Null-assertion operator (!) ditemukan — pastikan tidak null`);
  });
  const hasImport = /^import\s+/m.test(code);
  const classList = (code.match(/class\s+(\w+)/g) || []).map(c => c.replace('class ', ''));
  const funcList  = (code.match(/(?:void|Future|String|int|double|bool|Widget)\s+\w+\s*\(/g) || []).map(f => f.trim());
  let report = `STATUS: ${errors.length > 0 ? '❌ Ada Error' : warnings.length > 0 ? '⚠️ Ada Warning' : '✅ Tidak Ada Error Kritis'}\n\n`;
  report += `📦 STRUKTUR:\n`;
  report += `• File memiliki ${lines.length} baris\n`;
  if (hasImport) report += `• Import ditemukan\n`;
  if (classList.length) report += `• Class: ${classList.join(', ')}\n`;
  if (funcList.length)  report += `• Fungsi: ${funcList.slice(0, 10).join(', ')}${funcList.length > 10 ? '...' : ''}\n`;
  if (errors.length) {
    report += `\n❌ ERROR (${errors.length}):\n`;
    errors.forEach(e => { report += `  - ${e}\n`; });
  }
  if (warnings.length) {
    report += `\n⚠️ WARNING (${warnings.length}):\n`;
    warnings.forEach(w => { report += `  - ${w}\n`; });
  }
  if (suggestions.length) {
    report += `\n💡 SARAN:\n`;
    suggestions.slice(0, 5).forEach(s => { report += `  - ${s}\n`; });
  }
  report += `\nKESIMPULAN: ${errors.length === 0 ? 'Kode siap di-build (tidak ada error kritis).' : 'Perbaiki error di atas sebelum di-build.'}`;
  return report;
}

// ---- Pure Dart fixer (tanpa AI) ----
function _pureFixDart(code) {
  let fixed = code.replace(/^\uFEFF/, '').replace(/\r\n/g, '\n').replace(/\r/g, '\n');
  // Fix print statements untuk produksi (beri komentar)
  // NOT: kita tidak hapus, hanya balance brackets
  // Balance braces
  const opens = {'(':')', '[':']', '{':'}'};
  const closesSet = new Set([')', ']', '}']);
  const stack = [];
  let inStr = false, strChar = '', inComment = false;
  for (let i = 0; i < fixed.length; i++) {
    const c = fixed[i], n = fixed[i+1] || '', pr = i > 0 ? fixed[i-1] : '';
    if (inComment) { if (c === '\n') inComment = false; continue; }
    if (!inStr) {
      if (c === '/' && n === '/') { inComment = true; continue; }
      if (c === '"' || c === "'") { inStr = true; strChar = c; continue; }
      if (opens[c]) stack.push(opens[c]);
      else if (closesSet.has(c) && stack.length && stack[stack.length-1] === c) stack.pop();
    } else {
      if (c === strChar && pr !== '\\') inStr = false;
    }
  }
  for (let i = stack.length - 1; i >= 0; i--) fixed += '\n' + stack[i];
  // Remove Windows line endings, trailing whitespace
  fixed = fixed.split('\n').map(l => l.trimEnd()).join('\n');
  fixed = fixed.replace(/\n{4,}/g, '\n\n\n');
  return fixed.trim();
}

// ---- Pure function structure extractor (tanpa AI) ----
function _extractFunctionStructure(code) {
  const lines = code.split('\n');
  const result = [];
  // Extract function declarations
  const funcPattern = /(?:async\s+)?function\s+(\w+)\s*\(([^)]*)\)/g;
  const arrowPattern = /(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?\(?([^)=]*)\)?\s*=>/g;
  const methodPattern = /(\w+)\s*\(([^)]*)\)\s*(?:async\s*)?\{/g;
  const funcs = [];
  let m;
  // Named functions
  const codeFlat = code;
  while ((m = funcPattern.exec(codeFlat)) !== null) {
    const line = codeFlat.substring(0, m.index).split('\n').length;
    funcs.push({ name: m[1], params: m[2].trim(), line, type: m[0].includes('async') ? 'async function' : 'function' });
  }
  // Arrow functions
  const arrowRe = new RegExp(arrowPattern.source, 'g');
  while ((m = arrowRe.exec(codeFlat)) !== null) {
    const line = codeFlat.substring(0, m.index).split('\n').length;
    if (!funcs.find(f => f.name === m[1])) {
      funcs.push({ name: m[1], params: m[2].trim(), line, type: 'arrow' });
    }
  }
  if (!funcs.length) {
    return '// Tidak ada function declaration yang terdeteksi';
  }
  for (const fn of funcs) {
    result.push(`// Line ${fn.line} — ${fn.type}`);
    result.push(`${fn.type.includes('async') ? 'async ' : ''}function ${fn.name}(${fn.params}) {`);
    // Find body of this function and extract key calls
    const bodyStart = code.indexOf(fn.name + '(');
    const bodySlice = code.slice(bodyStart, bodyStart + 1000);
    // Extract await calls
    const awaits = (bodySlice.match(/await\s+[\w.]+\s*\([^)]{0,60}\)/g) || []).slice(0, 5);
    const httpCalls = (bodySlice.match(/axios\.[a-z]+\s*\([^)]{0,60}\)/g) || []).slice(0, 3);
    const ifBlocks = (bodySlice.match(/if\s*\([^)]{0,50}\)/g) || []).slice(0, 3);
    awaits.forEach(a => result.push(`  ${a.trim()};`));
    httpCalls.forEach(h => result.push(`  // HTTP: ${h.trim()}`));
    ifBlocks.forEach(b => result.push(`  ${b} { ... }`));
    result.push(`}`);
    result.push('');
  }
  return result.join('\n');
}
async function extractCodeFromReply(msg) {
  const reply = msg.reply_to_message;
  if (!reply) return null;

  // Dari teks biasa atau code block
  let code = reply.text || reply.caption || '';

  // Dari file dokumen
  if (!code && reply.document) {
    const link = await bot.getFileLink(reply.document.file_id);
    const r = await axios.get(link, { responseType: 'arraybuffer', timeout: 30000 });
    code = Buffer.from(r.data).toString('utf-8');
  }

  return code.trim() || null;
}

// Deteksi ekstensi file dari reply (untuk caption hasil)
function detectFileExt(msg) {
  const reply = msg.reply_to_message;
  if (reply?.document?.file_name) {
    const name = reply.document.file_name;
    const ext  = name.split('.').pop().toLowerCase();
    return { ext, name };
  }
  return { ext: 'js', name: 'code.js' };
}

// Helper: kirim ke semua users via token bot yang dikontrol
async function controlBroadcast(token, method, params) {
  const users = getAllUsers();
  let sukses = 0, gagal = 0;
  for (const user of users) {
    try {
      await axios.post(`https://api.telegram.org/bot${token}/${method}`, {
        chat_id: user.id,
        ...params
      }, { timeout: 10000 });
      sukses++;
      await new Promise(r => setTimeout(r, 60));
    } catch { gagal++; }
  }
  return { sukses, gagal, total: users.length };
}

// Helper: download file dari our bot dan upload via token lain
async function controlSendMedia(bot, token, method, fileId, extraParams = {}) {
  const fileLink = await bot.getFileLink(fileId);
  const imgRes = await axios.get(fileLink, { responseType: 'arraybuffer', timeout: 30000 });
  const buf = Buffer.from(imgRes.data);
  const users = getAllUsers();
  let sukses = 0, gagal = 0;
  const fieldName = method.startsWith('sendPhoto') ? 'photo' :
    method.startsWith('sendVideo') ? 'video' :
    method.startsWith('sendAudio') ? 'audio' :
    method.startsWith('sendSticker') ? 'sticker' : 'document';
  for (const user of users) {
    try {
      const fd = new FormData();
      fd.append('chat_id', String(user.id));
      fd.append(fieldName, new Blob([buf]), `file`);
      if (extraParams.caption) fd.append('caption', extraParams.caption);
      if (extraParams.parse_mode) fd.append('parse_mode', extraParams.parse_mode);
      await fetch(`https://api.telegram.org/bot${token}/${method}`, {
        method: 'POST', body: fd, signal: AbortSignal.timeout(15000)
      });
      sukses++;
      await new Promise(r => setTimeout(r, 60));
    } catch { gagal++; }
  }
  return { sukses, gagal, total: users.length };
}
// ======================================= //
// 🚀 HELPERS
// ======================================= //
const PORN_DOMAINS = [
  'pornhub','xvideos','xnxx','xhamster','redtube','youporn','tube8','spankbang',
  'beeg','porn','sex','xxx','onlyfans','fapello','eporner','drtuber','empflix',
  'xtube','keezmovies','sunporno','tnaflix','txxx','vjav','javhd','jav','hentai',
  'rule34','gelbooru','danbooru','nhentai','doujin','hanime','xempire','brazzers',
  'bangbros','realitykings','nubiles','mofos','twistys','maturetubehere'
];

const PORN_KEYWORDS_ID = [
  'bokep','ngentot','memek','kontol','ngaceng','sange','colmek',
  'masturbasi','bugil','telanjang','mesum','nakal','hot abg',
  'video mesum','foto bugil','nude leak','foto hot','video hot',
  'porno','nudes','leak foto','jual foto','jual video','open bo',
  'open jasa','jasa esek','sempak','crot','pepek','kocok'
];

const PORN_KEYWORDS_EN = [
  'pornography','nude','nudes','naked','nsfw','xxx','blowjob','handjob',
  'cumshot','creampie','orgasm','horny','sex tape','leaked video',
  'onlyfans link','only fans','adult content'
];

async function moderateSafetyWithGemini(parts, userId, mode='media') {
  if (!AI_CONFIG.geminiKey) return null;
  try {
    const input = [{
      type: 'text',
      text: [
        'Kamu adalah moderator keamanan grup Telegram.',
        'Nilai HANYA konten visual yang diberikan, bukan identitas orang.',
        'Balas tepat satu baris JSON tanpa markdown dengan format:',
        '{"decision":"SAFE|BLOCK","categories":["sexual","drugs","illegal"]}',
        'Gunakan category sexual untuk pornografi, ketelanjangan seksual, aktivitas seksual eksplisit, fetish seksual, sexual solicitation, atau konten 18+ yang jelas.',
        'Gunakan category drugs untuk narkotika/obat terlarang, penggunaan/penjualan/promosi narkoba, atau alat yang jelas terkait peredaran narkoba.',
        'Gunakan category illegal untuk aktivitas ilegal yang terlihat jelas dan relevan untuk moderasi grup (misalnya perdagangan ilegal yang nyata).',
        'Jangan blokir pakaian biasa, swimwear biasa, konten medis/edukasi yang tidak seksual, obat legal, berita umum, atau benda biasa hanya karena konteksnya.',
        'decision BLOCK hanya jika setidaknya satu category benar-benar terlihat dari konten visual.',
        `Mode: ${mode}.`,
        `User ID internal: ${String(userId)}`
      ].join(' ')
    }];
    for (const part of parts || []) input.push({type:'image',mime_type:part.mime||'image/jpeg',data:part.buffer.toString('base64')});
    const res = await axios.post('https://generativelanguage.googleapis.com/v1/interactions', {
      model: AI_CONFIG.geminiModel,
      input,
      generation_config: {max_output_tokens: 180, thinking_level:'minimal', thinking_summaries:'none'}
    }, {timeout:90000, headers:{'x-goog-api-key':AI_CONFIG.geminiKey,'Content-Type':'application/json'}});
    const answer = extractInteractionText(res.data) || '';
    const match = answer.match(/\{[\s\S]*\}/);
    if (!match) return null;
    const parsed = JSON.parse(match[0]);
    const allowed = new Set(['sexual','drugs','illegal']);
    const categories = Array.isArray(parsed.categories) ? parsed.categories.map(x=>String(x).toLowerCase()).filter(x=>allowed.has(x)) : [];
    const decision = String(parsed.decision || '').toUpperCase() === 'BLOCK' && categories.length > 0 ? 'BLOCK' : 'SAFE';
    return {decision,categories};
  } catch (e) {
    console.warn(`[GROUP SAFETY AI] ${mode}:`, e?.message || e);
    return null;
  }
}

async function extractVideoSafetyFrames(buffer, ext='mp4') {
  const tmpBase = path.join(require('os').tmpdir(), `group-safety-${Date.now()}-${crypto.randomBytes(5).toString('hex')}`);
  const input = `${tmpBase}.${String(ext||'mp4').replace(/[^a-z0-9]/gi,'') || 'mp4'}`;
  const outPattern = `${tmpBase}-%02d.jpg`;
  const frames = [];
  try {
    fs.writeFileSync(input, buffer);
    await new Promise((resolve,reject)=>{
      const proc = spawn(ffmpegPath, ['-y','-hide_banner','-loglevel','error','-i',input,'-vf','fps=1/2,scale=768:-2','-frames:v','3',outPattern], {stdio:['ignore','ignore','pipe']});
      let err=''; proc.stderr.on('data',d=>err+=d.toString()); proc.on('error',reject);
      proc.on('close',c=>c===0?resolve():reject(new Error(err.slice(-500)||'frame extraction gagal')));
    });
    for (let i=1;i<=3;i++) {
      const fp=`${tmpBase}-${String(i).padStart(2,'0')}.jpg`;
      if (fs.existsSync(fp)) frames.push({buffer:fs.readFileSync(fp),mime:'image/jpeg'});
    }
    return frames;
  } finally {
    try { fs.unlinkSync(input); } catch {}
    for (let i=1;i<=3;i++) { try { fs.unlinkSync(`${tmpBase}-${String(i).padStart(2,'0')}.jpg`); } catch {} }
  }
}

async function downloadTelegramFileForModeration(fileId, maxBytes=MEDIA_SAFETY_MAX_BYTES) {
  const link = await bot.getFileLink(fileId);
  const res = await axios.get(link,{responseType:'arraybuffer',timeout:90000,maxContentLength:maxBytes,maxBodyLength:maxBytes});
  const buf=Buffer.from(res.data);
  if (!buf.length) throw new Error('media kosong');
  if (buf.length>maxBytes) throw new Error('media terlalu besar untuk moderasi AI');
  return buf;
}

async function analyzeStickerForSafety(sticker, userId) {
  const key = String(sticker?.file_unique_id || sticker?.file_id || '');
  if (!key) return {categories:[]};
  const cached = mediaSafetyCache.get(`sticker:${key}`);
  if (cached && Date.now()-cached.checkedAt<MEDIA_SAFETY_TTL_MS) return cached;
  const metaText = `${sticker?.set_name || ''} ${sticker?.emoji || ''}`;
  const metaCategories=[];
  if (containsPornoContent(metaText)) metaCategories.push('sexual');
  if (containsDrugContent(metaText)) metaCategories.push('drugs');
  if (metaCategories.length) {
    const result={categories:[...new Set(metaCategories)],checkedAt:Date.now()};
    mediaSafetyCache.set(`sticker:${key}`,result); return result;
  }
  try {
    if (!AI_CONFIG.geminiKey) return {categories:[],checkedAt:Date.now()};
    const imageBuffer=await downloadTelegramFileForModeration(sticker.file_id,8*1024*1024);
    let frames;
    if (sticker.is_video) frames=await extractVideoSafetyFrames(imageBuffer,'webm');
    else if (sticker.is_animated) frames=[]; // TGS/Lottie is not safely decodable with current dependencies.
    else frames=[{buffer:await require('sharp')(imageBuffer).jpeg({quality:86}).toBuffer(),mime:'image/jpeg'}];
    if (!frames.length) return {categories:[],checkedAt:Date.now()};
    const result=await moderateSafetyWithGemini(frames,userId,'sticker');
    const safeResult={categories:Array.isArray(result?.categories)?result.categories:[],checkedAt:Date.now()};
    mediaSafetyCache.set(`sticker:${key}`,safeResult); return safeResult;
  } catch (e) {
    console.warn('[GROUP SAFETY STICKER]',e?.message||e);
    return {categories:[],checkedAt:Date.now()};
  }
}

async function analyzeMediaForSafety(msg, userId) {
  const media = msg.photo?.length ? {type:'photo',fileId:msg.photo[msg.photo.length-1].file_id,fileKey:msg.photo[msg.photo.length-1].file_unique_id,mime:'image/jpeg'}
    : msg.video ? {type:'video',fileId:msg.video.file_id,fileKey:msg.video.file_unique_id,mime:'video/mp4',ext:'mp4'}
    : msg.animation ? {type:'video',fileId:msg.animation.file_id,fileKey:msg.animation.file_unique_id,mime:'video/mp4',ext:'mp4'}
    : msg.video_note ? {type:'video',fileId:msg.video_note.file_id,fileKey:msg.video_note.file_unique_id,mime:'video/mp4',ext:'mp4'}
    : (msg.document && /^(image|video)\//i.test(String(msg.document.mime_type||''))) ? {type:String(msg.document.mime_type).startsWith('image/')?'photo':'video',fileId:msg.document.file_id,fileKey:msg.document.file_unique_id,mime:msg.document.mime_type,ext:String(msg.document.file_name||'mp4').split('.').pop()}
    : null;
  if (!media?.fileId) return {categories:[],unknown:false};
  const cacheKey=`media:${String(media.fileKey||media.fileId)}`;
  const cached=mediaSafetyCache.get(cacheKey);
  if (cached && Date.now()-cached.checkedAt<MEDIA_SAFETY_TTL_MS) return cached;
  try {
    if (!AI_CONFIG.geminiKey) return {categories:[],unknown:true,checkedAt:Date.now()};
    const size=Number(msg.photo?.[msg.photo.length-1]?.file_size || msg.video?.file_size || msg.animation?.file_size || msg.video_note?.file_size || msg.document?.file_size || 0);
    if (size && size>MEDIA_SAFETY_MAX_BYTES) return {categories:[],unknown:true,tooLarge:true,checkedAt:Date.now()};
    const buffer=await downloadTelegramFileForModeration(media.fileId);
    let frames;
    if (media.type==='photo') frames=[{buffer:await require('sharp')(buffer).jpeg({quality:86}).toBuffer(),mime:'image/jpeg'}];
    else frames=await extractVideoSafetyFrames(buffer,media.ext||'mp4');
    if (!frames.length) return {categories:[],unknown:true,checkedAt:Date.now()};
    const result=await moderateSafetyWithGemini(frames,userId,media.type);
    const safeResult={categories:Array.isArray(result?.categories)?result.categories:[],unknown:!result,checkedAt:Date.now()};
    mediaSafetyCache.set(cacheKey,safeResult);
    return safeResult;
  } catch (e) {
    console.warn('[GROUP SAFETY MEDIA]',e?.message||e);
    return {categories:[],unknown:true,checkedAt:Date.now()};
  }
}

async function runEnhancedGroupMediaSafety(msg, gs, userId) {
  if (!gs?.antiporno && !gs?.antidrugs) return null;
  if (!msg?.from || msg.from.is_bot) return null;
  if (msg.sticker) {
    const result=await analyzeStickerForSafety(msg.sticker,userId);
    if (gs.antiporno && result.categories?.includes('sexual')) return 'antiporno';
    if (gs.antidrugs && result.categories?.includes('drugs')) return 'antidrugs';
    if (result.categories?.includes('illegal')) return 'antiporno';
    return null;
  }
  const hasVisual=Boolean(msg.photo||msg.video||msg.animation||msg.video_note||(msg.document&&/^(image|video)\//i.test(String(msg.document.mime_type||''))));
  if (!hasVisual) return null;
  const result=await analyzeMediaForSafety(msg,userId);
  if (gs.antiporno && (result.categories?.includes('sexual') || result.categories?.includes('illegal'))) return 'antiporno';
  if (gs.antidrugs && result.categories?.includes('drugs')) return 'antidrugs';
  return null;
}

function containsPornoContent(text) {
  if (!text) return false;
  const lower = text.toLowerCase();
  for (const kw of PORN_KEYWORDS_ID) { if (lower.includes(kw)) return true; }
  for (const kw of PORN_KEYWORDS_EN) { if (lower.includes(kw)) return true; }
  const urlPattern = /https?:\/\/([^\s\/]+)/gi;
  let m;
  while ((m = urlPattern.exec(text)) !== null) {
    const domain = m[1].toLowerCase();
    for (const pd of PORN_DOMAINS) { if (domain.includes(pd)) return true; }
  }
  return false;
}

// ---- ANTIPROMOSI: deteksi promosi/jualan yang lebih kuat ----
// Catatan: deteksi dibuat berbasis beberapa sinyal agar promosi yang ditulis
// dengan variasi ejaan, URL, nomor kontak, atau CTA tetap terjaring.
const PROMO_KEYWORDS = [
  'open order','open po','buka po','preorder','pre order','open jasa','open service',
  'promo hari ini','promo','promosi','diskon','discount','cashback','voucher','gratis ongkir',
  'free ongkir','harga murah','harga grosir','harga promo','harga normal','reseller','dropship',
  'jual','dijual','jualan','menjual','tersedia','ready stock','ready stok','stok terbatas',
  'limited stock','buruan order','order sekarang','pesan sekarang','yuk order','ayo order',
  'minat dm','minat chat','pm admin','dm admin','hub admin','wa admin','chat wa','contact wa',
  'cek toko','link toko','toko online','online shop','olshop','marketplace','jastip','preloved',
  'ambil order','terima order','booking','book sekarang','join grup jualan','klik link bio',
  'klik di bio','link bio','affiliate','afiliator','kode promo','kode voucher','flash sale',
  'sale besar','cuci gudang','giveaway berbayar','slot tersedia','daftar sekarang','registrasi sekarang'
];

const PROMO_DOMAINS = [
  'wa.me','api.whatsapp.com','chat.whatsapp.com','t.me','telegram.me',
  'shopee.co.id','shopee.com','tokopedia.com','lazada.co.id','bukalapak.com',
  'blibli.com','linktr.ee','lynk.id','s.id','bit.ly','tinyurl.com','taplink.cc'
];

function normalizePromoText(text) {
  return String(text || '')
    .toLowerCase()
    .normalize('NFKC')
    .replace(/[ⓐ@]/g, 'a')
    .replace(/[ⓘ!1]/g, 'i')
    .replace(/[ⓞ0]/g, 'o')
    .replace(/[ⓢ5]/g, 's')
    .replace(/[ⓔ3]/g, 'e')
    .replace(/(.)\1{2,}/g, '$1$1')
    .replace(/[^a-z0-9@._:/+\s-]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}


// ---- ANTIDRUGS: deteksi istilah narkotika/peredaran yang umum ----
// Fokus pada istilah yang jelas terkait narkoba agar tidak menghapus percakapan
// biasa secara berlebihan. Admin/creator tetap dikecualikan di handler.
const DRUG_KEYWORDS = [
  'narkoba','narkotika','sabu','sabu-sabu','meth','methamphetamine','ice drug',
  'kokain','cocaine','heroin','heroin','ganja','marijuana','cannabis','weed',
  'tembakau gorila','tembakau super','ekstasi','mdma','pil inex','inex','pil koplo',
  'lsd','acid tab','dmt','ketamin','ketamine','fentanil','fentanyl','opium','morfin',
  'morphine','putaw','putau','gelek','hashish','hasis','crystal meth','crystalmet',
  'obat keras tanpa resep','jual sabu','jual ganja','jual narkoba','jual ekstasi',
  'pesan sabu','pesan ganja','pesan narkoba','stok sabu','stok ganja','open sabu',
  'open ganja','open narkoba'
];

function normalizeDrugText(text) {
  return String(text || '')
    .toLowerCase()
    .normalize('NFKC')
    .replace(/[0-9]/g, ch => ({'0':'o','1':'i','3':'e','4':'a','5':'s','7':'t'}[ch] || ch))
    .replace(/[^a-z\s-]/g, ' ')
    .replace(/(.)\1{2,}/g, '$1$1')
    .replace(/\s+/g, ' ')
    .trim();
}

function containsDrugContent(text, msg = null) {
  const raw = String(text || '').trim();
  if (!raw && !msg) return false;
  const lower = normalizeDrugText(raw);
  if (DRUG_KEYWORDS.some(kw => lower.includes(kw))) return true;

  const urls = lower.match(/(?:https?:\/\/|www\.)[^\s<>]+/gi) || [];
  if (urls.some(u => /(narkoba|narkotika|sabu|ganja|cocaine|heroin|mdma|drug)/i.test(u))) return true;

  if (msg) {
    const entities = [...(msg.entities || []), ...(msg.caption_entities || [])];
    if (entities.some(e => e.type === 'text_link')) {
      const combined = `${raw} ${(msg.caption || '')}`;
      if (DRUG_KEYWORDS.some(kw => normalizeDrugText(combined).includes(kw))) return true;
    }
  }
  return false;
}

function containsPromoContent(text, msg = null) {
  const raw = String(text || '').trim();
  if (!raw && !msg) return false;
  const lower = normalizePromoText(raw);
  if (!lower) return false;

  // URL/domain promosi: satu URL marketplace/contact/shortener sudah cukup.
  const urls = lower.match(/(?:https?:\/\/|www\.)[^\s<>]+/gi) || [];
  if (urls.some(u => PROMO_DOMAINS.some(d => u.includes(d)))) return true;
  if (/(?:^|\s)(?:wa\.me|t\.me|chat\.whatsapp\.com)\/\S+/i.test(lower)) return true;

  // Nomor kontak + CTA/penjualan adalah sinyal kuat.
  const hasPhone = /(?:\+?62|0)\d(?:[ .-]?\d){7,13}/.test(lower);
  const hasCta = /(wa|whatsapp|dm|pm|chat|hubungi|contact|order|pesan|booking|daftar|klik|link|admin)/i.test(lower);
  if (hasPhone && hasCta) return true;

  // Kata promosi yang jelas.
  if (PROMO_KEYWORDS.some(kw => lower.includes(kw))) return true;

  // Pola harga/penawaran: Rp 10k, 50rb, "10 ribu", dll + CTA/produk.
  const hasPrice = /(?:rp\.?\s*\d[\d.,]*\s*(?:k|rb|ribu|jt|juta)?|\d[\d.,]*\s*(?:k|rb|ribu|jt|juta))\b/i.test(lower);
  if (hasPrice && (hasCta || /(harga|murah|diskon|promo|jual|jualan|ready|stok|produk|barang)/i.test(lower))) return true;

  // Entity URL/mention dari Telegram kadang tidak muncul persis di text yang terlihat.
  if (msg) {
    const entities = [...(msg.entities || []), ...(msg.caption_entities || [])];
    if (entities.some(e => ['url','text_link'].includes(e.type))) {
      if (hasCta || hasPrice || PROMO_KEYWORDS.some(kw => lower.includes(kw))) return true;
    }
  }
  return false;
}

// ---- ANTITOXIC: deteksi kata kasar/toxic (Bahasa Indonesia & slang) ----
const TOXIC_KEYWORDS = [
  'anjing','anjir','bangsat','bajingan','babi','goblok','goblog','tolol','bego',
  'idiot','kontol','kontl','ngentot','ngentod','memek','kntl','jancok','jancuk',
  'cok','tai','taek','tae','kampret','asu','pantek','pukimak','bangke','bangkai',
  'lonte','pelacur','sundal','dongo','tolol','sialan','brengsek','keparat','setan',
  'monyet','kampang','kntol','kwuntol','kunyuk','peler','jembut'
];

function containsToxicContent(text) {
  if (!text) return false;
  const lower = text.toLowerCase().replace(/[^a-z0-9\s]/gi, ' ');
  const words = lower.split(/\s+/);
  return TOXIC_KEYWORDS.some(kw => words.includes(kw) || lower.includes(kw));
}

// Helper: edit caption (untuk pesan berupa foto)
async function safeEditCaption(bot, chatId, messageId, caption, options = {}) {
  try {
    await bot.editMessageCaption(caption, {
      chat_id: chatId,
      message_id: messageId,
      ...options
    });
  } catch (e) {
    if (!e.message?.includes('message is not modified') && !e.message?.includes('not modified')) {
      try { await safeRichTextMessage(chatId, caption, { parse_mode: options.parse_mode || 'HTML' }); } catch {}
    }
  }
}

function generateRedeemCode() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';
  for (let i = 0; i < 5; i++) result += chars[Math.floor(Math.random() * chars.length)];
  return `FMD-${result}`;
}

function getFirstActiveCode() {
  const all = getAllActiveCodes();
  const now = Date.now();
  for (const [code, data] of Object.entries(all)) {
    if (new Date(data.expiresAt).getTime() > now && data.claimed < data.maxUsers) {
      return { code, data };
    }
  }
  return null;
}

function getImageDimensions(buf) {
  try {
    if (buf[0] === 0x89 && buf[1] === 0x50) {
      return { width: buf.readUInt32BE(16), height: buf.readUInt32BE(20) };
    }
    if (buf[0] === 0xFF && buf[1] === 0xD8) {
      let i = 2;
      while (i < buf.length - 9) {
        if (buf[i] !== 0xFF) break;
        const marker = buf[i + 1];
        if (marker >= 0xC0 && marker <= 0xC3) {
          return { height: buf.readUInt16BE(i + 5), width: buf.readUInt16BE(i + 7) };
        }
        i += 2 + buf.readUInt16BE(i + 2);
      }
    }
  } catch {}
  return null;
}

async function broadcastRedeemNotif(botUsername, code, rewardFileName, maxUsers, createdAt) {
  const state = readState();
  const time = getJakartaTime();
  const keyboard = {
    inline_keyboard: [[
      { text: '✿ Klaim Sekarang ✿', url: `https://t.me/${botUsername}?start=redeem`, style: 'success', icon_custom_emoji_id: '4956499161319998529' }
    ]]
  };  // ← hapus satu }; di sini
  const text =
    `${E.party} <b>Kode Redeem Tersedia!</b>\n\n` +
    `${E.jam} Jam: <code>${time}</code>\n` +
    `${E.gift} Hadiah: <code>${htmlEscape(rewardFileName)}</code>\n` +
    `${E.group} Berlaku untuk: <code>${maxUsers} Users</code>\n` +
    `${E.key} Kode: <code>${htmlEscape(code)}</code>\n` +
    `${E.hourglass} Berlaku: <code>15 Menit</code>\n\n` +
    `<blockquote>Segera masukan kode sebelum kehabisan atau kadaluarsa!\nKlik tombol di bawah untuk langsung klaim.</blockquote>`;
  // Kirim ke semua user (private)
  const userIds = Object.keys(state.users || {});
  for (const uid of userIds) {
    try {
      await safeRichTextMessage(uid, text, { parse_mode: 'HTML', reply_markup: keyboard });
      await new Promise(r => setTimeout(r, 80));
    } catch {}
  }
  // Kirim ke semua grup/chat yang berbeda dari user
  const chatIds = Object.keys(state.chats || {}).filter(id => !userIds.includes(id));
  for (const chatId of chatIds) {
    try {
      await safeRichTextMessage(chatId, text, { parse_mode: 'HTML', reply_markup: keyboard });
      await new Promise(r => setTimeout(r, 80));
    } catch {}
  }
  // Kirim ke channel
  try {
    const channelUsername = (c.REQUIRED_CHANNELS || [])[0]?.username;
    if (channelUsername) await safeRichTextMessage(channelUsername, text, { parse_mode: 'HTML', reply_markup: keyboard });
  } catch {}
}

async function broadcastClaimNotif(claimer, code, remaining) {
  const state = readState();
  const name = htmlEscape([claimer.first_name, claimer.last_name].filter(Boolean).join(' ') || claimer.username || String(claimer.id));
  const username = claimer.username ? `@${htmlEscape(claimer.username)}` : '-';
  const text =
    `${remaining > 0 ? E.check : E.red} <b>Kode Redeem Baru Diklaim!</b>\n\n` +
    `${E.Name} Nama: <code>${name}</code>\n` +
    `${E.user} Username: <code>${username}</code>\n` +
    `${E.key} Kode: <code>${htmlEscape(code)}</code>\n` +
    `${E.box} Sisa slot: <code>${remaining}</code>\n\n` +
    `<blockquote>${remaining > 0 ? 'Masih ada slot! Buruan klaim.' : 'Kode sudah habis.'}</blockquote>`;
  const allIds = new Set([
    ...Object.keys(state.users || {}),
    ...Object.keys(state.chats || {})
  ]);
  for (const chatId of allIds) {
    if (String(chatId) === String(claimer.id)) continue;
    try {
      await safeRichTextMessage(chatId, text, { parse_mode: 'HTML' });
      await new Promise(r => setTimeout(r, 80));
    } catch {}
  }
}



function makeBar(percent, length = 12) {
  const p = Math.max(0, Math.min(100, percent));
  const filled = Math.round((p / 100) * length);
  return `[${'█'.repeat(filled)}${'░'.repeat(length - filled)}] ${p}%`;
}

function isOwner(id) {
  return String(c.ID || '').split(',').map(x => x.trim()).includes(String(id));
}

function getJakartaTime() {
  return new Date().toLocaleString('id-ID', {
    timeZone: 'Asia/Jakarta',
    hour: '2-digit', minute: '2-digit',
    day: '2-digit', month: 'long', year: 'numeric'
  });
}

// ======================================= //
// 🤖 AI RESPONSE FORMATTER
// ======================================= //
function detectCodeLang(code) {
  if (/def |import |print\(|elif |:\n/.test(code)) return 'python';
  if (/public (class|static|void)|System\.out/.test(code)) return 'java';
  if (/SELECT|INSERT|UPDATE|DELETE|FROM\s+\w/i.test(code)) return 'sql';
  if (/<\/?[a-z][\s\S]*?>/i.test(code) && !/[{};]/.test(code)) return 'html';
  if (/\$[a-zA-Z_]|->|<?php/.test(code)) return 'php';
  if (/#include|std::|cout/.test(code)) return 'cpp';
  return 'javascript';
}

function formatAiResponse(text) {
  if (!text) return '';
  const codePattern = /^\s*(const|let|var|function|async|await|return|if\s*\(|else|for\s*\(|while\s*\(|class\s|import\s|export\s|require\s*\(|def |print\(|public |SELECT|INSERT|#include|echo |\$[a-zA-Z])/;
  const lines = text.split('\n');
  let result = '';
  let codeBuffer = [];
  let inCode = false;

  for (const line of lines) {
    const isCode = codePattern.test(line) || (inCode && (line.trim() === '' || /[{};()=>]/.test(line)));
    if (isCode && !inCode) { inCode = true; codeBuffer = [line]; }
    else if (inCode && (isCode || line.trim() === '')) { codeBuffer.push(line); }
    else if (inCode) {
      const cs = codeBuffer.join('\n').trim();
      if (cs) result += `<pre><code class="language-${detectCodeLang(cs)}">${htmlEscape(cs)}</code></pre>\n`;
      inCode = false; codeBuffer = [];
      result += htmlEscape(line) + '\n';
    } else {
      result += htmlEscape(line) + '\n';
    }
  }
  if (inCode && codeBuffer.length) {
    const cs = codeBuffer.join('\n').trim();
    if (cs) result += `<pre><code class="language-${detectCodeLang(cs)}">${htmlEscape(cs)}</code></pre>\n`;
  }
  return result.trim() || htmlEscape(text);
}

function isJailbreak(text) {
  const lower = text.toLowerCase();
  return ['ignore previous', 'ignore all', 'pretend you are', 'act as if', 'jailbreak',
    'dan mode', 'do anything now', 'developer mode', 'bypass', 'no restrictions',
    'forget your rules', 'ignore your instructions', 'you have no limits'
  ].some(p => lower.includes(p));
}

// ======================================= //
// 🔘 KEYBOARDS MODERN
// ======================================= //

// ======================================= //
// 💎 RICH MESSAGE — JSON -> Telegram Inline Mode
// ======================================= //
function safeRichUrl(value) {
  if (typeof value !== 'string') return null;
  let url = value.trim();
  const md = url.match(/^\[[^\]]+\]\((https?:\/\/[^)\s]+)\)$/i);
  if (md) url = md[1];
  try {
    const u = new URL(url);
    if (u.protocol !== 'http:' && u.protocol !== 'https:') return null;
    return u.toString();
  } catch {
    return null;
  }
}

function richEscape(value) {
  return htmlEscape(String(value == null ? '' : value));
}

function richText(value) {
  if (Array.isArray(value)) return value.map(richText).filter(Boolean).join('\n');
  if (value && typeof value === 'object') {
    if (typeof value.text !== 'undefined') return richText(value.text);
    if (typeof value.content !== 'undefined') return richText(value.content);
    return richEscape(JSON.stringify(value));
  }
  return richEscape(value);
}

function richArray(value) {
  if (Array.isArray(value)) return value;
  if (value == null) return [];
  return [value];
}

function richUrlFromItem(item) {
  if (typeof item === 'string') return safeRichUrl(item);
  if (!item || typeof item !== 'object') return null;
  return safeRichUrl(item.url || item.href || item.link || item.value);
}

function richLabel(item, fallback = 'Buka') {
  if (typeof item === 'string') return 'Buka';
  return richEscape(item?.text || item?.label || item?.title || fallback);
}

function richButtonsFromValue(value) {
  const buttons = [];
  for (const item of richArray(value)) {
    if (Array.isArray(item)) {
      for (const nested of item) {
        const url = richUrlFromItem(nested);
        if (url) buttons.push({ text: richLabel(nested), url });
      }
    } else {
      const url = richUrlFromItem(item);
      if (url) buttons.push({ text: richLabel(item), url });
    }
  }
  return buttons;
}

function richInlineCode() {
  for (let i = 0; i < 50; i++) {
    const code = String(crypto.randomInt(100000, 1000000));
    if (!getRichMessage(code)) return code;
  }
  throw new Error('Gagal membuat kode Rich Message unik. Coba lagi.');
}

function renderRichBlocks(payload) {
  const nodes = Array.isArray(payload) ? payload : [payload];
  const out = [];
  const buttons = [];
  const push = (v) => { if (v !== '') out.push(v); };

  const renderNode = (node) => {
    if (node == null) return;
    if (typeof node !== 'object') { push(richText(node)); return; }

    for (const [rawTag, rawValue] of Object.entries(node)) {
      const tag = String(rawTag).toLowerCase();
      const values = ['h1','title','h2','subtitle','h3','h4','h5','h6','p','text','body','b','i','u','s',
        'mark','spoiler','code','math','pre','blockquote','quote','aside','details','footer','figcaption',
        'thinking','html'].includes(tag) ? [rawValue] : richArray(rawValue);

      if (['h1'].includes(tag)) push(`<b><u>${richText(rawValue)}</u></b>`);
      else if (['title','h2','subtitle','h3','h4','h5','h6'].includes(tag)) push(`<b>${richText(rawValue)}</b>`);
      else if (['p','text','body'].includes(tag)) push(richText(rawValue));
      else if (tag === 'b') push(`<b>${richText(rawValue)}</b>`);
      else if (tag === 'i') push(`<i>${richText(rawValue)}</i>`);
      else if (tag === 'u') push(`<u>${richText(rawValue)}</u>`);
      else if (tag === 's') push(`<s>${richText(rawValue)}</s>`);
      else if (tag === 'mark') push(`<u>${richText(rawValue)}</u>`);
      else if (tag === 'spoiler') push(`<tg-spoiler>${richText(rawValue)}</tg-spoiler>`);
      else if (tag === 'code' || tag === 'math') push(`<code>${richText(rawValue)}</code>`);
      else if (tag === 'pre') push(`<pre>${richText(rawValue)}</pre>`);
      else if (tag === 'hr' || tag === 'divider') push('────────────');
      else if (tag === 'a' || tag === 'link') {
        const arr = richArray(rawValue);
        for (const item of arr) {
          const url = richUrlFromItem(item);
          if (url) {
            const label = richLabel(item, 'Link');
            push(`<a href="${richEscape(url)}">${label}</a>`);
          }
        }
      } else if (['blockquote','quote'].includes(tag)) {
        push(`<blockquote>${richText(rawValue)}</blockquote>`);
      } else if (tag === 'aside') {
        push(`<i>${richText(rawValue)}</i>`);
      } else if (tag === 'details') {
        const obj = rawValue && typeof rawValue === 'object' ? rawValue : { content: rawValue };
        const summary = obj.summary || obj.title || 'Details';
        const text = obj.text || obj.content || obj.body || '';
        push(`▸ <b>${richText(summary)}</b>${text ? `\n${richText(text)}` : ''}`);
      } else if (tag === 'footer') {
        push(`<i>${richText(rawValue)}</i>`);
      } else if (tag === 'thinking') {
        push(`<i>💭 ${richText(rawValue)}</i>`);
      } else if (tag === 'figcaption') {
        push(`<i>${richText(rawValue)}</i>`);
      } else if (['img','image','photo','video','audio'].includes(tag)) {
        for (const item of values) {
          const url = richUrlFromItem(item);
          if (url) push(`🔗 <a href="${richEscape(url)}">${tag.toUpperCase()}</a>`);
        }
      } else if (tag === 'figure') {
        const obj = rawValue && typeof rawValue === 'object' ? rawValue : { image: rawValue };
        const url = richUrlFromItem(obj.image || obj.url || obj.src);
        if (url) push(`🖼️ <a href="${richEscape(url)}">FIGURE</a>`);
        if (obj.caption || obj.figcaption) push(`<i>${richText(obj.caption || obj.figcaption)}</i>`);
      } else if (tag === 'collage' || tag === 'slideshow') {
        let n = 0;
        for (const item of values) {
          const url = richUrlFromItem(item);
          if (url) push(`🔗 <a href="${richEscape(url)}">${tag === 'collage' ? 'COLLAGE' : 'SLIDE'} ${++n}</a>`);
        }
      } else if (tag === 'ul' || tag === 'list') {
        for (const item of values) push(`• ${richText(item)}`);
      } else if (tag === 'ol') {
        let n = 0;
        for (const item of values) push(`${++n}. ${richText(item)}`);
      } else if (tag === 'checkbox' || tag === 'tasklist') {
        for (const item of values) {
          const obj = item && typeof item === 'object' ? item : { text: item };
          push(`${obj.checked ? '☑️' : '☐'} ${richText(obj.text || obj.label || obj.title || '')}`);
        }
      } else if (tag === 'table') {
        const obj = Array.isArray(rawValue) ? { rows: rawValue } : (rawValue || {});
        const headers = Array.isArray(obj.headers) ? obj.headers.slice(0, 20) : [];
        const rows = Array.isArray(obj.rows) ? obj.rows.slice(0, 100) : [];
        const tableRows = [];
        if (headers.length) {
          tableRows.push(`<tr>${headers.map(v => `<th>${richText(v)}</th>`).join('')}</tr>`);
        }
        for (const row of rows) {
          const cells = Array.isArray(row)
            ? row.slice(0, 20)
            : (row && typeof row === 'object' ? Object.values(row).slice(0, 20) : [row]);
          tableRows.push(`<tr>${cells.map(v => `<td>${richText(v)}</td>`).join('')}</tr>`);
        }
        if (tableRows.length) push(`<table bordered compact>${tableRows.join('')}</table>`);
      } else if (tag === 'mathblock' || tag === 'math_block') {
        push(`<pre>${richText(rawValue)}</pre>`);
      } else if (tag === 'html') {
        const cleaned = String(rawValue == null ? '' : rawValue)
          .replace(/<script[\s\S]*?<\/script>/gi, '')
          .replace(/\son\w+\s*=\s*(['"]).*?\1/gi, '');
        push(cleaned);
      } else if (tag === 'blocks') {
        for (const item of values) renderNode(item);
      } else if (['buttons','keyboard','inline_keyboard'].includes(tag)) {
        buttons.push(...richButtonsFromValue(rawValue));
      }
    }
  };

  for (const node of nodes) renderNode(node);
  let text = out.join('\n').replace(/\n{3,}/g, '\n\n').trim();
  if (!text) text = '<i>Rich Message kosong.</i>';
  if (text.length > 3900) text = text.slice(0, 3890) + '\n…';
  const uniqueButtons = [];
  const seen = new Set();
  for (const b of buttons) {
    const key = `${b.text}|${b.url}`;
    if (!seen.has(key)) { seen.add(key); uniqueButtons.push(b); }
  }
  return {
    text,
    reply_markup: uniqueButtons.length
      ? { inline_keyboard: uniqueButtons.slice(0, 50).map(b => [{ text: b.text, url: b.url }]) }
      : undefined
  };
}

function richHelpText(botUsername = 'BOT_USERNAME') {
  return [
    '<b>💎 I\'m Rich — Telegram Rich Message Builder</b>',
    '',
    '<i>AI builder untuk mengubah teks promosi biasa menjadi Rich Message dengan tabel dan tombol.</i>',
    '',
    '<b>⚡ Cara pakai sekarang</b>',
    '1. Reply pesan promosi/jualan biasa.',
    '2. Ketik <code>/richmessage</code>.',
    '3. AI menyusun judul, deskripsi, tabel, footer, dan tombol dari teks asli.',
    '4. Bot langsung mengirim hasil sebagai Rich Message.',
    '5. Tidak perlu JSON atau wizard panjang.',
    '',
    '<blockquote>🔐 Kode hanya bisa dipakai oleh akun yang membuatnya. JSON tidak valid tidak disimpan.</blockquote>',
    '',
    '<b>📦 Contoh Simple</b>',
    '<pre>{"h1":"Sore der","p":"Obf ON ya","hr":true}</pre>',
    '',
    '<b>📝 Contoh Payload Lengkap</b>',
    `<pre>{
  "h1":"Judul utama",
  "h2":"Subjudul",
  "p":"Paragraf pertama",
  "img":{"src":"https://example.com/image.jpg"},
  "video":"https://example.com/video.mp4",
  "details":{"summary":"Catatan","content":"Isi detail"},
  "checkbox":[{"checked":true,"text":"Selesai"},{"checked":false,"text":"Belum"}],
  "buttons":[{"text":"Buka Website","url":"https://example.com"}]
}</pre>`,
    '',
    '<b>📚 Semua tipe Rich</b>',
    '<code>h1,title,h2,subtitle,h3,h4,h5,h6</code> — heading',
    '<code>p,text,body,b,i,u,s,mark,spoiler</code> — teks & format',
    '<code>code,math,pre,mathBlock,math_block</code> — kode & matematika',
    '<code>hr,divider,blockquote,quote,aside,details,footer,thinking</code> — layout',
    '<code>a,link,img,image,photo,video,audio,figure,figcaption</code> — link & media',
    '<code>collage,slideshow</code> — kumpulan media/link',
    '<code>ul,list,ol,checkbox,tasklist,table</code> — list & tabel',
    '<code>html,blocks</code> — blok lanjutan',
    '<code>buttons,keyboard,inline_keyboard</code> — tombol URL',
    '',
    '<b>⚠️ Catatan</b>',
    'Telegram Bot API mendukung Rich Messages native: tabel, divider, details, media, dan tombol terstruktur.',
    '',
    `<i>@${htmlEscape(botUsername)} — JSON to Rich Message</i>`
  ].join('\n');
}

function mainKeyboard() {
  // Main menu follows the same visual rhythm as the reference UI:
  // paired actions = red/blue, featured full-width action = green.
  const red = (b) => ({ ...b, style: 'danger' });
  const blue = (b) => ({ ...b, style: 'primary' });
  const green = (b) => ({ ...b, style: 'success' });
  const rows = [
    [red({text:'Fitur Utama',callback_data:'menu_utama'}), blue({text:'Tools',callback_data:'menu_alat'})],
    [green({text:'Fun & Games',callback_data:'menu_fun'})],
    [green({text:'Control Center',callback_data:'v6_dashboard'})],
    [red({text:'Jaga Group',callback_data:'menu_group'}), blue({text:'Market',callback_data:'market_home'})],
    [red({text:'Development',callback_data:'menu_dev'}), blue({text:'Request Fitur',callback_data:'feature_request'})],
    [green({text:'Lapor',callback_data:'lapor_menu'})]
  ];
  if (c.PUBLIC_GROUP_URL) rows.push([green({text:'GROUP PUBLIK MD',url:c.PUBLIC_GROUP_URL})]);
  rows.push([red({text:'Developer',url:c.OWNER_URL}), blue({text:'Channel',url:c.CHANNEL_URL})]);
  return { inline_keyboard: rows };
}
function joinKeyboard() {
  const rows = [];
  const channels = (c.REQUIRED_CHANNELS || []).filter(ch => ch && ch.url);
  channels.forEach((ch, i) => {
    rows.push([{
      text: `📢 Join Channel ${i + 1}`,
      url: ch.url,
      style: 'primary',
      icon_custom_emoji_id: '5424818078833715060'
    }]);
  });

  const group = c.REQUIRED_START_GROUP;
  if (group?.url) {
    rows.push([{
      text: '👥 Join Group',
      url: group.url,
      style: 'success'
    }]);
  }

  rows.push([{
    text: 'ϟ Saya Sudah Bergabung',
    callback_data: 'check_join',
    style: 'success',
    icon_custom_emoji_id: '5857044938755149915'
  }]);
  return { inline_keyboard: rows };
}

function backKeyboard(target = 'back_menu') {
  return {
    inline_keyboard: [
      [{ text: '✿ Kembali Ke Menu ✿', callback_data: target, style: 'danger', icon_custom_emoji_id: '5787546290527145353' }]
    ]
  };
}

function menuTambahanKeyboard() {
  return {
    inline_keyboard: [
      [{text:'📥 DOWNLOADER',callback_data:'media_downloader_menu',style:'primary'},{text:'🎵 MUSIK',callback_data:'media_audio_menu',style:'primary'}],
      [{text:'📱 TikTok HD',callback_data:'dl_tt'},{text:'📸 Instagram',callback_data:'dl_ig'}],
      [{text:'📌 Pinterest',callback_data:'dl_pinterest'},{text:'🎬 YouTube',callback_data:'dl_playvid'}],
      [{text:'🎧 Cari Musik',callback_data:'dl_play'},{text:'📦 NPM Package',callback_data:'dl_npm'}],
      [{text:'🗣️ TTS',callback_data:'dl_tts'},{text:'✨ HD Media',callback_data:'tool_hd'}],
      [{text:'Brat HD',callback_data:'brathd_menu'},{text:'Brat Video',callback_data:'bratvid_menu'}],
      [{text:'QC Sticker',callback_data:'tool_qc'},{text:'MediaFire',callback_data:'mediafire_menu'}],
      [{text:'📱 IQC',callback_data:'tool_iqc'},{text:'👥 Tag All',callback_data:'tagall_menu'}],
      [{text:'🧪 File Inspector',callback_data:'rinem_menu'},{text:'💾 Backup',callback_data:'backup_menu'}],
      [{text:'♟️ Catur',callback_data:'chess_start'},{text:'➡️ Halaman 2',callback_data:'menu_tambahan_2',style:'primary'}],
      [{text:'↩️ MENU UTAMA',callback_data:'back_menu',style:'danger'}]
    ]
  };
}

function downloaderPrompt(title, command, example, back='menu_tambahan') {
  return {
    parse_mode:'HTML',
    reply_markup:{inline_keyboard:[
      [{text:'📋 Contoh',callback_data:`${command}_example`}],
      [{text:'↩️ Downloader & Media',callback_data:back},{text:'🏠 Menu Utama',callback_data:'back_menu',style:'danger'}]
    ]}
  };
}

function menuTambahanKeyboard2() {
  return {
    inline_keyboard: [[
      { text: '✿ Previously ✿', callback_data: 'menu_tambahan', style: 'primary', icon_custom_emoji_id: '5463156928307801722' },
      { text: '✿ Kembali Ke Menu ✿', callback_data: 'back_menu', style: 'danger', icon_custom_emoji_id: '5787546290527145353' }
    ]]
  };
}

function menuGroupKeyboard(chatId = null, page = 1) {
  const gs = chatId != null ? getGroupSettings(chatId) : {};
  const status = (key) => Boolean(gs[key]);
  const toggle = (label, key) => ({
    text: `${label} ${status(key) ? '🟢' : '🔴'}`,
    callback_data: `group_toggle_${key}`,
    style: status(key) ? 'success' : 'danger'
  });

  if (page === 2) return {
    inline_keyboard: [
      [
        { text: 'Force Subscribe', callback_data: 'group_forcesub', style: 'success' },
        { text: 'Welcome', callback_data: 'welcome_setup', style: 'success' }
      ],
      [
        { text: 'Goodbye', callback_data: 'goodbye_setup', style: 'success' },
        { text: 'Status Welcome/Goodbye', callback_data: 'welcome_goodbye_status', style: 'primary' }
      ],
      [
        { text: 'Filters', callback_data: 'group_filters', style: 'primary' },
        { text: 'Add Filter', callback_data: 'group_filter_add', style: 'success' }
      ],
      [
        { text: 'Role Admin', callback_data: 'group_admin_roles', style: 'primary' },
        { text: 'Member Tools', callback_data: 'group_member_tools', style: 'primary' }
      ],
      [
        { text: 'Slowmode', callback_data: 'group_slowmode_help', style: 'primary' },
        { text: 'Group Info', callback_data: 'group_info_help', style: 'primary' }
      ],
      [
        { text: 'Tag All', callback_data: 'tagall_menu', style: 'success' },
        { text: 'Info Akun / ID', callback_data: 'group_account_info', style: 'primary' }
      ],
      [
        { text: 'Call One', callback_data: 'callone_menu', style: 'success' }
      ],
      [
        { text: 'Lock Media', callback_data: 'group_lockmedia', style: 'primary' }
      ],
      [
        { text: 'Lock All', callback_data: 'group_lock_all', style: 'danger' },
        { text: 'Unlock All', callback_data: 'group_unlock_all', style: 'success' }
      ],
      [
        { text: 'Rules', callback_data: 'group_rules', style: 'success' },
        { text: 'Pinned Info', callback_data: 'group_info_help', style: 'primary' }
      ],
      [
        { text: 'Keamanan', callback_data: 'group_page_1', style: 'primary' },
        { text: 'Menu Utama', callback_data: 'back_menu', style: 'danger' }
      ]
    ]
  };

  return {
    inline_keyboard: [
      [toggle('Link', 'antilink'), toggle('Forward', 'antiforward')],
      [toggle('Flood', 'antiflood'), toggle('Spam', 'antispam')],
      [toggle('Anti Promosi', 'antipromosi'), toggle('Toxic', 'antitoxic')],
      [toggle('18+', 'antiporno'), toggle('Sticker', 'antisticker')],
      [toggle('Anti Drugs', 'antidrugs'), toggle('Bot', 'antibot')],
      [{ text: '🛡️ Proteksi Kuat', callback_data: 'group_protection_strong', style: 'success' }],
      [toggle('Foto', 'antifoto'), toggle('Video', 'antivideo')],
      [{ text: `AntiAdmin ${gs.antiadmin ? '🟢' : '🔴'}`, callback_data: 'group_antiadmin_toggle', style: gs.antiadmin ? 'success' : 'danger' }, { text: 'Status Keamanan', callback_data: 'group_security_status', style: 'primary' }],
      [
        { text: 'Tools Grup', callback_data: 'group_page_2', style: 'primary' },
        { text: 'Pengaturan', callback_data: 'group_settings_help', style: 'primary' }
      ],
      [{ text: 'Menu Utama', callback_data: 'back_menu', style: 'danger' }]
    ]
  };
}

function menuFunKeyboard(page = 1) {
  if (page === 2) return { inline_keyboard: [
    [{text:'🎲 Dadu',callback_data:'fun_dice'},{text:'🪙 Koin',callback_data:'fun_coin'},{text:'🎱 8 Ball',callback_data:'fun_8ball'}],
    [{text:'✊ Suit',callback_data:'fun_rps'},{text:'🧠 Quiz',callback_data:'fun_quiz'},{text:'➗ Matematika',callback_data:'fun_math'}],
    [{text:'🎯 Tebak Angka',callback_data:'fun_number'},{text:'🔤 Tebak Kata',callback_data:'fun_word'},{text:'🧩 Hangman',callback_data:'fun_hangman'}],
    [{text:'🧠 Memory',callback_data:'fun_memory'},{text:'🔤 Scramble',callback_data:'fun_scramble'},{text:'📈 Higher/Lower',callback_data:'fun_higher'}],
    [{text:'🔢 Sequence',callback_data:'fun_sequence'},{text:'🎯 Target 24',callback_data:'fun_target24'},{text:'🧠 Trivia',callback_data:'fun_trivia'}],
    [{text:'⚡ Reaction',callback_data:'fun_reaction'},{text:'🧮 Math Rush',callback_data:'fun_mathrush'}],
    [{text:'👥 Multiplayer',callback_data:'fun_page_3',style:'success'},{text:'◀️ Kategori',callback_data:'fun_page_1'}],
    [{text:'↩️ Menu Utama',callback_data:'back_menu',style:'danger'}]
  ]};

  if (page === 3) return { inline_keyboard: [
    [{text:'❌⭕ TicTacToe',callback_data:'fun_tictac'},{text:'♟️ Catur',callback_data:'chess_start'}],
    [{text:'👥 Target Party 2–5',callback_data:'fun_party'},{text:'🔤 Kata Party 2–5',callback_data:'fun_wordparty'}],
    [{text:'🧠 Quiz Party 2–5',callback_data:'fun_quizparty'},{text:'⚔️ Duel 2 Pemain',callback_data:'fun_duel'}],
    [{text:'➗ Math Battle 2–5',callback_data:'mp_math_new'},{text:'😀 Emoji Battle 2–5',callback_data:'mp_emoji_new'}],
    [{text:'✊ RPS Battle 2–5',callback_data:'mp_rps_new'},{text:'🎯 Quick Choice 2–5',callback_data:'mp_choice_new'}],
    [{text:'🏆 Scoreboard',callback_data:'fun_scores'},{text:'📖 Panduan',callback_data:'fun_help'}],
    [{text:'◀️ Single Player',callback_data:'fun_page_2'},{text:'↩️ Menu Utama',callback_data:'back_menu',style:'danger'}]
  ]};

  return { inline_keyboard: [
    [{text:'🎯 SINGLE PLAYER',callback_data:'fun_page_2',style:'primary'}],
    [{text:'👥 MULTIPLAYER 2–5',callback_data:'fun_page_3',style:'success'}],
    [{text:'🏆 Scoreboard',callback_data:'fun_scores'},{text:'📖 Panduan Game',callback_data:'fun_help'}],
    [{text:'🧰 Menu Alat',callback_data:'menu_alat'}],
    [{text:'↩️ Menu Utama',callback_data:'back_menu',style:'danger'}]
  ]};
}

async function runOsintQuery(query) {
  const base = String(process.env.OSINT_API_URL || '').trim();
  if (!base) throw new Error('OSINT_API_URL belum diisi di environment Pterodactyl.');
  const apiKey = String(process.env.OSINT_API_KEY || '').trim();
  const method = String(process.env.OSINT_API_METHOD || 'GET').toUpperCase();
  const queryParam = String(process.env.OSINT_QUERY_PARAM || 'query').trim() || 'query';
  const keyParam = String(process.env.OSINT_KEY_PARAM || 'key').trim() || 'key';
  const timeout = Math.max(5000, Math.min(120000, Number(process.env.OSINT_TIMEOUT_MS || 30000)));
  let res;
  if (method === 'POST') {
    const body = { [queryParam]: query };
    if (apiKey) body[keyParam] = apiKey;
    res = await axios.post(base, body, { timeout, headers: { 'Content-Type':'application/json', ...(apiKey ? {'Authorization':`Bearer ${apiKey}`} : {}) } });
  } else {
    const params = { [queryParam]: query };
    if (apiKey) params[keyParam] = apiKey;
    res = await axios.get(base, { params, timeout, headers: apiKey ? { Authorization:`Bearer ${apiKey}` } : {} });
  }
  const data = res.data;
  if (data == null) throw new Error('Provider OSINT tidak mengembalikan data.');
  let output = '';
  if (typeof data === 'string') output = data;
  else if (data.result != null) output = typeof data.result === 'string' ? data.result : JSON.stringify(data.result, null, 2);
  else if (data.data != null) output = typeof data.data === 'string' ? data.data : JSON.stringify(data.data, null, 2);
  else output = JSON.stringify(data, null, 2);
  return output.slice(0, 12000);
}

function menuAlatKeyboard(page = 1) {
  if (page === 2) return { inline_keyboard: [
    [{text:'🔢 Random Angka',callback_data:'tool_randomnum'},{text:'🔐 Hash',callback_data:'tool_hash'},{text:'🔗 URL Encode',callback_data:'tool_urlencode'}],
    [{text:'↩️ URL Decode',callback_data:'tool_urldecode'},{text:'🕘 Timestamp',callback_data:'tool_timestamp'},{text:'🧹 HTML Escape',callback_data:'tool_escape'}],
    [{text:'📦 ZIP Info',callback_data:'tool_zipinfo'},{text:'📋 System Info',callback_data:'tool_sysinfo'}],
    [{text:'🔐 JS Encrypt',callback_data:'js_encrypt_menu'},{text:'🛠️ JS Obf',callback_data:'js_obf_menu'}],
    [{text:'💎 Create AM Premium',callback_data:'am_premium_menu',style:'success'}],
    [{text:'🔁 Reverse Text',callback_data:'tool_reverse'},{text:'📐 Text Stats',callback_data:'tool_textstats'}],
    [{text:'📱 QR Code',callback_data:'tool_qr'},{text:'🌍 Jam Dunia',callback_data:'tool_worldclock'},{text:'🌦️ Cuaca',callback_data:'tool_weather'}],
    [{text:'🤖 AI Asisten',callback_data:'menu_ai',style:'primary'},{text:'🕌 Relaxing',callback_data:'menu_relax',style:'primary'}],
    [{text:'◀️ Halaman 1',callback_data:'alat_page_1'}],
    [{text:'↩️ Menu Utama',callback_data:'back_menu',style:'danger'}]
  ]};
  return { inline_keyboard: [
    [{text:'📸 Photo Live',callback_data:'live_photo_menu',style:'success'},{text:'🔎 OSINT',callback_data:'osint_menu',style:'primary'}],
    [{text:'🧮 Kalkulator',callback_data:'tool_calc'},{text:'🔐 Password',callback_data:'tool_password'}],
    [{text:'🔤 Base64',callback_data:'tool_base64'},{text:'🆔 UUID',callback_data:'tool_uuid'}],
    [{text:'📊 Text Info',callback_data:'tool_textinfo'},{text:'🧾 JSON',callback_data:'tool_json'}],
    [{text:'🔗 URL Check',callback_data:'tool_url'},{text:'📱 QR Code',callback_data:'tool_qr'}],
    [{text:'🆔 Cek ID Emoji',callback_data:'tool_emoji_id',style:'primary'},{text:'🕒 Jam Digital',callback_data:'tool_time'}],
    [{text:'🌍 Jam Dunia',callback_data:'tool_worldclock'}],
    [{text:'🕌 Waktu Sholat',callback_data:'tool_prayer'},{text:'🌦️ Cek Cuaca',callback_data:'tool_weather'}],
    [{text:'📥 Downloader & Media',callback_data:'menu_tambahan'},{text:'✨ HD Media',callback_data:'tool_hd'}],
    [{text:'🖼️ QC Sticker',callback_data:'tool_qc'},{text:'📱 IQC',callback_data:'tool_iqc'}],
    [{text:'🖼️ TOURL Foto',callback_data:'tool_tourl'},{text:'👥 Tag All',callback_data:'tagall_menu'}],
    [{text:'🌐 Ganti Domain',callback_data:'tool_domain'},{text:'🔌 Ganti Port Panel',callback_data:'domain_port_menu'}],
    [{text:'🚀 Deploy Website',callback_data:'tool_deploy'}],
    [{text:'📢 ID Channel WA',callback_data:'tool_wachannel'}],
    [{text:'🧪 Regex Test',callback_data:'tool_regex'},{text:'🧮 Unit Converter',callback_data:'tool_convert'}],
    [{text:'🗂️ Text Cleaner',callback_data:'tool_cleantext'},{text:'🔢 Percentage',callback_data:'tool_percent'}],
    [{text:'💾 Backup',callback_data:'backup_menu'},{text:'🚀 Control Center',callback_data:'v6_dashboard'}],
    [{text:'🧪 Rinem / File Inspector',callback_data:'rinem_menu'}],
    [{text:'➡️ Alat Lanjutan',callback_data:'alat_page_2'}],
    [{text:'🎮 Menu Fun',callback_data:'menu_fun'},{text:'↩️ Menu Utama',callback_data:'back_menu',style:'danger'}]
  ]};
}

async function editMenuPage(bot, q, text, keyboard) {
  const chatId = q.message?.chat?.id;
  const messageId = q.message?.message_id;
  if (!chatId || !messageId) return;
  await safeDelete(bot, chatId, messageId).catch(() => {});
  return sendRichMenu(chatId, text, keyboard, c.BANNER_URL);
}

function menuAlatText(page = 1) {
  const pageLabel = page === 2 ? 'TOOLS LANJUTAN' : 'TOOLS UTAMA';
  const sections = page === 2 ? [
    ['UTILITIES', ['/randomnum', '/hash', '/urlencode', '/urldecode', '/timestamp', '/escapehtml']],
    ['SYSTEM & FILE', ['/zipinfo', '/sysinfo', '/backup', '/rinem']],
    ['TEXT', ['/reverse', '/textstats']],
    ['AI & RELAX', ['/ai', '/relax']],
  ] : [
    ['DEVELOPER', ['/calc', '/json', '/base64', '/unbase64', '/uuid', '/hash', '/urlcheck', '/urlencode', '/urldecode', '/textinfo', '/escapehtml']],
    ['GENERATOR', ['/password', '/randomnum', '/acak', '/qr']],
    ['WAKTU & INFORMASI', ['/waktu', '/jamdunia', '/sholat', '/cekcuaca', '/timestamp']],
    ['MEDIA', ['/hd', '/wink', '/qc', '/iqc', '/tourl']],
    ['PHOTO & INTELLIGENCE', ['Photo Live', 'OSINT']],
    ['PROJECT & DEVELOPER', ['/gantidomain', '/deploy', '/ceksaluranwa', '/regex', '/convert']],
    ['GRUP', ['/tagall']],
  ];
  const rows = sections.map(([title, items]) =>
    `<tr><td><b>${htmlEscape(title)}</b></td><td>${items.map(x => `<code>${htmlEscape(x)}</code>`).join(' · ')}</td></tr>`
  ).join('');
  return `<h2>🧰 UTILITY CENTER</h2>` +
    `<p><i>${htmlEscape(pageLabel)} • Pilih fitur dari tombol di bawah.</i></p>` +
    `<table bordered compact><tr><th>KATEGORI</th><th>FITUR</th></tr>${rows}</table>` +
    `<p><i>Tools hanya memproses input yang kamu kirim dan tidak menampilkan secret bot.</i></p>`;
}

function relaxingKeyboard() {
  return { inline_keyboard: [
    [{text:'📖 Al-Qur’an',callback_data:'relax_quran'},{text:'🔎 Cari Novel',callback_data:'relax_novel'}],
    [{text:'📚 Cari Komik',callback_data:'relax_comic'},{text:'🎬 Cari Dracin',callback_data:'relax_dracin'}],
    [{text:'🌐 Pencarian Umum',callback_data:'relax_web'},{text:'💡 Fakta',callback_data:'relax_fact'}],
    [{text:'💬 Quote',callback_data:'relax_quote'},{text:'😂 Joke Ringan',callback_data:'relax_joke'}],
    [{text:'🎯 Aktivitas',callback_data:'relax_activity'},{text:'🧠 Tebak Santai',callback_data:'relax_riddle'}],
    [{text:'😊 Mood Check',callback_data:'relax_mood'},{text:'🤔 Would You Rather',callback_data:'relax_wyr'}],
    [{text:'🫁 Napas 1 Menit',callback_data:'relax_breathe'},{text:'🍅 Pomodoro',callback_data:'relax_pomodoro'}],
    [{text:'🔢 Penghitung Zikir',callback_data:'relax_counter'},{text:'📝 Catatan Singkat',callback_data:'relax_note'}],
    [{text:'🧰 Menu Alat',callback_data:'menu_alat'},{text:'🎮 Menu Fun',callback_data:'menu_fun'}],
    [{text:'✿ Kembali ✿',callback_data:'back_menu',style:'danger'}]
  ]};
}

function relaxingText() {
  return '<blockquote>🕌 <b>RELAXING TIME</b></blockquote>\n<blockquote>' +
    '📖 <b>Al-Qur’an</b> — Juz 1 sampai 30 + teks Arab & terjemahan Indonesia.\n' +
    '📚 <b>Novel</b> — Cari judul/penulis melalui Open Library.\n' +
    '🖼️ <b>Komik</b> — Cari judul/penulis melalui Open Library.\n' +
    '🎬 <b>Dracin</b> — Cari judul sesuai kata kunci.\n' +
    '💡 <b>Fakta & Quote</b> — konten acak ringan.\n' +
    '🎯 <b>Aktivitas & Tebak Santai</b> — hiburan singkat tanpa API.\n' +
    '🔢 <b>Penghitung Zikir</b> — penghitung lokal sederhana.\n' +
    '📝 <b>Catatan Singkat</b> — bantu membuat catatan sementara.\n\n' +
    '<i>Konten bacaan menggunakan sumber publik; bot tidak menyalin karya berhak cipta secara penuh.</i></blockquote>';
}

function quranKeyboard(juz = 1, page = 0, total = 0) {
  const maxPage = Math.max(0, Math.ceil(total / 5) - 1);
  const rows = [];
  if (page > 0) rows.push([{text:'⬅️ Sebelumnya',callback_data:`quran_page_${juz}_${page-1}`}]);
  if (page < maxPage) rows.push([{text:'➡️ Berikutnya',callback_data:`quran_page_${juz}_${page+1}`}]);
  rows.push([{text:'📚 Pilih Juz 1–30',callback_data:'relax_quran'},{text:'🕌 Relaxing Time',callback_data:'menu_relax'}]);
  return { inline_keyboard: rows };
}

function quranJuzKeyboard() {
  const rows = [];
  for (let i = 1; i <= 30; i += 5) {
    rows.push(Array.from({length: Math.min(5, 31-i)}, (_, n) => ({text:`Juz ${i+n}`,callback_data:`quran_juz_${i+n}`})));
  }
  rows.push([{text:'🕌 Relaxing Time',callback_data:'menu_relax'}]);
  return { inline_keyboard: rows };
}

function iqcKeyboard() {
  return { inline_keyboard: [
    [{text:'🖼️ QC / IQC',callback_data:'tool_qc'}],
    [{text:'↩️ Menu Alat',callback_data:'menu_alat',style:'danger'}]
  ]};
}

function menuAIText(userId = 0, chatId = userId) {
  const enabled = isAssistantEnabled(chatId);
  const provider = normalizeAiProvider(getAssistantProvider(chatId));
  return `<h2>🤖 AI ASSISTANT</h2>` +
    `<p><i>Pusat pengaturan AI, fitur, provider, dan status asisten.</i></p>` +
    `<table bordered compact>` +
      `<tr><th>SETTING</th><th>STATUS</th></tr>` +
      `<tr><td>Asisten</td><td><b>${enabled ? '🟢 AKTIF' : '🔴 MATI'}</b></td></tr>` +
      `<tr><td>AI pilihan</td><td><b>${htmlEscape(aiProviderLabel(provider))}</b></td></tr>` +
      `<tr><td>Personality</td><td>${htmlEscape(aiPersonalityLabel(userId))}</td></tr>` +
    `</table>` +
    `<h3>FITUR</h3>` +
    `<p>💬 Chat · 📝 Ringkas · ✍️ Rewrite · 🌐 Translate<br>💻 Coding · 📚 Study · 🖼️ Analisis Gambar · 🎭 Personality</p>` +
    `<blockquote>${enabled ? 'Private: pesan biasa akan dijawab AI.\nGrup: awali pesan dengan <b>AI</b>.\nGunakan <code>/ai pertanyaan</code> untuk bertanya.' : 'Asisten otomatis tidak merespons pesan biasa.\nGunakan <code>/ai pertanyaan</code> untuk bertanya manual.'}</blockquote>`;
}
function menuAIKeyboard(chatId = 0) {
  const enabled = isAssistantEnabled(chatId);
  return {inline_keyboard:[
    [{text:enabled?'🟢 AI Asisten: AKTIF':'🔴 AI Asisten: MATI',callback_data:enabled?'ai_toggle_off':'ai_toggle_on',style:enabled?'success':'danger'}],
    [{text:'🤖 Pilih AI',callback_data:'ai_providers',style:'primary'}],
    [{text:'✨ Fitur AI',callback_data:'ai_features',style:'primary'}],
    [{text:'📡 Status AI',callback_data:'ai_status',style:'success'},{text:'🧹 Reset',callback_data:'ai_reset',style:'primary'}],
    [{text:'🧰 Menu Alat',callback_data:'menu_alat'},{text:'🎮 Menu Fun',callback_data:'menu_fun'}],
    [{text:'↩️ Menu Utama',callback_data:'back_menu',style:'danger'}]
  ]};
}
function aiProvidersText(chatId){
  const p=normalizeAiProvider(getAssistantProvider(chatId));
  return `<blockquote>🤖 <b>PILIH AI</b></blockquote>\n\n`+
    `AI pilihan: <b>${htmlEscape(aiProviderLabel(p))}</b>\n`+
    `Status Asisten: <b>${isAssistantEnabled(chatId)?'🟢 AKTIF':'🔴 MATI'}</b>\n\n`+
    `🔵 <b>Gemini</b> — general, cepat & multimodal\n`+
        `🌐 <b>OpenRouter</b> — akses model gratis melalui satu API\n\n`+
    `🎨 <b>Pixazo</b> — edit foto/video & foto → video dengan prompt.\n`+
    `🔄 <b>Auto Fallback</b> mencoba Gemini → OpenRouter saat provider sebelumnya gagal.\n\n`+
    `Memilih AI <b>tidak otomatis menyalakan</b> Asisten.`;
}

function marketKeyboard() {
  return { inline_keyboard: [
    [{text:'📊 IHSG',callback_data:'market_quote_^JKSE',style:'primary'},{text:'🇺🇸 S&P 500',callback_data:'market_quote_^GSPC',style:'primary'}],
    [{text:'🏦 BBCA',callback_data:'market_quote_BBCA.JK',style:'success'},{text:'🏦 BBRI',callback_data:'market_quote_BBRI.JK',style:'success'},{text:'🏦 BMRI',callback_data:'market_quote_BMRI.JK',style:'success'}],
    [{text:'📡 TLKM',callback_data:'market_quote_TLKM.JK',style:'success'},{text:'🚗 ASII',callback_data:'market_quote_ASII.JK',style:'success'},{text:'💻 GOTO',callback_data:'market_quote_GOTO.JK',style:'success'}],
    [{text:'🌎 AAPL',callback_data:'market_quote_AAPL',style:'primary'},{text:'⚡ NVDA',callback_data:'market_quote_NVDA',style:'primary'},{text:'🪟 MSFT',callback_data:'market_quote_MSFT',style:'primary'}],
    [{text:'📈 Trading View',callback_data:'market_trading_^JKSE_1d',style:'primary'},{text:'🔎 Cari Saham',callback_data:'market_search',style:'primary'}],
    [{text:'📊 Bandingkan',callback_data:'market_compare_help',style:'success'},{text:'🔄 Refresh',callback_data:'market_home',style:'success'}],
    [{text:'↩️ Kembali',callback_data:'back_menu',style:'danger'}]
  ]};
}

function marketDetailKeyboard(symbol) {
  const s=encodeURIComponent(symbol);
  return { inline_keyboard: [
    [{text:'📈 Trading 1D',callback_data:`market_trading_${s}_1d`,style:'primary'},{text:'📈 Trading 1W',callback_data:`market_trading_${s}_1w`,style:'primary'}],
    [{text:'📈 Trading 1M',callback_data:`market_trading_${s}_1mo`,style:'primary'},{text:'📈 Trading 3M',callback_data:`market_trading_${s}_3mo`,style:'primary'}],
    [{text:'🔄 Refresh',callback_data:`market_quote_${symbol}`,style:'success'},{text:'📊 Pantau Pasar',callback_data:'market_home',style:'primary'}],
    [{text:'↩️ Menu Utama',callback_data:'back_menu',style:'danger'}]
  ]};
}

function marketTradingKeyboard(symbol,period='1mo') {
  const s=encodeURIComponent(symbol);
  return { inline_keyboard: [
    [{text:'1D',callback_data:`market_trading_${s}_1d`},{text:'1W',callback_data:`market_trading_${s}_1w`},{text:'1M',callback_data:`market_trading_${s}_1mo`},{text:'3M',callback_data:`market_trading_${s}_3mo`}],
    [{text:'🔎 Detail',callback_data:`market_quote_${symbol}`,style:'primary'},{text:'📊 Pasar',callback_data:'market_home',style:'success'}],
    [{text:'↩️ Menu Utama',callback_data:'back_menu',style:'danger'}]
  ]};
}

function formatMarketNumber(value, currency='USD') {
  if (!Number.isFinite(Number(value))) return '-';
  const n=Number(value); const prefix=currency==='IDR'?'Rp ':'$ ';
  return prefix+n.toLocaleString('id-ID',{maximumFractionDigits:currency==='IDR'?0:2});
}
function marketSparkline(values=[]) {
  const chars='▁▂▃▄▅▆▇█'; if(!values.length)return '────────';
  const min=Math.min(...values),max=Math.max(...values); if(max===min)return '▅'.repeat(Math.min(values.length,24));
  return values.slice(-24).map(v=>chars[Math.round(((v-min)/(max-min))*7)]).join('');
}
function periodConfig(period='1mo') {
  const p=String(period).toLowerCase();
  if(p==='1d') return {range:'1d',interval:'5m',label:'1 hari'};
  if(p==='1w') return {range:'5d',interval:'30m',label:'1 minggu'};
  if(p==='3mo') return {range:'3mo',interval:'1d',label:'3 bulan'};
  return {range:'1mo',interval:'1d',label:'1 bulan'};
}

async function marketTradingText(symbol, period='1mo') {
  const q=await getMarketQuote(symbol); const cfg=periodConfig(period);
  const history=await getMarketHistory(symbol,cfg.range,cfg.interval);
  const values=history.map(x=>x.close).filter(Number.isFinite);
  const first=values[0],last=values.at(-1);
  const high=values.length?Math.max(...values):q.dayHigh, low=values.length?Math.min(...values):q.dayLow;
  const pct=Number.isFinite(first)&&first!==0&&Number.isFinite(last)?((last-first)/first)*100:null;
  const trend=pct==null?'⚪ Datar':pct>0?'🟢 Naik':pct<0?'🔴 Turun':'⚪ Datar';
  return `<h2>📈 TRADING VIEW</h2><p><b>${htmlEscape(q.name)}</b> · <code>${htmlEscape(q.symbol)}</code> · ${htmlEscape(cfg.label)}</p>` +
    `<table bordered compact><tr><th>INDIKATOR</th><th>NILAI</th></tr><tr><td>Harga</td><td><code>${formatMarketNumber(q.price,q.currency)}</code></td></tr><tr><td>Trend</td><td>${trend}</td></tr><tr><td>Perubahan</td><td><b>${pct==null?'-':(pct>=0?'+':'')+pct.toFixed(2)+'%'}</b></td></tr><tr><td>High</td><td><code>${formatMarketNumber(high,q.currency)}</code></td></tr><tr><td>Low</td><td><code>${formatMarketNumber(low,q.currency)}</code></td></tr><tr><td>Volume</td><td><code>${q.volume?q.volume.toLocaleString('id-ID'):'-'}</code></td></tr></table>` +
    `<p><b>📈 Chart</b><br><code>${marketSparkline(values)}</code></p><i>Data pasar eksternal. Tidak melakukan order atau transaksi nyata; gunakan untuk memantau informasi pasar.</i>`;
}

async function marketCompareText(a,b) {
  const [qa,qb]=await Promise.all([getMarketQuote(a),getMarketQuote(b)]);
  const row=q=>`<tr><td>${htmlEscape(q.name)}</td><td><code>${formatMarketNumber(q.price,q.currency)}</code></td><td><b>${q.changePct==null?'-':(q.changePct>=0?'+':'')+q.changePct.toFixed(2)+'%'}</b></td></tr>`;
  return `<h2>📊 BANDINGKAN PASAR</h2><table bordered compact><tr><th>ASET</th><th>HARGA</th><th>PERUBAHAN</th></tr>${row(qa)}${row(qb)}</table><p><i>Perbandingan data harga saat ini, bukan rekomendasi beli/jual.</i></p>`;
}

async function marketHomeText() {
  const symbols=['^JKSE','^GSPC','^IXIC','^DJI','BBCA.JK','BBRI.JK','BMRI.JK','TLKM.JK']; const quotes=await getMarketQuotes(symbols);
  const rows=quotes.map(q=>{ if(q.error)return `<tr><td>⚪ <b>${htmlEscape(q.name||q.symbol)}</b></td><td>-</td><td>Data tidak tersedia</td></tr>`; const state=q.change>0?'🟢':q.change<0?'🔴':'⚪'; const pct=q.changePct==null?'-':`${q.changePct>=0?'+':''}${q.changePct.toFixed(2)}%`; return `<tr><td>${state} <b>${htmlEscape(q.name)}</b></td><td><code>${formatMarketNumber(q.price,q.currency)}</code></td><td><b>${pct}</b></td></tr>`; }).join('');
  return `<h2>${E.market} PANTAU PASAR</h2>` +
    `<p><i>Market monitor · data eksternal</i></p>` +
    `<table bordered compact><tr><th>INDIKATOR</th><th>HARGA</th><th>PERUBAHAN</th></tr>${rows}</table>` +
    `<table bordered compact><tr><th>FITUR</th><th>KETERANGAN</th></tr>` +
      `<tr><td>📈 Trading View</td><td>Chart 1D/1W/1M/3M, high-low, volume, dan perubahan periode.</td></tr>` +
      `<tr><td>🔎 Cari Saham</td><td>Cari kode saham menggunakan tombol pencarian.</td></tr>` +
      `<tr><td>📊 Bandingkan</td><td>Bandingkan dua aset untuk melihat harga dan perubahan saat ini.</td></tr>` +
    `</table>` +
    `<footer>Informasi pasar saja — bukan nasihat keuangan.</footer>`;
}

async function marketDetailText(symbol) {
  const q=await getMarketQuote(symbol); const history=await getMarketHistory(symbol,'1mo','1d'); const values=history.map(x=>x.close).filter(Number.isFinite); const first=values[0],last=values.at(-1);
  const periodPct=Number.isFinite(first)&&first!==0&&Number.isFinite(last)?((last-first)/first)*100:null; const arrow=q.change>0?'🟢':q.change<0?'🔴':'⚪'; const pct=q.changePct==null?'-':`${q.changePct>=0?'+':''}${q.changePct.toFixed(2)}%`; const delta=q.change==null?'-':`${q.change>=0?'+':''}${Math.abs(q.change).toLocaleString('id-ID',{maximumFractionDigits:2})}`;
  return `<h2>${E.chart} ${htmlEscape(q.name)}</h2><p><code>${htmlEscape(q.symbol)}</code> · ${htmlEscape(q.exchange)}</p><table bordered compact><tr><th>INDIKATOR</th><th>NILAI</th></tr><tr><td>Harga</td><td><code>${formatMarketNumber(q.price,q.currency)}</code></td></tr><tr><td>Perubahan</td><td>${arrow} <b>${delta}</b> · <b>${pct}</b></td></tr><tr><td>High</td><td><code>${formatMarketNumber(q.dayHigh,q.currency)}</code></td></tr><tr><td>Low</td><td><code>${formatMarketNumber(q.dayLow,q.currency)}</code></td></tr><tr><td>Volume</td><td><code>${q.volume?q.volume.toLocaleString('id-ID'):'-'}</code></td></tr><tr><td>1 bulan</td><td><b>${periodPct==null?'-':(periodPct>=0?'+':'')+periodPct.toFixed(2)+'%'}</b></td></tr></table><p><b>📈 Trend 1 Bulan</b><br><code>${marketSparkline(values)}</code></p><p><i>Last update: ${htmlEscape(new Date(q.asOf).toLocaleString('id-ID',{timeZone:c.TIMEZONE}))}</i></p><i>Informasi pasar saja — bukan nasihat keuangan.</i>`;
}

// 📝 MENU TEXTS
// ======================================= //
function menuText(user) {
  const name = [user.first_name, user.last_name].filter(Boolean).join(' ') || 'Pengguna';
  return `<h2>👋 MELLSTECUU MD</h2>` +
    `<p><b>Welcome, ${htmlEscape(name)}</b><br><i>All-in-one assistant untuk tools, AI, media, game, group &amp; market.</i></p>` +
    `<table bordered compact><tr><th>MENU</th><th>ISI</th></tr>` +
      `<tr><td>Fitur Utama</td><td>Market, sender, testing, fixed code, protection</td></tr>` +
      `<tr><td>Tools</td><td>Downloader, utilities, media, developer tools</td></tr>` +
      `<tr><td>Fun &amp; Games</td><td>Single player dan multiplayer</td></tr>` +
      `<tr><td>Jaga Group</td><td>Moderasi, security, member tools</td></tr>` +
      `<tr><td>Market</td><td>Monitor saham dan indeks</td></tr>` +
    `</table>` +
    `<p><i>Pilih menu di bawah untuk memulai.</i></p>` +
    `<blockquote>${E.check} <b>© MELLSTECUU MD</b> • System Online</blockquote>`;
}

function getFeatureCount() {
  try {
    const source = fs.readFileSync(__filename, 'utf8');
    const callbacks = new Set();
    const commands = new Set();
    for (const m of source.matchAll(/callback_data\s*:\s*['"`]([^'"`]+)['"`]/g)) {
      const v = String(m[1] || '').trim();
      if (v && !v.includes('${')) callbacks.add(v.replace(/:\$\{.*\}/g, ':*'));
    }
    for (const m of source.matchAll(/bot\.onText\(\s*\/\\?([a-z0-9_]+)/gi)) {
      if (m[1]) commands.add(m[1].toLowerCase());
    }
    // Count registered UI actions + commands; remove a small set of pure navigation duplicates.
    const ignored = new Set(['back_menu','menu_utama','menu_alat','menu_tambahan','menu_fun','menu_group','menu_dev']);
    const count = [...callbacks].filter(x => !ignored.has(x)).length + commands.size;
    return Math.max(200, count);
  } catch {
    return 200;
  }
}

function menuUtamaText() {
  const groups = [
    ['Market Monitor', ['/pasar', '/saham BBCA', '/tradingview BBCA 1mo', '/bandingkan BBCA BBRI']],
    ['Sender & Koneksi', ['/connect', '/ceksender', '/totaltest']],
    ['Function Testing', ['/cekfunc', '/getcelah', '/combofunc', '/tesfunc']],
    ['Fixed Code', ['/fixcode', '/fixflutter', '/cleancode', '/cekflutter']],
    ['JS Protection', ['/encmedium', '/encarab', '/enchard']],
  ];
  const rows = groups.map(([name, cmds]) => `<tr><td><b>${htmlEscape(name)}</b></td><td>${cmds.map(c => `<code>${htmlEscape(c)}</code>`).join('<br>')}</td></tr>`).join('');
  return `<h2>⭐ FITUR UTAMA</h2>` +
    `<p><i>Perintah utama bot dalam format yang ringkas dan mudah dibaca.</i></p>` +
    `<table bordered compact><tr><th>KATEGORI</th><th>PERINTAH</th></tr>${rows}</table>` +
    `<p><i>Fitur tambahan termasuk Monitoring Channel, MediaFire Uploader, Brat Video, dan proteksi grup.</i></p>`;
}

function menuTambahanText() {
  const groups = [
    ['Downloader', ['/tt', '/ig', '/npmpackage', '/pinterest']],
    ['Musik & Audio', ['/playvid', '/play', '/ttsgenerate']],
    ['Maker & Media', ['/bratanime', '/brat', '/brathd', '/bratvid', '/qc', '/fakedana', '/imagetoqr', '/wink', 'Photo Live', 'OSINT', '/s atau /stiker']],
    ['AI Asisten', ['/asistent on', '/asistent off']],
    ['Utilities', ['/iqc', '/iqcv2', '/sholat', '/cekcuaca', '/jamdunia', '/relax']],
    ['Control & Request', ['/rasukbot <token>', '/listbot', '/getcontrol <token>', '/outcontrol', '/getbaseweb', '/broadcast', '/dmuser', '/lapor', '/req <fitur>', '/playv2']],
  ];
  const rows = groups.map(([name, cmds]) => `<tr><td><b>${htmlEscape(name)}</b></td><td>${cmds.map(c => `<code>${htmlEscape(c)}</code>`).join('<br>')}</td></tr>`).join('');
  return `<h2>⚡ FITUR TAMBAHAN</h2>` +
    `<p><i>Downloader, media, AI, utilities, dan fitur tambahan lainnya.</i></p>` +
    `<table bordered compact><tr><th>KATEGORI</th><th>PERINTAH / FITUR</th></tr>${rows}</table>` +
    `<footer>MELLSTECUU MD • Pilih fitur melalui tombol.</footer>`;
}

function menuTambahanText2() {
  return `<h2>⚡ FITUR TAMBAHAN — HALAMAN 2</h2>` +
    `<table bordered compact><tr><th>FITUR</th><th>CONTOH</th></tr>` +
      `<tr><td>Cek Masa Depan</td><td><code>/cekmasadepan &lt;nama&gt;</code></td></tr>` +
      `<tr><td>Cek User ID</td><td><code>/cekid</code> · <code>/cekid @username</code></td></tr>` +
      `<tr><td>Cek Chat ID</td><td><code>/cekchatid</code></td></tr>` +
    `</table>` +
    `<p><i>Gunakan tombol navigasi untuk kembali ke halaman sebelumnya.</i></p>`;
}

function menuGroupText() {
  return `<h2>🛡️ JAGA GROUP</h2>` +
    `<p><i>Pusat keamanan dan moderasi grup.</i></p>` +
    `<table bordered compact>` +
      `<tr><th>AREA</th><th>FITUR</th></tr>` +
      `<tr><td>Keamanan</td><td>Link · Forward · Flood · Spam · Promosi · Toxic · 18+ · Drugs · Sticker · Bot · Foto · Video</td></tr>
      <tr><td>Media AI</td><td>Foto · Video · GIF · Video Note · Visual Document · Sticker → pemeriksaan Gemini saat Anti 18+/Drugs aktif</td></tr>` +
      `<tr><td>Moderasi</td><td>Hapus pesan → Warn 1/3 → 2/3 → 3/3 → pelanggaran ke-4 mute permanen</td></tr>` +
      `<tr><td>Tools</td><td>Force Subscribe · Welcome · Filters · Slowmode · Lock Media · Lock All · Rules · Tag All · Call One · Member Tools</td></tr>` +
    `</table>`;
}

function menuFunText(page = 1) {
  if (page === 2) return `<h2>🎮 FUN CENTER — SINGLE PLAYER</h2><p>Game santai yang bisa dimainkan sendiri.</p><table bordered compact><tr><th>KATEGORI</th><th>GAME</th></tr><tr><td>Game Cepat</td><td>Dadu · Koin · 8 Ball · Suit · Quiz · Matematika</td></tr><tr><td>Tebak &amp; Puzzle</td><td>Tebak Angka · Tebak Kata · Hangman · Memory · Scramble</td></tr><tr><td>Challenge</td><td>Higher/Lower · Sequence · Target 24 · Trivia · Reaction · Math Rush</td></tr></table>`;
  if (page === 3) return `<h2>🎮 FUN CENTER — MULTIPLAYER</h2><p><b>2–5 pemain</b> dengan lobby, giliran, skor, dan sesi terpisah per chat.</p><table bordered compact><tr><th>GAME</th><th>PEMAIN</th></tr><tr><td>TicTacToe · Catur</td><td>2</td></tr><tr><td>Target Party · Kata Party · Quiz Party</td><td>2–5</td></tr><tr><td>Math Battle · Emoji Battle · RPS Battle · Quick Choice</td><td>2–5</td></tr><tr><td>Duel</td><td>2</td></tr></table>`;
  return `<h2>🎮 FUN CENTER</h2><p>Pilih kategori game dari tombol di bawah.</p><table bordered compact><tr><th>MODE</th><th>KETERANGAN</th></tr><tr><td>Single Player</td><td>Game cepat tanpa pemain lain.</td></tr><tr><td>Multiplayer</td><td>Game grup dengan lobby, join, giliran, dan skor.</td></tr></table>`;
}

// ======================================= //
// ⚙️ SYSTEM FUNCTIONS
// ======================================= //
function getForceSubscribeConfig(chatId) {
  const gs = getGroupSettings(chatId);
  const raw = gs.forceSubscribe || {};
  let channels = Array.isArray(raw.channels) ? raw.channels.filter(Boolean) : [];
  // Backward compatibility: migrate the old single-channel format in memory.
  if (!channels.length && raw.channel) {
    channels = [{ channel: raw.channel, invite: raw.invite || null, title: raw.title || raw.channel }];
  }
  return {
    enabled: Boolean(raw.enabled && channels.length),
    channel: channels[0]?.channel || raw.channel || null,
    invite: channels[0]?.invite || raw.invite || null,
    title: channels[0]?.title || raw.title || '',
    channels
  };
}

function parseChannelTarget(raw) {
  const v = String(raw || '').trim();
  if (!v) return null;
  // Public channel: @username or https://t.me/username
  const parts = v.split(/\s*\|\s*/);
  const main = parts[0].trim();
  const suppliedInvite = parts[1] && /^https?:\/\/t\.me\/(?:\+|joinchat\/)/i.test(parts[1].trim()) ? parts[1].trim() : null;
  const inviteOnly = /^https?:\/\/t\.me\/(?:\+|joinchat\/)/i.test(main);
  if (inviteOnly) {
    return null; // Invite link alone cannot be used as chat_id by Bot API.
  }
  if (/^-100\d{5,20}$/.test(main)) {
    return { channel: main, invite: suppliedInvite };
  }
  const username = main.replace(/^https?:\/\/t\.me\//i, '').replace(/^@/, '').split(/[/?#]/)[0];
  if (!/^[A-Za-z0-9_]{4,64}$/.test(username)) return null;
  return { channel: '@' + username, invite: suppliedInvite || 'https://t.me/' + username };
}

async function isForceSubscribed(channel, userId) {
  try {
    const member = await bot.getChatMember(channel, userId);
    return !['left', 'kicked'].includes(member.status);
  } catch (e) {
    return null; // misconfigured/private channel or bot lacks access
  }
}

async function getForceSubBotState(chatId) {
  try {
    const me = await bot.getMe();
    const m = await bot.getChatMember(chatId, me.id);
    if (!['administrator', 'creator'].includes(m.status)) {
      return { ok: false, status: m.status, reason: 'Bot belum menjadi admin grup.' };
    }
    // Force Subscribe versi V6.1 tidak melakukan mute/restrict.
    // Bot hanya membutuhkan status admin + izin Delete Messages agar pesan
    // member yang belum join bisa dihapus otomatis.
    if (m.status === 'administrator' && m.can_delete_messages !== true) {
      return { ok: false, status: m.status, reason: 'Bot adalah admin, tetapi izin <b>Delete Messages</b> belum aktif.' };
    }
    return { ok: true, member: m };
  } catch (e) {
    return { ok: false, reason: e?.message || 'Gagal membaca status admin bot.' };
  }
}

async function restoreGroupMember(chatId, userId) {
  // Telegram tidak menyediakan endpoint "unrestrict" terpisah. Unmute dilakukan
  // dengan restrictChatMember + semua permission pesan aktif + until_date 0.
  try {
    const botState = await getForceSubBotState(chatId);
    if (!botState.ok) return { ok: false, reason: botState.reason };

    const permissions = {
      can_send_messages: true,
      can_send_audios: true,
      can_send_documents: true,
      can_send_photos: true,
      can_send_videos: true,
      can_send_video_notes: true,
      can_send_voice_notes: true,
      can_send_polls: true,
      can_send_other_messages: true,
      can_add_web_page_previews: true,
      can_invite_users: false,
      can_change_info: false,
      can_pin_messages: false,
      can_manage_topics: false
    };

    await bot.restrictChatMember(chatId, userId, {
      permissions,
      until_date: 0,
      use_independent_chat_permissions: true
    });

    const member = await bot.getChatMember(chatId, userId);
    const canSend = member.status === 'creator' ||
      member.status === 'administrator' ||
      member.status === 'member' ||
      (member.status === 'restricted' && member.can_send_messages === true);

    if (!canSend) {
      return { ok: false, reason: 'Telegram masih mempertahankan pembatasan pesan.' };
    }
    return { ok: true, member };
  } catch (e) {
    return { ok: false, reason: e?.message || 'Gagal menghapus pembatasan.' };
  }
}

async function applyForceSubMute(chatId, userId) {
  const botState = await getForceSubBotState(chatId);
  if (!botState.ok) return { ok: false, reason: botState.reason };
  try {
    await bot.restrictChatMember(chatId, userId, {
      permissions: {
        can_send_messages: false,
        can_send_audios: false,
        can_send_documents: false,
        can_send_photos: false,
        can_send_videos: false,
        can_send_video_notes: false,
        can_send_voice_notes: false,
        can_send_polls: false,
        can_send_other_messages: false,
        can_add_web_page_previews: false,
        can_invite_users: false,
        can_change_info: false,
        can_pin_messages: false,
        can_manage_topics: false
      },
      until_date: 0,
      use_independent_chat_permissions: true
    });
    const member = await bot.getChatMember(chatId, userId);
    const muted = member.status === 'restricted' && member.can_send_messages === false;
    return muted ? { ok: true, member } : { ok: false, reason: 'Telegram tidak mengonfirmasi pembatasan anggota.' };
  } catch (e) {
    return { ok: false, reason: e?.message || 'Gagal membatasi anggota.' };
  }
}

async function enforceForceSubscribe(msg) {
  if (!msg?.chat || !msg?.from || !['group','supergroup'].includes(msg.chat.type)) return true;
  const cfg = getForceSubscribeConfig(msg.chat.id);
  if (!cfg.enabled || !cfg.channel) return true;

  const userId = msg.from.id;
  // Admin grup selalu bebas dari Force Subscribe.
  if (await isGroupAdmin(msg.chat.id, userId)) return true;

  const channels = cfg.channels || [];
  const results = await Promise.all(channels.map(ch => isForceSubscribed(ch.channel, userId)));
  // Jika salah satu channel gagal diverifikasi, jangan menghukum member.
  if (results.some(v => v === null)) return true;
  const missing = channels.filter((_, i) => results[i] === false);
  if (!missing.length) return true;

  // BELUM JOIN minimal satu channel = hapus pesan, tanpa mute/restrict.
  try { await bot.deleteMessage(msg.chat.id, msg.message_id); } catch (e) {
    // Jika izin Delete Messages belum ada, jangan pernah menggantinya dengan mute.
    return false;
  }

  const mention = msg.from.username
    ? `@${msg.from.username}`
    : `<a href="tg://user?id=${userId}">${htmlEscape(msg.from.first_name || 'Member')}</a>`;
  const joinRows = missing.slice(0, 7).map((ch, i) => {
    const url = ch.invite || (String(ch.channel).startsWith('@') ? `https://t.me/${String(ch.channel).slice(1)}` : null);
    return url ? [{ text: `Join ${i + 1}. ${String(ch.title || ch.channel).slice(0, 35)}`, url }] : null;
  }).filter(Boolean);
  joinRows.push([{ text: 'Cek Status Join', callback_data: `forcecheck_${msg.chat.id}_${userId}` }]);

  const missingNames = missing.map(ch => `<b>${htmlEscape(ch.title || ch.channel)}</b>`).join(', ');
  await safeRichTextMessage(msg.chat.id,
    `<blockquote><b>FORCE SUBSCRIBE</b></blockquote>\n\n${mention}, pesanmu dihapus karena belum join semua channel wajib.\n\nBelum join: ${missingNames}\n\n<i>Join semua channel di bawah, lalu tekan Cek Status Join.</i>`,
    { parse_mode: 'HTML', reply_markup: { inline_keyboard: joinRows } }).catch(() => {});
  return false;
}
async function isJoined(userId) {
  // Join security bot dinonaktifkan; kompatibel dengan tombol lama.
  if (c.START_JOIN_REQUIRED === false) return true;
  // Verifikasi 2 channel wajib + 1 group wajib khusus saat /start.
  // Ini sengaja terpisah dari konfigurasi Force Subscribe grup.
  const targets = [];
  for (const ch of c.REQUIRED_CHANNELS || []) {
    if (ch?.username) targets.push({ ...ch, kind: 'channel' });
  }
  const group = c.REQUIRED_START_GROUP;
  if (group?.username) targets.push({ ...group, kind: 'group' });

  for (const target of targets) {
    try {
      const member = await bot.getChatMember(target.username, userId);
      if (['left', 'kicked'].includes(member.status)) return false;
      // Untuk grup/channel, restricted yang masih aktif tetap dianggap member.
      if (!['creator', 'administrator', 'member', 'restricted'].includes(member.status)) return false;
    } catch (e) {
      console.error(`[START-JOIN] Gagal cek ${target.kind}:`, e.message);
      return false;
    }
  }
  return true;
}

async function requireJoin(msgOrQuery) {
  const msg = msgOrQuery.message || msgOrQuery;
  const user = msgOrQuery.from || msg.from;
  if (!user) return false;

  upsertUser(user);
  upsertChat(msg.chat);

  // Lewati gate join. Hanya hapus ban lama akibat unfollow channel.
  // Ban/moderasi dari fitur lain tetap berlaku.
  if (c.START_JOIN_REQUIRED === false) {
    const oldBan = isUserBanned(user.id);
    if (oldBan?.reason === 'unfollow_channel') unbanUser(user.id);
    return true;
  }

  // Selalu cek status join TERLEBIH DAHULU. Jika user sudah join kembali,
  // akses langsung dipulihkan walaupun masih ada penangguhan lama karena
  // sebelumnya pernah keluar. Ini membuat /start langsung membuka menu tanpa
  // harus menekan tombol "Saya Sudah Bergabung" berulang kali.
  const joined = await isJoined(user.id);
  if (joined) {
    markForceSubJoined(user.id);
    const oldBan = isUserBanned(user.id);
    if (oldBan?.reason === 'unfollow_channel') unbanUser(user.id);
    return true;
  }

  const banStatus = isUserBanned(user.id);
  if (banStatus) {
    const until = new Date(banStatus.until).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
    await safeRichSendMessage(msg.chat.id,
      `${E.lock} <b>Akses Ditangguhkan Sementara</b>\n\n` +
      `<blockquote>${banStatus.reason === 'unfollow_channel' ? 'Kamu masih belum bergabung kembali ke channel wajib.' : 'Akses bot sedang ditangguhkan.'}\n` +
      `Akses dibuka kembali pada:\n<code>${until} WIB</code>\n\n` +
      `Silakan join channel terlebih dahulu.</blockquote>`,
      { parse_mode: 'HTML', reply_markup: joinKeyboard() }).catch(() => {});
    return false;
  }

  const warning = getForceSubWarning(user.id);

  // User baru / belum pernah berhasil join: hanya tampilkan permintaan join.
  if (!warning.previouslyJoined) {
    const text = `${E.lock} <b>mellstecuu MD ☇ Security</b>\n\n` +
      `Haloo <b>${htmlEscape(user.first_name || 'Kacung')}</b>! Kamu harus join channel kami dulu.\n\n` +
      `Setelah join, tekan tombol <b>Saya Sudah Bergabung</b>.\n` +
      `<blockquote>— mellstecuu Security System</blockquote>`;
    await safeRichSendMessage(msg.chat.id, text, { parse_mode: 'HTML', reply_markup: joinKeyboard() }).catch(() => {});
    return false;
  }

  // User pernah join lalu keluar: beri peringatan terlebih dahulu.
  const nextWarning = Number(warning.count || 0) + 1;
  if (nextWarning === 1) {
    recordForceSubWarning(user.id);
    const text = `${E.warning} <b>Peringatan: Kamu Keluar dari Channel</b>\n\n` +
      `Kami mendeteksi kamu sudah tidak bergabung dengan channel wajib.\n\n` +
      `Silakan <b>join kembali</b> sebelum menggunakan bot. Ini adalah <b>peringatan pertama</b>; belum ada pemblokiran.\n\n` +
      `Jika kamu tetap mencoba menggunakan bot tanpa join kembali, akses dapat ditangguhkan sementara (maksimal <b>3 hari</b>).`;
    await safeRichSendMessage(msg.chat.id, text, { parse_mode: 'HTML', reply_markup: joinKeyboard() }).catch(() => {});
    return false;
  }

  // Eskalasi ringan: 1 hari -> 2 hari -> maksimal 3 hari.
  const durationDays = Math.min(nextWarning - 1, 3);
  const durationMs = durationDays * 24 * 60 * 60 * 1000;
  recordForceSubWarning(user.id);
  banUser(user.id, durationMs, 'unfollow_channel');
  const text = `${E.lock} <b>Akses Ditangguhkan ${durationDays} Hari</b>\n\n` +
    `Kamu sudah menerima peringatan sebelumnya karena keluar dari channel wajib.\n` +
    `Silakan join kembali channel kami. Setelah masa penangguhan selesai, kamu bisa mencoba lagi.\n\n` +
    `<b>Tidak ada ban 7 hari.</b> Penangguhan maksimal hanya <b>3 hari</b>.`;
  await safeRichSendMessage(msg.chat.id, text, { parse_mode: 'HTML', reply_markup: joinKeyboard() }).catch(() => {});
  return false;
}

function richPlain(text) {
  return String(text ?? '');
}

function richButton(button) {
  const out = { text: richPlain(button.text || '') };
  if (button.style) out.style = button.style;
  if (button.callback_data) out.callback_data = String(button.callback_data).slice(0, 64);
  if (button.url) out.url = button.url;
  return out;
}

function buildRichStartHtml(user) {
  const state = readState();
  const chats = Object.values(state.chats || {});
  const groupCount = chats.filter(chat => ['group', 'supergroup'].includes(chat.type)).length;
  const userCount = Object.keys(state.users || {}).length;
  const name = [user.first_name, user.last_name].filter(Boolean).join(' ') || 'Pengguna';
  const now = moment().tz(c.TIMEZONE);

  // Native Rich Message HTML. Telegram renders the table/layout itself, so
  // there is no Unicode-drawn table whose borders can become misaligned.
  return [
    `<h2>${E.crown} 『 MELLSTECUU MD 』</h2>`,
    `<p><b>Welcome, ${htmlEscape(name)}</b><br><i>All-in-one assistant untuk tools, AI, media, game, group &amp; market.</i></p>`,
    `<hr/>`,
    `<h3>SYSTEM INFORMATION</h3>`,
    `<table bordered compact><tr><th>SYSTEM</th><th>DETAIL</th></tr>` +
      `<tr><td>Version</td><td align="right">${htmlEscape(c.VERSION || '1.0.0')}</td></tr>` +
      `<tr><td>Bot Time</td><td align="right">${htmlEscape(runtime())}</td></tr>` +
      `<tr><td>VPS Time</td><td align="right">${htmlEscape(now.format('DD-MM-YYYY HH:mm:ss'))} WIB</td></tr>` +
      `<tr><td>Fitur Terdaftar</td><td align="right">${getFeatureCount()}+</td></tr>` +
      `<tr><td>Total User</td><td align="right">${userCount}</td></tr>` +
      `<tr><td>Jumlah Group</td><td align="right">${groupCount}</td></tr></table>`,
    `<hr/>`,
    `<details><summary>${E.tools} Multi Device × Test Func</summary><p>Pilih kategori tombol di bawah untuk membuka fitur.</p></details>`,
    `<blockquote>${E.check} <b>© MELLSTECUU MD</b> • System Online</blockquote>`,
    ...mainKeyboard().inline_keyboard.map(row => {
      const buttons = row.map(richButton).map(b => {
        const type = b.url ? 'url' : 'callback_data';
        const attr = b.url ? `url="${htmlEscape(b.url)}"` : `data="${htmlEscape(b.callback_data || '')}"`;
        return `<tg-button type="${type}" style="${b.style || 'primary'}" ${attr}>${htmlEscape(b.text)}</tg-button>`;
      }).join('');
      return `<tg-button-row>${buttons}</tg-button-row>`;
    })
  ].filter(Boolean).join('');
}

function richButtonRowsMarkup(keyboard) {
  const rows = keyboard?.inline_keyboard;
  if (!Array.isArray(rows)) return '';
  const out = [];
  for (const row of rows.slice(0, 50)) {
    if (!Array.isArray(row) || !row.length) continue;
    const buttons = [];
    for (const b of row.slice(0, 8)) {
      if (!b || b.request_location || b.request_contact || b.web_app || b.switch_inline_query || b.switch_inline_query_current_chat) continue;
      const text = htmlEscape(String(b.text || 'Button')).replace(/\n/g, ' ');
      const style = ['danger','success','primary','link'].includes(b.style) ? b.style : 'primary';
      if (b.url) buttons.push(`<tg-button type="url" style="${style}" url="${htmlEscape(String(b.url))}">${text}</tg-button>`);
      else if (b.callback_data) buttons.push(`<tg-button type="callback_data" style="${style}" data="${htmlEscape(String(b.callback_data).slice(0,64))}">${text}</tg-button>`);
    }
    if (buttons.length) out.push(`<tg-button-row>${buttons.join('')}</tg-button-row>`);
  }
  return out.join('');
}

const richTransport = { disabledUntil: 0, lastLogAt: 0 };
const RICH_MENU_COOLDOWN_MS = Math.max(15000, Math.min(180000, Number(process.env.RICH_MENU_COOLDOWN_MS || 45000)));
function richTransportBlocked() { return Date.now() < richTransport.disabledUntil; }
function shouldBypassRichTransport(error) {
  const code = String(error?.code || '').toUpperCase();
  const message = String(error?.message || '').toLowerCase();
  return code === 'ECONNABORTED' || code === 'ETIMEDOUT' || code === 'ECONNRESET' || code === 'ENOTFOUND' || message.includes('timeout');
}

function richMarkdownSafeCustomEmoji(text) {
  // Rich Messages support Telegram custom emoji in both Rich Markdown and
  // Rich HTML. Keep ONLY IDs already registered in the bot's E palette so
  // Premium emoji render as Premium emoji instead of falling back to plain
  // Unicode, while unknown/malformed markup is still stripped safely.
  let out = String(text || '');
  const emojiById = new Map();
  try {
    for (const value of Object.values(E || {})) {
      const m = String(value || '').match(/<tg-emoji\s+emoji-id=["'](\d+)["'][^>]*>([\s\S]*?)<\/tg-emoji>/i);
      if (m) emojiById.set(m[1], m[2] || '');
    }
  } catch (_) {}

  // Preserve known <tg-emoji> tags. Telegram explicitly supports this tag
  // in Rich HTML and allows arbitrary HTML inside Rich Markdown.
  out = out.replace(
    /<tg-emoji\s+emoji-id=["'](\d+)["'][^>]*>([\s\S]*?)<\/tg-emoji>/gi,
    (_m, id, fallback) => {
      const safeFallback = emojiById.get(String(id));
      return safeFallback
        ? `<tg-emoji emoji-id="${String(id)}">${safeFallback}</tg-emoji>`
        : String(fallback || '');
    }
  );

  // Normalize known Markdown custom-emoji forms and remove unknown ones.
  out = out.replace(/!\[([^\]]*)\]\(tg:\/\/emoji\?id=(\d+)\)/gi,
    (_m, alt, id) => emojiById.has(String(id))
      ? `![${String(alt || `Image: ${emojiById.get(String(id))}`).trim()}](tg://emoji?id=${String(id)})`
      : '');

  // Any raw/unknown custom-emoji URI left after normalization must never
  // leak into the user's message. Known <tg-emoji> tags were normalized
  // above and intentionally remain intact.
  out = out.replace(/!\[[^\]]*\]\(tg:\/\/emoji\?id=\d+\)/gi, '');
  out = out.replace(/\btg:\/\/emoji\?id=\d+\b/gi, '');

  return out.replace(/ {2,}/g, ' ').replace(/\n[ \t]+/g, '\n');
}

async function sendRichMenu(chatId, caption, keyboard, photo = c.BANNER_URL, replyToMsgId = null) {
  const cleanCaption = normalizeRichLayout(String(caption || '').trim());
  const richCaption = richMarkdownSafeCustomEmoji(cleanCaption);
  const richMarkdown = `${photo ? '![Banner](tg://photo?id=banner)\n\n' : ''}${richCaption}\n${richButtonRowsMarkup(keyboard)}`;
  const richMessage = { markdown: richMarkdown };
  if (photo) richMessage.media = [{ id: 'banner', media: { type: 'photo', media: photo } }];
  const payload = { chat_id: chatId, rich_message: richMessage };
  if (replyToMsgId) payload.reply_parameters = { message_id: replyToMsgId };
  if (richTransportBlocked()) {
    return legacySendMenuPhoto(bot, chatId, photo, { caption: cleanCaption, parse_mode: 'HTML', reply_markup: keyboard })
      .catch(() => safeSendMessage(bot, chatId, cleanCaption.replace(/<[^>]*>/g, ''), { reply_markup: keyboard }));
  }
  try {
    const res = await axios.post(`https://api.telegram.org/bot${c.BOT}/sendRichMessage`, payload, { timeout: 30000 });
    if (!res.data?.ok) throw new Error(res.data?.description || 'Telegram menolak Rich Menu.');
    richTransport.disabledUntil = 0;
    return res.data.result;
  } catch (e) {
    if (shouldBypassRichTransport(e)) {
      richTransport.disabledUntil = Date.now() + RICH_MENU_COOLDOWN_MS;
      if (Date.now() - richTransport.lastLogAt > 5000) {
        richTransport.lastLogAt = Date.now();
        console.warn(`[RICH MENU] transport timeout/network error; legacy fallback dipakai selama ${Math.round(RICH_MENU_COOLDOWN_MS / 1000)}s:`, e?.message || e);
      }
    } else {
      console.error('[RICH MENU] gagal, fallback ke menu legacy:', e?.response?.data?.description || e.message);
    }
    try {
      return await legacySendMenuPhoto(bot, chatId, photo, { caption: cleanCaption, parse_mode: 'HTML', reply_markup: keyboard });
    } catch {
      return safeSendMessage(bot, chatId, cleanCaption.replace(/<[^>]*>/g, ''), { reply_markup: keyboard });
    }
  }
}

async function sendMenuPhoto(botInstance, chatId, photo, options = {}) {
  return sendRichMenu(chatId, options.caption || '', options.reply_markup, photo, options.reply_to_message_id || null);
}

function normalizeRichLayout(text) {
  let source = String(text == null ? '' : text).trim();
  if (!source) return source;

  // Do not touch already-structured Rich Message tables or preformatted/code
  // blocks. Those are intentional and changing them could alter tool output.
  if (/<table\b/i.test(source)) return source;

  // Remove old terminal-style box/separator lines. Native Rich Message blocks
  // provide the spacing and borders, so these characters only create uneven
  // wrapping on mobile clients.
  source = source
    .replace(/^\s*[╭╮╰╯┣┫┏┓┗┛┠┨┝┥┳┻╋┃│─━═]{4,}\s*$/gmi, '')
    .replace(/\n{3,}/g, '\n\n');

  const lines = source.split('\n').map(v => v.trim()).filter((v, i, a) => v || (i > 0 && a[i - 1]));
  const out = [];
  const isCommandLine = line => /^<code>\/[^<\s]+(?:\s+[^<]+)?<\/code>\s*(?:—|–|-|:|→)\s*.+$/i.test(line);
  const isBoldKeyLine = line => /^[^A-Za-z0-9<]*<b>[^<]{1,60}<\/b>\s*:\s*.+$/iu.test(line);
  const isPlainKeyLine = line => /^[^A-Za-z0-9<]*(?:Status|Node|Platform|Uptime|RSS|Heap|External|Users|Chats|Events|Runtime errors|AI queue|AI aktif|Concurrent|Cooldown|Project|Version|Runtime|Dependencies|Dev Dependencies|Data directory|FFmpeg|BOT_TOKEN|GEMINI_API_KEY|GEMINI_MODEL|OPENROUTER_API_KEY|OPENROUTER_MODEL)\s*:\s*.+$/iu.test(line);
  const isCodeBulletLine = line => /^•\s*<code>[^<]+<\/code>\s*(?:—|–|-|→|:)\s*.+$/i.test(line);
  const isDataBulletLine = line => /^•\s*.+$/u.test(line) && !/^•\s*(?:https?:\/\/|<a\b)/i.test(line);
  const isArrowDataLine = line => /^(?:↳|└|→)\s*.+$/u.test(line);
  const isNumberedLine = line => /^\d+[.)]\s+.+$/u.test(line);
  const isPlainDashLine = line => /^(?:[-–—]|•)\s+.+?(?:\s+[-–—:]\s+.+)$/u.test(line);
  const isMarketRow = line => /^(?:[🟢🔴⚪])\s*<b>[^<]+<\/b>\s+<code>[^<]+<\/code>\s+<b>[^<]+<\/b>$/u.test(line);

  const commandRow = line => {
    const m = line.match(/^<code>(\/[^<]+)<\/code>\s*(?:—|–|-|:|→)\s*(.+)$/i);
    return m ? [m[1], m[2]] : null;
  };
  const boldRow = line => {
    const m = line.match(/^[^A-Za-z0-9<]*<b>([^<]{1,60})<\/b>\s*:\s*(.+)$/iu);
    return m ? [m[1], m[2]] : null;
  };
  const plainRow = line => {
    const m = line.match(/^[^A-Za-z0-9<]*([^:]{1,60})\s*:\s*(.+)$/u);
    return m ? [m[1].trim(), m[2].trim()] : null;
  };

  let i = 0;
  while (i < lines.length) {
    const line = lines[i];

    if (isCommandLine(line)) {
      const rows = [];
      let j = i;
      while (j < lines.length && isCommandLine(lines[j])) {
        const row = commandRow(lines[j]);
        if (row) rows.push(row);
        j++;
      }
      if (rows.length >= 2) {
        out.push(`<table bordered compact><tr><th>PERINTAH</th><th>KETERANGAN</th></tr>${rows.map(([a,b]) => `<tr><td><code>${a}</code></td><td>${b}</td></tr>`).join('')}</table>`);
        i = j;
        continue;
      }
    }

    if (isBoldKeyLine(line) || isPlainKeyLine(line)) {
      const rows = [];
      let j = i;
      while (j < lines.length && (isBoldKeyLine(lines[j]) || isPlainKeyLine(lines[j]))) {
        const row = isBoldKeyLine(lines[j]) ? boldRow(lines[j]) : plainRow(lines[j]);
        if (row) rows.push(row);
        j++;
      }
      if (rows.length >= 2) {
        out.push(`<table bordered compact><tr><th>DATA</th><th>DETAIL</th></tr>${rows.map(([a,b]) => `<tr><td><b>${a}</b></td><td>${b}</td></tr>`).join('')}</table>`);
        i = j;
        continue;
      }
    }

    if (isMarketRow(line)) {
      const rows = [];
      let j = i;
      while (j < lines.length && isMarketRow(lines[j])) {
        const m = lines[j].match(/^(?:([🟢🔴⚪]))\s*<b>([^<]+)<\/b>\s+<code>([^<]+)<\/code>\s+<b>([^<]+)<\/b>$/u);
        if (m) rows.push([m[1], m[2], m[3], m[4]]);
        j++;
      }
      if (rows.length >= 2) {
        out.push(`<table bordered compact><tr><th>INDIKATOR</th><th>HARGA</th><th>PERUBAHAN</th></tr>${rows.map(([state,name,price,pct]) => `<tr><td>${state} <b>${name}</b></td><td><code>${price}</code></td><td><b>${pct}</b></td></tr>`).join('')}</table>`);
        i = j;
        continue;
      }
    }

    if (isNumberedLine(line)) {
      const rows = [];
      let j = i;
      while (j < lines.length && isNumberedLine(lines[j])) {
        const m = lines[j].match(/^\d+[.)]\s+(.+)$/u);
        if (m) rows.push([String(rows.length + 1), m[1]]);
        j++;
      }
      if (rows.length >= 2) {
        out.push(`<table bordered compact><tr><th>#</th><th>DETAIL</th></tr>${rows.map(([a,b]) => `<tr><td><code>${a}</code></td><td>${b}</td></tr>`).join('')}</table>`);
        i = j;
        continue;
      }
    }

    if (isPlainDashLine(line)) {
      const rows = [];
      let j = i;
      while (j < lines.length && isPlainDashLine(lines[j])) {
        const m = lines[j].match(/^(?:[-–—]|•)\s+(.+?)\s+[-–—:]\s+(.+)$/u);
        if (m) rows.push([m[1].trim(), m[2].trim()]);
        j++;
      }
      if (rows.length >= 2) {
        out.push(`<table bordered compact><tr><th>ITEM</th><th>DETAIL</th></tr>${rows.map(([a,b]) => `<tr><td>${a}</td><td>${b}</td></tr>`).join('')}</table>`);
        i = j;
        continue;
      }
    }

    if (isDataBulletLine(line) && i + 1 < lines.length && isArrowDataLine(lines[i + 1])) {
      const rows = [];
      let j = i;
      while (j + 1 < lines.length && isDataBulletLine(lines[j]) && isArrowDataLine(lines[j + 1])) {
        const a = lines[j].replace(/^•\s*/, '').trim();
        const b = lines[j + 1].replace(/^↳\s*/, '').trim();
        rows.push([a, b]);
        j += 2;
      }
      if (rows.length >= 2) {
        out.push(`<table bordered compact><tr><th>ITEM</th><th>ID / DETAIL</th></tr>${rows.map(([a,b]) => `<tr><td>${a}</td><td><code>${b}</code></td></tr>`).join('')}</table>`);
        i = j;
        continue;
      }
    }

    if (isCodeBulletLine(line)) {
      const rows = [];
      let j = i;
      while (j < lines.length && isCodeBulletLine(lines[j])) {
        const m = lines[j].match(/^•\s*<code>([^<]+)<\/code>\s*(?:—|–|-|→)\s*(.+)$/i);
        if (m) rows.push([m[1], m[2]]);
        j++;
      }
      if (rows.length >= 2) {
        out.push(`<table bordered compact><tr><th>ITEM</th><th>DETAIL</th></tr>${rows.map(([a,b]) => `<tr><td><code>${a}</code></td><td>${b}</td></tr>`).join('')}</table>`);
        i = j;
        continue;
      }
    }

    // Generic bullet rows: when a menu contains several short bullet items,
    // render them as a native Rich Message table instead of a tall text wall.
    if (isDataBulletLine(line) && !isArrowDataLine(line)) {
      const rows = [];
      let j = i;
      while (j < lines.length && isDataBulletLine(lines[j]) && !isArrowDataLine(lines[j])) {
        const raw = lines[j].replace(/^•\s*/, '').trim();
        if (raw && !/^https?:\/\//i.test(raw)) rows.push([String(rows.length + 1), raw]);
        j++;
      }
      if (rows.length >= 3 && rows.length <= 20) {
        out.push(`<table bordered compact><tr><th>#</th><th>ITEM</th></tr>${rows.map(([a,b]) => `<tr><td><code>${a}</code></td><td>${b}</td></tr>`).join('')}</table>`);
        i = j;
        continue;
      }
    }

    // Compact provider/status rows such as “• <b>Gemini</b> — …”.
    if (/^•\s*<b>[^<]+<\/b>\s*(?:—|–|-|→)\s*.+$/i.test(line)) {
      const rows = [];
      let j = i;
      while (j < lines.length && /^•\s*<b>[^<]+<\/b>\s*(?:—|–|-|→)\s*.+$/i.test(lines[j])) {
        const m = lines[j].match(/^•\s*<b>([^<]+)<\/b>\s*(?:—|–|-|→)\s*(.+)$/i);
        if (m) rows.push([m[1], m[2]]);
        j++;
      }
      if (rows.length >= 2) {
        out.push(`<table bordered compact><tr><th>ITEM</th><th>STATUS</th></tr>${rows.map(([a,b]) => `<tr><td><b>${a}</b></td><td>${b}</td></tr>`).join('')}</table>`);
        i = j;
        continue;
      }
    }

    out.push(line);
    i++;
  }

  return out.join('\n').replace(/\n{3,}/g, '\n\n').trim();
}

async function sendDevRich(chatId, text, options = {}) {
  const cleaned = normalizeRichLayout(text);
  return sendRichMenu(chatId, cleaned, options.reply_markup, options.photo || c.BANNER_URL, options.reply_to_message_id || null);
}

// Music result card: uses the track's own artwork as the Rich Message banner.
// If the source has no artwork, it falls back to the bot banner. This keeps
// /play stable even when a provider omits thumbnails.
async function sendMusicRichBanner(chatId, meta = {}, keyboard, replyToMsgId = null) {
  const title = htmlEscape(String(meta.title || 'Audio').slice(0, 160));
  const artist = htmlEscape(String(meta.artist || meta.performer || 'Unknown Artist').slice(0, 120));
  const duration = meta.duration ? htmlEscape(String(meta.duration)) : '';
  const views = meta.views ? htmlEscape(String(meta.views)) : '';
  const lines = [
    `<h2>${title}</h2>`,
    `<p><b>${artist}</b>${duration ? ` · ${duration}` : ''}${views ? ` · ${views} views` : ''}</p>`,
    `<blockquote>${E.music} <b>MELLSTECUU MD</b> • Music</blockquote>`
  ];
  return sendRichMenu(chatId, lines.join(''), keyboard, meta.thumbnail || meta.artwork_url || meta.cover || meta.cover_url || meta.image || meta.image_url || c.BANNER_URL, replyToMsgId);
}

// Button/callback screens use Rich Message first. Keyboards that contain
// Telegram-only request buttons (location/contact/web_app) transparently use
// the legacy API so no functionality is lost.
async function safeRichTextMessage(chatId, text, options = {}) {
  const normalizedText = options?.parse_mode === 'HTML' ? normalizeRichLayout(text) : text;
  const markup = options?.reply_markup;
  const hasInlineKeyboard = Array.isArray(markup?.inline_keyboard);
  const hasUnsupportedMarkup = markup && !hasInlineKeyboard;
  const unsupportedOptions = [
    'disable_notification', 'protect_content', 'message_thread_id',
    'allow_sending_without_reply', 'business_connection_id'
  ];
  const needsLegacy = hasUnsupportedMarkup || unsupportedOptions.some(k => Object.prototype.hasOwnProperty.call(options || {}, k));
  if (needsLegacy) return safeSendMessage(bot, chatId, normalizedText, options);
  try {
    return await sendRichMenu(
      chatId,
      normalizedText,
      hasInlineKeyboard ? markup : undefined,
      null,
      options.reply_to_message_id || null
    );
  } catch (e) {
    return safeSendMessage(bot, chatId, normalizedText, options);
  }
}

async function safeRichSendMessage(chatId, text, options = {}) {
  const rows = options?.reply_markup?.inline_keyboard;
  const unsupported = Array.isArray(rows) && rows.some(row => Array.isArray(row) && row.some(b => b && (b.request_location || b.request_contact || b.web_app || b.switch_inline_query || b.switch_inline_query_current_chat)));
  if (unsupported) return safeSendMessage(bot, chatId, text, options);
  try {
    return await sendDevRich(chatId, text, options);
  } catch (e) {
    return safeSendMessage(bot, chatId, text, options);
  }
}

async function sendRichStartMenu(chatId, user, replyToMsgId = null) {
  const richHtml = buildRichStartHtml(user);
  const payload = {
    chat_id: chatId,
    rich_message: {
      markdown: `![Banner](tg://photo?id=banner)\n\n${richHtml}`,
      media: [{ id: 'banner', media: { type: 'photo', media: c.BANNER_URL } }]
    }
  };
  if (replyToMsgId) payload.reply_parameters = { message_id: replyToMsgId };

  if (richTransportBlocked()) {
    return legacySendMenuPhoto(bot, chatId, c.BANNER_URL, { caption: menuText(user), parse_mode:'HTML', reply_markup: mainKeyboard(), reply_to_message_id: replyToMsgId || undefined });
  }
  try {
    const res = await axios.post(`https://api.telegram.org/bot${c.BOT}/sendRichMessage`, payload, { timeout: 30000 });
    if (!res.data?.ok) throw new Error(res.data?.description || 'Telegram menolak Rich Message.');
    richTransport.disabledUntil = 0;
    const sent = res.data.result;
    try {
      await axios.post(`https://api.telegram.org/bot${c.BOT}/setMessageReaction`, {
        chat_id: chatId, message_id: sent.message_id,
        reaction: [{ type: 'custom_emoji', custom_emoji_id: '5424972470023104089' }]
      });
    } catch {}
    return sent;
  } catch (e) {
    if (shouldBypassRichTransport(e)) {
      richTransport.disabledUntil = Date.now() + RICH_MENU_COOLDOWN_MS;
      if (Date.now() - richTransport.lastLogAt > 5000) {
        richTransport.lastLogAt = Date.now();
        console.warn(`[RICH START] transport timeout/network error; legacy fallback dipakai selama ${Math.round(RICH_MENU_COOLDOWN_MS / 1000)}s:`, e?.message || e);
      }
    } else {
      console.error('[RICH START] Rich Message gagal, fallback ke menu biasa:', e?.response?.data?.description || e.message);
    }
    return legacySendMenuPhoto(bot, chatId, c.BANNER_URL, { caption: menuText(user), parse_mode:'HTML', reply_markup: mainKeyboard(), reply_to_message_id: replyToMsgId || undefined });
  }
}

async function sendMainMenu(chatId, user, replyToMsgId = null) {
  return sendRichStartMenu(chatId, user, replyToMsgId);
}

async function isGroupAdmin(chatId, userId) {
  try {
    const m = await bot.getChatMember(chatId, userId);
    return ['administrator', 'creator'].includes(m.status);
  } catch { return false; }
}

// AntiAdmin controls the admin exemption used ONLY by group-moderation filters.
// ON  = keep the normal behaviour: admins/creator are exempt from violations.
// OFF = admins/creator are also checked by the enabled moderation filters.
// This must never alter the separate admin permission checks for commands/settings.
async function isGroupModerationExempt(chatId, userId) {
  const gs = getGroupSettings(chatId);
  if (!gs.antiadmin) return false;
  return await isGroupAdmin(chatId, userId);
}

async function requireGroupAdmin(msg) {
  if (!(await isGroupAdmin(msg.chat.id, msg.from.id))) {
    await safeRichTextMessage(msg.chat.id, `${E.cross} Hanya admin grup yang bisa menggunakan perintah ini.`, { parse_mode: 'HTML' });
    return false;
  }
  return true;
}

async function requireBotAdmin(chatId, requiredPermission = null) {
  try {
    const me = await bot.getMe();
    const m = await bot.getChatMember(chatId, me.id);
    if (!['administrator', 'creator'].includes(m.status)) {
      await safeRichTextMessage(chatId, `${E.warning} <b>Bot belum menjadi admin grup.</b>\n\nJadikan bot admin agar fitur moderasi dapat bekerja.`, { parse_mode: 'HTML' }).catch(() => {});
      return false;
    }
    if (requiredPermission && m.status === 'administrator' && m[requiredPermission] !== true) {
      const labels={can_delete_messages:'Delete Messages',can_restrict_members:'Restrict Members',can_pin_messages:'Pin Messages',can_invite_users:'Invite Users',can_promote_members:'Add New Admins'};
      await safeRichTextMessage(chatId, `${E.warning} <b>Izin bot belum cukup.</b>\n\nBot membutuhkan izin <b>${htmlEscape(labels[requiredPermission] || requiredPermission)}</b> untuk fitur ini.`, { parse_mode: 'HTML' }).catch(() => {});
      return false;
    }
    return true;
  } catch (e) {
    await safeRichTextMessage(chatId, `${E.cross} <b>Status admin bot tidak bisa diperiksa.</b>\n<code>${htmlEscape(e?.message || 'Telegram API error')}</code>`, { parse_mode: 'HTML' }).catch(() => {});
    return false;
  }
}

function isGroupBotAdder(chatId, userId) {
  return true;
}

async function getMainChannelId() {
  const id = String(c.MAIN_CHANNEL_ID || c.MAIN_CHANNEL_USERNAME || '').trim();
  return id || null;
}

function mainChannelReady() {
  return Boolean(String(c.MAIN_CHANNEL_ID || '').trim());
}

async function getEffectiveChannelMonitor(channelId) {
  const id = String(channelId || '').trim();
  if (!id) return null;
  const saved = getChannelMonitor(id);
  if (saved?.enabled) {
    return { ...saved, outputChannelId: saved.outputChannelId || id };
  }
  const legacy = String(c.MAIN_CHANNEL_ID || '').trim();
  if (legacy && legacy === id) {
    // Legacy fallback: main channel is also the notification destination.
    return {
      channelId: id,
      title: c.MAIN_CHANNEL_TITLE || c.CHANNEL_NAME || 'Main Channel',
      username: '',
      ownerId: String(c.ID),
      outputChannelId: legacy,
      outputTitle: c.MAIN_CHANNEL_TITLE || c.CHANNEL_NAME || 'Main Channel',
      enabled: true,
      legacy: true
    };
  }
  return null;
}

async function canManageMonitoredChannel(channelId, userId) {
  try {
    const member = await bot.getChatMember(channelId, userId);
    const isAdmin = ['administrator','creator'].includes(member.status);
    if (!isAdmin) return { ok:false, reason:'Kamu harus menjadi admin channel.' };
    const me = await bot.getMe();
    const botMember = await bot.getChatMember(channelId, me.id);
    if (!['administrator','creator'].includes(botMember.status)) return { ok:false, reason:'Bot belum menjadi admin channel.' };
    if (botMember.status === 'administrator' && botMember.can_post_messages === false) return { ok:false, reason:'Bot admin tetapi izin Post Messages belum aktif.' };
    return { ok:true, member, botMember };
  } catch (e) {
    return { ok:false, reason:e?.message || 'Channel tidak bisa diakses.' };
  }
}

function channelMonitorKeyboard(monitors = []) {
  const rows = [[{text:'Tambah / Set Channel',callback_data:'channel_monitor_add',style:'success'}]];
  for (const m of monitors.slice(0, 10)) {
    rows.push([{text:`${m.enabled ? '●' : '○'} ${String(m.title || m.channelId).slice(0, 32)}`,callback_data:`channel_monitor_view:${m.channelId}`,style:'primary'}]);
  }
  rows.push([{text:'Refresh',callback_data:'channel_monitor'}],[{text:'Menu Utama',callback_data:'back_menu',style:'danger'}]);
  return {inline_keyboard:rows};
}

function channelMonitorText(userId) {
  const monitors = getUserChannelMonitors(userId);
  const body = monitors.length
    ? monitors.map((m,i)=>`${i+1}. <b>${htmlEscape(m.title || m.channelId)}</b>
   Main: <code>${htmlEscape(m.channelId)}</code>
   Output: <code>${htmlEscape(m.outputChannelId || 'belum diatur')}</code>
   Status: ${m.enabled ? 'Aktif' : 'Nonaktif'}`).join('\n\n')
    : '<i>Belum ada main channel yang didaftarkan.</i>';
  return `<blockquote><b>MONITORING CHANNEL</b></blockquote>\n\n` +
    `Atur <b>main channel</b> yang dipantau dan <b>channel monitoring</b> tempat kartu notifikasi dikirim. Polanya sama seperti contoh: member masuk/keluar dari Main Channel → kartu Rich Message masuk ke channel monitoring.\n\n` +
    `<b>Channel kamu</b>\n${body}\n\n` +
    `<b>Syarat</b>\n` +
    `1. Kamu admin di kedua channel.\n` +
    `2. Bot admin di kedua channel.\n` +
    `3. Bot harus punya izin posting di channel monitoring.\n` +
    `4. Untuk tombol Ban/Unban, bot juga perlu izin yang sesuai di main channel.\n\n` +
    `<i>Catatan penting: bot harus menjadi administrator channel dan menerima update <code>chat_member</code>. Jika izin posting tersedia, kartu JOIN/LEAVE dikirim otomatis ke channel tersebut.</i>`;
}

function formatUserIdentity(user) {
  const name = [user?.first_name, user?.last_name].filter(Boolean).join(' ') || 'Pengguna';
  const username = user?.username ? `@${user.username}` : '-';
  return { name, username };
}

async function notifyNewUser(user) {
  // Private OWNER notification only. Keep this card intentionally compact:
  // one Rich Message + one Profile button. Main-channel join/leave activity
  // is handled separately by notifyMainChannelMember().
  const ownerId = String(process.env.OWNER_ID || c.OWNER_ID || c.ID || '').trim();
  if (!ownerId || !user?.id) return false;

  try {
    const { name, username } = formatUserIdentity(user);
    const totalUsers = getAllUsers().length;
    const time = moment().tz(c.TIMEZONE).format('DD/MM/YYYY HH:mm:ss');
    const cleanName = htmlEscape(name);
    const cleanUsername = htmlEscape(username);
    const profileButton = user.username
      ? { text:'👤 Profil Pengguna', url:`https://t.me/${String(user.username).replace(/^@/,'')}`, style:'primary' }
      : { text:'👤 Profil Pengguna', url:`tg://user?id=${String(user.id)}`, style:'primary' };
    // Owner new-user notification intentionally has ONE button only.
    // Do not add Developer/Channel/Group buttons here; those belong to other menus.
    const ownerButtons = [[profileButton]];

    const text = [
      `<h2>💬 USER BARU TERDETEKSI!</h2>`,
      `<p>Pengguna baru telah melakukan <code>/start</code> pada bot.</p>`,
      `<table bordered compact>`,
      `<tr><th>DATA USER</th><th>INFORMASI</th></tr>`,
      `<tr><td>Nama</td><td><b>${cleanName}</b></td></tr>`,
      `<tr><td>ID</td><td><code>${htmlEscape(String(user.id))}</code></td></tr>`,
      `<tr><td>Username</td><td>${cleanUsername}</td></tr>`,
      `<tr><td>User ke</td><td><b>${htmlEscape(String(totalUsers))}</b></td></tr>`,
      `<tr><td>Total Users</td><td><b>${htmlEscape(String(totalUsers))}</b></td></tr>`,
      `<tr><td>Waktu</td><td>${htmlEscape(time)} WIB</td></tr>`,
      `</table>`,
      `<hr/>`,
      `<footer>© MELLSTECUU MD • User Activity</footer>`
    ].join('');

    // One button only, exactly for opening the user's profile.
    await sendRichMenu(ownerId, text, { inline_keyboard:ownerButtons }, null);
    return true;
  } catch (e) {
    console.warn('[OWNER] notifyNewUser:', e?.response?.data?.description || e?.message || e);
    // Hard fallback so the notification is never lost if Rich Message is unavailable.
    try {
      const { name, username } = formatUserIdentity(user);
      const fallback =
        `💬 <b>USER BARU TERDETEKSI!</b>\n\n` +
        `👤 Nama: <b>${htmlEscape(name)}</b>\n` +
        `🆔 ID: <code>${htmlEscape(String(user.id))}</code>\n` +
        `🔗 Username: ${htmlEscape(username)}\n\n` +
        `🕒 ${htmlEscape(moment().tz(c.TIMEZONE).format('DD/MM/YYYY HH:mm:ss'))} WIB`;
      const profileButton = user.username
        ? { text:'👤 Profil Pengguna', url:`https://t.me/${String(user.username).replace(/^@/,'')}` }
        : { text:'👤 Profil Pengguna', url:`tg://user?id=${String(user.id)}` };
      await safeSendMessage(bot, ownerId, fallback, { parse_mode:'HTML', reply_markup:{inline_keyboard:[[profileButton]]} });
      return true;
    } catch (fallbackErr) {
      console.warn('[OWNER] notifyNewUser fallback:', fallbackErr?.message || fallbackErr);
      return false;
    }
  }
}

async function notifyMainChannelMember(action, user, extra = '', channelIdOverride = null) {
  const sourceChannelId = String(channelIdOverride || '').trim();
  const monitor = await getEffectiveChannelMonitor(sourceChannelId || await getMainChannelId());
  const channelId = String(monitor?.outputChannelId || sourceChannelId || await getMainChannelId() || '').trim();
  if (!channelId || !user?.id) return false;

  const {name, username} = formatUserIdentity(user);
  const isJoin = action === 'join';
  const time = moment().tz(c.TIMEZONE).format('DD/MM/YYYY, HH.mm.ss');
  const userId = String(user.id);
  const cleanName = htmlEscape(name);
  const cleanUsername = htmlEscape(username);
  const sourceMonitor = await getEffectiveChannelMonitor(sourceChannelId || channelId);
  const channelTitle = htmlEscape(String(sourceMonitor?.title || c.MAIN_CHANNEL_TITLE || c.CHANNEL_NAME || 'Main Channel'));
  const sourceIdForButtons = String(sourceMonitor?.channelId || sourceChannelId || channelId);

  // Main-channel notifications intentionally use the same Rich Message
  // structure for JOIN and LEAVE. Keep this isolated so other menus/features
  // are not affected by changes to the monitoring card.
  const text = [
    `<h2>${isJoin ? '🟢' : '🔴'} ${isJoin ? 'MEMBER BARU MASUK' : 'ADA YANG KELUAR'}</h2>`,
    `<p><b>👤 ${cleanName}</b> ${cleanUsername !== '-' ? `<a href="https://t.me/${htmlEscape(String(user.username || '').replace(/^@/, ''))}">${cleanUsername}</a>` : ''}</p>`,
    `<hr/>`,
    `<h3>👤 INFORMASI USER</h3>`,
    `<table bordered compact>` +
      `<tr><th>Detail</th><th>Informasi</th></tr>` +
      `<tr><td>ID</td><td>${userId}</td></tr>` +
      `<tr><td>Username</td><td>${cleanUsername}</td></tr>` +
      `<tr><td>Nama</td><td>${cleanName}</td></tr>` +
      `<tr><td>Main Channel</td><td>📢 ${channelTitle} (${htmlEscape(sourceIdForButtons)})</td></tr>` +
      `<tr><td>Waktu</td><td>🕒 ${htmlEscape(time)} WIB</td></tr>` +
    `</table>`,
    extra ? `<p>${extra}</p>` : '',
    `<hr/>`,
    `<h3>⚡ AKSI CEPAT</h3>`,
    `<p><i>${isJoin ? 'Member terdeteksi bergabung ke main channel.' : 'Member terdeteksi meninggalkan main channel.'}</i></p>`
  ].filter(Boolean).join('');

  const profileButton = user.username
    ? {text:'👤 Show Profile', url:`https://t.me/${String(user.username).replace(/^@/, '')}`, style:'primary'}
    : {text:'👤 Show Profile', url:`tg://user?id=${userId}`, style:'primary'};
  let botUrl = '';
  try {
    const me = await bot.getMe();
    if (me?.username) botUrl = `https://t.me/${me.username}`;
  } catch {}
  const keyboard = {inline_keyboard:[
    [profileButton],
    [
      {text:'🚫 Ban User',callback_data:`mainchan_ban_${sourceIdForButtons}_${userId}`,style:'danger'},
      ...(botUrl ? [{text:'🤖 BOT',url:botUrl,style:'success'}] : [])
    ]
  ]};

  try {
    await sendRichMenu(channelId, text, keyboard, null);
    return true;
  } catch (e) {
    console.warn('[MAIN CHANNEL] member notification:', e.message);
    return false;
  }
}


async function notifyAmPremiumActivity(action, user, details = {}) {
  const channelId = String(c.MAIN_CHANNEL_ID || c.MAIN_CHANNEL_USERNAME || '').trim();
  if (!channelId || !user?.id) {
    console.warn('[AMPREM NOTIFY] MAIN_CHANNEL_ID / MAIN_CHANNEL_USERNAME belum dikonfigurasi.');
    return false;
  }
  try {
    // Confirm the configured main channel is reachable before building the card.
    // This also makes configuration/permission errors visible in Pterodactyl logs.
    try { await bot.getChat(channelId); } catch (chatErr) {
      console.warn('[AMPREM NOTIFY] Main channel tidak bisa diakses:', chatErr?.response?.body?.description || chatErr?.message || chatErr);
      return false;
    }
    const { name, username } = formatUserIdentity(user);
    const time = moment().tz(c.TIMEZONE).format('DD/MM/YYYY HH:mm:ss');
    const isBulk = action === 'bulk';
    const actionLabel = isBulk ? 'Bulk Create Amprem' : 'Create Amprem';
    const total = details.total != null ? Number(details.total) : null;
    const success = details.success != null ? Number(details.success) : null;
    const failed = details.failed != null ? Number(details.failed) : null;
    const text = [
      `<h2>💎 ${isBulk ? 'BULK AMPREM ACTIVITY' : 'AMPREM ACTIVITY'}</h2>`,
      `<p>👤 <b>${htmlEscape(name)}</b> ${username !== '-' ? htmlEscape(username) : ''}</p>`,
      `<table bordered compact>`,
      `<tr><th>DATA</th><th>INFORMASI</th></tr>`,
      `<tr><td>Action</td><td><b>${htmlEscape(actionLabel)}</b></td></tr>`,
      `<tr><td>Status</td><td>🟢 ${htmlEscape(details.status || 'Berhasil')}</td></tr>`,
      total != null ? `<tr><td>Total</td><td><code>${htmlEscape(String(total))}</code></td></tr>` : '',
      success != null ? `<tr><td>Success</td><td><code>${htmlEscape(String(success))}</code></td></tr>` : '',
      failed != null ? `<tr><td>Failed</td><td><code>${htmlEscape(String(failed))}</code></td></tr>` : '',
      `<tr><td>Waktu</td><td>${htmlEscape(time)} WIB</td></tr>`,
      `</table>`,
      `<hr/><footer>Notifikasi aktivitas Amprem • Data akun/credential tidak ditampilkan.</footer>`
    ].filter(Boolean).join('');

    let botUrl = '';
    try { const me = await bot.getMe(); if (me?.username) botUrl = `https://t.me/${me.username}`; } catch {}
    const keyboard = { inline_keyboard: [[
      user.username
        ? { text:'👤 Show Profile', url:`https://t.me/${String(user.username).replace(/^@/,'')}`, style:'primary' }
        : { text:'👤 Show Profile', url:`tg://user?id=${String(user.id)}`, style:'primary' },
      { text:'🚫 Ban User', callback_data:`amprem_ban_${channelId}_${String(user.id)}`, style:'danger' },
      ...(botUrl ? [{ text:'🤖 BOT', url:botUrl, style:'success' }] : [])
    ]]};

    // First try the same Rich Message pipeline used by the rest of the bot.
    // Then explicitly fall back to Telegram's normal sendMessage. This is
    // important for deployments where sendRichMessage is unavailable for a
    // channel even though ordinary channel posting is allowed.
    try {
      const result = await sendRichMenu(channelId, text, keyboard, null);
      if (result) { console.log(`[AMPREM NOTIFY] sent to ${channelId}`); return true; }
    } catch (richErr) {
      console.warn('[AMPREM NOTIFY] Rich Message failed:', richErr?.message || richErr);
    }

    try {
      const fallbackText = text.replace(/<\/?(?:table|tr|th|td|h2|p|footer|hr)[^>]*>/gi, '\n').replace(/<[^>]+>/g, '').replace(/\n{3,}/g, '\n\n').trim();
      await safeSendMessage(bot, channelId, fallbackText, {
        parse_mode:'HTML',
        reply_markup:keyboard
      });
      console.log(`[AMPREM NOTIFY] fallback sent to ${channelId}`);
      return true;
    } catch (fallbackErr) {
      console.warn('[AMPREM NOTIFY] fallback failed:', fallbackErr?.message || fallbackErr);
      return false;
    }
  } catch (e) {
    console.warn('[AMPREM NOTIFY] failed:', e?.message || e);
    return false;
  }
}

// Owner-configured Main Channel activity notifications. Every caller uses this
// in a non-blocking way so a channel/network problem can never break the feature
// that generated the activity.
async function notifyMainChannelActivity(type, user, details = {}) {
  const channelId = String(c.MAIN_CHANNEL_ID || c.MAIN_CHANNEL_USERNAME || '').trim();
  if (!channelId || !user?.id) return false;
  try {
    const { name, username } = formatUserIdentity(user);
    const time = moment().tz(c.TIMEZONE).format('DD/MM/YYYY HH:mm:ss');
    const rows = [
      `<tr><td>${E.Name} Pengguna</td><td><b>${htmlEscape(name)}</b></td></tr>`,
      `<tr><td>Username</td><td>${htmlEscape(username)}</td></tr>`,
      `<tr><td>User ID</td><td><code>${htmlEscape(String(user.id))}</code></td></tr>`,
      `<tr><td>Action</td><td><b>${htmlEscape(String(details.action || type || 'ACTIVITY'))}</b></td></tr>`
    ];
    for (const [label, value] of Object.entries(details.fields || {})) {
      if (value == null || value === '') continue;
      rows.push(`<tr><td>${htmlEscape(String(label).slice(0, 60))}</td><td>${htmlEscape(String(value).slice(0, 220))}</td></tr>`);
    }
    rows.push(`<tr><td>${E.watch} Waktu</td><td>${htmlEscape(time)} WIB</td></tr>`);
    // Keep the activity notification intentionally simple and stable.
    // Do NOT render the caller-provided "PLAY ACTIVITY" / "PLAY V2 ACTIVITY"
    // title above the table: those titles can contain custom-emoji markup and
    // are unnecessary because the stable "AKTIVITAS BOT" heading already
    // identifies the notification. This preserves the Rich table + button
    // layout without exposing implementation markup or changing other menus.
    const text = [
      `<p>${E.speaker} <b>AKTIVITAS BOT</b></p>`,
      `<table bordered compact><tr><th>DATA</th><th>DETAIL</th></tr>${rows.join('')}</table>`,
      `<blockquote>${E.info} Aktivitas otomatis di <b>${htmlEscape(String(c.MAIN_CHANNEL_USERNAME || 'Main Channel'))}</b>.</blockquote>`
    ].join('');
    const profileButton = user.username
      ? { text:'👤 Show Profile', url:`https://t.me/${String(user.username).replace(/^@/,'')}`, style:'primary' }
      : { text:'👤 Show Profile', url:`tg://user?id=${String(user.id)}`, style:'primary' };
    await sendRichMenu(channelId, text, { inline_keyboard:[[profileButton]] }, null);
    return true;
  } catch (e) {
    console.warn(`[MAIN CHANNEL] ${String(type || 'activity')} notification failed:`, e?.response?.data?.description || e?.message || e);
    return false;
  }
}

function channelMemberJoined(oldStatus, newStatus) {
  return ['left','kicked'].includes(oldStatus) && ['member','administrator','creator','restricted'].includes(newStatus);
}

function channelMemberLeft(oldStatus, newStatus) {
  return ['member','administrator','creator','restricted'].includes(oldStatus) && ['left','kicked'].includes(newStatus);
}


// ======================================= //
// 🕌 RELAXING TIME / WEATHER / CLOCK HELPERS
// ======================================= //
const WORLD_TIMEZONES = {
  'jakarta': 'Asia/Jakarta', 'wib': 'Asia/Jakarta', 'makassar': 'Asia/Makassar', 'wita': 'Asia/Makassar',
  'jayapura': 'Asia/Jayapura', 'wit': 'Asia/Jayapura', 'singapore': 'Asia/Singapore', 'kuala lumpur': 'Asia/Kuala_Lumpur',
  'tokyo': 'Asia/Tokyo', 'seoul': 'Asia/Seoul', 'beijing': 'Asia/Shanghai', 'shanghai': 'Asia/Shanghai',
  'dubai': 'Asia/Dubai', 'makkah': 'Asia/Riyadh', 'riyadh': 'Asia/Riyadh', 'london': 'Europe/London',
  'paris': 'Europe/Paris', 'berlin': 'Europe/Berlin', 'moscow': 'Europe/Moscow', 'new york': 'America/New_York',
  'los angeles': 'America/Los_Angeles', 'chicago': 'America/Chicago', 'sydney': 'Australia/Sydney'
};

function worldClockText(name, timezone) {
  const now = new Date();
  const text = new Intl.DateTimeFormat('id-ID', {
    timeZone: timezone, dateStyle: 'full', timeStyle: 'medium'
  }).format(now);
  return `🌍 <b>Jam Dunia</b>\n\n📍 <b>${htmlEscape(name)}</b>\n🕒 <code>${htmlEscape(text)}</code>\n🌐 Zona: <code>${htmlEscape(timezone)}</code>`;
}

async function geocodeLocation(query) {
  const res = await axios.get('https://geocoding-api.open-meteo.com/v1/search', {
    params: { name: query, count: 1, language: 'id', format: 'json' }, timeout: 15000
  });
  const r = res.data?.results?.[0];
  if (!r) throw new Error('Lokasi tidak ditemukan. Coba nama kota yang lebih jelas.');
  return r;
}

function weatherCodeLabel(code) {
  const map = {
    0:['☀️','Cerah'],1:['🌤️','Cerah berawan'],2:['⛅','Berawan sebagian'],3:['☁️','Mendung'],
    45:['🌫️','Berkabut'],48:['🌫️','Kabut beku'],51:['🌦️','Gerimis ringan'],53:['🌦️','Gerimis'],55:['🌧️','Gerimis lebat'],
    61:['🌦️','Hujan ringan'],63:['🌧️','Hujan'],65:['🌧️','Hujan lebat'],71:['🌨️','Salju ringan'],73:['🌨️','Salju'],75:['❄️','Salju lebat'],
    80:['🌦️','Hujan lokal'],81:['🌧️','Hujan lokal'],82:['⛈️','Hujan deras lokal'],95:['⛈️','Badai petir'],96:['⛈️','Badai petir + es'],99:['⛈️','Badai petir + es']
  };
  return map[code] || ['🌡️','Kondisi tidak diketahui'];
}

async function getWeatherByCoords(latitude, longitude, label='Lokasi kamu') {
  const res = await axios.get('https://api.open-meteo.com/v1/forecast', {
    params: {
      latitude, longitude,
      current: 'temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m',
      daily: 'weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max',
      timezone: 'auto', forecast_days: 1
    }, timeout: 15000
  });
  const d = res.data;
  const cur = d?.current;
  const daily = d?.daily;
  if (!cur || !daily) throw new Error('Data cuaca tidak lengkap dari server.');
  const [icon, condition] = weatherCodeLabel(cur.weather_code);
  return `🌦️ <b>Cuaca Hari Ini</b>\n\n📍 <b>${htmlEscape(label)}</b>\n${icon} <b>${condition}</b>\n🌡️ Suhu: <code>${cur.temperature_2m}°C</code>\n🤗 Terasa: <code>${cur.apparent_temperature}°C</code>\n💧 Kelembapan: <code>${cur.relative_humidity_2m}%</code>\n💨 Angin: <code>${cur.wind_speed_10m} km/jam</code>\n📈 Maks/Min: <code>${daily.temperature_2m_max?.[0]}°C / ${daily.temperature_2m_min?.[0]}°C</code>\n🌧️ Peluang hujan: <code>${daily.precipitation_probability_max?.[0] ?? '-'}%</code>\n\n<i>Data prakiraan otomatis dari Open-Meteo.</i>`;
}

async function getWeatherByCity(city) {
  const loc = await geocodeLocation(city);
  const label = [loc.name, loc.admin1, loc.country].filter(Boolean).join(', ');
  return getWeatherByCoords(loc.latitude, loc.longitude, label);
}

async function getPrayerTimesByCity(city='Jakarta') {
  const date = moment().tz(c.TIMEZONE).format('DD-MM-YYYY');
  const res = await axios.get(`https://api.aladhan.com/v1/timingsByCity/${date}`, {
    params: { city, country: 'Indonesia', method: 11, school: 0, timezone: c.TIMEZONE }, timeout: 15000
  });
  const t = res.data?.data?.timings;
  if (!t) throw new Error('Jadwal sholat tidak tersedia untuk kota tersebut.');
  return `🕌 <b>Waktu Sholat Hari Ini</b>\n📍 <b>${htmlEscape(city)}</b>\n📅 <code>${htmlEscape(moment().tz(c.TIMEZONE).format('dddd, DD MMMM YYYY'))}</code>\n\n🌅 Subuh: <b>${t.Fajr}</b>\n🌄 Terbit: <b>${t.Sunrise}</b>\n☀️ Dzuhur: <b>${t.Dhuhr}</b>\n🌤️ Ashar: <b>${t.Asr}</b>\n🌇 Maghrib: <b>${t.Maghrib}</b>\n🌙 Isya: <b>${t.Isha}</b>\n\n<i>Metode perhitungan dapat berbeda dari jadwal masjid setempat.</i>`;
}

async function fetchQuranPage(juz, page) {
  const key = `${juz}:${page}`;
  const cached = quranPageCache.get(key);
  if (cached && Date.now() - cached.updatedAt < 30 * 60 * 1000) return cached;

  let full = quranJuzCache.get(String(juz));
  if (!full || Date.now() - full.updatedAt >= 30 * 60 * 1000) {
    const [ar, id] = await Promise.all([
      axios.get(`https://api.alquran.cloud/v1/juz/${juz}/quran-uthmani`, { params:{limit:2000}, timeout:30000 }),
      axios.get(`https://api.alquran.cloud/v1/juz/${juz}/id.indonesian`, { params:{limit:2000}, timeout:30000 })
    ]);
    const aa = ar.data?.data?.ayahs || [];
    const ii = id.data?.data?.ayahs || [];
    if (!aa.length) throw new Error('Ayat Juz tidak ditemukan.');
    full = {
      ayahs: aa.map((a, i) => ({ arabic:a.text, translation:ii[i]?.text || '', number:a.numberInSurah, surah:a.surah?.englishName || a.surah?.name || '' })),
      total: aa.length,
      title: ar.data?.data?.name || `Juz ${juz}`,
      updatedAt: Date.now()
    };
    quranJuzCache.set(String(juz), full);
  }

  const ayahs = full.ayahs.slice(page * 5, page * 5 + 5);
  if (!ayahs.length) throw new Error('Halaman Juz tidak ditemukan.');
  const result = { ...full, ayahs, updatedAt: Date.now() };
  quranPageCache.set(key, result);
  return result;
}
async function sendQuranPage(chatId, juz, page, oldMessageId=null) {
  const data = await fetchQuranPage(juz, page);
  const maxPage = Math.max(0, Math.ceil(data.total / 5) - 1);
  const body = data.ayahs.map(a => `📖 <b>${a.surah} ${a.number}</b>\n${a.arabic}\n<i>${htmlEscape(a.translation)}</i>`).join('\n\n');
  const text = `🕌 <b>Al-Qur’an — Juz ${juz}/30</b>\nHalaman <code>${page+1}/${maxPage+1}</code>\n\n${body}`;
  const opts = { chat_id:chatId, message_id:oldMessageId, parse_mode:'HTML', reply_markup:quranKeyboard(juz,page,data.total) };
  if (oldMessageId) return bot.editMessageText(text, opts).catch(async () => safeRichTextMessage(chatId,text,{parse_mode:'HTML',reply_markup:opts.reply_markup}));
  return safeRichTextMessage(chatId,text,{parse_mode:'HTML',reply_markup:opts.reply_markup});
}

function relaxSearchUrl(type, query) {
  const q = encodeURIComponent(query);
  if (type === 'dracin') return `https://www.google.com/search?q=${encodeURIComponent('dracin china drama ' + query)}`;
  return `https://openlibrary.org/search?q=${q}`;
}

// ======================================= //
// 📡 /start
// ======================================= //
bot.onText(/^\/start(?:\s+(.+))?$/, async (msg, match) => {
  const param = (match[1] || '').trim();
  const newUser = claimStartNotification(msg.from.id);
  upsertUser(msg.from, msg.chat.id);
  upsertChat(msg.chat);
  const botBan = isUserBanned(msg.from.id);
  if (botBan && botBan.reason === 'amprem_channel_moderation') {
    return safeRichSendMessage(msg.chat.id,
      `<blockquote>🚫 <b>AKSES DIBATASI</b></blockquote>

` +
      `Anda terkena pelanggaran oleh bot kami dan akses bot telah dibatasi.

` +
      `Silakan hubungi <b>Owner / Developer</b> untuk mengajukan pembukaan pelanggaran.`,
      {parse_mode:'HTML',reply_markup:{inline_keyboard:[
        [{text:'👨‍💻 Hubungi Owner',url:c.OWNER_URL,style:'primary'}],
        [{text:'📢 Channel',url:c.CHANNEL_URL,style:'success'}]
      ]}});
  }
  // Owner alert is emitted on the first /start itself, even before ForceSub.
  // This avoids the old pending-notification path silently disappearing when
  // the user never reaches the check-join callback.
  if (newUser) {
    const notified = await notifyNewUser(msg.from).catch(e => { console.warn('[OWNER] new user notify:', e?.message || e); return false; });
    if (notified) markStartNotificationSent(msg.from.id);
  }
  if (!(await requireJoin(msg))) return;
  await sendRichStartMenu(msg.chat.id, msg.from, msg.message_id);
});


// ======================================= //
// 💎 /richmessage — AI PROMO → RICH MESSAGE
// ======================================= //
function parseRichAiJson(raw) {
  let text = String(raw || '').trim();
  text = text.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '').trim();
  try { return JSON.parse(text); } catch {}

  // Provider-safe recovery: locate a balanced JSON object while respecting
  // quoted strings. This handles a model that accidentally adds one sentence
  // before/after an otherwise valid JSON payload.
  const first = text.indexOf('{');
  if (first < 0) throw new Error(`Output AI bukan JSON: ${text.slice(0, 180)}`);
  let depth = 0, inString = false, escaped = false;
  for (let i = first; i < text.length; i++) {
    const ch = text[i];
    if (inString) {
      if (escaped) escaped = false;
      else if (ch === '\\') escaped = true;
      else if (ch === '"') inString = false;
      continue;
    }
    if (ch === '"') { inString = true; continue; }
    if (ch === '{') depth++;
    else if (ch === '}') {
      depth--;
      if (depth === 0) return JSON.parse(text.slice(first, i + 1));
    }
  }
  throw new Error(`Output AI bukan JSON valid: ${text.slice(0, 180)}`);
}

// Premium Telegram emoji palette used by /richmessage.
// AI chooses only the semantic key; the bot maps it to a known-safe emoji ID.
// This keeps the layout consistent and prevents the AI from inventing invalid
// <tg-emoji> tags or emoji IDs.
const RICH_AI_EMOJI = Object.freeze({
  fire: E.fire,
  star: E.star,
  gift: E.gift,
  money: E.wink,
  info: E.info,
  check: E.check,
  warning: E.warning,
  link: E.link,
  phone: E.phone,
  user: E.Name,
  id: E.id,
  stats: E.stats,
  chart: E.chart,
  tools: E.tools,
  box: E.box,
  folder: E.folder,
  download: E.download,
  globe: E.globe,
  group: E.group,
  crown: E.crown,
  shield: E.shield,
  flash: E.flash,
  chat: E.chat,
  share: E.share,
  image: E.image,
  video: E.video,
  movie: E.movie,
  web: E.web,
  clock: E.watch,
  pin: E.pin,
  bot: E.bot,
  ai: E.ai,
  party: E.party,
  heart: E.heart,
  speaker: E.speaker,
  market: E.market,
  refresh: E.refresh,
  key: E.key,
  lock: E.lock,
  hourglass: E.hourglass,
  clipboard: E.clipboard,
  ruler: E.ruler,
  eyes: E.eyes,
  next: E.next,
  tiktok: E.tiktok,
  wink: E.wink
});

function richAiEmoji(key, fallback = 'info') {
  const k = String(key || '').trim().toLowerCase().replace(/[^a-z0-9_-]/g, '');
  return RICH_AI_EMOJI[k] || RICH_AI_EMOJI[fallback] || '';
}

// The AI picks semantic emoji keys, while this arranger controls the visual
// rhythm. It intentionally avoids putting an emoji on every word and tries
// to use a different Premium Emoji for each visible section/row. This gives
// /richmessage a rich, varied look without allowing the model to spam or
// invent custom-emoji markup/IDs.
const RICH_PREMIUM_ARRANGEMENT = Object.freeze({
  title:    ['fire','star','crown','gift','flash','party','market','shield'],
  summary:  ['info','speaker','chat','heart','eyes','globe','web'],
  desc:     ['check','phone','tools','ai','image','video','movie','bot'],
  table:    ['stats','chart','box','folder','clipboard','ruler','key','download'],
  rows:     ['money','market','gift','check','shield','phone','clock','link','box','download','crown','star'],
  detail:  ['info','pin','refresh','key','lock','hourglass','tools','globe','chat','speaker'],
  quote:   ['warning','speaker','info','shield','heart','star'],
  footer:  ['link','next','party','check','share','globe']
});

function createPremiumEmojiArranger() {
  const used = new Set();
  const pick = (preferred, fallbackPool = []) => {
    const candidates = [...(preferred || []), ...(fallbackPool || []), ...Object.keys(RICH_AI_EMOJI)];
    for (const key of candidates) {
      const k = String(key || '').toLowerCase();
      if (!k || used.has(k) || !RICH_AI_EMOJI[k]) continue;
      used.add(k);
      return RICH_AI_EMOJI[k];
    }
    // Only reached if the visible card somehow needs more unique emojis than
    // the registered palette. Reusing a safe Premium Emoji is preferable to
    // emitting invalid markup or a raw emoji-id string.
    return RICH_AI_EMOJI.info || '';
  };
  return { used, pick };
}

function buildAiRichPromotion(data) {
  const emoji = data?.emoji || {};
  const layout = RICH_AI_LAYOUT_TYPES.includes(String(data?.layout || '').toLowerCase()) ? String(data.layout).toLowerCase() : 'promo';
  const title = htmlEscape(String(data?.title || 'PROMO TERBARU').trim().slice(0, 180));
  const descriptionRaw = String(data?.description || '').trim().replace(/\s+/g, ' ');
  const summaryRaw = String(data?.summary || '').trim().replace(/\s+/g, ' ');
  const quoteRaw = String(data?.quote || '').trim().replace(/\s+/g, ' ');
  const footerRaw = String(data?.footer || '').trim().replace(/\s+/g, ' ');
  const desc = htmlEscape(descriptionRaw.slice(0, 900));
  const summary = htmlEscape((summaryRaw || descriptionRaw).slice(0, 240));
  const quote = htmlEscape(quoteRaw.slice(0, 500));
  const footer = htmlEscape(footerRaw.slice(0, 300));
  const rows = Array.isArray(data?.table?.rows) ? data.table.rows : [];
  const headers = Array.isArray(data?.table?.headers) && data.table.headers.length >= 2
    ? data.table.headers.slice(0, 2).map(v => htmlEscape(String(v).slice(0, 70))) : ['INFO','DETAIL'];
  const arranger = createPremiumEmojiArranger();
  const safeEmoji = (key, fallback='info') => {
    const preferred = key && RICH_AI_EMOJI[key] ? [key] : [];
    const fallbackKeys = fallback && RICH_AI_EMOJI[fallback] ? [fallback] : [];
    return arranger.pick(preferred, fallbackKeys);
  };
  const titleEmoji = safeEmoji(emoji.title, layout === 'warning' ? 'warning' : layout === 'product' ? 'box' : 'fire');
  const summaryEmoji = safeEmoji(emoji.description, layout === 'info' ? 'info' : 'speaker');
  const descEmoji = safeEmoji(emoji.description, 'check');
  const tableEmoji = safeEmoji(emoji.table, layout === 'status' ? 'stats' : layout === 'download' ? 'download' : 'chart');
  const safeRows = rows.slice(0, 8).map((row, index) => {
    const a = Array.isArray(row) ? row[0] : row?.label;
    const b = Array.isArray(row) ? row[1] : row?.value;
    // Prefer the AI's semantic choice, but always rotate to an unused Premium
    // Emoji when that choice has already been used elsewhere on the card.
    const rowEmoji = safeEmoji(Array.isArray(row) ? '' : row?.emoji, RICH_PREMIUM_ARRANGEMENT.rows[index % RICH_PREMIUM_ARRANGEMENT.rows.length]);
    return `<tr><td>${rowEmoji ? rowEmoji + ' ' : ''}${htmlEscape(String(a ?? '-').slice(0, 90))}</td><td>${htmlEscape(String(b ?? '-').slice(0, 180))}</td></tr>`;
  }).join('');
  const buttons = Array.isArray(data?.buttons) ? data.buttons.slice(0, 4).map(b => ({
    text: String(b?.text || 'Buka').trim().replace(/\s+/g,' ').slice(0, 40), url: safeRichUrl(String(b?.url || '').trim())
  })).filter(b => b.url && /^https?:\/\//i.test(b.url)) : [];
  const details = Array.isArray(data?.details) ? data.details.slice(0, 5).map(d => ({
    title: htmlEscape(String(d?.title || 'Detail').trim().slice(0, 90)),
    text: htmlEscape(String(d?.text || '').trim().replace(/\s+/g,' ').slice(0, 500))
  })).filter(d => d.text) : [];
  const labels = {
    product:'PRODUCT', service:'SERVICE', package:'PACKAGE', pricing:'PRICING', promo:'PROMOTION', offer:'SPECIAL OFFER', stock:'STOCK UPDATE',
    order:'ORDER', payment:'PAYMENT', download:'DOWNLOAD', announcement:'ANNOUNCEMENT', update:'UPDATE', status:'STATUS', warning:'WARNING',
    info:'INFORMATION', event:'EVENT', giveaway:'GIVEAWAY', membership:'MEMBERSHIP', contact:'CONTACT', portfolio:'PORTFOLIO', review:'REVIEW',
    comparison:'COMPARISON', faq:'FAQ', steps:'STEPS', tutorial:'TUTORIAL', schedule:'SCHEDULE', market:'MARKET', changelog:'CHANGELOG', news:'NEWS'
  };
  const kicker = labels[layout] || 'PROMOTION';
  const quoteEmoji = safeEmoji(emoji.quote, layout === 'warning' ? 'warning' : 'info');
  const footerEmoji = safeEmoji(emoji.footer, 'link');
  const detailRows = details.map((d, index) => {
    const detailEmoji = arranger.pick([RICH_PREMIUM_ARRANGEMENT.detail[index % RICH_PREMIUM_ARRANGEMENT.detail.length]]);
    return `<p><b>${detailEmoji} ${d.title}</b><br>${d.text}</p>`;
  }).join('');
  const body = [
    `<p><b>${titleEmoji} ${htmlEscape(kicker)}</b></p>`,
    `<h2>${title}</h2>`,
    summary && summary !== desc ? `<p>${summaryEmoji} ${summary}</p>` : '',
    desc && desc.length > 260 ? `<details><summary>${descEmoji} Detail</summary><p>${desc}</p></details>` : (desc ? `<p>${descEmoji} ${desc}</p>` : ''),
    safeRows ? `<table bordered compact><tr><th>${tableEmoji} ${headers[0]}</th><th>${headers[1]}</th></tr>${safeRows}</table>` : '',
    details.length ? `<details><summary>${arranger.pick(RICH_PREMIUM_ARRANGEMENT.detail)} Detail Tambahan</summary>${detailRows}</details>` : '',
    quote ? `<blockquote expandable>${quoteEmoji} <b>CATATAN</b>\n${quote}</blockquote>` : '',
    footer ? `<blockquote>${footerEmoji} ${footer}</blockquote>` : ''
  ].filter(Boolean).join('');
  const keyboardRows = [];
  for (let i=0;i<buttons.length;i+=2) keyboardRows.push(buttons.slice(i,i+2).map(b=>({text:b.text,url:b.url,style:'primary'})));
  return { body, keyboard: keyboardRows.length ? {inline_keyboard:keyboardRows} : undefined, layout };
}

function getRichMessagePhotoFileId(msg) {
  const photo = Array.isArray(msg?.photo) && msg.photo.length ? msg.photo[msg.photo.length - 1] : null;
  if (photo?.file_id) return photo.file_id;
  const replyPhoto = Array.isArray(msg?.reply_to_message?.photo) && msg.reply_to_message.photo.length
    ? msg.reply_to_message.photo[msg.reply_to_message.photo.length - 1]
    : null;
  return replyPhoto?.file_id || null;
}

function stripRichMessageCommand(text) {
  return String(text || '').replace(/^\s*\/richmessage(?:@\w+)?(?:\s+|$)/i, '').trim();
}

function getRichMessageInput(msg) {
  const isDirectPhoto = Array.isArray(msg?.photo) && msg.photo.length > 0;
  const reply = msg?.reply_to_message;
  const rawSource = isDirectPhoto
    ? String(msg?.caption || '').trim()
    : String(reply?.text || reply?.caption || '').trim();
  return {
    source: stripRichMessageCommand(rawSource),
    photoFileId: getRichMessagePhotoFileId(msg),
    isDirectPhoto
  };
}

function richMessagePhotoChoiceKeyboard() {
  return {
    inline_keyboard: [
      [
        { text: 'Foto + Rich', callback_data: 'richmessage_photo', style: 'success', icon_custom_emoji_id: '5267139375447159076' },
        { text: 'Rich Saja', callback_data: 'richmessage_text', style: 'primary', icon_custom_emoji_id: '5440660757194744323' }
      ],
      [{ text: 'Batal', callback_data: 'richmessage_photo_cancel', style: 'danger', icon_custom_emoji_id: '5787672755839176187' }]
    ]
  };
}

async function sendRichPromotionWithPhoto(chatId, body, keyboard, photoFileId, replyToMsgId = null) {
  const cleanCaption = normalizeRichLayout(String(body || '').trim());
  const richMarkdown = `![Promotion](tg://photo?id=promotion_photo)\n\n${cleanCaption}\n${richButtonRowsMarkup(keyboard)}`;
  const payload = {
    chat_id: chatId,
    rich_message: {
      markdown: richMarkdown,
      media: [{ id: 'promotion_photo', media: { type: 'photo', media: photoFileId } }]
    }
  };
  if (replyToMsgId) payload.reply_parameters = { message_id: replyToMsgId };

  if (!richTransportBlocked()) {
    try {
      const res = await axios.post(`https://api.telegram.org/bot${c.BOT}/sendRichMessage`, payload, { timeout: 30000 });
      if (!res.data?.ok) throw new Error(res.data?.description || 'Telegram menolak Rich Message foto.');
      richTransport.disabledUntil = 0;
      return res.data.result;
    } catch (e) {
      if (shouldBypassRichTransport(e)) {
        richTransport.disabledUntil = Date.now() + RICH_MENU_COOLDOWN_MS;
        if (Date.now() - richTransport.lastLogAt > 5000) {
          richTransport.lastLogAt = Date.now();
          console.warn(`[RICH PHOTO] transport timeout/network error; fallback foto + teks dipakai selama ${Math.round(RICH_MENU_COOLDOWN_MS / 1000)}s:`, e?.message || e);
        }
      } else {
        console.error('[RICH PHOTO] Rich Message foto gagal, fallback foto + teks:', e?.response?.data?.description || e.message);
      }
    }
  }

  try {
    const sentPhoto = await bot.sendPhoto(chatId, photoFileId, {
      reply_parameters: replyToMsgId ? { message_id: replyToMsgId } : undefined
    });
    return await safeRichTextMessage(chatId, cleanCaption, {
      reply_markup: keyboard,
      reply_to_message_id: sentPhoto?.message_id || undefined
    });
  } catch (fallbackError) {
    console.error('[RICH PHOTO] fallback foto + teks gagal:', fallbackError?.message || fallbackError);
    return sendRichMenu(chatId, cleanCaption, keyboard, null, replyToMsgId);
  }
}

bot.onText(/^\/richmessage(?:@\w+)?$/i, async (msg) => {
  const input = getRichMessageInput(msg);
  const source = input.source;
  const photoFileId = input.photoFileId;

  if (!source) {
    return safeRichTextMessage(msg.chat.id,
      `<h2>💎 RICH MESSAGE AI</h2>` +
      `<p>Reply pesan promosi/jualan yang ingin diubah, lalu kirim <code>/richmessage</code>.</p>` +
      `<p>Kalau promosinya memakai foto, foto juga bisa ikut masuk ke hasil Rich Message.</p>` +
      `<table bordered compact><tr><th>INPUT</th><th>HASIL</th></tr>` +
      `<tr><td>📝 Teks</td><td>Rich Message + tabel + tombol</td></tr>` +
      `<tr><td>🖼️ Foto + caption</td><td>Pilih Foto + Rich atau Rich saja</td></tr></table>`,
      {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'↩️ Menu Rich',callback_data:'rich_message'}]]}});
  }

  const loading = await safeRichTextMessage(
    msg.chat.id,
    `<p>${E.ai} <b>AI sedang menyusun Rich Message...</b></p>` +
    `<p>${photoFileId ? '${E.image} Foto terdeteksi. Setelah selesai kamu bisa memilih dua versi output.' : 'Menata judul, isi, tabel, dan tombol.'}</p>`,
    {parse_mode:'HTML'}
  );

  try {
    const prompt = `Ubah teks promosi/jualan/informasi berikut menjadi Rich Message Telegram yang sangat rapi, menarik, ringkas, dan siap dikirim. Jangan mengubah fakta, harga, kontak, username, URL, tanggal, jumlah, atau klaim utama. AI yang mengatur seluruh desain: pilih satu layout dari 30 tipe, susun judul, ringkasan, deskripsi, tabel 2 kolom, quote/pullquote, detail yang bisa dilipat, footer, tombol, dan Premium Emoji.

Tipe layout valid: product, service, package, pricing, promo, offer, stock, order, payment, download, announcement, update, status, warning, info, event, giveaway, membership, contact, portfolio, review, comparison, faq, steps, tutorial, schedule, market, changelog, news.

WAJIB output JSON murni tanpa markdown fence dengan schema:
{"layout":"promo","title":"...","description":"...","summary":"...","quote":"...","emoji":{"title":"fire","description":"info","table":"stats","quote":"info","footer":"link"},"table":{"headers":["INFO","DETAIL"],"rows":[{"label":"...","value":"...","emoji":"pin"}]},"details":[{"title":"...","text":"..."}],"buttons":[{"text":"...","url":"https://..."}],"footer":"..."}

Premium Emoji semantic key yang boleh dipakai: fire, star, gift, money, info, check, warning, link, phone, user, id, stats, chart, tools, box, folder, download, globe, group, crown, shield, flash, chat, share, image, video, movie, web, clock, pin, bot, ai, party, heart, speaker, market, refresh, key, lock, hourglass, clipboard, ruler, eyes, next, tiktok, wink.

Aturan desain: gunakan Premium Emoji cukup banyak tetapi TETAP RAPI. Jangan menaruh emoji di setiap kata. Gunakan 1 Premium Emoji untuk kicker/judul, 1 untuk ringkasan bila ada, 1 untuk deskripsi, 1 untuk header tabel, lalu 1 Premium Emoji berbeda untuk setiap baris tabel (maksimal 8), 1 berbeda untuk setiap detail (maksimal 5), 1 untuk quote, dan 1 untuk footer. Hindari pengulangan emoji sebisa mungkin. AI hanya memilih semantic key; bot akan mengatur ulang penempatan dan memastikan variasinya. Ringkasan <=240 karakter, deskripsi <=900 karakter. Jika panjang, pecah menjadi details <=5 item agar bisa dilipat. Maksimal 8 baris tabel, selalu 2 kolom, maksimal 4 tombol. AI harus memadatkan teks dan membuang pengulangan. Jangan mengarang URL. Jangan menulis <tg-emoji> atau emoji-id sendiri; gunakan semantic key saja.

TEKS ASLI:
${source.slice(0,7000)}`;

    const ai = await callRichMessageAI(msg.chat.id, prompt);
    const rendered = buildAiRichPromotion(ai.data);

    if (loading?.message_id) await safeDelete(bot, msg.chat.id, loading.message_id).catch(()=>{});

    if (photoFileId) {
      const uid = String(msg.from?.id || '');
      if (uid) {
        pendingRichPhotoChoice.set(uid, {
          chatId: msg.chat.id,
          rendered,
          photoFileId,
          replyToMsgId: msg.message_id,
          expiresAt: Date.now() + 10 * 60 * 1000
        });
        setTimeout(() => {
          const current = pendingRichPhotoChoice.get(uid);
          if (current?.expiresAt && current.expiresAt <= Date.now()) pendingRichPhotoChoice.delete(uid);
        }, 10 * 60 * 1000 + 1000);
      }

      return sendRichMenu(
        msg.chat.id,
        `<h2>${E.image} PROMO + RICH MESSAGE</h2>` +
        `<p>Foto promosi terdeteksi. Pilih versi hasil yang kamu mau:</p>` +
        `<table bordered compact>` +
        `<tr><th>VERSI</th><th>HASIL</th></tr>` +
        `<tr><td>${E.image} Foto + Rich</td><td>Foto menyatu dengan kartu Rich Message + tabel + tombol</td></tr>` +
        `<tr><td>${E.chat} Rich saja</td><td>Hanya kartu Rich Message seperti sebelumnya</td></tr>` +
        `</table>` +
        `<p><i>Foto tidak diubah atau diunggah ulang. Bot memakai file Telegram yang sudah diterima.</i></p>`,
        richMessagePhotoChoiceKeyboard(),
        null,
        msg.message_id
      );
    }

    return sendRichMenu(msg.chat.id, rendered.body, rendered.keyboard, null, msg.message_id);
  } catch (e) {
    if (loading?.message_id) await safeDelete(bot, msg.chat.id, loading.message_id).catch(()=>{});
    return safeRichTextMessage(msg.chat.id, `<blockquote>❌ <b>RICH MESSAGE GAGAL</b></blockquote><p>${htmlEscape(String(e?.message || 'Semua AI gagal memproses teks.').slice(0,700))}</p><p>Rich Message ini hanya menggunakan <b>Gemini</b>. Tidak ada fallback provider lain.</p>`, {parse_mode:'HTML'});
  }
});



// Direct photo workflow: a photo caption beginning with /richmessage can be
// processed without requiring a separate reply command. The guard prevents a
// duplicate AI request on library versions that already dispatch captions to
// onText.
bot.on('message', async (msg) => {
  if (!Array.isArray(msg?.photo) || !msg.photo.length) return;
  const caption = String(msg?.caption || '').trim();
  if (!/^\/richmessage(?:@\w+)?(?:\s|$)/i.test(caption)) return;

  const uid = String(msg.from?.id || '');
  const guardKey = `${uid}:${msg.chat?.id}:${msg.message_id}`;
  if (!global.__mdRichPhotoCommandGuards) global.__mdRichPhotoCommandGuards = new Map();
  if (global.__mdRichPhotoCommandGuards.has(guardKey)) return;
  global.__mdRichPhotoCommandGuards.set(guardKey, Date.now());
  setTimeout(() => global.__mdRichPhotoCommandGuards.delete(guardKey), 30 * 1000);

  // If the regular onText handler already produced the selector, do nothing.
  if (pendingRichPhotoChoice.has(uid)) return;

  const input = getRichMessageInput(msg);
  if (!input.source || !input.photoFileId) return;

  const loading = await safeRichTextMessage(
    msg.chat.id,
    `<p>${E.ai} <b>AI sedang menyusun Rich Message...</b></p><p>🖼️ Foto terdeteksi dari caption.</p>`,
    {parse_mode:'HTML'}
  );

  try {
    const prompt = `Ubah teks promosi/jualan/informasi berikut menjadi Rich Message Telegram yang sangat rapi, menarik, ringkas, dan siap dikirim. Jangan mengubah fakta, harga, kontak, username, URL, tanggal, jumlah, atau klaim utama. AI yang mengatur seluruh desain: pilih satu layout dari 30 tipe, susun judul, ringkasan, deskripsi, tabel 2 kolom, quote/pullquote, detail yang bisa dilipat, footer, tombol, dan Premium Emoji.

Tipe layout valid: product, service, package, pricing, promo, offer, stock, order, payment, download, announcement, update, status, warning, info, event, giveaway, membership, contact, portfolio, review, comparison, faq, steps, tutorial, schedule, market, changelog, news.

WAJIB output JSON murni tanpa markdown fence dengan schema:
{"layout":"promo","title":"...","description":"...","summary":"...","quote":"...","emoji":{"title":"fire","description":"info","table":"stats","quote":"info","footer":"link"},"table":{"headers":["INFO","DETAIL"],"rows":[{"label":"...","value":"...","emoji":"pin"}]},"details":[{"title":"...","text":"..."}],"buttons":[{"text":"...","url":"https://..."}],"footer":"..."}

Premium Emoji semantic key yang boleh dipakai: fire, star, gift, money, info, check, warning, link, phone, user, id, stats, chart, tools, box, folder, download, globe, group, crown, shield, flash, chat, share, image, video, movie, web, clock, pin, bot, ai, party, heart, speaker, market, refresh, key, lock, hourglass, clipboard, ruler, eyes, next, tiktok, wink.

Aturan desain: gunakan Premium Emoji cukup banyak tetapi TETAP RAPI. Jangan menaruh emoji di setiap kata. Gunakan 1 Premium Emoji untuk kicker/judul, 1 untuk ringkasan bila ada, 1 untuk deskripsi, 1 untuk header tabel, lalu 1 Premium Emoji berbeda untuk setiap baris tabel (maksimal 8), 1 berbeda untuk setiap detail (maksimal 5), 1 untuk quote, dan 1 untuk footer. Hindari pengulangan emoji sebisa mungkin. AI hanya memilih semantic key; bot akan mengatur ulang penempatan dan memastikan variasinya. Ringkasan <=240 karakter, deskripsi <=900 karakter. Jika panjang, pecah menjadi details <=5 item agar bisa dilipat. Maksimal 8 baris tabel, selalu 2 kolom, maksimal 4 tombol. AI harus memadatkan teks dan membuang pengulangan. Jangan mengarang URL. Jangan menulis <tg-emoji> atau emoji-id sendiri; gunakan semantic key saja.

TEKS ASLI:
${input.source.slice(0,7000)}`;

    const ai = await callRichMessageAI(msg.chat.id, prompt);
    const rendered = buildAiRichPromotion(ai.data);
    if (loading?.message_id) await safeDelete(bot, msg.chat.id, loading.message_id).catch(()=>{});

    pendingRichPhotoChoice.set(uid, {
      chatId: msg.chat.id,
      rendered,
      photoFileId: input.photoFileId,
      replyToMsgId: msg.message_id,
      expiresAt: Date.now() + 10 * 60 * 1000
    });

    return sendRichMenu(
      msg.chat.id,
      `<h2>${E.image} PROMO + RICH MESSAGE</h2>` +
      `<p>Foto promosi terdeteksi. Pilih versi hasil yang kamu mau:</p>` +
      `<table bordered compact><tr><th>VERSI</th><th>HASIL</th></tr>` +
      `<tr><td>${E.image} Foto + Rich</td><td>Foto menyatu dengan kartu Rich Message + tabel + tombol</td></tr>` +
      `<tr><td>📝 Rich saja</td><td>Hanya kartu Rich Message seperti sebelumnya</td></tr></table>`,
      richMessagePhotoChoiceKeyboard(),
      null,
      msg.message_id
    );
  } catch (e) {
    if (loading?.message_id) await safeDelete(bot, msg.chat.id, loading.message_id).catch(()=>{});
    return safeRichTextMessage(msg.chat.id, `<blockquote>❌ <b>RICH MESSAGE GAGAL</b></blockquote><p>${htmlEscape(String(e?.message || 'Semua AI gagal memproses teks.').slice(0,700))}</p><p>Rich Message ini hanya menggunakan <b>Gemini</b>. Tidak ada fallback provider lain.</p>`, {parse_mode:'HTML'});
  }
});


// ======================================= //
// 💎 /rich — legacy JSON Rich Message
// ======================================= //
bot.onText(/^\/rich$/i, async (msg) => {
  const uid = String(msg.from?.id || '');
  if (!uid) return;
  pendingRichMessage.set(uid, {
    chatId: msg.chat.id,
    expiresAt: Date.now() + 10 * 60 * 1000
  });
  let username = 'BOT_USERNAME';
  try {
    const me = await bot.getMe();
    username = me.username || username;
  } catch {}
  return safeRichTextMessage(msg.chat.id, richHelpText(username), {
    parse_mode: 'HTML',
    disable_web_page_preview: true,
    reply_markup: backKeyboard()
  });
});



// ======================================= //
// /pasar & /saham — MARKET MONITOR
// ======================================= //
bot.onText(/^\/pasar(?:\s+(.+))?$/i, async (msg, match) => {
  if (!(await requireJoin(msg))) return;
  try {
    const symbol = match[1] ? normalizeMarketSymbol(match[1]) : '';
    const text = symbol ? await marketDetailText(symbol) : await marketHomeText();
    return sendMenuPhoto(bot, msg.chat.id, c.BANNER_URL, {
      caption: text, parse_mode: 'HTML',
      reply_markup: symbol ? marketDetailKeyboard(symbol) : marketKeyboard()
    });
  } catch (e) {
    return safeRichTextMessage(msg.chat.id,
      `${E.cross} <b>Market Monitor tidak dapat mengambil data.</b>\n<blockquote>${htmlEscape(e.message)}</blockquote>`,
      { parse_mode:'HTML', reply_markup: backKeyboard() });
  }
});

bot.onText(/^\/saham(?:\s+(.+))?$/i, async (msg, match) => {
  if (!(await requireJoin(msg))) return;
  const raw = (match[1] || '').trim();
  if (!raw) {
    return safeRichTextMessage(msg.chat.id,
      `${E.search} <b>Cari Saham</b>\n\nKetik contoh: <code>/saham BBCA</code> atau <code>/saham AAPL</code>`,
      { parse_mode:'HTML', reply_markup: marketKeyboard() });
  }
  try {
    const symbol = normalizeMarketSymbol(raw);
    const text = await marketDetailText(symbol);
    return sendMenuPhoto(bot, msg.chat.id, c.BANNER_URL, {
      caption: text, parse_mode:'HTML', reply_markup: marketDetailKeyboard(symbol)
    });
  } catch (e) {
    return safeRichTextMessage(msg.chat.id,
      `${E.cross} <b>Saham tidak ditemukan</b>\n<blockquote>${htmlEscape(e.message)}</blockquote>`,
      { parse_mode:'HTML', reply_markup: marketKeyboard() });
  }
});

// /tradingview — market chart dashboard
bot.onText(/^\/tradingview(?:\s+([^\s]+)(?:\s+(1d|1w|1mo|3mo))?)?$/i, async (msg, match) => {
  if (!(await requireJoin(msg))) return;
  const symbol=normalizeMarketSymbol(match?.[1] || '^JKSE'); const period=match?.[2] || '1mo';
  try { const text=await marketTradingText(symbol,period); return sendMenuPhoto(bot,msg.chat.id,c.BANNER_URL,{caption:text,parse_mode:'HTML',reply_markup:marketTradingKeyboard(symbol,period)}); }
  catch(e){ return safeRichTextMessage(msg.chat.id,`${E.cross} <b>Trading View gagal mengambil data.</b>\n<code>${htmlEscape(e.message)}</code>`,{parse_mode:'HTML',reply_markup:marketKeyboard()}); }
});

bot.onText(/^\/bandingkan\s+([^\s]+)\s+([^\s]+)$/i, async (msg, match) => {
  if (!(await requireJoin(msg))) return;
  try { const text=await marketCompareText(normalizeMarketSymbol(match[1]),normalizeMarketSymbol(match[2])); return safeRichTextMessage(msg.chat.id,text,{parse_mode:'HTML',reply_markup:marketKeyboard()}); }
  catch(e){ return safeRichTextMessage(msg.chat.id,`${E.cross} <b>Perbandingan gagal.</b>\n<code>${htmlEscape(e.message)}</code>`,{parse_mode:'HTML',reply_markup:marketKeyboard()}); }
});

// ======================================= //
// 🚀 CONTROL CENTER
// ======================================= //
function v6DashboardText() {
  const mem = process.memoryUsage();
  const state = readState();
  const uptime = Math.floor(process.uptime());
  const h = Math.floor(uptime/3600), m = Math.floor((uptime%3600)/60), sec = uptime%60;
  const backupDir = path.join(__dirname, '..', 'backups');
  let backupCount = 0;
  try { backupCount = fs.readdirSync(backupDir).filter(x => /^mellstecuu-auto-\d{8}-\d{6}\.zip$/.test(x)).length; } catch {}
  const autoHours = Math.max(1, Number(process.env.AUTO_BACKUP_HOURS || 6));
  const retention = Math.max(1, Number(process.env.AUTO_BACKUP_RETENTION || 7));
  const users = Object.keys(state.users || {}).length;
  const chats = Object.keys(state.chats || {}).length;
  return `<h2>🚀 MELLSTECUU — CONTROL CENTER</h2>` +
    `<table bordered compact>` +
      `<tr><th>SYSTEM</th><th>DETAIL</th></tr>` +
      `<tr><td>Status</td><td>🟢 <b>ONLINE</b></td></tr>` +
      `<tr><td>Uptime</td><td><code>${h}h ${m}m ${sec}s</code></td></tr>` +
      `<tr><td>Node</td><td><code>${htmlEscape(process.version)}</code></td></tr>` +
      `<tr><td>RSS</td><td><code>${Math.round(mem.rss/1024/1024)} MB</code></td></tr>` +
      `<tr><td>Users</td><td><b>${users}</b></td></tr>` +
      `<tr><td>Chats</td><td><b>${chats}</b></td></tr>` +
      `<tr><td>Events</td><td><b>${activityLog.length}</b></td></tr>` +
      `<tr><td>Runtime errors</td><td><b>${devErrorLog.length}</b></td></tr>` +
    `</table>` +
    `<h3>💾 AUTO BACKUP</h3>` +
    `<table bordered compact>` +
      `<tr><th>SETTING</th><th>VALUE</th></tr>` +
      `<tr><td>Status</td><td>🟢 ACTIVE</td></tr>` +
      `<tr><td>Interval</td><td><code>${autoHours} jam</code></td></tr>` +
      `<tr><td>Retention</td><td><code>${retention}</code></td></tr>` +
      `<tr><td>Local backups</td><td><b>${backupCount}</b></td></tr>` +
    `</table>`;
}
function v6DashboardKeyboard() { return { inline_keyboard: [
  [{text:'📊 Analytics',callback_data:'v6_analytics',style:'primary'},{text:'📋 Activity Log',callback_data:'v6_activity',style:'primary'}],
  [{text:'🚨 Error Center',callback_data:'v6_errors',style:'danger'},{text:'⚡ Performance',callback_data:'v6_performance',style:'success'}],
  [{text:'💾 Backup Center',callback_data:'backup_menu',style:'primary'},{text:'📱 Sender Status',callback_data:'v6_senders',style:'primary'}],
  [{text:'🧪 Development',callback_data:'menu_dev',style:'primary'},{text:'🧰 Tools',callback_data:'menu_alat'}],
  [{text:'🔄 Refresh',callback_data:'v6_dashboard'},{text:'🏠 Menu Utama',callback_data:'back_menu',style:'danger'}]
]}; }
function v6AnalyticsText() {
  const state=readState();
  const totalTests=Number(state.totalTests||0);
  const events=activityLog.length;
  const commands=activityLog.filter(x=>x.type==='command').length;
  const errors=devErrorLog.length;
  return `<h2>📊 ANALYTICS</h2>` +
    `<table bordered compact><tr><th>METRIC</th><th>VALUE</th></tr>` +
      `<tr><td>Users</td><td><b>${Object.keys(state.users||{}).length}</b></td></tr>` +
      `<tr><td>Chats</td><td><b>${Object.keys(state.chats||{}).length}</b></td></tr>` +
      `<tr><td>Total tests</td><td><b>${totalTests}</b></td></tr>` +
      `<tr><td>Commands tracked</td><td><b>${commands}</b></td></tr>` +
      `<tr><td>Runtime events</td><td><b>${events}</b></td></tr>` +
      `<tr><td>Errors tracked</td><td><b>${errors}</b></td></tr>` +
    `</table><p><i>Analytics bersifat lokal dan tidak mengirim data statistik ke pihak ketiga.</i></p>`;
}
// ======================================= //
// 🔘 CALLBACK QUERY HANDLER
// ======================================= //
bot.on('callback_query', async (q) => {
  try {
  const data = q.data || '';
  const chatId = q.message?.chat?.id;
  const msgId = q.message?.message_id;
  await bot.answerCallbackQuery(q.id).catch(() => {});
  upsertUser(q.from);
  if (q.message?.chat) upsertChat(q.message.chat);
  if (data.startsWith('listgb_page_')) {
    if (!isOwner(q.from?.id)) {
      return bot.answerCallbackQuery(q.id, { text: 'Khusus owner bot.', show_alert: true }).catch(() => {});
    }
    const page = Number(data.slice('listgb_page_'.length));
    if (!Number.isInteger(page) || page < 1 || page > 9999) {
      return bot.answerCallbackQuery(q.id, { text: 'Halaman tidak valid.', show_alert: true }).catch(() => {});
    }
    const view = buildListGbRich(page);
    return sendDevRich(chatId, view.text, {
      parse_mode: 'HTML',
      reply_markup: listGbKeyboard(view.page, view.totalPages)
    });
  }
  if (data === 'v6_dashboard') { recordActivity('navigation','dashboard'); return sendDevRich(chatId,v6DashboardText(),{parse_mode:'HTML',reply_markup:v6DashboardKeyboard()}); }
  if (data.startsWith('amprem_ban_')) {
    const parts = data.split('_');
    const targetChatId = String(parts[2] || '');
    const targetUserId = String(parts[3] || '');
    if (!/^-?\d+$/.test(targetChatId) || !/^\d+$/.test(targetUserId)) {
      return bot.answerCallbackQuery(q.id,{text:'Data user/channel tidak valid.',show_alert:true}).catch(()=>{});
    }
    if (!['channel','group','supergroup'].includes(q.message?.chat?.type)) {
      return bot.answerCallbackQuery(q.id,{text:'Aksi ban hanya dapat dijalankan dari kartu notifikasi di channel.',show_alert:true}).catch(()=>{});
    }
    try {
      const actor = await bot.getChatMember(targetChatId, q.from.id);
      if (!['administrator','creator'].includes(actor.status)) {
        return bot.answerCallbackQuery(q.id,{text:'Hanya admin channel yang dapat melakukan Ban User.',show_alert:true}).catch(()=>{});
      }
      const me = await bot.getMe();
      const botMember = await bot.getChatMember(targetChatId, me.id);
      if (!['administrator','creator'].includes(botMember.status) || (botMember.status === 'administrator' && botMember.can_restrict_members !== true)) {
        return bot.answerCallbackQuery(q.id,{text:'Bot membutuhkan izin Ban Users/Restrict Members di channel.',show_alert:true}).catch(()=>{});
      }
      if (String(targetUserId) === String(me.id)) {
        return bot.answerCallbackQuery(q.id,{text:'Bot tidak boleh memban dirinya sendiri.',show_alert:true}).catch(()=>{});
      }
      await bot.banChatMember(targetChatId, Number(targetUserId));
      // Permanent bot-access ban; existing unfollow-channel temporary bans remain untouched.
      try { banUser(targetUserId, 10 * 365 * 24 * 60 * 60 * 1000, 'amprem_channel_moderation'); } catch {}
      await bot.answerCallbackQuery(q.id,{text:'User berhasil diban.',show_alert:true}).catch(()=>{});
      return safeRichTextMessage(chatId,
        `<blockquote>🚫 <b>USER DIBAN</b></blockquote>\n\n` +
        `👤 User ID: <code>${htmlEscape(targetUserId)}</code>\n` +
        `📢 Channel: <code>${htmlEscape(targetChatId)}</code>\n` +
        `🛡️ Akses bot juga ditangguhkan.\n\n` +
        `<i>Jika ingin membuka kembali akses, owner dapat melakukan unban dari sistem bot.</i>`,
        {parse_mode:'HTML',reply_markup:{inline_keyboard:[
          [{text:'🤖 Menu Bot',callback_data:'back_menu'}]
        ]}});
    } catch (e) {
      return bot.answerCallbackQuery(q.id,{text:`Ban gagal: ${String(e.message||'Telegram error').slice(0,180)}`,show_alert:true}).catch(()=>{});
    }
  }

  // ---- MEDIAFIRE UPLOADER ----
  if (data === 'mediafire_menu') {
    if (!mediaFireReady()) {
      return safeRichSendMessage(chatId,
        `<blockquote><b>MEDIAFIRE</b></blockquote>\n\n` +
        `Fitur belum dikonfigurasi. Isi environment berikut di panel/server:\n` +
        mediaFireConfigNames().map(k=>`• <code>${k}</code>`).join('\n') +
        `\n\n<i>Secret tidak perlu ditaruh di source code.</i>`,
        {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'Menu Tools',callback_data:'menu_alat'}]]}});
    }
    pendingMediaFire.set(String(q.from.id), {chatId,createdAt:Date.now()});
    setTimeout(()=>pendingMediaFire.delete(String(q.from.id)),10*60*1000);
    return safeRichSendMessage(chatId,
      `<blockquote><b>MEDIAFIRE UPLOADER</b></blockquote>\n\n` +
      `Kirim <b>APK, ZIP, JS, PDF, video, foto, atau file lain</b>. Bot akan mengunggahnya ke akun MediaFire yang dikonfigurasi lalu mengirim link hasilnya.\n\n` +
      `<i>Ukuran maksimal juga dipengaruhi batas download file dari Telegram Bot API/server kamu.</i>`,
      {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'Batal',callback_data:'menu_alat'}]]}});
  }

  if (data === 'live_photo_menu') {
    pendingLivePhoto.delete(String(q.from.id));
    return safeRichSendMessage(chatId,
      `<blockquote>📸 <b>PHOTO LIVE</b></blockquote>\n\n` +
      `Ubah <b>1 video</b> menjadi format Photo Live/Motion Photo.\n\n` +
      `🎬 Maksimal input: <b>20 detik</b>\n🎞️ Hasil Live/Motion Photo: <b>5 detik</b>\n` +
      `🖼️ Foto utama dibuat otomatis dari video\n` +
      `✨ Tidak perlu kirim foto terpisah\n` +
      `💎 Proses lokal di server/Pterodactyl\n\n` +
      `<i>Catatan: Telegram mengirim hasil sebagai file agar byte/metadata tetap utuh. Apple dan Android memakai format yang berbeda.</i>`,
      {parse_mode:'HTML',reply_markup:{inline_keyboard:[
        [{text:'🍎 Apple Live Photo',callback_data:'live_photo_apple',style:'primary'}],
        [{text:'🤖 Android Motion Photo',callback_data:'live_photo_android',style:'success'}],
        [{text:'↩️ Kembali ke Tools',callback_data:'menu_alat',style:'danger'}]
      ]}});
  }
  if (data === 'live_photo_apple' || data === 'live_photo_android') {
    const mode = data === 'live_photo_apple' ? 'apple' : 'android';
    pendingLivePhoto.set(String(q.from.id), {chatId, mode, createdAt:Date.now()});
    setTimeout(() => {
      const cur = pendingLivePhoto.get(String(q.from.id));
      if (cur && Date.now() - cur.createdAt >= 10 * 60 * 1000) pendingLivePhoto.delete(String(q.from.id));
    }, 10 * 60 * 1000);
    return safeRichSendMessage(chatId,
      `<blockquote>${mode === 'apple' ? '🍎' : '🤖'} <b>${mode === 'apple' ? 'APPLE LIVE PHOTO' : 'ANDROID MOTION PHOTO'}</b></blockquote>\n\n` +
      `Kirim <b>1 video</b> sekarang.\n\n` +
      `⏱️ Maksimal <b>20 detik</b>\n` +
      `🖼️ Frame utama akan dibuat otomatis.\n` +
      `✨ Kualitas foto dipertahankan/dioptimalkan dari sumber.\n\n` +
      `<i>Video lebih dari 20 detik akan ditolak. Hasil Motion/Live Photo tetap dibuat sepanjang 5 detik.</i>`,
      {parse_mode:'HTML',reply_markup:{inline_keyboard:[
        [{text:'✖️ Batal',callback_data:'live_photo_cancel',style:'danger'}],
        [{text:'↩️ Photo Live',callback_data:'live_photo_menu'}]
      ]}});
  }
  if (data === 'live_photo_cancel') {
    pendingLivePhoto.delete(String(q.from.id));
    return safeRichSendMessage(chatId,'✖️ <b>Photo Live dibatalkan.</b>',{parse_mode:'HTML',reply_markup:menuAlatKeyboard(1)});
  }
  if (data === 'osint_menu') {
    pendingOsint.set(String(q.from.id), {chatId,createdAt:Date.now()});
    setTimeout(()=>pendingOsint.delete(String(q.from.id)),10*60*1000);
    const ready = Boolean(process.env.OSINT_API_URL);
    return safeRichSendMessage(chatId,
      `<blockquote>🔎 <b>OSINT</b></blockquote>\n\n` +
      `Cari informasi yang tersedia secara publik menggunakan provider OSINT yang kamu konfigurasi.\n\n` +
      `🔐 API: ${ready ? '🟢 Terkonfigurasi' : '🔴 Belum dikonfigurasi'}\n` +
      `📌 Contoh input: <code>username</code>, <code>email</code>, atau <code>query publik</code>\n\n` +
      `<i>Gunakan hanya untuk informasi publik dan tujuan yang sah. Jangan masukkan password, token, atau data privat.</i>`,
      {parse_mode:'HTML',reply_markup:{inline_keyboard:[
        [{text:'✖️ Batal',callback_data:'osint_cancel',style:'danger'}],
        [{text:'↩️ Tools',callback_data:'menu_alat'}]
      ]}});
  }
  if (data === 'osint_cancel') {
    pendingOsint.delete(String(q.from.id));
    return safeRichSendMessage(chatId,'✖️ <b>OSINT dibatalkan.</b>',{parse_mode:'HTML',reply_markup:menuAlatKeyboard(2)});
  }

  if (data === 'bratvid_menu') {
    return safeRichSendMessage(chatId,
      `<blockquote><b>BRAT VIDEO</b></blockquote>\n\n` +
      `Buat Brat Video/GIF dari teks.\n\n` +
      `Contoh: <code>/bratvid shizuku cpanel sc paling gacor</code>\n\n` +
      `<i>Output mengikuti generator Brat Video yang sudah ada di project.</i>`,
      {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'Kembali ke Tools',callback_data:'menu_tambahan'}],[{text:'Menu Utama',callback_data:'back_menu',style:'danger'}]]}});
  }

  // ---- CHANNEL MONITORING ----
  if (data === 'channel_monitor') {
    if (q.message?.chat?.type !== 'private') {
      return bot.answerCallbackQuery(q.id,{text:'Buka Monitoring Channel dari chat pribadi bot.',show_alert:true}).catch(()=>{});
    }
    return safeRichSendMessage(chatId, channelMonitorText(q.from.id), {parse_mode:'HTML', reply_markup:channelMonitorKeyboard(getUserChannelMonitors(q.from.id))});
  }

  if (data === 'channel_monitor_add') {
    if (q.message?.chat?.type !== 'private') return bot.answerCallbackQuery(q.id,{text:'Atur Monitoring Channel dari chat pribadi bot.',show_alert:true}).catch(()=>{});
    pendingChannelMonitor.set(String(q.from.id), {chatId, step:'source', createdAt:Date.now()});
    setTimeout(()=>pendingChannelMonitor.delete(String(q.from.id)),10*60*1000);
    return safeRichSendMessage(chatId,
      `<blockquote><b>SET MONITORING CHANNEL</b></blockquote>\n\n` +
      `<b>Langkah 1/2 — Main Channel</b>\n` +
      `Kirim <b>@username</b> atau <b>ID -100...</b> dari channel yang ingin dipantau.\n\n` +
      `Contoh: <code>@channelkamu</code> atau <code>-1001234567890</code>\n\n` +
      `<i>Bot harus admin di channel ini. Setelah itu bot akan meminta channel tujuan notifikasi.</i>`,
      {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'Batal',callback_data:'channel_monitor'}]]}});
  }

  if (data.startsWith('channel_monitor_view:')) {
    const channelId = data.slice('channel_monitor_view:'.length);
    const monitor = getChannelMonitor(channelId);
    if (!monitor) return bot.answerCallbackQuery(q.id,{text:'Monitor tidak ditemukan.',show_alert:true}).catch(()=>{});
    const access = await canManageMonitoredChannel(channelId, q.from.id);
    if (!access.ok && String(monitor.ownerId) !== String(q.from.id)) {
      return bot.answerCallbackQuery(q.id,{text:'Kamu tidak punya akses mengelola monitor ini.',show_alert:true}).catch(()=>{});
    }
    return safeRichSendMessage(chatId,
      `<blockquote><b>CHANNEL MONITOR</b></blockquote>\n\n` +
      `<b>Main Channel:</b> ${htmlEscape(monitor.title || channelId)}\n` +
      `<b>ID:</b> <code>${htmlEscape(channelId)}</code>\n` +
      `<b>Channel Monitoring:</b> ${htmlEscape(monitor.outputTitle || monitor.outputChannelId || 'Belum diatur')}\n` +
      `<b>Output ID:</b> <code>${htmlEscape(monitor.outputChannelId || '-')}</code>\n` +
      `<b>Status:</b> ${monitor.enabled ? 'Aktif' : 'Nonaktif'}\n` +
      `<blockquote>Subscriber join/leave channel tidak dipush oleh Bot API secara umum. Tes Monitoring hanya menguji output.</blockquote>\n\n` +
      `<i>Member masuk/keluar dari Main Channel akan dibuatkan kartu Rich Message di Channel Monitoring.</i>`,
      {parse_mode:'HTML',reply_markup:{inline_keyboard:[
        [{text:'Tes Monitoring',callback_data:`channel_monitor_test:${channelId}`,style:'primary'}],
        [{text:monitor.enabled?'Nonaktifkan':'Aktifkan',callback_data:`channel_monitor_toggle:${channelId}`,style:monitor.enabled?'danger':'success'}],
        [{text:'Hapus Monitor',callback_data:`channel_monitor_remove:${channelId}`,style:'danger'}],
        [{text:'Kembali',callback_data:'channel_monitor'}]
      ]}});
  }

  if (data.startsWith('channel_monitor_test:')) {
    const channelId = data.slice('channel_monitor_test:'.length);
    const monitor = getChannelMonitor(channelId);
    if (!monitor) return bot.answerCallbackQuery(q.id,{text:'Monitor tidak ditemukan.',show_alert:true}).catch(()=>{});
    if (String(monitor.ownerId) !== String(q.from.id)) return bot.answerCallbackQuery(q.id,{text:'Hanya pengelola monitor yang bisa mengetes.',show_alert:true}).catch(()=>{});
    const access = await canManageMonitoredChannel(channelId, q.from.id);
    if (!access.ok) return bot.answerCallbackQuery(q.id,{text:access.reason,show_alert:true}).catch(()=>{});
    if (!monitor.outputChannelId) return bot.answerCallbackQuery(q.id,{text:'Channel monitoring belum diatur.',show_alert:true}).catch(()=>{});
    const outputAccess = await canManageMonitoredChannel(monitor.outputChannelId, q.from.id);
    if (!outputAccess.ok) return bot.answerCallbackQuery(q.id,{text:`Output belum siap: ${outputAccess.reason}`,show_alert:true}).catch(()=>{});
    const testUser = q.from;
    await notifyMainChannelMember('join', testUser, '<i>Ini kartu TEST. Tidak ada perubahan keanggotaan yang dilakukan.</i>', channelId);
    return bot.answerCallbackQuery(q.id,{text:'Tes monitoring dikirim ke channel output.',show_alert:false}).catch(()=>{});
  }

  if (data.startsWith('channel_monitor_toggle:')) {
    const channelId = data.slice('channel_monitor_toggle:'.length);
    const monitor = getChannelMonitor(channelId);
    if (!monitor) return bot.answerCallbackQuery(q.id,{text:'Monitor tidak ditemukan.',show_alert:true}).catch(()=>{});
    const access = await canManageMonitoredChannel(channelId, q.from.id);
    if (!access.ok) return bot.answerCallbackQuery(q.id,{text:access.reason,show_alert:true}).catch(()=>{});
    setChannelMonitor(channelId,{...monitor,enabled:!monitor.enabled});
    await bot.answerCallbackQuery(q.id,{text:`Monitoring ${!monitor.enabled?'diaktifkan':'dinonaktifkan'}.`}).catch(()=>{});
    return safeRichSendMessage(chatId, channelMonitorText(q.from.id), {parse_mode:'HTML', reply_markup:channelMonitorKeyboard(getUserChannelMonitors(q.from.id))});
  }

  if (data.startsWith('channel_monitor_remove:')) {
    const channelId = data.slice('channel_monitor_remove:'.length);
    const monitor = getChannelMonitor(channelId);
    if (!monitor) return bot.answerCallbackQuery(q.id,{text:'Monitor tidak ditemukan.',show_alert:true}).catch(()=>{});
    if (monitor.legacy) return bot.answerCallbackQuery(q.id,{text:'MAIN_CHANNEL_ID legacy tidak dihapus dari menu ini.',show_alert:true}).catch(()=>{});
    const access = await canManageMonitoredChannel(channelId, q.from.id);
    if (!access.ok && String(monitor.ownerId) !== String(q.from.id)) return bot.answerCallbackQuery(q.id,{text:'Tidak punya akses.',show_alert:true}).catch(()=>{});
    removeChannelMonitor(channelId);
    await bot.answerCallbackQuery(q.id,{text:'Monitor dihapus.'}).catch(()=>{});
    return safeRichSendMessage(chatId, channelMonitorText(q.from.id), {parse_mode:'HTML', reply_markup:channelMonitorKeyboard(getUserChannelMonitors(q.from.id))});
  }

  // ---- MODERATION ACTION BUTTONS ----
  if (data.startsWith('mod_reset:') || data.startsWith('mod_mute:')) {
    if (!chatId || !['group','supergroup'].includes(q.message?.chat?.type)) {
      return bot.answerCallbackQuery(q.id, { text: 'Tombol ini hanya berlaku di grup.', show_alert: true }).catch(() => {});
    }
    const parts = data.split(':');
    const action = parts[0];
    const targetChatId = String(parts[1] || '');
    const targetUserId = String(parts[2] || '');
    if (targetChatId !== String(chatId) || !/^-?\d+$/.test(targetUserId)) {
      return bot.answerCallbackQuery(q.id, { text: 'Data target tidak valid.', show_alert: true }).catch(() => {});
    }
    if (!(await isGroupAdmin(chatId, q.from.id))) {
      return bot.answerCallbackQuery(q.id, { text: 'Khusus admin grup.', show_alert: true }).catch(() => {});
    }
    if (action === 'mod_reset') {
      clearAllModerationStrikes(chatId, targetUserId);
      resetModerationRecord(chatId, targetUserId);
      await bot.answerCallbackQuery(q.id, { text: 'Semua warn member sudah di-reset.' }).catch(() => {});
      return sendModerationRich(chatId, `<blockquote>↻ <b>WARN DI-RESET</b></blockquote>\n\nSemua peringatan untuk <a href="tg://user?id=${targetUserId}">member tersebut</a> sudah dihapus.\n\n<i>Perhitungan dimulai lagi dari 1/3 jika ada pelanggaran baru.</i>`, targetUserId);
    }
    if (!(await requireBotAdmin(chatId, 'can_restrict_members'))) {
      return bot.answerCallbackQuery(q.id, { text: 'Bot perlu izin Restrict Members.', show_alert: true }).catch(() => {});
    }
    try {
      await muteMemberForModeration(chatId, targetUserId, 30);
      clearAllModerationStrikes(chatId, targetUserId);
      await bot.answerCallbackQuery(q.id, { text: 'Member di-mute 30 menit.' }).catch(() => {});
      return sendModerationRich(chatId, `<blockquote>🔇 <b>MUTE MANUAL</b></blockquote>\n\n<a href="tg://user?id=${targetUserId}">Member tersebut</a> di-mute selama <b>30 menit</b> oleh admin.\n\n<i>Warn juga di-reset agar perhitungan berikutnya dimulai dari awal.</i>`, targetUserId);
    } catch (e) {
      return bot.answerCallbackQuery(q.id, { text: 'Mute gagal. Cek izin Restrict Members.', show_alert: true }).catch(() => {});
    }
  }


  if (data === 'v6_analytics') { recordActivity('navigation','analytics'); return sendDevRich(chatId,v6AnalyticsText(),{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🔄 Refresh',callback_data:'v6_analytics'}],[{text:'🚀 Control Center',callback_data:'v6_dashboard'}]]}}); }
  if (data === 'v6_activity') { const rows=activityLog.slice(-15).reverse().map((x,i)=>`${i+1}. <code>${htmlEscape(moment(x.time).tz(c.TIMEZONE).format('HH:mm:ss'))}</code> <b>${htmlEscape(x.type)}</b> — ${htmlEscape(x.detail)}`).join('\n')||'<i>Belum ada aktivitas.</i>'; return sendDevRich(chatId,`<blockquote>📋 <b>ACTIVITY LOG</b></blockquote>\n\n${rows}`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🔄 Refresh',callback_data:'v6_activity'}],[{text:'🚀 Control Center',callback_data:'v6_dashboard'}]]}}); }
  if (data === 'v6_errors') { const rows=devErrorLog.slice(-12).reverse().map((x,i)=>`${i+1}. <code>${htmlEscape(moment(x.time).tz(c.TIMEZONE).format('HH:mm:ss'))}</code> <b>${htmlEscape(x.type)}</b>\n<code>${htmlEscape(x.message).slice(0,500)}</code>`).join('\n\n')||'<i>Belum ada runtime error tercatat.</i>'; return sendDevRich(chatId,`<blockquote>🚨 <b>ERROR CENTER</b></blockquote>\n\n${rows}`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🔄 Refresh',callback_data:'v6_errors'}],[{text:'🚀 Control Center',callback_data:'v6_dashboard'}]]}}); }
  if (data === 'v6_performance') { const mem=process.memoryUsage(); return sendDevRich(chatId,`<blockquote>⚡ <b>PERFORMANCE MONITOR</b></blockquote>\n\n🟢 Status: <b>ONLINE</b>\n🧠 Heap: <code>${Math.round(mem.heapUsed/1024/1024)} / ${Math.round(mem.heapTotal/1024/1024)} MB</code>\n💾 RSS: <code>${Math.round(mem.rss/1024/1024)} MB</code>\n🧩 External: <code>${Math.round(mem.external/1024/1024)} MB</code>\n⏱️ Uptime: <code>${Math.floor(process.uptime())} sec</code>\n🧵 Platform: <code>${htmlEscape(process.platform)}</code>`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🔄 Refresh',callback_data:'v6_performance'}],[{text:'🚀 Control Center',callback_data:'v6_dashboard'}]]}}); }
  if (data === 'v6_senders') { let rows=[]; try { const numbers=getUserSenders(q.from.id); const statuses=getAllSenderStatuses(numbers); rows=(statuses||[]).map(v=>`• <code>${htmlEscape(v.number)}</code> — ${v?.online?'🟢 Connected':'🔴 Offline'}`); } catch(e) { rows=[`❌ ${htmlEscape(e.message)}`]; } return sendDevRich(chatId,`<blockquote>📱 <b>SENDER STATUS</b></blockquote>\n\n${rows.join('\n')||'<i>Belum ada sender.</i>'}`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🔄 Refresh',callback_data:'v6_senders'}],[{text:'🚀 Control Center',callback_data:'v6_dashboard'}]]}}); }

  // Dedicated secondary router handles chess and utility callbacks.
  // Return here to prevent a false \"unhandled callback\" alert.
  const delegatedCallbacks = new Set(['tagall_menu','tagall_help','callone_menu','callone_help','backup_menu','backup_info','backup_run','rinem_menu','brathd_menu','tonaked_menu']);
  if (data.startsWith('chess_') || delegatedCallbacks.has(data)) return;

  // ---- PROJECT TOOL CALLBACKS ----
  if (data === 'domain_cancel') {
    pendingDomainRename.delete(String(q.from.id));
    return safeRichSendMessage( chatId,'🌐 <b>Ganti Domain</b> dibatalkan.',{parse_mode:'HTML',reply_markup:toolKeyboardBack()});
  }
  if (data === 'domain_port_menu') {
    pendingDomainRename.set(String(q.from.id), { chatId, step:'port_zip', createdAt:Date.now(), mode:'port' });
    setTimeout(()=>pendingDomainRename.delete(String(q.from.id)),10*60*1000);
    return safeRichSendMessage(chatId,'🔌 <b>GANTI PORT PANEL</b>\n\nKirim <b>file ZIP project</b>. Bot akan memeriksa port yang benar-benar muncul di URL (<code>:PORT</code>) atau konfigurasi <code>PORT/PANEL_PORT</code>.',{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'✖️ Batal',callback_data:'domain_cancel'}],[{text:'🧰 Menu Tools',callback_data:'menu_alat'}]]}});
  }
  if (data === 'domain_retry_old') {
    const flow=pendingDomainRename.get(String(q.from.id));
    if (!flow || flow.mode!=='domain') return bot.answerCallbackQuery(q.id,{text:'Sesi sudah kedaluwarsa.',show_alert:true}).catch(()=>{});
    flow.step='olddomain'; flow.createdAt=Date.now(); pendingDomainRename.set(String(q.from.id),flow);
    return safeRichSendMessage(chatId,'🔎 Kirim kembali <b>domain lama</b> yang ingin dicari di ZIP.',{parse_mode:'HTML'});
  }
  if (data === 'port_retry_old') {
    const flow=pendingDomainRename.get(String(q.from.id));
    if (!flow || flow.mode!=='port') return bot.answerCallbackQuery(q.id,{text:'Sesi sudah kedaluwarsa.',show_alert:true}).catch(()=>{});
    flow.step='oldport'; flow.createdAt=Date.now(); pendingDomainRename.set(String(q.from.id),flow);
    return safeRichSendMessage(chatId,'🔌 Kirim kembali <b>port lama</b> yang ingin dicari di ZIP.',{parse_mode:'HTML'});
  }
  if (data === 'tourl_cancel') { pendingTourl.delete(String(q.from.id)); return safeRichSendMessage( chatId,'🖼️ TOURL dibatalkan.'); }
  if (data.startsWith('tourl_')) {
    const parts=data.split('_'); const provider=parts[1]; const uid=parts[2]; const flow=pendingTourl.get(String(uid));
    if (!flow?.buffer) return bot.answerCallbackQuery(q.id,{text:'Foto/session sudah kedaluwarsa.',show_alert:true}).catch(()=>{});
    await bot.answerCallbackQuery(q.id,{text:`Mengupload ${provider==='auto'?'dengan fallback otomatis':`ke ${provider}`}...`}).catch(()=>{});
    try {
      const result=await uploadToProviderWithFallback(provider,flow.buffer,flow.fileName||'photo.jpg');
      pendingTourl.delete(String(uid));
      const note=result.fallback ? `\n\n⚠️ Provider <b>${htmlEscape(provider)}</b> sedang bermasalah, jadi bot otomatis memakai <b>${htmlEscape(result.provider)}</b>.` : '';
      return safeRichSendMessage(chatId,`✅ <b>TOURL BERHASIL</b>\n\nProvider: <code>${htmlEscape(result.provider)}</code>\nURL:\n<code>${htmlEscape(result.url)}</code>${note}`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🔗 Buka URL',url:result.url}],[{text:'🖼️ Upload Foto Lagi',callback_data:'tool_tourl'}]]}});
    } catch(e) {
      return safeRichSendMessage(chatId,`❌ <b>TOURL gagal</b>\n\n<code>${htmlEscape(e.message)}</code>\n\nSemua provider yang tersedia sudah dicoba. Coba lagi beberapa saat kemudian.`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🔄 Coba Lagi',callback_data:'tool_tourl'}],[{text:'🧰 Menu Tools',callback_data:'menu_alat'}]]}});
    }
  }

    if (data.startsWith('forcecheck_')) {
      const parts = data.split('_');
      const targetChatId = parts[1]; const targetUserId = parts[2];
      if (String(q.from.id) !== String(targetUserId)) return bot.answerCallbackQuery(q.id, {text:'Tombol ini bukan untuk akunmu.',show_alert:true}).catch(()=>{});
      const cfg = getForceSubscribeConfig(targetChatId);
      if (!cfg.enabled || !cfg.channels.length) return bot.answerCallbackQuery(q.id,{text:'Force Subscribe sudah dimatikan.',show_alert:true}).catch(()=>{});
      const results = await Promise.all(cfg.channels.map(ch => isForceSubscribed(ch.channel, q.from.id)));
      if (results.some(v => v === null)) return bot.answerCallbackQuery(q.id,{text:'Status salah satu channel belum bisa diverifikasi. Coba lagi.',show_alert:true}).catch(()=>{});
      if (results.some(v => v !== true)) return bot.answerCallbackQuery(q.id,{text:'Kamu belum join semua channel wajib.',show_alert:true}).catch(()=>{});
      await bot.answerCallbackQuery(q.id,{text:'Berhasil! Semua channel sudah diikuti.',show_alert:true}).catch(()=>{});
      return safeRichSendMessage( targetChatId, `<b>Verifikasi berhasil</b>

Kamu sudah join semua <b>${cfg.channels.length}</b> channel wajib. Pesan berikutnya tidak akan dihapus oleh Force Subscribe.`, {parse_mode:'HTML'}).catch(()=>{});
    }

    if (data === 'check_join') {
    // Untuk pengguna yang masih menekan tombol join dari pesan lama.
    if (c.START_JOIN_REQUIRED === false) {
      const oldBan = isUserBanned(q.from.id);
      if (oldBan?.reason === 'unfollow_channel') unbanUser(q.from.id);
      await bot.answerCallbackQuery(q.id, { text: 'Wajib join sudah dinonaktifkan.' }).catch(() => {});
      await safeDelete(bot, chatId, msgId);
      return sendRichStartMenu(chatId, q.from);
    }
    if (!(await isJoined(q.from.id))) {
      return bot.answerCallbackQuery(q.id, { text: 'Kamu belum join semua channel & group wajib!', show_alert: true }).catch(() => {});
    }
    // Join sudah valid: hapus penangguhan lama akibat pernah unfollow.
    markForceSubJoined(q.from.id);
    const oldBan = isUserBanned(q.from.id);
    if (oldBan?.reason === 'unfollow_channel') unbanUser(q.from.id);
    await safeDelete(bot, chatId, msgId);
    const loading = await safeRichSendMessage( chatId, `<code>${makeBar(40)}</code>\n${E.hourglass} Memeriksa validasi...`, { parse_mode: 'HTML' });
    
    await safeEdit(bot, chatId, loading.message_id, `<blockquote>${E.check} Pemeriksaan berhasil! Menyiapkan sesi...</blockquote>`, { parse_mode: 'HTML' });
    await safeDelete(bot, chatId, loading.message_id);
    return sendRichStartMenu(chatId, q.from);
  }


  if (data === 'menu_info') {
    return safeRichSendMessage( chatId,
      `<h2>${E.crown} USER INFO</h2><p>Lihat informasi akun dengan tampilan Rich Message yang ringkas.</p><table bordered compact><tr><th>PERINTAH</th><th>FUNGSI</th></tr><tr><td><code>/info</code></td><td>Akun sendiri</td></tr><tr><td><code>/info @username</code></td><td>Cari user yang sudah dikenal bot</td></tr><tr><td><code>/info USER_ID</code></td><td>Cari berdasarkan ID</td></tr><tr><td>Reply + <code>/info</code></td><td>Info user yang direply</td></tr></table><footer>Reply adalah cara paling akurat untuk target yang baru ditemui bot.</footer>`,
      {parse_mode:'HTML', reply_markup:{inline_keyboard:[[{text:'👤 Info Saya',callback_data:`info_self_${q.from.id}`,style:'primary'},{text:'↩️ Kembali',callback_data:'back_menu'}]]}});
  }
  if (data.startsWith('info_self_')) {
    const uid=Number(data.slice('info_self_'.length));
    if(uid!==q.from.id) return bot.answerCallbackQuery(q.id,{text:'Tombol bukan milikmu.',show_alert:true}).catch(()=>{});
    return sendUserInfo(chatId,q.from,q.message?.chat?.id, {source:'self', chatType:q.message?.chat?.type, replyToMessageId:q.message?.message_id});
  }
  if (data === 'menu_dev') {
    return sendDevRich(chatId, '<blockquote><b>DEVELOPMENT CENTER</b></blockquote>\n\n<code>/health</code> — status runtime\n<code>/devcheck</code> — dependency & konfigurasi tanpa secret\n<code>/sysinfo</code> — RAM, Node, uptime\n<code>/id</code> — ID user/chat\n<code>/info</code> — detail akun\n<code>/json</code> — validasi & format JSON\n<code>/hash</code> — SHA/MD5 hash\n<code>/urlcheck</code> — validasi URL\n<code>/escapehtml</code> — escape HTML\n<code>/zipinfo</code> — inspeksi ZIP\n<code>/tesfunc</code> — tes function JS\n<code>/req</code> — request fitur ke Developer\n\n<b>Developer Lab</b>\nDiagnosis AI, project audit, runtime monitor, dependency inspector, error tracker, Git status, Regex Lab, Prompt Lab, API Lab, checklist .env, dan coding cheat sheet.\n\n<i>Secret/API key tidak pernah ditampilkan.</i>', {parse_mode:'HTML', reply_markup:{inline_keyboard:[
      [{text:'🧪 Tes Function',callback_data:'dev_tesfunc',style:'primary'},{text:'🩺 Dev Check',callback_data:'dev_check',style:'primary'}],
      [{text:'🤖 AI Diagnostics',callback_data:'dev_ai_diag',style:'primary'},{text:'🔎 Project Audit',callback_data:'dev_project_audit',style:'primary'}],
      [{text:'📊 Runtime Monitor',callback_data:'dev_runtime',style:'primary'},{text:'🔑 ENV Checklist',callback_data:'dev_env',style:'primary'}],
      [{text:'📚 Coding Cheat Sheet',callback_data:'dev_cheatsheet',style:'success'}],
      [{text:'🐞 Error Tracker',callback_data:'dev_errors',style:'danger'},{text:'📦 Dependencies',callback_data:'dev_deps',style:'primary'}],
      [{text:'💚 Health Snapshot',callback_data:'dev_health_snapshot',style:'success'},{text:'🧪 Regex Lab',callback_data:'dev_regex',style:'primary'}],
      [{text:'🧠 Prompt Lab',callback_data:'dev_prompt',style:'primary'}],
      [{text:'🌐 API Lab',callback_data:'dev_api_lab',style:'primary'},{text:'🗂️ Git Status',callback_data:'dev_git',style:'primary'}],
      [{text:'💡 Request Fitur',callback_data:'feature_request',style:'primary'}],
      [{text:'🧰 Menu Alat',callback_data:'menu_alat'},{text:'↩️ Menu Utama',callback_data:'back_menu',style:'danger'}]]}});
  }

  if (data === 'dev_ai_diag') {
    const rows = AI_PROVIDERS.map(p => {
      const key = providerKey(p);
      const model = providerModel(p);
      return `• <b>${htmlEscape(aiProviderLabel(p))}</b> — ${key ? '🟢 KEY TERISI' : '🔴 KEY KOSONG'}\n  Model: <code>${htmlEscape(model)}</code>`;
    }).join('\n');
    const selected = normalizeAiProvider(getAssistantProvider(chatId));
    return sendDevRich(chatId, `<blockquote>🤖 <b>AI DIAGNOSTICS</b></blockquote>\n\n${rows}\n\n<b>Provider aktif:</b> ${htmlEscape(aiProviderLabel(selected))}\n<b>Fallback:</b> Gemini → OpenRouter\n<b>Queue:</b> <code>${aiQueue.length}/${AI_CONFIG.maxQueue}</code>\n<b>Concurrent:</b> <code>${aiActive}/${AI_CONFIG.maxConcurrent}</code>\n<b>Cooldown:</b> <code>${Math.round(AI_CONFIG.userCooldownMs/1000)} detik</code>\n\n<i>Diagnosis ini tidak melakukan request ke provider, jadi aman untuk mengecek konfigurasi tanpa menghabiskan quota.</i>`, {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🤖 Menu AI',callback_data:'ai_menu'}],[{text:'🛠️ Development',callback_data:'menu_dev'}]]}});
  }

  if (data === 'dev_runtime') {
    const mem = process.memoryUsage();
    const mb = n => `${(n/1024/1024).toFixed(1)} MB`;
    const uptime = Math.floor(process.uptime());
    const h = Math.floor(uptime/3600), m = Math.floor((uptime%3600)/60), sec = uptime%60;
    return sendDevRich(chatId, `<blockquote>📊 <b>RUNTIME MONITOR</b></blockquote>\n\n<b>Node:</b> <code>${htmlEscape(process.version)}</code>\n<b>Platform:</b> <code>${htmlEscape(process.platform)} / ${htmlEscape(process.arch)}</code>\n<b>Uptime:</b> <code>${h}j ${m}m ${sec}d</code>\n<b>RSS:</b> <code>${mb(mem.rss)}</code>\n<b>Heap:</b> <code>${mb(mem.heapUsed)} / ${mb(mem.heapTotal)}</code>\n<b>External:</b> <code>${mb(mem.external)}</code>\n<b>AI queue:</b> <code>${aiQueue.length}</code>\n<b>AI aktif:</b> <code>${aiActive}</code>`, {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🔄 Refresh',callback_data:'dev_runtime'}],[{text:'🛠️ Development',callback_data:'menu_dev'}]]}});
  }

  if (data === 'dev_env') {
    const required = ['BOT_TOKEN','GEMINI_API_KEY','OPENROUTER_API_KEY','PIXAZO_API_KEY'];
    const optional = ['GEMINI_MODEL','OPENROUTER_MODEL','OPENROUTER_SITE_URL','OPENROUTER_APP_NAME'];
    const r = required.map(k=>`• <code>${k}</code> — ${process.env[k] ? '🟢 terisi' : '🔴 kosong'}`).join('\n');
    const o = optional.map(k=>`• <code>${k}</code> — ${process.env[k] ? '🟢 terisi' : '⚪ default/kosong'}`).join('\n');
    return sendDevRich(chatId, `<blockquote>🔑 <b>ENV CHECKLIST</b></blockquote>\n\n<b>Wajib / fitur terkait:</b>\n${r}\n\n<b>Opsional:</b>\n${o}\n\n<b>OpenRouter:</b> <code>OPENROUTER_SITE_URL</code> boleh kosong.\n\n<i>Nilai secret tidak pernah ditampilkan.</i>`, {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🩺 Dev Check',callback_data:'dev_check'}],[{text:'🛠️ Development',callback_data:'menu_dev'}]]}});
  }

  if (data === 'dev_project_audit') {
    const root = path.join(__dirname, '..');
    const walk = (dir, depth=0) => {
      if (depth > 3) return [];
      let out=[];
      for (const ent of fs.readdirSync(dir,{withFileTypes:true})) {
        if (['node_modules','.git','.cache'].includes(ent.name)) continue;
        const full=path.join(dir,ent.name);
        if (ent.isDirectory()) out=out.concat(walk(full,depth+1));
        else out.push(full);
      }
      return out;
    };
    let files=[]; try { files=walk(root); } catch (_) {}
    const js=files.filter(f=>f.endsWith('.js')).length;
    const json=files.filter(f=>f.endsWith('.json')).length;
    const env=fs.existsSync(path.join(root,'.env'));
    const pkg=fs.existsSync(path.join(root,'package.json'));
    const readme=files.filter(f=>path.basename(f).toLowerCase().startsWith('readme')).length;
    return sendDevRich(chatId, `<blockquote>🔎 <b>PROJECT AUDIT</b></blockquote>\n\n📄 JS files: <code>${js}</code>\n🧾 JSON files: <code>${json}</code>\n📚 README/docs: <code>${readme}</code>\n📦 package.json: ${pkg?'🟢 ada':'🔴 tidak ada'}\n🔐 .env: ${env?'🟢 ada':'⚪ tidak ada (gunakan .env.example)'}\n\n<b>AI:</b> 2 provider teks (Gemini, OpenRouter) + Pixazo Studio untuk media\n<b>Chess:</b> handler aktif\n<b>DeepSeek:</b> tidak terdaftar\n\n<i>Audit ini bersifat non-destruktif: tidak mengubah atau menghapus file.</i>`, {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🤖 AI Diagnostics',callback_data:'dev_ai_diag'}],[{text:'🛠️ Development',callback_data:'menu_dev'}]]}});
  }

  if (data === 'dev_cheatsheet') {
    return sendDevRich(chatId, `<blockquote>📚 <b>CODING CHEAT SHEET</b></blockquote>\n\n<b>Node.js</b>\n<code>npm install</code> — install dependency\n<code>npm start</code> — jalankan bot\n<code>node --check src/bot.js</code> — cek syntax\n<code>npm outdated</code> — cek package usang\n\n<b>Git</b>\n<code>git status</code> — lihat perubahan\n<code>git diff</code> — lihat detail perubahan\n<code>git log --oneline -5</code> — 5 commit terakhir\n\n<b>Debug cepat</b>\n• Baca error pertama, bukan error terakhir.\n• Cek <code>.env</code> sebelum menyalahkan API.\n• Setelah ubah dependency, jalankan install ulang.\n• Gunakan log yang jelas untuk callback dan API response.\n• Jangan pernah commit API key/token.\n\n<b>AI project</b>\n• Simpan provider/model di ENV.\n• Bedakan timeout, 429, 4xx, dan 5xx.\n• Sediakan fallback agar satu provider gagal tidak mematikan bot.`, {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🛠️ Development',callback_data:'menu_dev'}]]}});
  }

  if (data === 'dev_health_snapshot') {
    const mem=process.memoryUsage(); const uptime=Math.floor(process.uptime());
    const h=Math.floor(uptime/3600), m=Math.floor((uptime%3600)/60), sec=uptime%60;
    return sendDevRich(chatId,`<blockquote>💚 <b>HEALTH SNAPSHOT</b></blockquote>\n\nStatus: <b>ONLINE</b>\nNode: <code>${htmlEscape(process.version)}</code>\nUptime: <code>${h}j ${m}m ${sec}d</code>\nRSS: <code>${Math.round(mem.rss/1024/1024)} MB</code>\nHeap: <code>${Math.round(mem.heapUsed/1024/1024)} / ${Math.round(mem.heapTotal/1024/1024)} MB</code>\nGame sessions: <code>${tttSessions.size+partySessions.size+quizPartySessions.size+duelSessions.size+mpGameSessions.size}</code>\nError log: <code>${devErrorLog.length}</code>`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🔄 Refresh',callback_data:'dev_health_snapshot'}],[{text:'🛠️ Development',callback_data:'menu_dev'}]]}});
  }

  if (data === 'dev_errors') {
    const rows = devErrorLog.length ? devErrorLog.slice(-12).reverse().map((e,i) => {
      const time = new Date(e.time).toLocaleTimeString('id-ID');
      return `${i+1}. <code>${htmlEscape(time)}</code> <b>${htmlEscape(e.type)}</b>\n<code>${htmlEscape(e.message.slice(0,500))}</code>`;
    }).join('\n\n') : '<i>Belum ada uncaught/unhandled error yang tercatat sejak proses bot dimulai.</i>';
    return sendDevRich(chatId, `<blockquote>🐞 <b>ERROR TRACKER</b></blockquote>\n\n${rows}\n\n<i>Tracker hanya menyimpan error runtime terbaru di memory; token/API key tidak dicatat.</i>`, {parse_mode:'HTML', reply_markup:{inline_keyboard:[[{text:'🔄 Refresh',callback_data:'dev_errors'}],[{text:'🛠️ Development',callback_data:'menu_dev'}]]}});
  }

  if (data === 'dev_deps') {
    const pkgPath = path.join(__dirname,'..','package.json');
    let pkg = {};
    try { pkg = JSON.parse(fs.readFileSync(pkgPath,'utf8')); } catch (e) { return sendDevRich(chatId,`${E.cross} package.json tidak bisa dibaca: <code>${htmlEscape(e.message)}</code>`,{parse_mode:'HTML'}); }
    const deps = Object.entries(pkg.dependencies || {});
    const devDeps = Object.entries(pkg.devDependencies || {});
    const fmt = arr => arr.length ? arr.map(([k,v])=>`• <code>${htmlEscape(k)}</code> — <code>${htmlEscape(String(v))}</code>`).join('\n') : '<i>Tidak ada</i>';
    return sendDevRich(chatId,`<blockquote>📦 <b>DEPENDENCY INSPECTOR</b></blockquote>\n\n<b>Project:</b> <code>${htmlEscape(pkg.name||'-')}</code>\n<b>Version:</b> <code>${htmlEscape(pkg.version||'-')}</code>\n<b>Runtime:</b> <code>${htmlEscape(pkg.engines?.node||'-')}</code>\n\n<b>Dependencies (${deps.length})</b>\n${fmt(deps)}\n\n<b>Dev Dependencies (${devDeps.length})</b>\n${fmt(devDeps)}\n\n<i>Inspector bersifat read-only.</i>`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🛠️ Development',callback_data:'menu_dev'}]]}});
  }

  if (data === 'dev_regex') {
    return sendDevRich(chatId,`<blockquote>🧪 <b>REGEX LAB</b></blockquote>\n\nUji regular expression tanpa perlu keluar dari Telegram.\n\n<b>Format:</b> <code>/regex pattern | text</code>\n<b>Contoh:</b> <code>/regex ^halo | halo dunia</code>\n\nTips: gunakan <code>\\d+</code> untuk angka, <code>^</code> awal teks, dan <code>$</code> akhir teks.`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'↩️ Development',callback_data:'menu_dev'}]]}});
  }

  if (data === 'dev_prompt') {
    return sendDevRich(chatId,`<blockquote>🧠 <b>AI PROMPT LAB</b></blockquote>\n\nTemplate prompt yang bisa dipakai untuk coding/AI:\n\n<code>Role: senior software engineer\nTask: jelaskan masalah dan solusi\nContext: [tempel konteks]\nConstraints: jangan ubah API publik\nOutput: kode siap pakai + langkah tes</code>\n\n<b>Tip:</b> sertakan error asli, file terkait, expected behavior, dan batasan perubahan.`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🤖 Menu AI',callback_data:'ai_menu'}],[{text:'↩️ Development',callback_data:'menu_dev'}]]}});
  }

  if (data === 'dev_api_lab') {
    const rows = AI_PROVIDERS.map(p => `• <b>${htmlEscape(aiProviderLabel(p))}</b> — <code>${htmlEscape(providerModel(p))}</code> — ${providerKey(p)?'🟢 key siap':'🔴 key belum ada'}`).join('\n');
    return sendDevRich(chatId,`<blockquote>🌐 <b>API LAB</b></blockquote>\n\n${rows}\n\n<b>Mode aman:</b> halaman ini hanya memeriksa konfigurasi lokal. Tidak mengirim request ke provider, jadi tidak menghabiskan quota.\n\nUntuk tes koneksi sungguhan, gunakan menu AI dan kirim prompt pendek.`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🤖 AI Diagnostics',callback_data:'dev_ai_diag'}],[{text:'🔑 ENV Checklist',callback_data:'dev_env'}],[{text:'🛠️ Development',callback_data:'menu_dev'}]]}});
  }

  if (data === 'dev_git') {
    const { execFile } = require('child_process');
    return new Promise(resolve => {
      execFile('git',['status','--short','--branch'],{cwd:path.join(__dirname,'..'),timeout:8000},(err,stdout,stderr)=>{
        const text = err ? `Git tidak tersedia/repository tidak aktif.\n<code>${htmlEscape((stderr||err.message||'').slice(0,700))}</code>` : (stdout.trim() || 'Working tree bersih.');
        resolve(sendDevRich(chatId,`<blockquote>🗂️ <b>GIT STATUS</b></blockquote>\n\n<pre>${htmlEscape(text)}</pre>\n\n<i>Read-only: bot tidak melakukan commit, push, pull, atau reset.</i>`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🔄 Refresh',callback_data:'dev_git'}],[{text:'🛠️ Development',callback_data:'menu_dev'}]]}}));
      });
    });
  }

  if (data === 'dev_check') {
    const checks = [
      ['Node.js', process.version],
      ['Platform', `${process.platform}/${process.arch}`],
      ['FFmpeg', ffmpegPath ? 'OK' : 'TIDAK TERSEDIA'],
      ['BOT_TOKEN', process.env.BOT_TOKEN ? 'TERISI' : 'KOSONG'],
      ['GEMINI_API_KEY', process.env.GEMINI_API_KEY ? 'TERISI' : 'KOSONG'],
      ['GEMINI_MODEL', AI_CONFIG.geminiModel],
    ['OPENROUTER_API_KEY', process.env.OPENROUTER_API_KEY ? 'TERISI' : 'KOSONG'],
    ['OPENROUTER_MODEL', AI_CONFIG.openrouterModel],
          ['Data directory', fs.existsSync(path.join(__dirname,'..','data')) ? 'OK' : 'BELUM ADA'],
      ['Runtime', runtime()]
    ];
    return sendDevRich(chatId, `<blockquote>🩺 <b>DEVELOPER HEALTH CHECK</b></blockquote>\n\n${checks.map(([k,v])=>`• <b>${htmlEscape(k)}</b>: <code>${htmlEscape(v)}</code>`).join('\n')}\n\n<i>Nilai secret tidak pernah ditampilkan.</i>`, {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🛠️ Development',callback_data:'menu_dev'}]]}});
  }

  if (data === 'dev_tesfunc') {
    return sendDevRich(chatId,
      '<blockquote>🧪 <b>TES FUNCTION</b></blockquote>\n\n' +
      'Menu ini sekarang terhubung langsung ke handler <code>/tesfunc</code>.\n\n' +
      '<b>Cara pakai:</b>\n' +
      '1. Pastikan sender sudah terhubung dengan <code>/connect</code>.\n' +
      '2. Reply file <code>.js</code> atau pesan yang berisi function.\n' +
      '3. Jalankan <code>/tesfunc 628xxxxxxxxxx</code>.\n' +
      '4. Atur <code>loop|sleep</code>, contoh <code>1|700</code>.\n\n' +
      '💡 Untuk pengujian aman, gunakan <b>1 loop</b> terlebih dahulu.\n' +
      'Bot akan menolak kode yang tidak valid dan menampilkan error dengan jelas.',
      {parse_mode:'HTML', reply_markup:{inline_keyboard:[[{text:'▶️ Buka /tesfunc',callback_data:'dev_tesfunc_start',style:'success'}],[{text:'↩️ Development',callback_data:'menu_dev'}]]}}
    );
  }

  if (data === 'dev_tesfunc_start') {
    return sendDevRich(chatId,
      '🧪 <b>TES FUNCTION SIAP</b>\n\n' +
      'Reply function/file <code>.js</code> yang ingin diuji, lalu kirim:\n' +
      '<code>/tesfunc 628xxxxxxxxxx</code>\n\n' +
      'Setelah valid, reply pesan setup bot dengan format <code>1|700</code> untuk uji satu kali.\n' +
      'Jika muncul error, bot akan menampilkan penyebabnya tanpa membuat bot crash.',
      {parse_mode:'HTML', reply_markup:{inline_keyboard:[[{text:'↩️ Development',callback_data:'menu_dev'}]]}}
    );
  }

  if (data === 'rich_message') {
    return sendDevRich(chatId,
      `<h2>💎 RICH MESSAGE AI</h2>` +
      `<p>Reply pesan promosi / jualan biasa, lalu ketik <code>/richmessage</code>.</p>` +
      `<table bordered compact><tr><th>Langkah</th><th>Aksi</th></tr>` +
      `<tr><td>1</td><td>Tulis teks promosi biasa</td></tr>` +
      `<tr><td>2</td><td>Reply teks tersebut</td></tr>` +
      `<tr><td>3</td><td>Ketik <code>/richmessage</code></td></tr>` +
      `<tr><td>4</td><td>AI menyusun kartu Rich Message</td></tr></table>` +
      `<p>Hasil dibuat rapi dengan <b>tabel + tombol inline Rich</b>, emoji secukupnya, dan isi tetap mengikuti teks asli.</p>`,
      {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'💎 Gunakan /richmessage',callback_data:'richmessage_help',style:'success'}],[{text:'↩️ Menu Utama',callback_data:'back_menu',style:'danger'}]]}});
  }
  if (data === 'richmessage_help') {
    return sendDevRich(chatId,
      `<h2>💎 /richmessage</h2><p>Reply pesan promosi yang mau diubah, kemudian kirim:</p><p><code>/richmessage</code></p><p>AI akan membuat judul, deskripsi, tabel ringkas, footer, dan tombol URL yang relevan. Tidak perlu JSON dan tidak perlu wizard panjang.</p>`,
      {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'↩️ Kembali',callback_data:'rich_message'}]]}});
  }
  if (data === 'richmessage_photo') {
    const uid = String(q.from?.id || '');
    const pending = pendingRichPhotoChoice.get(uid);
    if (!pending || pending.expiresAt <= Date.now()) {
      pendingRichPhotoChoice.delete(uid);
      return bot.answerCallbackQuery(q.id, { text: 'Pilihan Rich Message sudah kedaluwarsa. Jalankan /richmessage lagi.', show_alert: true }).catch(()=>{});
    }
    pendingRichPhotoChoice.delete(uid);
    return sendRichPromotionWithPhoto(
      pending.chatId,
      pending.rendered.body,
      pending.rendered.keyboard,
      pending.photoFileId,
      pending.replyToMsgId
    );
  }

  if (data === 'richmessage_text') {
    const uid = String(q.from?.id || '');
    const pending = pendingRichPhotoChoice.get(uid);
    if (!pending || pending.expiresAt <= Date.now()) {
      pendingRichPhotoChoice.delete(uid);
      return bot.answerCallbackQuery(q.id, { text: 'Pilihan Rich Message sudah kedaluwarsa. Jalankan /richmessage lagi.', show_alert: true }).catch(()=>{});
    }
    pendingRichPhotoChoice.delete(uid);
    return sendRichMenu(
      pending.chatId,
      pending.rendered.body,
      pending.rendered.keyboard,
      null,
      pending.replyToMsgId
    );
  }

  if (data === 'richmessage_photo_cancel') {
    pendingRichPhotoChoice.delete(String(q.from?.id || ''));
    return sendRichMenu(
      chatId,
      `<h2>✖️ PILIHAN DIBATALKAN</h2><p>Hasil foto + Rich Message tidak dikirim.</p>`,
      { inline_keyboard: [[{text:'💎 Menu Rich Message',callback_data:'rich_message',style:'primary'}],[{text:'↩️ Menu Utama',callback_data:'back_menu',style:'danger'}]] },
      null
    );
  }

  if (data === 'feature_request') {
    pendingFeatureRequest.set(String(q.from.id), {chatId, createdAt:Date.now()});
    setTimeout(()=>pendingFeatureRequest.delete(String(q.from.id)),10*60*1000);
    return sendDevRich(chatId,'💡 <b>REQUEST FITUR KE DEVELOPER</b>\n\nKirim pesan berisi fitur yang ingin ditambahkan atau diperbaiki.\n\nContoh: <code>/req tambahin menu download Instagram</code>\natau cukup ketik detail request setelah menekan tombol ini.\n\nDeveloper akan menerima nama, username, ID, dan isi request.',{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'✖️ Batal',callback_data:'back_menu'}]]}});
  }
  if (data === 'lapor_menu') {
    pendingLapor.set(String(q.from.id), true);
    return sendDevRich(chatId,'📨 <b>LAPOR / SARAN</b>\n\nKirim bug, laporan, atau saran yang ingin disampaikan ke Developer.',{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'✖️ Batal',callback_data:'back_menu'}]]}});
  }

  // ---- CREATE AM PREMIUM ----
  if (data === 'am_premium_menu') {
    amPremiumSessions.delete(String(q.from.id));
    const quota = getAmPremiumUsage(String(q.from.id));
    return safeRichSendMessage(chatId,
      `<h2>CREATE AM PREMIUM</h2><p>Pilih alur yang kamu butuhkan.</p>` +
      `<p><b>Crate Email Sendiri:</b> ${Math.max(0, 2 - quota.own)}/2 tersisa hari ini<br/><b>Crate Bulk:</b> ${Math.max(0, 3 - quota.bulk)}/3 tersisa hari ini</p>` +
      `<p><i>Kuota otomatis reset setiap hari (WIB).</i></p>`,
      { parse_mode:'HTML', reply_markup:{inline_keyboard:[
        [{text:'📧 Email Sendiri',callback_data:'am_premium_own',style:'primary'}],
        [{text:'📦 Bulk 5 Akun',callback_data:'am_premium_bulk',style:'success'}],
        [{text:'↩️ Menu Tools',callback_data:'menu_alat',style:'danger'}]
      ]}}
    );
  }

  if (data === 'am_premium_cancel') {
    amPremiumSessions.delete(String(q.from.id));
    return safeRichSendMessage(chatId,'✖️ <b>Create AM Premium dibatalkan.</b>',{parse_mode:'HTML',reply_markup:menuAlatKeyboard(2)});
  }

  if (data === 'am_premium_own') {
    const uid = String(q.from.id);
    const current = amPremiumSessions.get(uid);
    if (current?.processing) return bot.answerCallbackQuery(q.id,{text:'Masih ada proses AM Premium yang berjalan.',show_alert:true}).catch(()=>{});
    const quota = getAmPremiumUsage(uid);
    if (quota.own >= 2) return bot.answerCallbackQuery(q.id,{text:'Limit Email Sendiri hari ini sudah 2/2. Reset otomatis besok.',show_alert:true}).catch(()=>{});
    amPremiumSessions.set(uid,{chatId,step:'waiting_email',createdAt:Date.now(),processing:false,quotaReserved:false});
    return safeRichSendMessage(chatId,
      `<h2>📧 CREATE AM PREMIUM</h2><p>Kirim email yang ingin diproses.</p><p>Contoh: <code>nama@gmail.com</code></p><p><i>Sisa crate email sendiri hari ini: <b>${Math.max(0, 2 - getAmPremiumUsage(uid).own)}/2</b>. Setelah email dikirim, buka Gmail, tekan lama link verifikasi → Salin alamat link, lalu kirim URL tersebut ke bot. Jangan buka link di browser.</i></p>`,
      {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'✖️ Batal',callback_data:'am_premium_cancel',style:'danger'}]]}}
    );
  }

  if (data === 'am_premium_retry_url') {
    const uid = String(q.from.id);
    const session = amPremiumSessions.get(uid);
    if (!session || !session.email) return safeRichSendMessage(chatId,'⚠️ Sesi AM Premium tidak ditemukan. Mulai dari menu Create AM Premium lagi.',{parse_mode:'HTML',reply_markup:menuAlatKeyboard(2)});
    session.step = 'waiting_verification_url';
    session.processing = false;
    session.createdAt = Date.now();
    return safeRichSendMessage(chatId,`📨 <b>KIRIM URL VERIFIKASI</b>\n\nEmail: <code>${htmlEscape(session.email)}</code>\n\n<b>PENTING:</b> jangan buka link di browser. Di Gmail, tekan lama link verifikasi → <b>Salin alamat link</b> → kirim URL lengkapnya ke bot.\n\nKalau link lama sudah dibuka dan muncul <b>404 / Page Not Found</b>, minta email verifikasi baru lalu gunakan URL terbaru.`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'✖️ Batal',callback_data:'am_premium_cancel',style:'danger'}]]}});
  }

  if (data === 'am_premium_resend') {
    const uid = String(q.from.id);
    const session = amPremiumSessions.get(uid);
    if (!session || !session.email) return safeRichSendMessage(chatId,'⚠️ Sesi AM Premium tidak ditemukan. Mulai dari menu Create AM Premium lagi.',{parse_mode:'HTML',reply_markup:menuAlatKeyboard(2)});
    if (session.processing) return bot.answerCallbackQuery(q.id,{text:'Masih mengirim email verifikasi...',show_alert:true}).catch(()=>{});
    session.processing = true;
    try {
      const result = await amSendLink(session.email);
      session.processing = false;
      session.step = 'waiting_verification_url';
      session.createdAt = Date.now();
      return safeRichSendMessage(chatId,`📨 <b>EMAIL VERIFIKASI DIKIRIM ULANG</b>\n\nEmail: <code>${htmlEscape(session.email)}</code>\n\n1. Buka Gmail dan cari email terbaru.\n2. Tekan lama tombol/link verifikasi → <b>Salin alamat link</b>.\n3. <b>Jangan buka link tersebut.</b> Langsung kirim URL lengkapnya ke bot.\n\n${result?.message ? `<i>${htmlEscape(result.message)}</i>` : 'Gunakan email terbaru agar token verifikasinya tidak kedaluwarsa.'}`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'✖️ Batal',callback_data:'am_premium_cancel',style:'danger'}]]}});
    } catch (e) {
      session.processing = false;
      return safeRichSendMessage(chatId,`❌ <b>Gagal mengirim ulang email.</b>\n\n<code>${htmlEscape(e?.message || 'Unknown error')}</code>`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🔄 Coba Lagi',callback_data:'am_premium_resend',style:'success'}],[{text:'✖️ Batal',callback_data:'am_premium_cancel',style:'danger'}]]}});
    }
  }

  if (data === 'am_premium_bulk') {
    const uid = String(q.from.id);
    const current = amPremiumSessions.get(uid);
    if (current?.processing) return bot.answerCallbackQuery(q.id,{text:'Masih ada proses AM Premium yang berjalan.',show_alert:true}).catch(()=>{});
    const quota = consumeAmPremiumQuota(uid, 'bulk', {own:2, bulk:3});
    if (!quota.ok) return bot.answerCallbackQuery(q.id,{text:'Limit Bulk hari ini sudah 3/3. Reset otomatis besok.',show_alert:true}).catch(()=>{});
    amPremiumSessions.set(uid,{chatId,step:'bulk',createdAt:Date.now(),processing:true});
    try {
      await bot.answerCallbackQuery(q.id,{text:'Bulk 5 akun dimulai.',show_alert:false}).catch(()=>{});
      await safeRichSendMessage(chatId,'<h2>📦 BULK CREATE AM PREMIUM</h2><p>⏳ Memproses <b>5 akun</b>...</p><p>Progress akan dikirim lewat Rich Message.</p>',{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'✖️ Tutup',callback_data:'am_premium_cancel',style:'danger'}]]}});
      const {accounts, summary} = await amBulkGenerate(5, async (ev) => {
        // Do not send one Telegram message per generated account.
        // The completed result is consolidated into a single bulk.text file below.
      });
      const successCount = summary?.success ?? accounts.length;
      const failedCount = summary?.failed ?? Math.max(0, 5 - accounts.length);
      const totalCount = Number(summary?.total ?? (successCount + failedCount));
      const bulkText = [
        'MD RICH • BULK AM PREMIUM',
        `Waktu: ${moment().tz(c.TIMEZONE).format('DD/MM/YYYY HH:mm:ss')} WIB`,
        `Total: ${totalCount}`,
        `Success: ${successCount}`,
        `Failed: ${failedCount}`,
        '',
        '=== HASIL ===',
        ...accounts.map((a,i) => [
          `${i+1}. Email: ${a.email || '-'}`,
          `   Status: ${a.status || '-'}`,
          `   Order ID: ${a.orderId || '-'}`,
          `   Login URL: ${a.login_url || '-'}`,
          ''
        ].join('\n'))
      ].join('\n');

      // Notify MAIN_CHANNEL independently of the result-file delivery.
      // This means the owner also gets the activity card and a temporary
      // Telegram file-send problem cannot suppress the channel notification.
      await notifyAmPremiumActivity('bulk', q.from, {
        status: failedCount > 0 ? 'Selesai dengan sebagian gagal' : 'Berhasil',
        total: totalCount,
        success: successCount,
        failed: failedCount
      }).catch(err => console.warn('[AMPREM NOTIFY] bulk:', err?.message || err));

      const bulkBuffer = Buffer.from(bulkText, 'utf8');
      // IMPORTANT: sendDocument uses normal Bot API HTML parsing. Tags such as
      // <h2> and <p> are Rich Message tags, not supported by sendDocument's
      // parse_mode=HTML, and were the direct cause of the 400 error shown in
      // the screenshot. Keep the file delivery caption to Telegram-safe HTML.
      await sendDocumentBufferReliable(chatId, bulkBuffer, {
        caption:
          `<b>✅ BULK GENERATE SELESAI</b>\n\n` +
          `📦 Total: <b>${totalCount}</b>\n` +
          `✅ Success: <b>${successCount}</b>\n` +
          `❌ Failed: <b>${failedCount}</b>\n\n` +
          `📄 Semua hasil sudah digabung menjadi <code>bulk.text</code> agar chat tidak spam.`,
        parse_mode:'HTML',
        reply_markup:{inline_keyboard:[
          [{text:'🚀 Generate Lagi',callback_data:'am_premium_bulk'}],
          [{text:'↩️ Menu Tools',callback_data:'menu_alat'}]
        ]}
      }, { filename:'bulk.text', contentType:'text/plain; charset=utf-8' });

      amPremiumSessions.delete(uid);
      return;
    } catch (e) {
      amPremiumSessions.delete(uid);
      return safeRichSendMessage(chatId,`❌ <b>BULK AM PREMIUM GAGAL</b>\n\n<code>${htmlEscape(e?.message || 'Unknown error')}</code>`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🔄 Coba Lagi',callback_data:'am_premium_bulk',style:'success'}],[{text:'↩️ Menu Tools',callback_data:'menu_alat',style:'danger'}]]}});
    }
  }

  if (data === 'menu_utama') {
    await safeDelete(bot, chatId, msgId);
    return sendMenuPhoto(bot, chatId, c.BANNER_URL, { caption: menuUtamaText(), parse_mode: 'HTML', reply_markup: backKeyboard() });
  }

  if (data === 'menu_tambahan' || data === 'downloader_media' || data === 'menu_downloader') {
    // Do not edit the main menu message here. The main menu is normally a photo
    // caption, and Telegram can reject caption edits depending on the banner
    // payload. Sending a fresh menu makes this navigation deterministic.
    try {
      await sendDevRich(chatId, menuTambahanText(), {
        parse_mode: 'HTML',
        reply_markup: menuTambahanKeyboard()
      });
      return;
    } catch (e) {
      console.error('[DOWNLOADER MENU] sendMessage failed:', e?.message || e);
      // One final fallback: use the page editor only if sending a fresh menu failed.
      return editMenuPage(bot, q, menuTambahanText(), menuTambahanKeyboard());
    }
  }

  if (data === 'media_downloader_menu') {
    return sendDevRich(chatId,
      `📥 <b>DOWNLOADER & MEDIA</b>\n\n` +
      `Pilih layanan di bawah. Setelah memilih, bot akan memberi tahu input yang harus kamu kirim.\n\n` +
      `📱 <b>TikTok</b> — kirim link TikTok\n` +
      `📸 <b>Instagram</b> — kirim link Instagram\n` +
      `📌 <b>Pinterest</b> — kirim link Pinterest\n` +
      `🎬 <b>YouTube</b> — kirim judul/video yang dicari\n` +
      `🎧 <b>Musik</b> — kirim judul lagu\n` +
      `📦 <b>NPM</b> — kirim nama package\n` +
      `🗣️ <b>TTS</b> — kirim teks yang ingin diubah menjadi suara`,
      {parse_mode:'HTML',reply_markup:menuTambahanKeyboard()});
  }
  if (data === 'media_audio_menu') {
    return sendDevRich(chatId,
      `🎵 <b>MUSIK & AUDIO</b>\n\n` +
      `🎬 YouTube Video → pilih tombol lalu kirim judul video.\n` +
      `🎧 Musik → pilih tombol lalu kirim judul lagu.\n` +
      `🗣️ TTS → pilih tombol lalu kirim teks.`,
      {parse_mode:'HTML',reply_markup:{inline_keyboard:[
        [{text:'🎬 YouTube Video',callback_data:'dl_playvid'},{text:'🎧 Cari Musik',callback_data:'dl_play'}],
        [{text:'🗣️ TTS',callback_data:'dl_tts'}],
        [{text:'↩️ Downloader & Media',callback_data:'media_downloader_menu'}]
      ]}});
  }
  if (data === 'dl_tt') return sendDevRich(chatId, `📱 <b>TIKTOK DOWNLOADER HD</b>\n\nKirim <b>link TikTok</b> pada pesan berikutnya.\n\nContoh: <code>https://www.tiktok.com/@user/video/123</code>\n\nAtau gunakan: <code>/tt link</code>`, {parse_mode:'HTML',reply_markup:menuTambahanKeyboard()});
  if (data === 'dl_cancel') { pendingDownloader.delete(String(q.from.id)); return sendDevRich(chatId, '✅ Sesi downloader dibatalkan.', {parse_mode:'HTML',reply_markup:menuTambahanKeyboard()}); }
  if (data === 'dl_ig') { pendingDownloader.set(String(q.from.id), {chatId, type:'instagram', createdAt:Date.now()}); return sendDevRich(chatId, `📸 <b>INSTAGRAM DOWNLOADER</b>\n\nKirim <b>link Instagram</b> sekarang.\n\nContoh: <code>https://www.instagram.com/reel/xxxxx/</code>\n\n⏱️ Sesi berlaku 10 menit.`, {parse_mode:'HTML',reply_markup:menuTambahanKeyboard()}); }
  if (data === 'dl_pinterest') return sendDevRich(chatId, `📌 <b>PINTEREST DOWNLOADER</b>\n\nKirim <b>link Pinterest</b> pada pesan berikutnya.\n\nContoh: <code>https://pin.it/xxxxx</code>\n\nAtau gunakan: <code>/pinterest link</code>`, {parse_mode:'HTML',reply_markup:menuTambahanKeyboard()});
  if (data === 'dl_playvid') return sendDevRich(chatId, `🎬 <b>YOUTUBE VIDEO</b>\n\nKirim <b>judul video</b> yang ingin dicari.\n\nContoh: <code>/playvid lofi hip hop</code>`, {parse_mode:'HTML',reply_markup:menuTambahanKeyboard()});
  if (data === 'dl_play') return sendDevRich(chatId, `🎧 <b>CARI MUSIK</b>\n\nKirim <b>judul lagu + artis</b>.\n\nContoh: <code>/play judul lagu</code>`, {parse_mode:'HTML',reply_markup:menuTambahanKeyboard()});
  if (data === 'dl_npm') return sendDevRich(chatId, `📦 <b>NPM PACKAGE</b>\n\nKirim <b>nama package NPM</b>.\n\nContoh: <code>/npmpackage axios</code>`, {parse_mode:'HTML',reply_markup:menuTambahanKeyboard()});
  if (data === 'dl_tts') return sendDevRich(chatId, `🗣️ <b>TTS GENERATOR</b>\n\nKirim <b>teks</b> yang ingin diubah menjadi suara.\n\nContoh: <code>/ttsgenerate Halo semuanya</code>`, {parse_mode:'HTML',reply_markup:menuTambahanKeyboard()});
  if (data.endsWith('_example')) {
    const examples = {dl_tt:'/tt https://www.tiktok.com/@user/video/123',dl_ig:'/ig https://www.instagram.com/p/xxxxx/',dl_pinterest:'/pinterest https://pin.it/xxxxx',dl_playvid:'/playvid judul video',dl_play:'/play judul lagu',dl_npm:'/npmpackage axios',dl_tts:'/ttsgenerate Halo semuanya'};
    const key=data.slice(0,-8);
    if (examples[key]) return sendDevRich(chatId, `📋 <b>CONTOH</b>\n<code>${htmlEscape(examples[key])}</code>`, {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'↩️ Kembali',callback_data:key}]]}});
  }

  if (data === 'menu_tambahan_2') {
    return editMenuPage(bot, q, menuTambahanText2(), menuTambahanKeyboard2());
  }

  if (data === 'group_page_1') {
    return editMenuPage(bot, q, menuGroupText(), menuGroupKeyboard(chatId, 1));
  }
  if (data === 'group_page_2') {
    return editMenuPage(bot, q, menuGroupText(), menuGroupKeyboard(chatId, 2));
  }

  if (data === 'group_protection_strong') {
    if (!q.message?.chat || !['group','supergroup'].includes(q.message.chat.type)) return bot.answerCallbackQuery(q.id,{text:'Buka menu ini dari grup.',show_alert:true}).catch(()=>{});
    if (!(await isGroupAdmin(chatId,q.from.id))) return bot.answerCallbackQuery(q.id,{text:'Khusus admin grup.',show_alert:true}).catch(()=>{});
    if (!(await requireBotAdmin(chatId,'can_delete_messages'))) return bot.answerCallbackQuery(q.id,{text:'Bot perlu izin Delete Messages.',show_alert:true}).catch(()=>{});
    if (!(await requireBotAdmin(chatId,'can_restrict_members'))) return bot.answerCallbackQuery(q.id,{text:'Bot perlu izin Restrict Members.',show_alert:true}).catch(()=>{});
    const current=getGroupSettings(chatId);
    const strong={...current,antilink:true,antiforward:true,antiflood:true,antispam:true,antipromosi:true,antitoxic:true,antiporno:true,antidrugs:true,antisticker:true,antibot:true};
    // Do not enable Anti Foto/Anti Video here: the strong preset uses AI to
    // block only unsafe visual content, while normal photos/videos remain allowed.
    setGroupSettings(chatId,strong);
    await bot.answerCallbackQuery(q.id,{text:'Proteksi Kuat diaktifkan.'}).catch(()=>{});
    return sendDevRich(chatId,
      `<blockquote>🛡️ <b>PROTEKSI KUAT AKTIF</b></blockquote>\n\n`+
      `• Anti 18+ → teks, link, sticker, foto, video, GIF, dan visual document\n`+
      `• Anti Drugs → teks, link, sticker, foto, video, GIF, dan visual document\n`+
      `• Anti Sticker → semua sticker diblokir\n`+
      `• Anti Link / Forward / Flood / Spam / Promosi / Toxic / Bot → aktif\n\n`+
      `<blockquote>Foto dan video normal tetap diperbolehkan. AI hanya memblokir visual yang terdeteksi masuk kategori berbahaya.</blockquote>`,
      {parse_mode:'HTML',reply_markup:menuGroupKeyboard(chatId,1)});
  }

  if (data === 'group_antiadmin_toggle') {
    if (!q.message?.chat || !['group','supergroup'].includes(q.message.chat.type)) {
      return bot.answerCallbackQuery(q.id, { text: 'Buka menu ini dari grup.', show_alert: true }).catch(() => {});
    }
    if (!(await isGroupAdmin(chatId, q.from.id))) {
      return bot.answerCallbackQuery(q.id, { text: 'Khusus admin grup.', show_alert: true }).catch(() => {});
    }
    if (!(await requireBotAdmin(chatId, 'can_delete_messages'))) {
      return bot.answerCallbackQuery(q.id, { text: 'Bot perlu izin Delete Messages.', show_alert: true }).catch(() => {});
    }
    const current = getGroupSettings(chatId);
    const enabled = !Boolean(current.antiadmin);
    setGroupSettings(chatId, { ...current, antiadmin: enabled });
    await bot.answerCallbackQuery(q.id, { text: enabled ? 'AntiAdmin ON: admin dikecualikan.' : 'AntiAdmin OFF: admin ikut diperiksa.' }).catch(() => {});
    return sendDevRich(chatId,
      `<h2>${enabled ? '🟢' : '🔴'} ANTIADMIN ${enabled ? 'AKTIF' : 'NONAKTIF'}</h2>` +
      `<p>Pengaturan ini hanya mengatur pengecualian <b>admin & creator</b> pada filter pelanggaran Jaga Group.</p>` +
      `<table bordered compact>` +
      `<tr><th>SUBJEK</th><th>STATUS</th></tr>` +
      `<tr><td>👑 Admin / Creator</td><td><b>${enabled ? 'Dikecualikan' : 'Ikut diperiksa'}</b></td></tr>` +
      `<tr><td>👤 Member</td><td><b>Ikut diperiksa</b></td></tr>` +
      `<tr><td>🛡️ Filter Jaga Group</td><td><b>Semua filter yang aktif</b></td></tr>` +
      `</table>` +
      `<blockquote>${enabled ? 'Mode ON: admin & creator aman dari pelanggaran.' : 'Mode OFF: admin & creator ikut terkena pelanggaran sesuai filter yang aktif.'}</blockquote>`,
      { parse_mode:'HTML', reply_markup:menuGroupKeyboard(chatId, 1) });
  }

  if (data.startsWith('group_toggle_')) {
    if (!q.message?.chat || !['group','supergroup'].includes(q.message.chat.type)) {
      return bot.answerCallbackQuery(q.id, { text: 'Buka menu ini dari grup.', show_alert: true }).catch(() => {});
    }
    const key = data.slice('group_toggle_'.length);
    const allowed = ['antilink','antiforward','antiflood','antispam','antipromosi','antitoxic','antiporno','antisticker','antidrugs','antifoto','antivideo','antibot'];
    if (!allowed.includes(key)) return bot.answerCallbackQuery(q.id, { text: 'Fitur tidak dikenal.', show_alert: true }).catch(() => {});
    if (!(await isGroupAdmin(chatId, q.from.id))) return bot.answerCallbackQuery(q.id, { text: 'Khusus admin grup.', show_alert: true }).catch(() => {});
    if (!(await requireBotAdmin(chatId, 'can_delete_messages'))) return bot.answerCallbackQuery(q.id, { text: 'Bot perlu izin Delete Messages.', show_alert: true }).catch(() => {});
    const current = getGroupSettings(chatId);
    const enabled = !Boolean(current[key]);
    const needsRestrict = ['antilink','antiforward','antiflood','antispam','antipromosi','antitoxic','antiporno','antisticker','antidrugs','antifoto','antivideo','antibot'].includes(key);
    const warnBased = ['antilink','antiforward','antipromosi','antitoxic','antiporno','antisticker','antidrugs','antifoto','antivideo'].includes(key);
    if (enabled && needsRestrict && !(await requireBotAdmin(chatId, 'can_restrict_members'))) {
      return bot.answerCallbackQuery(q.id, { text: 'Fitur warn membutuhkan izin Restrict Members untuk auto-mute.', show_alert: true }).catch(() => {});
    }
    setGroupSettings(chatId, { ...current, [key]: enabled });
    const labels = {antilink:'Anti Link',antiforward:'Anti Forward',antiflood:'Anti Flood',antispam:'Anti Spam',antipromosi:'Anti Promosi',antitoxic:'Anti Toxic',antiporno:'Anti 18+',antisticker:'Anti Sticker',antidrugs:'Anti Drugs',antifoto:'Anti Foto',antivideo:'Anti Video',antibot:'Anti Bot'};
    await bot.answerCallbackQuery(q.id, { text: `${labels[key]} ${enabled ? 'diaktifkan' : 'dimatikan'}.` }).catch(() => {});
    const detail = enabled && warnBased
      ? `\n\nPelanggaran: pesan dihapus → Warn 1/3 → 2/3 → 3/3 → pelanggaran ke-4 mute permanen otomatis.\n${getGroupSettings(chatId).antiadmin ? 'Admin/creator dikecualikan.' : 'Admin/creator juga ikut diperiksa.'}`
      : '';
    return sendDevRich(chatId, `${enabled ? '🟢' : '🔴'} <b>${labels[key]} ${enabled ? 'AKTIF' : 'NONAKTIF'}</b>${detail}`, { parse_mode:'HTML', reply_markup: menuGroupKeyboard(chatId, 1) });
  }

  if (data === 'group_lockmedia') {
    if (!q.message?.chat || !['group','supergroup'].includes(q.message.chat.type)) return bot.answerCallbackQuery(q.id,{text:'Buka dari grup.',show_alert:true}).catch(()=>{});
    if (!(await isGroupAdmin(chatId,q.from.id))) return bot.answerCallbackQuery(q.id,{text:'Khusus admin grup.',show_alert:true}).catch(()=>{});
    if (!(await requireBotAdmin(chatId, 'can_delete_messages'))) return bot.answerCallbackQuery(q.id,{text:'Bot perlu izin Delete Messages.',show_alert:true}).catch(()=>{});
    const gs=getGroupSettings(chatId); const enabled=!Boolean(gs.lockmedia);
    setGroupSettings(chatId,{...gs,lockmedia:enabled});
    return safeRichSendMessage(chatId,`${enabled?'🔒':'🔓'} <b>Lock Media ${enabled?'AKTIF':'NONAKTIF'}</b>\n\n${enabled?'Foto, video, GIF, dokumen, audio, dan voice dari member akan dihapus otomatis. Admin tetap diperbolehkan.':'Media kembali diperbolehkan untuk member.'}`,{parse_mode:'HTML',reply_markup:menuGroupKeyboard(chatId,2)});
  }
  if (data === 'group_lock_all' || data === 'group_unlock_all') {
    if (!q.message?.chat || !['group','supergroup'].includes(q.message.chat.type)) return bot.answerCallbackQuery(q.id,{text:'Buka dari grup.',show_alert:true}).catch(()=>{});
    if (!(await isGroupAdmin(chatId,q.from.id))) return bot.answerCallbackQuery(q.id,{text:'Khusus admin grup.',show_alert:true}).catch(()=>{});
    if (!(await requireBotAdmin(chatId,'can_restrict_members'))) return bot.answerCallbackQuery(q.id,{text:'Bot perlu izin Restrict Members.',show_alert:true}).catch(()=>{});
    const gs=getGroupSettings(chatId), locking=data==='group_lock_all';
    const locked={can_send_messages:false,can_send_audios:false,can_send_documents:false,can_send_photos:false,can_send_videos:false,can_send_video_notes:false,can_send_voice_notes:false,can_send_polls:false,can_send_other_messages:false,can_add_web_page_previews:false};
    const unlocked={can_send_messages:true,can_send_audios:true,can_send_documents:true,can_send_photos:true,can_send_videos:true,can_send_video_notes:true,can_send_voice_notes:true,can_send_polls:true,can_send_other_messages:true,can_add_web_page_previews:true};
    if (locking) {
      if (gs.lockall) return bot.answerCallbackQuery(q.id,{text:'Group sudah terkunci.',show_alert:true}).catch(()=>{});
      let previous=null; try { previous=(await bot.getChat(chatId))?.permissions||null; } catch(e) { console.warn('[LOCK ALL] getChat:',e.message); }
      try { await bot.setChatPermissions(chatId,locked,{use_independent_chat_permissions:true}); }
      catch { try { await bot.setChatPermissions(chatId,locked); } catch(e) { return bot.answerCallbackQuery(q.id,{text:`Lock All gagal: ${String(e.message||e).slice(0,120)}`,show_alert:true}).catch(()=>{}); } }
      setGroupSettings(chatId,{...gs,lockall:true,lockAllBackup:previous});
      return safeRichSendMessage(chatId,'🔒 <b>LOCK ALL AKTIF</b>\n\nSemua member kini tidak dapat mengirim pesan. Admin tetap dapat chat dan mengelola grup.\n\nGunakan <b>Unlock All</b> untuk membuka kembali.',{parse_mode:'HTML',reply_markup:menuGroupKeyboard(chatId,2)});
    }
    if (!gs.lockall) return bot.answerCallbackQuery(q.id,{text:'Group tidak sedang terkunci.',show_alert:true}).catch(()=>{});
    try { await bot.setChatPermissions(chatId,gs.lockAllBackup||unlocked,{use_independent_chat_permissions:true}); }
    catch { try { await bot.setChatPermissions(chatId,gs.lockAllBackup||unlocked); } catch(e) { return bot.answerCallbackQuery(q.id,{text:`Unlock All gagal: ${String(e.message||e).slice(0,120)}`,show_alert:true}).catch(()=>{}); } }
    setGroupSettings(chatId,{...gs,lockall:false,lockAllBackup:null});
    return safeRichSendMessage(chatId,'🔓 <b>UNLOCK ALL AKTIF</b>\n\nPermission default chat sudah dikembalikan. Member dapat chat kembali sesuai pengaturan grup.',{parse_mode:'HTML',reply_markup:menuGroupKeyboard(chatId,2)});
  }

  if (data === 'group_rules') {
    if (!chatId || !['group','supergroup'].includes(q.message?.chat?.type)) return bot.answerCallbackQuery(q.id,{text:'Buka dari grup.',show_alert:true}).catch(()=>{});
    const gs=getGroupSettings(chatId); const rules=String(gs.rules||'').trim();
    return safeRichSendMessage(chatId,`📜 <b>RULES GRUP</b>\n\n${rules?htmlEscape(rules):'<i>Rules belum diatur.</i>'}\n\n${rules?'Gunakan /rules untuk melihat kapan saja.':'Admin dapat mengatur dengan /setrules teks.'}`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'✏️ Set Rules',callback_data:'group_rules_set',style:'success'}],[{text:'🗑️ Hapus Rules',callback_data:'group_rules_clear',style:'danger'}],[{text:'↩️ Tools Grup',callback_data:'group_page_2',style:'primary'}]]}});
  }
  if (data === 'group_rules_set') {
    if (!q.message?.chat || !['group','supergroup'].includes(q.message.chat.type)) return bot.answerCallbackQuery(q.id,{text:'Buka dari grup.',show_alert:true}).catch(()=>{});
    if (!(await isGroupAdmin(chatId,q.from.id))) return bot.answerCallbackQuery(q.id,{text:'Khusus admin grup.',show_alert:true}).catch(()=>{});
    return safeRichSendMessage(chatId,'📜 <b>SET RULES</b>\n\nGunakan command:\n<code>/setrules isi rules grup</code>\n\nContoh: <code>/setrules Dilarang spam, promosi, dan link.</code>',{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'📜 Lihat Rules',callback_data:'group_rules'}],[{text:'↩️ Tools Grup',callback_data:'group_page_2'}]]}});
  }
  if (data === 'group_rules_clear') {
    if (!q.message?.chat || !['group','supergroup'].includes(q.message.chat.type)) return bot.answerCallbackQuery(q.id,{text:'Buka dari grup.',show_alert:true}).catch(()=>{});
    if (!(await isGroupAdmin(chatId,q.from.id))) return bot.answerCallbackQuery(q.id,{text:'Khusus admin grup.',show_alert:true}).catch(()=>{});
    const gs=getGroupSettings(chatId); setGroupSettings(chatId,{...gs,rules:''});
    return safeRichSendMessage(chatId,'🗑️ <b>Rules grup dihapus.</b>',{parse_mode:'HTML',reply_markup:menuGroupKeyboard(chatId,2)});
  }

  if (data === 'group_admin_roles') {
    if (!q.message?.chat || !['group','supergroup'].includes(q.message.chat.type)) return bot.answerCallbackQuery(q.id,{text:'Buka dari grup.',show_alert:true}).catch(()=>{});
    if (!(await isGroupAdmin(chatId, q.from.id))) return bot.answerCallbackQuery(q.id,{text:'Khusus admin grup.',show_alert:true}).catch(()=>{});
    return safeRichSendMessage(chatId,
      `<blockquote><b>ROLE ADMIN</b></blockquote>\n\n` +
      `<b>Promote</b> — jadikan member sebagai admin.\n<code>/promote @username</code>\n<code>/promote</code> + reply pesan member\natau <code>/promote 123456789</code>\n\n` +
      `<b>Demote</b> — cabut status admin.\n<code>/demote @username</code>\n<code>/demote</code> + reply pesan admin\natau <code>/demote 123456789</code>\n\n` +
      `<i>Bot membutuhkan izin Add New Admins. Creator grup tidak dapat di-demote.</i>`,
      {parse_mode:'HTML',reply_markup:{inline_keyboard:[
        [{text:'Promote',callback_data:'info_promote',style:'success'},{text:'Demote',callback_data:'info_demote',style:'danger'}],
        [{text:'Member Tools',callback_data:'group_member_tools',style:'primary'},{text:'Tools Grup',callback_data:'group_page_2',style:'primary'}]
      ]}});
  }

  if (data === 'group_member_tools') {
    if (!q.message?.chat || !['group','supergroup'].includes(q.message.chat.type)) return bot.answerCallbackQuery(q.id,{text:'Buka dari grup.',show_alert:true}).catch(()=>{});
    if (!(await isGroupAdmin(chatId,q.from.id))) return bot.answerCallbackQuery(q.id,{text:'Khusus admin grup.',show_alert:true}).catch(()=>{});
    return sendDevRich(chatId, `<b>👥 MEMBER TOOLS</b>\n\nReply pesan member lalu gunakan salah satu command:\n\n• <code>/mute</code> — bisukan\n• <code>/unmute</code> — buka mute\n• <code>/kick</code> — keluarkan\n• <code>/ban</code> — ban\n• <code>/unban</code> — unban\n• <code>/promote</code> — jadikan admin\n• <code>/unpromote</code> — cabut admin\n• <code>/pin</code> — pin pesan\n\n<i>Bot akan memeriksa hak admin dan izin bot sebelum menjalankan aksi.</i>`, {parse_mode:'HTML', reply_markup:{inline_keyboard:[[{text:'◀️ Tools Grup',callback_data:'group_page_2',style:'primary'},{text:'🏠 Menu Utama',callback_data:'back_menu',style:'danger'}]]}});
  }

  if (data === 'group_slowmode_help') {
    if (!q.message?.chat || !['group','supergroup'].includes(q.message.chat.type)) return bot.answerCallbackQuery(q.id,{text:'Buka dari grup.',show_alert:true}).catch(()=>{});
    if (!(await isGroupAdmin(chatId,q.from.id))) return bot.answerCallbackQuery(q.id,{text:'Khusus admin grup.',show_alert:true}).catch(()=>{});
    return sendDevRich(chatId, `<b>🐌 SLOWMODE</b>\n\nGunakan:\n<code>/slowmode 10</code> — jeda 10 detik\n<code>/slowmode 30</code> — jeda 30 detik\n<code>/slowmode off</code> — matikan\n\n<i>Slowmode membantu mengurangi spam saat grup ramai.</i>`, {parse_mode:'HTML', reply_markup:{inline_keyboard:[[{text:'◀️ Tools Grup',callback_data:'group_page_2',style:'primary'}]]}});
  }

  if (data === 'group_account_info') {
    if (!q.message?.chat || !['group','supergroup'].includes(q.message.chat.type)) return bot.answerCallbackQuery(q.id,{text:'Buka menu ini dari grup.',show_alert:true}).catch(()=>{});
    return sendDevRich(chatId, `<b>ℹ️ INFO AKUN & ID</b>\n\n• <code>/info</code> — info akun sendiri.\n• Reply pesan seseorang + <code>/info</code> — info akun orang tersebut.\n• <code>/id</code> — User ID + Chat ID.\n• Reply pesan + <code>/id</code> — ambil ID user yang direply.\n\n<i>Mirip pola bot moderasi grup: fitur identitas ditempatkan di Group Center agar menu utama tetap bersih.</i>`, {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'👤 Info Saya',callback_data:`info_self_${q.from.id}`}],[{text:'🛡️ Status Grup',callback_data:'group_security_status'}],[{text:'↩️ Tools Grup',callback_data:'group_page_2'}]]}});
  }

  if (data === 'group_info_help') {
    if (!q.message?.chat || !['group','supergroup'].includes(q.message.chat.type)) return bot.answerCallbackQuery(q.id,{text:'Buka menu ini dari grup.',show_alert:true}).catch(()=>{});
    const gs=getGroupSettings(chatId);
    return sendDevRich(chatId, `<b>📋 GROUP INFO</b>\n\nNama: <b>${htmlEscape(q.message.chat.title||'-')}</b>\nChat ID: <code>${chatId}</code>\nTipe: <code>${q.message.chat.type}</code>\n\n🛡️ Keamanan: ${Object.values(gs).filter(v=>v===true).length} fitur aktif\n👋 Welcome: ${gs.welcome?.enabled?'🟢 Aktif':'🔴 Nonaktif'}\n📜 Rules: ${gs.rules?'🟢 Tersedia':'⚪ Belum diatur'}\n🐌 Slowmode: ${gs.slowmode?`🟢 ${gs.slowmode}s`:'🔴 Nonaktif'}\n🔒 Lock Media: ${gs.lockmedia?'🟢 Aktif':'🔴 Nonaktif'}\n🔒 Lock All: ${gs.lockall?'🟢 Aktif':'🔴 Nonaktif'}`, {parse_mode:'HTML', reply_markup:{inline_keyboard:[[{text:'🛡️ Cek Status',callback_data:'group_security_status',style:'primary'}],[{text:'ℹ️ Info Akun / ID',callback_data:'group_account_info',style:'primary'}],[{text:'◀️ Tools Grup',callback_data:'group_page_2'}]]}});
  }

  if (data === 'group_antilink_toggle') {
    if (!['group','supergroup'].includes(q.message?.chat?.type)) {
      return bot.answerCallbackQuery(q.id, { text: 'Fitur ini hanya untuk grup.', show_alert: true }).catch(() => {});
    }
    const okAdmin = await isGroupAdmin(chatId, q.from.id);
    if (!okAdmin) return bot.answerCallbackQuery(q.id, { text: 'Khusus admin grup.', show_alert: true }).catch(() => {});
    if (!(await requireBotAdmin(chatId))) return bot.answerCallbackQuery(q.id, { text: 'Bot harus menjadi admin grup.', show_alert: true }).catch(() => {});
    const current = getGroupSettings(chatId);
    const enabled = !Boolean(current.antilink);
    setGroupSettings(chatId, { ...current, antilink: enabled });
    await bot.answerCallbackQuery(q.id, { text: enabled ? 'Anti Link diaktifkan.' : 'Anti Link dimatikan.' }).catch(() => {});
    return sendDevRich(chatId, `${enabled ? '🟢' : '🔴'} <b>Anti Link ${enabled ? 'AKTIF' : 'NONAKTIF'}</b>\n\n${enabled ? 'Link dari member akan dihapus otomatis (TikTok & Instagram tetap dikecualikan).' : 'Link sekarang diperbolehkan kembali.'}`, { parse_mode: 'HTML', reply_markup: menuGroupKeyboard(chatId) });
  }

  if (data === 'group_forcesub') {
    if (!chatId || !['group','supergroup'].includes(q.message?.chat?.type)) {
      return bot.answerCallbackQuery(q.id, { text: 'Buka menu ini dari grup.', show_alert: true }).catch(()=>{});
    }
    const admin = await isGroupAdmin(chatId, q.from.id);
    if (!admin) return bot.answerCallbackQuery(q.id, { text: 'Khusus admin grup.', show_alert: true }).catch(()=>{});
    const botState = await getForceSubBotState(chatId);
    const cfg = getForceSubscribeConfig(chatId);
    const status = cfg.enabled && cfg.channels.length
      ? `🟢 <b>Aktif</b>\nChannel wajib: <b>${cfg.channels.length}</b> (maks. 7)\n${cfg.channels.map((ch,i)=>`${i+1}. ${htmlEscape(ch.title || ch.channel)}`).join('\n')}`
      : '🔴 <b>Nonaktif</b>';
    const readiness = botState.ok
      ? '✅ Bot grup siap: izin <b>Delete Messages</b> aktif.'
      : `⚠️ <b>Bot grup belum siap:</b> ${botState.reason}`;
    return sendDevRich(chatId,
      `🔒 <b>FORCE SUBSCRIBE</b>\n\n${status}\n\n${readiness}\n\n` +
      `Sebelum mengaktifkan fitur, pastikan bot adalah admin grup dengan izin <b>Delete Messages</b> dan admin channel target. Member yang belum join hanya akan dihapus pesannya, bukan di-mute.`,
      { parse_mode:'HTML', reply_markup:{ inline_keyboard:[
        [{text:'Set / Ganti Channel',callback_data:'group_forcesub_set'}],
        [{text:'Cara Pasang',callback_data:'group_forcesub_help'}],
        [{text:'Cek Status',callback_data:'group_forcesub_status'},{text:'Matikan',callback_data:'group_forcesub_off'}],
        [{text:'↩️ Menu Grup',callback_data:'menu_group'}]
      ]}}
    );
  }
  if (data === 'group_forcesub_help') {
    if (!chatId || !['group','supergroup'].includes(q.message?.chat?.type)) return bot.answerCallbackQuery(q.id,{text:'Buka dari grup.',show_alert:true}).catch(()=>{});
    if (!(await isGroupAdmin(chatId,q.from.id))) return bot.answerCallbackQuery(q.id,{text:'Khusus admin grup.',show_alert:true}).catch(()=>{});
    return sendDevRich(chatId, `<blockquote><b>CARA PASANG FORCE SUBSCRIBE</b></blockquote>\n\n` +
      `<b>1.</b> Bot harus admin di grup target + izin <b>Delete Messages</b>.\n` +
      `<b>2.</b> Bot harus admin di setiap channel wajib.\n` +
      `<b>3.</b> Tekan <b>Set / Ganti Channel</b>.\n` +
      `<b>4.</b> Kirim <b>1–7 channel</b>, satu channel per baris.\n\n` +
      `<b>Public</b>\n<code>@channel_satu\n@channel_dua\n@channel_tiga</code>\n\n` +
      `<b>Private</b>\n<code>-1001234567890 | https://t.me/+InviteLink</code>\n\n` +
      `<b>Contoh 3 channel</b>\n<code>@channel_satu\n@channel_dua\n-1001234567890 | https://t.me/+InviteLink</code>\n\n` +
      `Setelah aktif, member wajib join <b>semua</b> channel. Jika belum, pesan akan dihapus otomatis dan bot menampilkan tombol Join.\n\n<i>Maksimal 7 channel. Konfigurasi baru menggantikan daftar lama.</i>`,
      {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'Set / Ganti Channel',callback_data:'group_forcesub_set',style:'success'}],[{text:'Kembali',callback_data:'group_forcesub'}]]}});
  }

  if (data === 'group_forcesub_set') {
    if (!chatId || !['group','supergroup'].includes(q.message?.chat?.type)) return bot.answerCallbackQuery(q.id,{text:'Buka dari grup.',show_alert:true}).catch(()=>{});
    if (!(await isGroupAdmin(chatId,q.from.id))) return bot.answerCallbackQuery(q.id,{text:'Khusus admin grup.',show_alert:true}).catch(()=>{});
    const botState = await getForceSubBotState(chatId);
    if (!botState.ok) {
      return bot.answerCallbackQuery(q.id, { text: botState.reason.replace(/<[^>]+>/g,''), show_alert:true }).catch(()=>{});
    }
    pendingForceSub.set(String(q.from.id), { chatId, createdAt: Date.now() });
    setTimeout(()=>pendingForceSub.delete(String(q.from.id)), 5*60*1000);
    return sendDevRich(chatId,
      `<b>SET FORCE SUBSCRIBE</b>\n\nKirim <b>1–7 channel</b>, satu per baris. Setiap baris = satu channel. Public: <code>@channel</code>. Private: <code>-100123... | https://t.me/+InviteLink</code>. Contoh 3 channel: <code>@satu\n@dua\n-1001234567890 | https://t.me/+InviteLink</code>.\n\nContoh:\n<code>@channel_satu\n@channel_dua\n-1001234567890 | https://t.me/+InviteLink</code>\n\nBot harus menjadi <b>admin</b> di setiap channel. Konfigurasi baru akan menggantikan daftar lama.`,
      {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'✖️ Batal',callback_data:'group_forcesub'}]]}}
    );
  }
  if (data === 'group_forcesub_status') {
    if (!chatId || !(await isGroupAdmin(chatId,q.from.id))) return bot.answerCallbackQuery(q.id,{text:'Khusus admin grup.',show_alert:true}).catch(()=>{});
    const cfg = getForceSubscribeConfig(chatId);
    const groupBotState = await getForceSubBotState(chatId);
    const channelStates = [];
    const me = await bot.getMe().catch(() => null);
    for (const ch of cfg.channels) {
      try {
        const cm = await bot.getChatMember(ch.channel, me.id);
        channelStates.push(`${htmlEscape(ch.title || ch.channel)} — ${['administrator','creator'].includes(cm.status) ? 'bot admin' : `bot: ${htmlEscape(cm.status)}`}`);
      } catch (e) {
        channelStates.push(`${htmlEscape(ch.title || ch.channel)} — tidak bisa dicek`);
      }
    }
    const body = cfg.enabled && cfg.channels.length
      ? `<b>FORCE SUBSCRIBE AKTIF</b>\n\n<b>Channel wajib:</b> ${cfg.channels.length}/7\n${cfg.channels.map((ch,i)=>`${i+1}. <b>${htmlEscape(ch.title || ch.channel)}</b>\n   <code>${htmlEscape(ch.channel)}</code>`).join('\n')}\n\n<b>Kesiapan:</b>\n${groupBotState.ok ? 'Bot grup: Delete Messages aktif' : `Bot grup: ${htmlEscape(groupBotState.reason || 'belum siap')}`}\n${channelStates.join('\n')}\n\nMember yang belum join semua channel akan dihapus pesannya. Tidak ada mute.`
      : `<b>FORCE SUBSCRIBE NONAKTIF</b>\n\nBelum ada channel wajib join untuk grup ini.`;
    return sendDevRich(chatId, body, {parse_mode:'HTML',disable_web_page_preview:true,reply_markup:{inline_keyboard:[[{text:'⚙️ Force Subscribe',callback_data:'group_forcesub'}],[{text:'↩️ Menu Grup',callback_data:'menu_group'}]]}});
  }
  if (data === 'group_forcesub_off') {
    if (!chatId || !(await isGroupAdmin(chatId,q.from.id))) return bot.answerCallbackQuery(q.id,{text:'Khusus admin grup.',show_alert:true}).catch(()=>{});
    if (!(await requireBotAdmin(chatId))) return;
    const gs = getGroupSettings(chatId);
    setGroupSettings(chatId,{...gs,forceSubscribe:{...(gs.forceSubscribe||{}),enabled:false}});
    return sendDevRich(chatId,'⛔ <b>Force Subscribe dimatikan.</b>\n\nMember tidak lagi diwajibkan join channel.',{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🔒 Force Subscribe',callback_data:'group_forcesub'}],[{text:'↩️ Menu Grup',callback_data:'menu_group'}]]}});
  }
  if (data === 'group_settings_help') {
    return sendDevRich(chatId, `⚙️ <b>PENGATURAN GRUP</b>\n\nGunakan tombol di bawah untuk mengatur fitur grup.\n\n👋 <b>Welcome</b> dapat disetup langsung: tekan <b>Welcome</b>, kirim teks sambutan, lalu pilih apakah memakai foto atau tidak.`, {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'👋 Setup Welcome',callback_data:'welcome_setup',style:'success'}],[{text:'📋 Status Welcome',callback_data:'welcome_status'}],[{text:'🔒 Force Subscribe',callback_data:'group_forcesub'}],[{text:'↩️ Menu Grup',callback_data:'menu_group'}]]}});
  }

  if (data === 'group_filters') {
    if (!chatId || !['group','supergroup'].includes(q.message?.chat?.type)) return bot.answerCallbackQuery(q.id,{text:'Buka dari grup.',show_alert:true}).catch(()=>{});
    if (!(await isGroupAdmin(chatId,q.from.id))) return bot.answerCallbackQuery(q.id,{text:'Khusus admin grup.',show_alert:true}).catch(()=>{});
    const filters = getGroupFilters(chatId);
    const keys = Object.keys(filters).sort();
    const body = keys.length
      ? `<b>🔎 FILTERS GRUP</b>\n\n${keys.map((k,i)=>`${i+1}. <code>${htmlEscape(k)}</code>`).join('\n')}\n\n📊 Total: <b>${keys.length}</b> filter\n🗑 Hapus: <code>/stop kata</code>`
      : `<b>🔎 FILTERS GRUP</b>\n\nBelum ada filter.\n\nReply pesan lalu gunakan <code>/filter kata</code>.`;
    return safeRichSendMessage(chatId,body,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'➕ Add Filter',callback_data:'group_filter_add',style:'success'}],[{text:'↩️ Menu Grup',callback_data:'menu_group'}]]}});
  }
  if (data === 'group_filter_add') {
    if (!chatId || !['group','supergroup'].includes(q.message?.chat?.type)) return bot.answerCallbackQuery(q.id,{text:'Buka dari grup.',show_alert:true}).catch(()=>{});
    if (!(await isGroupAdmin(chatId,q.from.id))) return bot.answerCallbackQuery(q.id,{text:'Khusus admin grup.',show_alert:true}).catch(()=>{});
    return safeRichSendMessage(chatId,`<b>➕ TAMBAH FILTER</b>\n\n1️⃣ Reply pesan yang ingin disimpan.\n2️⃣ Ketik <code>/filter kata</code>.\n\nContoh: reply foto → <code>/filter gambar</code>.\n\nSaat member mengetik <code>gambar</code>, bot akan mengirim ulang pesan tersebut.\n\n📋 <code>/filters</code> = daftar filter\n🗑 <code>/stop gambar</code> = hapus filter`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🔎 Lihat Filters',callback_data:'group_filters'}],[{text:'↩️ Menu Grup',callback_data:'menu_group'}]]}});
  }

  if (data === 'welcome_status') {
    if (!q.message?.chat || !['group','supergroup'].includes(q.message.chat.type)) return bot.answerCallbackQuery(q.id,{text:'Buka menu ini dari grup.',show_alert:true}).catch(()=>{});
    if (!(await requireGroupAdmin({chat:q.message.chat,from:q.from}))) return;
    const gs = getGroupSettings(chatId);
    const enabled = Boolean(gs.welcome?.enabled);
    const preview = gs.welcome?.message ? htmlEscape(gs.welcome.message).slice(0,1200) : '<i>Belum ada teks welcome.</i>';
    return sendDevRich(chatId, `👋 <b>STATUS WELCOME</b>\n\nStatus: ${enabled ? '🟢 Aktif' : '🔴 Nonaktif'}\n\n<b>Teks:</b>\n<blockquote>${preview}</blockquote>\n\nVariabel: <code>{username}</code> <code>{name}</code> <code>{id}</code>`, {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'✏️ Set / Ganti Teks',callback_data:'welcome_setup',style:'success'}],[{text:'⛔ Matikan',callback_data:'welcome_disable'}],[{text:'↩️ Menu Grup',callback_data:'menu_group'}]]}});
  }

  if (data === 'welcome_disable') {
    if (!(await requireGroupAdmin({chat:q.message?.chat,from:q.from}))) return;
    const gs = getGroupSettings(chatId);
    setGroupSettings(chatId,{...gs,welcome:{...gs.welcome,enabled:false}});
    return sendDevRich(chatId,'⛔ <b>Welcome dinonaktifkan.</b>\n\nTeks dan foto tetap tersimpan. Kamu bisa mengaktifkannya lagi lewat <b>Setup Welcome</b>.',{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'👋 Setup Welcome',callback_data:'welcome_setup',style:'success'}],[{text:'↩️ Menu Grup',callback_data:'menu_group'}]]}});
  }

  if (data === 'welcome_setup') {
    if (!q.message?.chat || !['group','supergroup'].includes(q.message.chat.type)) return bot.answerCallbackQuery(q.id,{text:'Buka menu ini dari grup.',show_alert:true}).catch(()=>{});
    if (!(await requireGroupAdmin({chat:q.message.chat,from:q.from}))) return;
    if (!isGroupBotAdder(chatId,q.from.id)) return bot.answerCallbackQuery(q.id,{text:'Hanya pengatur grup yang boleh setup welcome.',show_alert:true}).catch(()=>{});
    const key = `welcome_msg:${chatId}:${q.from.id}`;
    pendingWelcomeSetup.set(key,{step:'message',chatId,userId:q.from.id,createdAt:Date.now()});
    setTimeout(()=>{ const cur=pendingWelcomeSetup.get(key); if(cur && Date.now()-cur.createdAt>=10*60*1000) pendingWelcomeSetup.delete(key); },10*60*1000);
    return sendDevRich(chatId, `👋 <b>SETUP WELCOME</b>\n\nKirim <b>teks sambutan</b> yang ingin dipakai.\n\nVariabel: <code>{username}</code> = username, <code>{name}</code> = nama, <code>{id}</code> = ID.\n\nContoh:\n<code>Halo {name}! Selamat datang di grup 🎉</code>\n\n<i>Setelah teks diterima, bot akan menampilkan pilihan foto atau tanpa foto.</i>`, {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'✖️ Batal',callback_data:'menu_group'}]]}});
  }

  if (data.startsWith('welcome_photo_prompt_')) {
    const grpId=data.replace('welcome_photo_prompt_','');
    const setup=pendingWelcomeSetup.get(`welcome_photo:${grpId}:${q.from.id}`);
    if(!setup) return bot.answerCallbackQuery(q.id,{text:'Sesi setup sudah habis. Tekan Setup Welcome lagi.',show_alert:true}).catch(()=>{});
    return sendDevRich(chatId,'🖼️ <b>Kirim foto welcome sekarang.</b>\n\nBot akan memakai foto yang kamu kirim sebagai gambar sambutan member baru.',{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'✅ Tanpa Foto',callback_data:`welcome_nophoto_${grpId}`}],[{text:'✖️ Batal',callback_data:`welcome_cancel_${grpId}`}]]}});
  }

  if (data.startsWith('welcome_nophoto_')) {
    const grpId = data.replace('welcome_nophoto_', '');
    const key = `welcome_photo:${grpId}:${q.from.id}`;
    const setup = pendingWelcomeSetup.get(key);
    if (!setup) return bot.answerCallbackQuery(q.id, { text: 'Sesi setup sudah habis. Tekan Setup Welcome lagi.', show_alert: true });
    pendingWelcomeSetup.delete(key);
    const gs = getGroupSettings(grpId);
    setGroupSettings(grpId, { ...gs, welcome: { enabled: true, message: setup.message, photo: null } });
    await safeDelete(bot, chatId, msgId);
    return sendDevRich(chatId, `<blockquote>${E.check} <b>Welcome aktif!</b></blockquote>\n\n<b>Preview:</b>\n${htmlEscape(setup.message)}\n\n<blockquote>Member baru akan menerima teks ini saat masuk grup.</blockquote>`, { parse_mode: 'HTML', reply_markup:{inline_keyboard:[[{text:'📋 Status Welcome',callback_data:'welcome_status'}],[{text:'↩️ Menu Grup',callback_data:'menu_group'}]]} });
  }

  if (data.startsWith('welcome_cancel_')) {
    const grpId=data.replace('welcome_cancel_','');
    pendingWelcomeSetup.delete(`welcome_msg:${grpId}:${q.from.id}`);
    pendingWelcomeSetup.delete(`welcome_photo:${grpId}:${q.from.id}`);
    return sendDevRich(chatId,'✖️ <b>Setup Welcome dibatalkan.</b>',{parse_mode:'HTML',reply_markup:menuGroupKeyboard(chatId)});
  }

  if (data === 'welcome_goodbye_status') {
    if (!q.message?.chat || !['group','supergroup'].includes(q.message.chat.type)) return bot.answerCallbackQuery(q.id,{text:'Buka menu ini dari grup.',show_alert:true}).catch(()=>{});
    if (!(await requireGroupAdmin({chat:q.message.chat,from:q.from}))) return;
    const gs = getGroupSettings(chatId);
    const w = gs.welcome || {}; const g = gs.goodbye || {};
    return sendDevRich(chatId, `<blockquote><b>WELCOME & GOODBYE</b></blockquote>\n\n` +
      `<b>Welcome:</b> ${w.enabled ? 'Aktif' : 'Nonaktif'}\n${w.message ? `<blockquote>${htmlEscape(w.message)}</blockquote>` : '<i>Belum diatur.</i>'}\n\n` +
      `<b>Goodbye:</b> ${g.enabled ? 'Aktif' : 'Nonaktif'}\n${g.message ? `<blockquote>${htmlEscape(g.message)}</blockquote>` : '<i>Belum diatur.</i>'}`,
      {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'Setup Welcome',callback_data:'welcome_setup',style:'success'},{text:'Setup Goodbye',callback_data:'goodbye_setup',style:'success'}],[{text:'Menu Grup',callback_data:'menu_group'}]]}});
  }

  if (data === 'goodbye_setup') {
    if (!q.message?.chat || !['group','supergroup'].includes(q.message.chat.type)) return bot.answerCallbackQuery(q.id,{text:'Buka menu ini dari grup.',show_alert:true}).catch(()=>{});
    if (!(await requireGroupAdmin({chat:q.message.chat,from:q.from}))) return;
    const key = `goodbye_msg:${chatId}:${q.from.id}`;
    pendingWelcomeSetup.set(key,{step:'message',chatId,userId:q.from.id,createdAt:Date.now(),goodbye:true});
    setTimeout(()=>{ const cur=pendingWelcomeSetup.get(key); if(cur && Date.now()-cur.createdAt>=10*60*1000) pendingWelcomeSetup.delete(key); },10*60*1000);
    return sendDevRich(chatId, `<blockquote><b>SETUP GOODBYE</b></blockquote>\n\nKirim <b>teks saat member keluar</b>.\n\nVariabel: <code>{username}</code> = username, <code>{name}</code> = nama, <code>{id}</code> = ID.\n\nContoh:\n<code>{name} keluar dari grup. Sampai jumpa!</code>\n\nSetelah teks diterima, kamu bisa memilih tanpa foto atau memakai foto.`, {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'Batal',callback_data:'menu_group'}]]}});
  }

  if (data.startsWith('goodbye_photo_prompt_')) {
    const grpId=data.replace('goodbye_photo_prompt_','');
    const setup=pendingWelcomeSetup.get(`goodbye_photo:${grpId}:${q.from.id}`);
    if(!setup) return bot.answerCallbackQuery(q.id,{text:'Sesi setup sudah habis. Tekan Setup Goodbye lagi.',show_alert:true}).catch(()=>{});
    return sendDevRich(chatId,'<blockquote><b>KIRIM FOTO GOODBYE</b></blockquote>\n\nKirim foto yang akan tampil saat member keluar dari grup.',{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'Tanpa Foto',callback_data:`goodbye_nophoto_${grpId}`}],[{text:'Batal',callback_data:`goodbye_cancel_${grpId}`}]]}});
  }

  if (data.startsWith('goodbye_nophoto_')) {
    const grpId=data.replace('goodbye_nophoto_','');
    const key=`goodbye_photo:${grpId}:${q.from.id}`; const setup=pendingWelcomeSetup.get(key);
    if(!setup) return bot.answerCallbackQuery(q.id,{text:'Sesi setup sudah habis.',show_alert:true});
    pendingWelcomeSetup.delete(key);
    const gs=getGroupSettings(grpId); setGroupSettings(grpId,{...gs,goodbye:{enabled:true,message:setup.message,photo:null}});
    return sendDevRich(chatId,'<b>Goodbye aktif.</b>\n\nTeks tersimpan dan akan dikirim saat member keluar.',{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'Status Welcome/Goodbye',callback_data:'welcome_goodbye_status'}],[{text:'Menu Grup',callback_data:'menu_group'}]]}});
  }

  if (data.startsWith('goodbye_cancel_')) {
    const grpId=data.replace('goodbye_cancel_',''); pendingWelcomeSetup.delete(`goodbye_msg:${grpId}:${q.from.id}`); pendingWelcomeSetup.delete(`goodbye_photo:${grpId}:${q.from.id}`);
    return sendDevRich(chatId,'Setup Goodbye dibatalkan.',{parse_mode:'HTML',reply_markup:menuGroupKeyboard(chatId,2)});
  }

  if (data === 'goodbye_disable') {
    if (!(await requireGroupAdmin({chat:q.message?.chat,from:q.from}))) return;
    const gs=getGroupSettings(chatId); setGroupSettings(chatId,{...gs,goodbye:{...(gs.goodbye||{}),enabled:false}});
    return sendDevRich(chatId,'<b>Goodbye dinonaktifkan.</b>',{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'Setup Goodbye',callback_data:'goodbye_setup',style:'success'}],[{text:'Menu Grup',callback_data:'menu_group'}]]}});
  }

  if (data === 'menu_group') {
    await safeDelete(bot, chatId, msgId);
    return sendMenuPhoto(bot, chatId, c.BANNER_URL, { caption: menuGroupText(), parse_mode: 'HTML', reply_markup: menuGroupKeyboard(chatId) });
  }

  if (data === 'menu_fun') {
    await safeDelete(bot, chatId, msgId);
    return sendMenuPhoto(bot, chatId, c.BANNER_URL, { caption: menuFunText(), parse_mode: 'HTML', reply_markup: menuFunKeyboard() });
  }

  if (data === 'menu_alat') {
    await safeDelete(bot, chatId, msgId);
    return sendMenuPhoto(bot, chatId, c.BANNER_URL, { caption: menuAlatText(), parse_mode: 'HTML', reply_markup: menuAlatKeyboard() });
  }
  if (data === 'menu_relax') {
    await safeDelete(bot, chatId, msgId);
    return sendMenuPhoto(bot, chatId, c.BANNER_URL, { caption: relaxingText(), parse_mode:'HTML', reply_markup: relaxingKeyboard() });
  }
  if (data === 'fun_dicebattle') { const a=crypto.randomInt(1,7),b=crypto.randomInt(1,7); return sendDevRich(chatId,`🎲 <b>Dice Battle</b>\nKamu: <code>${a}</code>\nBot: <code>${b}</code>\n\n${a>b?'🏆 Kamu menang!':a<b?'🤖 Bot menang!':'🤝 Seri!'}`,{parse_mode:'HTML',reply_markup:menuFunKeyboard(3)}); }
  if (data === 'fun_guess100') { const n=crypto.randomInt(1,101); return sendDevRich(chatId,`🔢 <b>Guess 1–100</b>\n\nAngka rahasia sudah dibuat: <code>${n}</code>\nTebak dengan perintah <code>/tebakangka</code> untuk game interaktif biasa.`,{parse_mode:'HTML',reply_markup:menuFunKeyboard(3)}); }
  if (data === 'fun_truefalse') { const qs=[['Matahari adalah bintang.','Benar'],['Python adalah bahasa markup.','Salah'],['7 × 8 = 56.','Benar'],['Bumi memiliki dua Bulan.','Salah']]; const x=qs[crypto.randomInt(qs.length)]; return sendDevRich(chatId,`🧠 <b>True / False</b>\n\n${x[0]}\n\nJawaban: <tg-spoiler>${x[1]}</tg-spoiler>`,{parse_mode:'HTML',reply_markup:menuFunKeyboard(3)}); }
  if (data === 'fun_wordchain') { const words=['apel','lampu','ular','robot','buku','kamera','awan','nasi']; const w=words[crypto.randomInt(words.length)]; return sendDevRich(chatId,`📝 <b>Word Chain</b>\n\nKata awal: <code>${w}</code>\nLanjutkan dengan kata yang diawali huruf <b>${w.slice(-1).toUpperCase()}</b>.`,{parse_mode:'HTML',reply_markup:menuFunKeyboard(3)}); }
  if (data === 'fun_fastmath') { const a=crypto.randomInt(10,51),b=crypto.randomInt(2,16); return sendDevRich(chatId,`⚡ <b>Fast Math</b>\n\nBerapa hasil <code>${a} × ${b}</code>?\nJawaban: <tg-spoiler>${a*b}</tg-spoiler>`,{parse_mode:'HTML',reply_markup:menuFunKeyboard(3)}); }
  if (data === 'tool_emoji_id') {
    const uid = String(q.from?.id || '');
    pendingEmojiId.set(uid, { chatId, createdAt: Date.now() });
    setTimeout(() => {
      const cur = pendingEmojiId.get(uid);
      if (cur && Date.now() - cur.createdAt >= 5 * 60 * 1000) pendingEmojiId.delete(uid);
    }, 5 * 60 * 1000);
    return sendRichMenu(chatId,
      `<h2>🆔 EMOJI ID CHECKER</h2>` +
      `<p>Kirim <b>1 atau beberapa emoji</b> sekarang.</p>` +
      `<table bordered compact><tr><th>JENIS</th><th>HASIL</th></tr>` +
      `<tr><td>Premium / Custom</td><td>Telegram custom emoji ID akan dibaca dari entity pesan.</td></tr>` +
      `<tr><td>Emoji biasa</td><td>Tidak memiliki custom emoji ID Telegram.</td></tr></table>` +
      `<p><i>Bisa menerima emoji Premium/custom maupun emoji Unicode biasa.</i></p>`,
      { inline_keyboard: [
        [{ text:'✖️ Batal', callback_data:'tool_emoji_id_cancel', style:'danger' }],
        [{ text:'↩️ Kembali ke Tools', callback_data:'menu_alat', style:'primary' }]
      ] }, c.BANNER_URL
    );
  }

  if (data === 'tool_emoji_id_cancel') {
    pendingEmojiId.delete(String(q.from?.id || ''));
    return sendRichMenu(chatId, menuAlatText(1), menuAlatKeyboard(1), c.BANNER_URL);
  }

  if (data === 'tool_regex') return sendDevRich(chatId,'🧪 <b>Regex Test</b>\nGunakan <code>/regex pattern | text</code>. Contoh: <code>/regex ^halo | halo dunia</code>.',{parse_mode:'HTML',reply_markup:toolKeyboardBack()});
  if (data === 'tool_convert') return sendDevRich(chatId,'🧮 <b>Unit Converter</b>\nContoh: <code>/convert 100 cm m</code> atau <code>/convert 32 f c</code>.',{parse_mode:'HTML',reply_markup:toolKeyboardBack()});
  if (data === 'tool_percent') return sendDevRich(chatId,'📊 <b>Percentage</b>\nContoh: <code>/percent 15 200</code>.',{parse_mode:'HTML',reply_markup:toolKeyboardBack()});
  if (data === 'tool_slug') return sendDevRich(chatId,'🧹 <b>SLUGIFY</b>\n\nUbah teks menjadi slug URL yang rapi.\nContoh: <code>/slug Halo Dunia! 2026</code>',{parse_mode:'HTML',reply_markup:menuAlatKeyboard(2)});
  if (data === 'tool_reverse') return sendDevRich(chatId,'🔁 <b>REVERSE TEXT</b>\n\nBalik urutan karakter teks.\nContoh: <code>/reverse Halo Dunia</code>',{parse_mode:'HTML',reply_markup:menuAlatKeyboard(2)});
  if (data === 'tool_textstats') return sendDevRich(chatId,'📐 <b>TEXT STATS</b>\n\nHitung karakter, kata, baris dan angka.\nContoh: <code>/textstats teks kamu</code>',{parse_mode:'HTML',reply_markup:menuAlatKeyboard(2)});

  if (data === 'tool_cleantext') return sendDevRich(chatId,'🗂️ <b>Text Cleaner</b>\nGunakan <code>/cleantext teks</code> untuk merapikan spasi berlebih.',{parse_mode:'HTML',reply_markup:toolKeyboardBack()});

  if (data === 'relax_quran') return sendDevRich(chatId, '📖 <b>Pilih Juz Al-Qur’an</b>\n\nTersedia lengkap Juz 1 sampai 30, dengan teks Arab dan terjemahan Indonesia.', {parse_mode:'HTML', reply_markup:quranJuzKeyboard()});
  if (data.startsWith('quran_juz_')) {
    const juz = Number(data.slice('quran_juz_'.length));
    if (!Number.isInteger(juz) || juz < 1 || juz > 30) return bot.answerCallbackQuery(q.id,{text:'Juz tidak valid.',show_alert:true}).catch(()=>{});
    try { return await sendQuranPage(chatId,juz,0); } catch(e) { return sendDevRich(chatId,`${E.cross} Gagal mengambil Juz ${juz}: <code>${htmlEscape(e.message)}</code>`,{parse_mode:'HTML'}); }
  }
  if (data.startsWith('quran_page_')) {
    const parts = data.split('_'); const juz=Number(parts[2]), page=Number(parts[3]);
    if (!Number.isInteger(juz) || juz<1 || juz>30 || !Number.isInteger(page) || page<0) return bot.answerCallbackQuery(q.id,{text:'Halaman tidak valid.',show_alert:true}).catch(()=>{});
    try { return await sendQuranPage(chatId,juz,page,msgId); } catch(e) { return bot.answerCallbackQuery(q.id,{text:`Quran gagal dimuat: ${e.message}`.slice(0,190),show_alert:true}).catch(()=>{}); }
  }
  if (data === 'relax_novel' || data === 'relax_comic' || data === 'relax_dracin' || data === 'relax_web') {
    const type = data === 'relax_novel' ? 'novel' : data === 'relax_comic' ? 'comic' : data === 'relax_dracin' ? 'dracin' : 'web';
    pendingRelaxSearch.set(String(q.from.id), {chatId, type, createdAt:Date.now()});
    setTimeout(()=>pendingRelaxSearch.delete(String(q.from.id)),2*60*1000);
    const prompt = type==='novel' ? 'Ketik judul atau nama penulis novel yang ingin dicari.' : type==='comic' ? 'Ketik judul atau nama penulis komik yang ingin dicari.' : type==='dracin' ? 'Ketik judul atau kata kunci dracin yang ingin dicari.' : 'Ketik kata kunci pencarian yang kamu inginkan.';
    return sendDevRich(chatId,`🔎 <b>Cari ${type==='web'?'apa saja':type}</b>\n\n${prompt}\n\n<i>Sesi pencarian berlaku 2 menit.</i>`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🕌 Batal',callback_data:'menu_relax'}]]}});
  }
  if (data === 'relax_fact') {
    const facts = [
      'Gurita memiliki tiga jantung.',
      'Madu dapat bertahan sangat lama jika disimpan dengan baik.',
      'Pisang secara botani termasuk buah beri.',
      'Jerapah memiliki tujuh ruas tulang leher, sama seperti manusia.',
      'Cahaya Matahari membutuhkan sekitar 8 menit untuk mencapai Bumi.'
    ];
    const fact = facts[Math.floor(Math.random() * facts.length)];
    return sendDevRich(chatId, `💡 <b>Fakta Acak</b>\\n\\n${fact}`, {parse_mode:'HTML', reply_markup:relaxingKeyboard()});
  }
  if (data === 'relax_quote') {
    const quotes = [
      'Pelan bukan berarti berhenti.',
      'Satu langkah kecil tetap sebuah kemajuan.',
      'Istirahat juga bagian dari perjalanan.',
      'Fokus pada hal yang bisa kamu lakukan hari ini.',
      'Tidak semua hal harus selesai sekaligus.'
    ];
    const quote = quotes[Math.floor(Math.random() * quotes.length)];
    return sendDevRich(chatId, `💬 <b>Quote Acak</b>\\n\\n“${quote}”`, {parse_mode:'HTML', reply_markup:relaxingKeyboard()});
  }
  if (data === 'relax_activity') {
    const activities = [
      'Rapikan meja selama 2 menit.',
      'Minum air lalu istirahat sebentar.',
      'Dengarkan satu lagu favorit.',
      'Tulis tiga hal yang ingin kamu selesaikan hari ini.',
      'Coba tebak angka 1–20 sebelum membuka /tebakangka.'
    ];
    const activity = activities[Math.floor(Math.random() * activities.length)];
    return sendDevRich(chatId, `🎯 <b>Aktivitas Acak</b>\\n\\n${activity}`, {parse_mode:'HTML', reply_markup:relaxingKeyboard()});
  }
  if (data === 'relax_riddle') {
    const riddles = [
      ['Aku punya banyak kunci tetapi tidak bisa membuka pintu. Apa aku?', 'Piano'],
      ['Aku berjalan tanpa kaki dan bisa mengalir. Apa aku?', 'Air'],
      ['Semakin diisi, semakin ringan. Apa aku?', 'Balon'],
      ['Aku punya wajah dan dua tangan tetapi tidak punya kaki. Apa aku?', 'Jam']
    ];
    const [question, answer] = riddles[Math.floor(Math.random() * riddles.length)];
    return sendDevRich(chatId, `🧠 <b>Tebak Santai</b>\\n\\n${question}\\n\\n<tg-spoiler>Jawaban: ${answer}</tg-spoiler>`, {parse_mode:'HTML', reply_markup:relaxingKeyboard()});
  }
  if (data === 'relax_joke') { const a=['Kenapa programmer suka kopi? Karena tanpa JavaScript, hidup terasa compile error.','Bug itu bukan hama, tapi fitur yang belum ditemukan.','Aku mau bikin aplikasi sempurna… lalu sadar deadline duluan.']; return sendDevRich(chatId,`😂 <b>Joke Ringan</b>\n\n${a[crypto.randomInt(a.length)]}`,{parse_mode:'HTML',reply_markup:relaxingKeyboard()}); }
  if (data === 'relax_mood') { const a=['😊 Produktif — lanjut pelan-pelan.','😌 Santai — istirahat sebentar juga boleh.','🔥 Semangat — kerjakan satu hal kecil dulu.','🥱 Lelah — minum air dan tarik napas.']; return sendDevRich(chatId,`🌤️ <b>Mood Check</b>\n\n${a[crypto.randomInt(a.length)]}`,{parse_mode:'HTML',reply_markup:relaxingKeyboard()}); }
  if (data === 'relax_wyr') { const a=['Mending punya internet cepat tapi baterai boros, atau baterai awet tapi internet lambat?','Mending bisa teleportasi atau bisa membaca pikiran?','Mending jago coding atau jago desain?']; return sendDevRich(chatId,`🤔 <b>Would You Rather</b>\n\n${a[crypto.randomInt(a.length)]}`,{parse_mode:'HTML',reply_markup:relaxingKeyboard()}); }
  if (data === 'relax_breathe') { return sendDevRich(chatId,'🫁 <b>Napas 1 Menit</b>\n\nTarik napas 4 detik → tahan 4 detik → buang 6 detik. Ulangi sekitar 5 kali.',{parse_mode:'HTML',reply_markup:relaxingKeyboard()}); }
  if (data === 'relax_pomodoro') { return sendDevRich(chatId,'🍅 <b>Pomodoro</b>\n\nKerja fokus 25 menit → istirahat 5 menit. Ulangi 4 sesi, lalu ambil istirahat lebih panjang.',{parse_mode:'HTML',reply_markup:relaxingKeyboard()}); }

  if (data === 'relax_counter') {
    const key = String(q.from.id);
    const count = relaxCounters.get(key) || 0;
    return sendDevRich(chatId, `🔢 <b>Penghitung</b>\\n\\nHitungan saat ini: <b>${count}</b>`, {
      parse_mode:'HTML',
      reply_markup:{inline_keyboard:[
        [{text:'+1',callback_data:'relax_count_1'},{text:'+10',callback_data:'relax_count_10'},{text:'Reset',callback_data:'relax_count_reset'}],
        [{text:'🕌 Relaxing Time',callback_data:'menu_relax'}]
      ]}
    });
  }
  if (data === 'relax_count_1' || data === 'relax_count_10' || data === 'relax_count_reset') {
    const key = String(q.from.id);
    let count = relaxCounters.get(key) || 0;
    if (data === 'relax_count_reset') count = 0;
    else count += data === 'relax_count_10' ? 10 : 1;
    relaxCounters.set(key, count);
    return bot.editMessageText(`🔢 <b>Penghitung</b>\\n\\nHitungan saat ini: <b>${count}</b>`, {
      chat_id:chatId,message_id:msgId,parse_mode:'HTML',
      reply_markup:{inline_keyboard:[
        [{text:'+1',callback_data:'relax_count_1'},{text:'+10',callback_data:'relax_count_10'},{text:'Reset',callback_data:'relax_count_reset'}],
        [{text:'🕌 Relaxing Time',callback_data:'menu_relax'}]
      ]}
    }).catch(() => safeRichSendMessage( chatId, `🔢 Hitungan saat ini: <b>${count}</b>`, {parse_mode:'HTML', reply_markup:relaxingKeyboard()}));
  }
  if (data === 'relax_note') {
    pendingRelaxNote.set(String(q.from.id), {chatId, createdAt:Date.now()});
    setTimeout(()=>pendingRelaxNote.delete(String(q.from.id)), 2*60*1000);
    return sendDevRich(chatId, '📝 <b>Catatan Singkat</b>\\n\\nKirim teks catatanmu pada pesan berikutnya. Catatan hanya diproses sementara dan tidak disimpan ke database.', {
      parse_mode:'HTML', reply_markup:{inline_keyboard:[[{text:'🕌 Batal',callback_data:'menu_relax'}]]}
    });
  }

  if (data === 'tool_qc') return sendDevRich(chatId,
    `<blockquote><b>QC STICKER</b></blockquote>\n\n` +
    `Ketik <code>/qc ALL TRX NO REFF</code> untuk membuat stiker QC.\n` +
    `Atau ketik <code>/qc</code> lalu kirim teks pada pesan berikutnya.\n\n` +
    `<i>Output diberi label QC • SIMULASI agar tidak dianggap sebagai bukti transaksi.</i>`,
    {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'IQC iPhone',callback_data:'tool_iqc'}],[{text:'Kembali',callback_data:'back_menu',style:'danger'}]]}});

  if (data === 'tool_iqc') return sendDevRich(chatId,
    `📱 <b>IQC iPhone</b>\n\n` +
    `Mode cepat: <code>/iqc woi</code>\n` +
    `Mode lengkap: <code>/iqc woi,Axis,20:00,50</code>\n\n` +
    `Atau gunakan <code>/iqcv2 Halo bro</code>.`,
    {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🖼️ QC Sticker',callback_data:'tool_qc'}],[{text:'✿ Kembali Ke Menu ✿',callback_data:'back_menu',style:'danger'}]]}});
  if (data === 'tool_domain') {
    pendingDomainRename.set(String(q.from.id), { chatId, step:'zip', createdAt:Date.now(), mode:'domain' });
    setTimeout(()=>pendingDomainRename.delete(String(q.from.id)),10*60*1000);
    return safeRichSendMessage(chatId,'🌐 <b>GANTI DOMAIN</b>\n\n<b>Langkah 1/3</b>\nKirim <b>file ZIP project</b> yang ingin diperiksa.\n\nBot akan memindai file teks project dan menampilkan domain yang ditemukan. Setelah itu kamu cukup mengirim <b>domain lama</b> secara manual.',{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'✖️ Batal',callback_data:'domain_cancel'}],[{text:'🔌 Ganti Port Panel',callback_data:'domain_port_menu'}],[{text:'🧰 Menu Tools',callback_data:'menu_alat'}]]}});
  }
  if (data === 'tool_tourl') {
    pendingTourl.set(String(q.from.id), { chatId, step: 'photo', createdAt: Date.now() });
    setTimeout(() => pendingTourl.delete(String(q.from.id)), 5 * 60 * 1000);
    return safeRichSendMessage( chatId, '🖼️ <b>TOURL FOTO</b>\n\nKirim foto, lalu pilih provider URL. <b>Auto</b> akan mencoba provider lain otomatis jika server provider pilihan sedang down.', { parse_mode:'HTML', reply_markup: backKeyboard('menu_alat') });
  }
  if (data === 'tool_deploy') {
    pendingDeploy.set(String(q.from.id), { chatId, step: 'zip', createdAt: Date.now() });
    setTimeout(() => pendingDeploy.delete(String(q.from.id)), 10 * 60 * 1000);
    return safeRichSendMessage( chatId, '🚀 <b>DEPLOY WEBSITE</b>\n\nKirim <b>ZIP website</b>. Bot akan men-deploy ke Vercel jika <code>VERCEL_TOKEN</code> sudah diisi di environment panel.', { parse_mode:'HTML', reply_markup: backKeyboard('menu_alat') });
  }
  if (data === 'tool_wachannel') {
    pendingWaChannel.set(String(q.from.id), { chatId, step: 'input', createdAt: Date.now() });
    setTimeout(() => pendingWaChannel.delete(String(q.from.id)), 3 * 60 * 1000);
    return safeRichSendMessage( chatId, '📢 <b>CEK ID CHANNEL / SALURAN WHATSAPP</b>\n\nKirim link Channel WhatsApp, contoh:\n<code>https://whatsapp.com/channel/xxxxxxxx</code>\n\n✨ Tidak wajib memasang/menautkan sesi WhatsApp. Bot mencoba metadata publik terlebih dahulu dan hanya memakai sesi yang tersedia sebagai jalur tambahan.', { parse_mode:'HTML', reply_markup: backKeyboard('menu_alat') });
  }
  if (data === 'tool_prayer') return safeRichSendMessage( chatId,'🕌 <b>Waktu Sholat</b>\n\nKetik nama kota, contoh: <code>/sholat Jakarta</code>\nJika dikosongkan, bot memakai Jakarta.',{parse_mode:'HTML',reply_markup:toolKeyboardBack()});
  if (data === 'tool_weather') {
    pendingWeather.set(String(q.from.id),{chatId,mode:'city',createdAt:Date.now()});
    setTimeout(()=>pendingWeather.delete(String(q.from.id)),2*60*1000);
    return safeRichSendMessage( chatId,'🌦️ <b>Cek Cuaca Hari Ini</b>\n\nKetik nama kota, contoh <code>Jakarta</code>.\nAtau gunakan tombol <b>📍 Kirim Lokasi</b> agar lebih akurat.',{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'📍 Kirim Lokasi',request_location:true}],[{text:'↩️ Menu Alat',callback_data:'menu_alat'}]]}});
  }
  if (data === 'tool_worldclock') return safeRichSendMessage( chatId,'🌍 <b>Jam Dunia</b>\n\nContoh: <code>/jamdunia Tokyo</code>\nKota yang didukung umum: Jakarta, Makassar, Jayapura, Singapore, Kuala Lumpur, Tokyo, Seoul, Beijing, Dubai, London, Paris, Berlin, Moscow, New York, Los Angeles, Chicago, Sydney.',{parse_mode:'HTML',reply_markup:toolKeyboardBack()});
  if (data === 'menu_ai') {
    await safeDelete(bot, chatId, msgId);
    return sendMenuPhoto(bot, chatId, c.BANNER_URL, { caption: menuAIText(q.from.id, chatId), parse_mode: 'HTML', reply_markup: menuAIKeyboard(chatId) });
  }
  if (data === 'js_encrypt_menu') {
    return safeRichSendMessage( chatId,
      `<blockquote>🔐 <b>JS ENCRYPTION CENTER</b></blockquote>\n` +
      `Pilih level enkripsi yang ingin digunakan. Setelah memilih, kirim file <code>.js</code>.\n\n` +
      `• Basic — ringan\n• Medium — sedang\n• Arab — alternatif\n• Invisible — karakter zero-width\n• Hard — paling kompleks dari preset bawaan`,
      {parse_mode:'HTML', reply_markup:{inline_keyboard:[
        [{text:'Basic',callback_data:'enc_pick_encbasic'},{text:'Medium',callback_data:'enc_pick_encmedium'}],
        [{text:'Arab',callback_data:'enc_pick_encarab'},{text:'Invisible',callback_data:'enc_pick_encinvisble'}],
        [{text:'Hard',callback_data:'enc_pick_enchard'},{text:'Hard+',callback_data:'enc_pick_encultra'}],
        [{text:'🛠️ JS Obfuscator',callback_data:'js_obf_menu'}],
        [{text:'↩️ Menu Alat',callback_data:'menu_alat'}]
      ]}});
  }
  if (data === 'js_obf_menu') {
    return safeRichSendMessage( chatId,
      `<blockquote>🛠️ <b>JS OBFUSCATOR</b></blockquote>\n` +
      `Preset aman untuk merapikan/menyamarkan kode tanpa dependency tambahan.\n\n` +
      `Pilih mode lalu kirim file <code>.js</code>.`,
      {parse_mode:'HTML', reply_markup:{inline_keyboard:[
        [{text:'Clean Obf',callback_data:'enc_pick_obfclean'},{text:'String Escape',callback_data:'enc_pick_obfstring'}],
        [{text:'Compact',callback_data:'enc_pick_obfcompact'},{text:'Char Escape',callback_data:'enc_pick_obfhex'}],
        [{text:'Obf Pro',callback_data:'enc_pick_obfpro'}],
        [{text:'🔐 JS Encryption',callback_data:'js_encrypt_menu'}],
        [{text:'↩️ Menu Alat',callback_data:'menu_alat'}]
      ]}});
  }
  if (data.startsWith('enc_pick_')) {
    const level = data.slice('enc_pick_'.length);
    if (!encConfigs[level] && !obfConfigs[level]) return bot.answerCallbackQuery(q.id,{text:'Mode tidak tersedia.',show_alert:true}).catch(()=>{});
    const cfg = encConfigs[level] || obfConfigs[level];
    const key = `${chatId}:${q.from.id}`;
    pendingEnc.set(key,{level,createdAt:Date.now()});
    setTimeout(()=>pendingEnc.delete(key),5*60*1000);
    return safeRichSendMessage( chatId,
      `${encConfigs[level] ? '🔐' : '🛠️'} <b>${htmlEscape(cfg.label)}</b>\n\n` +
      `${htmlEscape(cfg.desc)}\n\nKirim file <code>.js</code> pada pesan berikutnya.`,
      {parse_mode:'HTML',reply_markup:{inline_keyboard:[
        [{text:'↩️ Kembali',callback_data:encConfigs[level]?'js_encrypt_menu':'js_obf_menu'}]
      ]}});
  }

  if (data === 'fun_page_1') return editMenuPage(bot, q, menuFunText(1), menuFunKeyboard(1));
  if (data === 'fun_page_2') return editMenuPage(bot, q, menuFunText(2), menuFunKeyboard(2));
  if (data === 'fun_page_3') return editMenuPage(bot, q, menuFunText(3), menuFunKeyboard(3));
  if (data === 'alat_page_1') return editMenuPage(bot, q, menuAlatText(1), menuAlatKeyboard(1));
  if (data === 'alat_page_2') return editMenuPage(bot, q, menuAlatText(2), menuAlatKeyboard(2));
  if (data === 'fun_help') return safeRichSendMessage( chatId,'<blockquote>🎮 <b>PANDUAN GAME</b></blockquote>\\n<blockquote>Game single player langsung dimainkan. Game multiplayer dijalankan di grup: buat lobby, lalu pemain lain bergabung. Setiap sesi dipisahkan berdasarkan chat agar aman dari bentrok.</blockquote>',{parse_mode:'HTML',reply_markup:menuFunKeyboard()});
  if (data === 'fun_multi') return safeRichSendMessage( chatId,'<b>MULTIPLAYER</b>\\n\\n/tictac\\n/catur\\n/party\\n/wordparty\\n/quizparty\\n/duel\\n\\nPemain lain dapat bergabung dari tombol atau perintah join yang tersedia.',{parse_mode:'HTML',reply_markup:menuFunKeyboard()});
  if (data === 'fun_single') return safeRichSendMessage( chatId,'<b>SINGLE PLAYER</b>\\n\\n/memory\\n/scramble\\n/higherlower\\n/sequence\\n/target24\\n/reaction\\n/trivia\\n/mathrush', {parse_mode:'HTML',reply_markup:menuFunKeyboard(2)});
  if (data === 'fun_memory') return safeRichSendMessage( chatId,'🧩 <b>Memory</b>\\nCari pasangan angka. Ketik <code>/memory</code>.', {parse_mode:'HTML',reply_markup:menuFunKeyboard(2)});
  if (data === 'fun_scramble') return safeRichSendMessage( chatId,'🔤 <b>Scramble</b>\\nSusun kembali kata acak. Ketik <code>/scramble</code>.', {parse_mode:'HTML',reply_markup:menuFunKeyboard(2)});
  if (data === 'fun_higher') return safeRichSendMessage( chatId,'📈 <b>Higher / Lower</b>\\nTebak apakah angka berikut lebih tinggi atau lebih rendah. Ketik <code>/higherlower</code>.', {parse_mode:'HTML',reply_markup:menuFunKeyboard(2)});
  if (data === 'fun_reaction') return safeRichSendMessage( chatId,'⚡ <b>Reaction</b>\\nTes kecepatan reaksi dengan tombol. Ketik <code>/reaction</code>.', {parse_mode:'HTML',reply_markup:menuFunKeyboard(2)});
  if (data === 'fun_duel') return safeRichSendMessage( chatId,'⚔️ <b>Duel</b>\\nBuat duel 2 pemain dengan <code>/duel</code>.', {parse_mode:'HTML',reply_markup:menuFunKeyboard(2)});
  if (data === 'fun_trivia') return safeRichSendMessage( chatId,'🧠 <b>Trivia</b>\\nQuiz cepat dengan skor. Ketik <code>/trivia</code>.', {parse_mode:'HTML',reply_markup:menuFunKeyboard(2)});
  if (data === 'fun_target24') return safeRichSendMessage( chatId,'🎯 <b>Target 24</b>\\nGabungkan angka menjadi 24. Ketik <code>/target24</code>.', {parse_mode:'HTML',reply_markup:menuFunKeyboard(2)});
  if (data === 'fun_sequence') return safeRichSendMessage( chatId,'🔢 <b>Sequence</b>\\nTebak angka berikutnya. Ketik <code>/sequence</code>.', {parse_mode:'HTML',reply_markup:menuFunKeyboard(2)});
  if (data === 'fun_mathrush') return safeRichSendMessage( chatId,'🧮 <b>Math Rush</b>\\nJawab soal matematika secepat mungkin. Ketik <code>/mathrush</code>.', {parse_mode:'HTML',reply_markup:menuFunKeyboard(2)});
  if (data === 'tool_randomnum') return safeRichSendMessage( chatId,'🔢 Contoh: <code>/randomnum 1 100</code>',{parse_mode:'HTML',reply_markup:menuAlatKeyboard(2)});
  if (data === 'tool_hash') return safeRichSendMessage( chatId,'🔐 Contoh: <code>/hash sha256 halo dunia</code>',{parse_mode:'HTML',reply_markup:menuAlatKeyboard(2)});
  if (data === 'tool_urlencode') return safeRichSendMessage( chatId,'🔗 Contoh: <code>/urlencode halo dunia</code>',{parse_mode:'HTML',reply_markup:menuAlatKeyboard(2)});
  if (data === 'tool_urldecode') return safeRichSendMessage( chatId,'↩️ Contoh: <code>/urldecode halo%20dunia</code>',{parse_mode:'HTML',reply_markup:menuAlatKeyboard(2)});
  if (data === 'tool_timestamp') return safeRichSendMessage( chatId,'🕘 Contoh: <code>/timestamp</code>',{parse_mode:'HTML',reply_markup:menuAlatKeyboard(2)});
  if (data === 'tool_escape') return safeRichSendMessage( chatId,'🧹 Contoh: <code>/escapehtml &lt;b&gt;halo&lt;/b&gt;</code>',{parse_mode:'HTML',reply_markup:menuAlatKeyboard(2)});
  if (data === 'tool_zipinfo') return safeRichSendMessage( chatId,'📦 <b>ZIP Info</b>\\nReply file ZIP dengan <code>/zipinfo</code>.', {parse_mode:'HTML',reply_markup:menuAlatKeyboard(2)});
  if (data === 'tool_sysinfo') return safeRichSendMessage( chatId,'📋 <b>System Info</b>\\nKetik <code>/sysinfo</code>.', {parse_mode:'HTML',reply_markup:menuAlatKeyboard(2)});

  if (data.startsWith('reaction_')) {
    const parts=data.split('_'), key=parts[1], token=parts[2], s=reactionSessions.get(key);
    if(!s || s.token!==token) return bot.answerCallbackQuery(q.id,{text:'Terlambat atau game sudah selesai.',show_alert:true}).catch(()=>{});
    reactionSessions.delete(key);
    const ms=Date.now()-s.createdAt;
    return bot.editMessageText(`⚡ <b>Reaction</b>\\nWaktu reaksi: <code>${ms} ms</code>`,{chat_id:chatId,message_id:msgId,parse_mode:'HTML'}).catch(()=>{});
  }
  if(data.startsWith('duel_join_')){
    const cid=data.replace('duel_join_',''), s=duelSessions.get(cid);
    if(!s) return bot.answerCallbackQuery(q.id,{text:'Duel sudah selesai.',show_alert:true}).catch(()=>{});
    if(q.from.id===s.host.id) return bot.answerCallbackQuery(q.id,{text:'Host tidak bisa join sendiri.',show_alert:true}).catch(()=>{});
    const winner=Math.random()<0.5?s.host:{id:q.from.id,name:playerName(q.from)};
    duelSessions.delete(cid);
    return bot.editMessageText(`⚔️ <b>DUEL SELESAI</b>\\n\\n${htmlEscape(s.host.name)} vs ${htmlEscape(playerName(q.from))}\\n\\n🏆 Pemenang: <b>${htmlEscape(winner.name)}</b>`,{chat_id:chatId,message_id:msgId,parse_mode:'HTML'}).catch(()=>{});
  }

  if (data === 'fun_dice') return safeRichSendMessage( chatId,`🎲 <b>Dadu</b>\nHasil: <b>${crypto.randomInt(1,7)}</b>`,{parse_mode:'HTML',reply_markup:menuFunKeyboard()});
  if (data === 'fun_coin') return safeRichSendMessage( chatId,`🪙 <b>Koin</b>\nHasil: <b>${crypto.randomInt(2)?'HEADS':'TAILS'}</b>`,{parse_mode:'HTML',reply_markup:menuFunKeyboard()});
  if (data === 'fun_8ball') return safeRichSendMessage( chatId,'🎱 Ketik <code>/8ball pertanyaanmu</code>.',{parse_mode:'HTML',reply_markup:menuFunKeyboard()});
  if (data === 'fun_rps') return safeRichSendMessage( chatId,'✊ Ketik <code>/rps batu</code>, <code>/rps gunting</code>, atau <code>/rps kertas</code>.',{parse_mode:'HTML',reply_markup:menuFunKeyboard()});
  if (data === 'fun_quiz') { const qq=QUIZ_BANK[crypto.randomInt(QUIZ_BANK.length)]; quizSessions.set(chatId,{...qq,startedAt:Date.now()}); return safeRichSendMessage( chatId,`🧠 <b>Quiz</b>\n${htmlEscape(qq.q)}\n\n1️⃣ ${htmlEscape(qq.o[0])}\n2️⃣ ${htmlEscape(qq.o[1])}\n3️⃣ ${htmlEscape(qq.o[2])}\n4️⃣ ${htmlEscape(qq.o[3])}\n\nJawab 1–4.`,{parse_mode:'HTML'}); }
  if (data === 'fun_math') return safeRichSendMessage( chatId,'➗ Mulai dengan <code>/matematika</code>.',{parse_mode:'HTML',reply_markup:menuFunKeyboard()});
  if (data === 'fun_random') return safeRichSendMessage( chatId,'🔀 Contoh: <code>/acak apel,jeruk,mangga</code>',{parse_mode:'HTML',reply_markup:menuFunKeyboard()});
  if (data === 'fun_number') return safeRichSendMessage( chatId,'🎯 Ketik <code>/tebakangka</code> untuk mulai.',{parse_mode:'HTML',reply_markup:menuFunKeyboard()});
  if (data === 'fun_word') return safeRichSendMessage( chatId,'🔤 Ketik <code>/tebakkata</code> untuk mulai.',{parse_mode:'HTML',reply_markup:menuFunKeyboard()});
  if (/^mp_(math|emoji|choice)_new$/.test(data)) {
    const type=data.split('_')[1];
    const s=mpNew(chatId,q.from,type);
    if(!s) return bot.answerCallbackQuery(q.id,{text:'Masih ada game multiplayer aktif di chat ini.',show_alert:true}).catch(()=>{});
    return safeRichSendMessage(chatId,`👥 <b>${type==='math'?'MATH BATTLE':type==='emoji'?'EMOJI BATTLE':'QUICK CHOICE'}</b>\n\nHost: <b>${mpName(q.from)}</b>\nPemain lain tekan <b>Join</b>. Maksimal 5 pemain.\n\nHost tekan <b>Mulai</b> setelah minimal 2 pemain.`,{parse_mode:'HTML',reply_markup:mpLobbyKeyboard(type,chatId)});
  }
  if (data === 'mp_rps_new') {
    const s=mpNew(chatId,q.from,'rps');
    if(!s) return bot.answerCallbackQuery(q.id,{text:'Masih ada game multiplayer aktif di chat ini.',show_alert:true}).catch(()=>{});
    return safeRichSendMessage(chatId,`✊ <b>RPS BATTLE</b>\n\nHost: <b>${mpName(q.from)}</b>\nPemain lain tekan Join. Maksimal 5 pemain.\n\nHost mulai setelah minimal 2 pemain.`,{parse_mode:'HTML',reply_markup:mpLobbyKeyboard('rps',chatId)});
  }
  if (/^mp_(math|emoji|choice|rps)_join_-?\d+$/.test(data)) {
    const parts=data.split('_'), type=parts[1], cid=parts.slice(3).join('_'); const s=mpGameSessions.get(Number(cid));
    if(!s || s.type!==type) return bot.answerCallbackQuery(q.id,{text:'Lobby sudah tidak tersedia.',show_alert:true}).catch(()=>{});
    if(s.players.some(p=>p.id===q.from.id)) return bot.answerCallbackQuery(q.id,{text:'Kamu sudah bergabung.',show_alert:true}).catch(()=>{});
    if(s.players.length>=s.max) return bot.answerCallbackQuery(q.id,{text:'Lobby penuh.',show_alert:true}).catch(()=>{});
    s.players.push({id:q.from.id,name:mpName(q.from)});
    return safeRichSendMessage(Number(cid),`✅ <b>${mpName(q.from)}</b> bergabung. <b>${s.players.length}/${s.max}</b> pemain.`,{parse_mode:'HTML',reply_markup:mpLobbyKeyboard(type,Number(cid))});
  }
  if (/^mp_(math|emoji|choice|rps)_start_-?\d+$/.test(data)) {
    const parts=data.split('_'), type=parts[1], cid=parts.slice(3).join('_'); const s=mpGameSessions.get(Number(cid));
    if(!s) return bot.answerCallbackQuery(q.id,{text:'Lobby sudah tidak tersedia.',show_alert:true}).catch(()=>{});
    if(s.host!==q.from.id) return bot.answerCallbackQuery(q.id,{text:'Hanya host yang bisa memulai.',show_alert:true}).catch(()=>{});
    if(s.players.length<2) return bot.answerCallbackQuery(q.id,{text:'Minimal 2 pemain.',show_alert:true}).catch(()=>{});
    if(type==='rps'){ s.started=true; s.answers=new Map(); return safeRichSendMessage(Number(cid),'✊ <b>RPS BATTLE DIMULAI!</b>\n\nSemua pemain pilih satu:',{parse_mode:'HTML',reply_markup:{inline_keyboard:[[
      {text:'🪨 Batu',callback_data:`mp_rps_pick_${cid}_rock`},{text:'✂️ Gunting',callback_data:`mp_rps_pick_${cid}_scissors`},{text:'📄 Kertas',callback_data:`mp_rps_pick_${cid}_paper`}
    ]]}}); }
    Object.assign(s,mpQuestion(type),{started:true,answers:new Map()});
    s.players.forEach(p=>s.scores[p.id]=s.scores[p.id]||0);
    return safeRichSendMessage(Number(cid),`🎮 <b>${type==='math'?'MATH BATTLE':type==='emoji'?'EMOJI BATTLE':'QUICK CHOICE'}</b>\n\n${htmlEscape(s.q)}\n\nJawab secepatnya!`,{parse_mode:'HTML',reply_markup:mpAnswerKeyboard(type,Number(cid),s.options)});
  }
  if (/^mp_(math|emoji|choice)_ans_-?\d+_\d+$/.test(data)) {
    const parts=data.split('_'), type=parts[1], cid=Number(parts[3]), idx=Number(parts[4]), s=mpGameSessions.get(cid);
    if(!s || s.type!==type || !s.started) return bot.answerCallbackQuery(q.id,{text:'Game sudah selesai.',show_alert:true}).catch(()=>{});
    if(!s.players.some(p=>p.id===q.from.id)) return bot.answerCallbackQuery(q.id,{text:'Kamu belum join game.',show_alert:true}).catch(()=>{});
    if(s.answers.has(q.from.id)) return bot.answerCallbackQuery(q.id,{text:'Jawabanmu sudah tercatat.',show_alert:true}).catch(()=>{});
    s.answers.set(q.from.id,idx);
    if(idx===s.answer) s.scores[q.from.id]=(s.scores[q.from.id]||0)+3;
    if(s.answers.size>=s.players.length){ const winners=s.players.filter(p=>s.answers.get(p.id)===s.answer); const winText=winners.length?winners.map(p=>p.name).join(', '):'Tidak ada'; const score=mpScoreText(s); mpGameSessions.delete(cid); return safeRichSendMessage(cid,`🏆 <b>RONDE SELESAI!</b>\n\nJawaban benar: <b>${String.fromCharCode(65+s.answer)}. ${s.options[s.answer]}</b>\nPemenang ronde: <b>${winText}</b>\n\n${score}`,{parse_mode:'HTML',reply_markup:menuFunKeyboard(3)}); }
    return bot.answerCallbackQuery(q.id,{text:`Jawaban tercatat. ${s.answers.size}/${s.players.length}`,show_alert:false}).catch(()=>{});
  }
  if (/^mp_rps_pick_-?\d+_(rock|scissors|paper)$/.test(data)) {
    const parts=data.split('_'), cid=Number(parts[2]), pick=parts[3], s=mpGameSessions.get(cid);
    if(!s || s.type!=='rps' || !s.started) return bot.answerCallbackQuery(q.id,{text:'Game sudah selesai.',show_alert:true}).catch(()=>{});
    if(!s.players.some(p=>p.id===q.from.id)) return bot.answerCallbackQuery(q.id,{text:'Kamu belum join game.',show_alert:true}).catch(()=>{});
    if(s.answers.has(q.from.id)) return bot.answerCallbackQuery(q.id,{text:'Pilihanmu sudah tercatat.',show_alert:true}).catch(()=>{});
    s.answers.set(q.from.id,pick);
    if(s.answers.size<s.players.length) return bot.answerCallbackQuery(q.id,{text:`Pilihan tercatat. ${s.answers.size}/${s.players.length}`,show_alert:false}).catch(()=>{});
    const counts={rock:0,scissors:0,paper:0}; for(const v of s.answers.values()) counts[v]++;
    const present=Object.keys(counts).filter(k=>counts[k]>0); let winning=null; if(present.length===1) winning=present[0]; else if(present.length===2){ const beats={rock:'scissors',scissors:'paper',paper:'rock'}; winning=present.find(a=>beats[a]===present.find(b=>b!==a)); }
    const winners=s.players.filter(p=>s.answers.get(p.id)===winning); winners.forEach(p=>s.scores[p.id]=(s.scores[p.id]||0)+3); const score=mpScoreText(s); mpGameSessions.delete(cid);
    return safeRichSendMessage(cid,`✊ <b>RPS SELESAI!</b>\n\n${winning?'Pilihan pemenang: '+winning:'Hasil: Seri'}\n🏆 Pemenang: <b>${winners.length?winners.map(p=>p.name).join(', '):'Semua seri'}</b>\n\n${score}`,{parse_mode:'HTML',reply_markup:menuFunKeyboard(3)});
  }
  if (/^mp_(math|emoji|choice|rps)_stop_-?\d+$/.test(data)) {
    const parts=data.split('_'), cid=Number(parts.slice(3).join('_')), s=mpGameSessions.get(cid);
    if(!s) return bot.answerCallbackQuery(q.id,{text:'Game sudah tidak aktif.',show_alert:true}).catch(()=>{});
    if(s.host!==q.from.id) return bot.answerCallbackQuery(q.id,{text:'Hanya host yang bisa membatalkan.',show_alert:true}).catch(()=>{});
    mpGameSessions.delete(cid); return safeRichSendMessage(cid,'🛑 <b>Game multiplayer dibatalkan.</b>',{parse_mode:'HTML',reply_markup:menuFunKeyboard(3)});
  }

  if (data === 'fun_tictac') return safeRichSendMessage( chatId,'❌⭕ <b>TicTacToe</b>\n\nMulai dengan <code>/tictac</code>, lalu pemain kedua tekan <b>Join</b>.',{parse_mode:'HTML',reply_markup:menuFunKeyboard()});
  if (data === 'fun_party') return safeRichSendMessage( chatId,'👥 <b>Party 2–5 Orang</b>\n\nKetik <code>/party</code> untuk membuat lobby.',{parse_mode:'HTML',reply_markup:menuFunKeyboard()});
  if (data === 'fun_wordparty') return safeRichSendMessage( chatId,'🔤 <b>Kata Party 2–5</b>\n\nKetik <code>/wordparty</code> lalu pemain lain <code>/joinparty</code>.',{parse_mode:'HTML',reply_markup:menuFunKeyboard()});
  if (data === 'fun_quizparty') return safeRichSendMessage( chatId,'🧠 <b>Quiz Party 2–5</b>\n\nKetik <code>/quizparty</code> lalu pemain lain <code>/joinquizparty</code>.',{parse_mode:'HTML',reply_markup:menuFunKeyboard()});
  if (data === 'fun_scores') return safeRichSendMessage( chatId, getPartyScoreText(chatId), {parse_mode:'HTML', reply_markup:menuFunKeyboard()});
  if (data.startsWith('ttt_join_')) {
    const cid=Number(data.slice('ttt_join_'.length)); const s=tttSessions.get(cid);
    if(!s) return bot.answerCallbackQuery(q.id,{text:'Game sudah selesai.',show_alert:true}).catch(()=>{});
    if(s.players.some(p=>p.id===q.from.id)) return bot.answerCallbackQuery(q.id,{text:'Kamu sudah masuk.',show_alert:true}).catch(()=>{});
    if(s.players.length>=2) return bot.answerCallbackQuery(q.id,{text:'Pemain sudah lengkap.',show_alert:true}).catch(()=>{});
    s.players.push({id:q.from.id,name:playerName(q.from),mark:'O'});
    await bot.editMessageText(`❌⭕ <b>TicTacToe</b>\n\nX: ${s.players[0].name}\nO: ${s.players[1].name}\n\nGiliran: <b>${s.players[0].name}</b>\n\n<code>${tttBoard(s)}</code>`,{chat_id:cid,message_id:msgId,parse_mode:'HTML',reply_markup:tttMarkup(cid)}).catch(()=>{});
    return;
  }
  if (data.startsWith('ttt_move_')) {
    const rest=data.slice('ttt_move_'.length).split('_'); const cid=Number(rest[0]), idx=Number(rest[1]); const s=tttSessions.get(cid);
    if(!s || s.players.length<2) return bot.answerCallbackQuery(q.id,{text:'Game belum lengkap.',show_alert:true}).catch(()=>{});
    const p=s.players[s.turn]; if(p.id!==q.from.id) return bot.answerCallbackQuery(q.id,{text:`Giliran ${p.name}`,show_alert:true}).catch(()=>{});
    if(s.board[idx]) return bot.answerCallbackQuery(q.id,{text:'Kotak sudah terisi.',show_alert:true}).catch(()=>{});
    s.board[idx]=p.mark; const win=tttWinner(s.board);
    if(win){ const text=win==='draw'?`❌⭕ <b>Seri!</b>\n\n<code>${tttBoard(s)}</code>`:`🏆 <b>${p.name} menang!</b> (${p.mark})\n\n<code>${tttBoard(s)}</code>`; tttSessions.delete(cid); return bot.editMessageText(text,{chat_id:cid,message_id:msgId,parse_mode:'HTML'}).catch(()=>{}); }
    s.turn=(s.turn+1)%2; return bot.editMessageText(`❌⭕ <b>TicTacToe</b>\n\nX: ${s.players[0].name}\nO: ${s.players[1].name}\n\nGiliran: <b>${s.players[s.turn].name}</b> (${s.players[s.turn].mark})\n\n<code>${tttBoard(s)}</code>`,{chat_id:cid,message_id:msgId,parse_mode:'HTML',reply_markup:tttMarkup(cid)}).catch(()=>{});
  }
  if (data.startsWith('ttt_stop_')) { const cid=Number(data.slice('ttt_stop_'.length)); const s=tttSessions.get(cid); if(!s) return bot.answerCallbackQuery(q.id,{text:'Game sudah selesai.',show_alert:true}).catch(()=>{}); if(s.players?.[0]?.id!==q.from.id) return bot.answerCallbackQuery(q.id,{text:'Hanya pembuat game yang bisa menghentikan.',show_alert:true}).catch(()=>{}); tttSessions.delete(cid); return bot.editMessageText('🛑 TicTacToe dihentikan.',{chat_id:cid,message_id:msgId}).catch(()=>{}); }
  if (data === 'group_security_status') {
    if (!chatId || !['group','supergroup'].includes(q.message?.chat?.type)) return bot.answerCallbackQuery(q.id,{text:'Buka menu ini dari grup.',show_alert:true}).catch(()=>{});
    const gs=getGroupSettings(chatId); const st=v=>v?'🟢 Aktif':'🔴 Nonaktif';
    return safeRichSendMessage( chatId,`<b>🛡️ STATUS KEAMANAN GRUP</b>\n\nAnti Link: ${st(gs.antilink)}\nAnti Forward: ${st(gs.antiforward)}\nAnti Flood: ${st(gs.antiflood)}\nAnti Spam: ${st(gs.antispam)}\nAnti Promosi: ${st(gs.antipromosi)}\nAnti Porno: ${st(gs.antiporno)}\nAnti Toxic: ${st(gs.antitoxic)}\nAnti Sticker: ${st(gs.antisticker)}\nAnti Drugs: ${st(gs.antidrugs)}\nAnti Foto: ${st(gs.antifoto)}\nAnti Video: ${st(gs.antivideo)}\nAnti Bot: ${st(gs.antibot)}\nAntiAdmin: ${gs.antiadmin ? '🟢 Aktif — admin dikecualikan' : '🔴 Nonaktif — admin ikut diperiksa'}\nLock Media: ${st(gs.lockmedia)}\nSlowmode: ${gs.slowmode ? `🟢 ${gs.slowmode}s` : '🔴 Nonaktif'}\nForce Subscribe: ${st(gs.forceSubscribe?.enabled)}\nWelcome: ${st(gs.welcome?.enabled)}\nGoodbye: ${st(gs.goodbye?.enabled)}\n\n<blockquote>Gunakan /groupinfo untuk detail.</blockquote>`,{parse_mode:'HTML',reply_markup:menuGroupKeyboard(chatId)});
  }
  if (data === 'fun_hangman') {
    const words=[['TELEGRAM','Platform chat'],['JAVASCRIPT','Bahasa pemrograman'],['KAMERA','Alat foto'],['KOMPUTER','Perangkat kerja'],['SEKOLAH','Tempat belajar']]; const pick=words[crypto.randomInt(words.length)];
    if(!global.__hangmanSessions) global.__hangmanSessions=new Map();
    global.__hangmanSessions.set(String(chatId),{word:pick[0],hint:pick[1],guessed:new Set(),startedAt:Date.now()});
    setTimeout(()=>{ const h=global.__hangmanSessions?.get(String(chatId)); if(h && Date.now()-h.startedAt>=10*60*1000) global.__hangmanSessions.delete(String(chatId)); },10*60*1000);
    return safeRichSendMessage( chatId,`🧩 <b>HANGMAN DIMULAI</b>\n\nHint: <i>${htmlEscape(pick[1])}</i>\nKata: <code>${pick[0].replace(/[A-Z]/g,'•').split('').join(' ')}</code>\n\nKirim satu huruf, atau ketik <code>/hangmanstop</code>.`,{parse_mode:'HTML',reply_markup:menuFunKeyboard(3)});
  }

  if (data === 'tool_calc') return safeRichSendMessage( chatId,'🧮 Contoh: <code>/calc 100/4+7</code>',{parse_mode:'HTML',reply_markup:toolKeyboardBack()});
  if (data === 'tool_password') return safeRichSendMessage( chatId,'🔐 Contoh: <code>/password 24</code>',{parse_mode:'HTML',reply_markup:toolKeyboardBack()});
  if (data === 'tool_base64') return safeRichSendMessage( chatId,'🔤 Contoh: <code>/base64 hello world</code>',{parse_mode:'HTML',reply_markup:toolKeyboardBack()});
  if (data === 'tool_uuid') return safeRichSendMessage( chatId,`🆔 <code>${crypto.randomUUID()}</code>`,{parse_mode:'HTML',reply_markup:toolKeyboardBack()});
  if (data === 'tool_textinfo') return safeRichSendMessage( chatId,'📊 Contoh: <code>/textinfo teks yang ingin dicek</code>',{parse_mode:'HTML',reply_markup:toolKeyboardBack()});
  if (data === 'tool_time') { const now=moment().tz(c.TIMEZONE); return safeRichSendMessage( chatId,`🕒 <b>${now.format('dddd, DD MMMM YYYY')}</b>\n<code>${now.format('HH:mm:ss')} WIB</code>`,{parse_mode:'HTML',reply_markup:toolKeyboardBack()}); }
  if (data === 'tool_json') return safeRichSendMessage( chatId,'🧾 Contoh: <code>/json {"nama":"bot"}</code>',{parse_mode:'HTML',reply_markup:toolKeyboardBack()});
  if (data === 'tool_url') return safeRichSendMessage( chatId,'🔗 Contoh: <code>/urlcheck https://example.com</code>',{parse_mode:'HTML',reply_markup:toolKeyboardBack()});
  if (data === 'tool_qr') return safeRichSendMessage( chatId,'📱 Contoh: <code>/qr https://example.com</code>',{parse_mode:'HTML',reply_markup:toolKeyboardBack()});
  if (data === 'tool_hd') return safeRichSendMessage( chatId,'✨ <b>HD Media 4×</b>\n\nKetik <code>/wink</code> lalu pilih HD foto atau HD video. Foto menggunakan upscale lokal 4× + sharpening.',{parse_mode:'HTML',reply_markup:menuAlatKeyboard()});
  if (data === 'ai_code_help') return safeRichSendMessage( chatId,menuAIText(q?.from?.id || chatId),{parse_mode:'HTML',reply_markup:menuAIKeyboard(chatId)});


  if (data === 'market_home') {
    try {
      const text = await marketHomeText();
      await safeDelete(bot, chatId, msgId);
      return sendMenuPhoto(bot, chatId, c.BANNER_URL, { caption:text, parse_mode:'HTML', reply_markup:marketKeyboard() });
    } catch (e) {
      return bot.answerCallbackQuery(q.id, { text:`Pasar tidak tersedia: ${e.message}`.slice(0,190), show_alert:true }).catch(()=>{});
    }
  }

  if (data === 'market_search') {
    pendingMarketSearch.set(String(q.from.id), chatId);
    setTimeout(() => pendingMarketSearch.delete(String(q.from.id)), 2 * 60 * 1000);
    return safeRichSendMessage( chatId,
      `${E.search} <b>Cari Saham / Indeks</b>\n\n<blockquote>Ketik kode: <code>BBCA</code> • <code>BBRI</code> • <code>AAPL</code> • <code>^JKSE</code></blockquote>`,
      { parse_mode:'HTML' });
  }

  if (data === 'market_compare_help') {
    pendingMarketSearch.set(String(q.from.id), {chatId, mode:'compare'});
    setTimeout(()=>pendingMarketSearch.delete(String(q.from.id)),2*60*1000);
    return safeRichSendMessage( chatId,`${E.search} <b>BANDINGKAN SAHAM</b>\n\nKirim dua kode dipisahkan spasi.\nContoh: <code>BBCA BBRI</code>`,{parse_mode:'HTML',reply_markup:marketKeyboard()});
  }

  if (data.startsWith('market_trading_')) {
    const raw=data.replace('market_trading_','');
    const last=raw.lastIndexOf('_'); const period=last>0?raw.slice(last+1):'1mo'; const symbol=normalizeMarketSymbol(decodeURIComponent(last>0?raw.slice(0,last):raw));
    try { const text=await marketTradingText(symbol,period); await safeDelete(bot,chatId,msgId); return sendMenuPhoto(bot,chatId,c.BANNER_URL,{caption:text,parse_mode:'HTML',reply_markup:marketTradingKeyboard(symbol,period)}); }
    catch(e){ return bot.answerCallbackQuery(q.id,{text:`Trading View gagal: ${e.message}`.slice(0,190),show_alert:true}).catch(()=>{}); }
  }

  if (data.startsWith('market_quote_')) {
    const symbol = normalizeMarketSymbol(data.replace('market_quote_', ''));
    try {
      const text = await marketDetailText(symbol);
      await safeDelete(bot, chatId, msgId);
      return sendMenuPhoto(bot, chatId, c.BANNER_URL, { caption:text, parse_mode:'HTML', reply_markup:marketDetailKeyboard(symbol) });
    } catch (e) {
      return bot.answerCallbackQuery(q.id, { text:`Data ${symbol} gagal diambil.`.slice(0,190), show_alert:true }).catch(()=>{});
    }
  }

  if (data.startsWith('market_chart_')) {
    const symbol = normalizeMarketSymbol(data.replace('market_chart_', ''));
    try {
      const history = await getMarketHistory(symbol, '3mo', '1d');
      const values = history.map(x => x.close);
      const first = values[0], last = values.at(-1);
      const pct = first && last ? ((last-first)/first)*100 : null;
      const text = `<blockquote>${E.chart} <b>GRAFIK — ${htmlEscape(symbol)}</b>\n<code>${marketSparkline(values)}</code></blockquote>\n\n`+
        `Periode: <b>3 bulan</b>\nAwal: <code>${first?.toLocaleString('id-ID',{maximumFractionDigits:2}) || '-'}</code>\nTerakhir: <code>${last?.toLocaleString('id-ID',{maximumFractionDigits:2}) || '-'}</code>\n`+
        `Perubahan: <b>${pct == null ? '-' : (pct >= 0 ? '+' : '') + pct.toFixed(2) + '%'}</b>\n\n<i>Informasi historis, bukan rekomendasi transaksi.</i>`;
      await safeDelete(bot, chatId, msgId);
      return safeRichSendMessage( chatId,text,{parse_mode:'HTML',reply_markup:marketDetailKeyboard(symbol)});
    } catch (e) {
      return bot.answerCallbackQuery(q.id,{text:'Grafik belum tersedia.',show_alert:true}).catch(()=>{});
    }
  }

  
    if (data.startsWith('set_sender_pw_')) {
    const number = data.replace('set_sender_pw_', '');
    pendingPasswordInput.set(String(q.from.id), { number, chatId, msgId, mode: 'set' });
    setTimeout(() => pendingPasswordInput.delete(String(q.from.id)), 5 * 60 * 1000);
    return safeRichSendMessage( chatId,
      `${E.key} <b>Atur Password Sender</b>\n\n` +
      `${E.phone} Nomor: <code>${number}</code>\n\n` +
      `<blockquote>Ketik password yang ingin kamu pasang.\nBisa kombinasi angka, huruf, dan simbol.\nContoh: <code>Lavender@2026</code></blockquote>`,
      { parse_mode: 'HTML' });
  }

  // ---- Hapus Sender Password ----
  if (data.startsWith('rm_sender_pw_')) {
    const number = data.replace('rm_sender_pw_', '');
    removeSenderPassword(number);
    // Alert pop-up tidak bisa baca HTML, jadi gunakan emoji standar ✅
    return bot.answerCallbackQuery(q.id, { text: `✅ Password sender ${number} berhasil dihapus.`, show_alert: true });
  }

  // ---- Konfirmasi pakai sender berbayar password ----
  if (data.startsWith('tesfunc_usepw_')) {
    const parts = data.replace('tesfunc_usepw_', '').split('_');
    const targetUid = parts[0];
    if (String(q.from.id) !== targetUid) return;
    const session = pendingTesfuncPw.get(targetUid);
    
    // Alert pop-up tidak bisa baca HTML, jadi gunakan emoji standar ⚠️
    if (!session) return bot.answerCallbackQuery(q.id, { text: '⚠️ Sesi habis.', show_alert: true });
    
    await safeDelete(bot, chatId, msgId);
    return safeRichSendMessage( chatId,
      `${E.lock2} <b>Masukan Password Sender</b>\n\n` +
      `<blockquote>Sender ini diproteksi password.\nKetik passwordnya sekarang untuk melanjutkan.</blockquote>`,
      { parse_mode: 'HTML' });
  }
  
  if (data === 'ctrl_listcmd') {
    if (!activeControl.has(String(q.from.id))) return bot.answerCallbackQuery(q.id,{text:'Mode kontrol belum aktif. Gunakan /getcontrol.',show_alert:true}).catch(()=>{});
    return safeRichSendMessage( chatId,'<b>📋 LIST COMMAND MODE KONTROL</b>\n\n<code>/message &lt;teks&gt;</code> — broadcast\nReply foto + <code>/foto</code> / <code>/fotocaption teks</code>\nReply video + <code>/video</code> / <code>/videocaption teks</code>\nReply stiker + <code>/stikersend</code>\nReply file + <code>/file</code> / <code>/filecaption teks</code>\nReply audio + <code>/audio</code> / <code>/audiocaption teks</code>\n<code>/outcontrol</code> — keluar mode kontrol',{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'↩️ Kembali',callback_data:'back_menu'}]]}});
  }
  if (data === 'ctrl_broadcast_again') {
    if (!activeControl.has(String(q.from.id))) return bot.answerCallbackQuery(q.id,{text:'Aktifkan mode kontrol terlebih dahulu.',show_alert:true}).catch(()=>{});
    return safeRichSendMessage( chatId,'📢 <b>BROADCAST LAGI</b>\n\nKetik <code>/message pesan kamu</code> untuk mengirim broadcast berikutnya.',{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'📋 List Command',callback_data:'ctrl_listcmd'}]]}});
  }
  const controlPrompts={ctrl_fotocaption:'Reply foto yang ingin dikirim, lalu gunakan <code>/fotocaption teks</code>.',ctrl_videocaption:'Reply video yang ingin dikirim, lalu gunakan <code>/videocaption teks</code>.',ctrl_filecaption:'Reply file yang ingin dikirim, lalu gunakan <code>/filecaption teks</code>.',ctrl_audiocaption:'Reply audio/voice yang ingin dikirim, lalu gunakan <code>/audiocaption teks</code>.'};
  if(controlPrompts[data]){
    if(!activeControl.has(String(q.from.id))) return bot.answerCallbackQuery(q.id,{text:'Mode kontrol belum aktif.',show_alert:true}).catch(()=>{});
    return safeRichSendMessage( chatId,`🛠️ <b>MODE KONTROL</b>\n\n${controlPrompts[data]}`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'📋 List Command',callback_data:'ctrl_listcmd'}]]}});
  }

  if (data.startsWith('req_reply_')) {
    if(!isOwner(q.from?.id)) return bot.answerCallbackQuery(q.id,{text:'Hanya Developer yang dapat membalas request.',show_alert:true}).catch(()=>{});
    const id=data.replace('req_reply_','').toUpperCase(); const req=getFeatureRequest(id); if(!req) return bot.answerCallbackQuery(q.id,{text:'Request tidak ditemukan.',show_alert:true}).catch(()=>{});
    pendingFeatureReply.set(String(q.from.id),id); setTimeout(()=>pendingFeatureReply.delete(String(q.from.id)),10*60*1000);
    return safeRichSendMessage( chatId,`💬 <b>Balas ${htmlEscape(id)}</b>\n\nKetik pesan balasan untuk user.\n\nRequest: <blockquote>${htmlEscape(req.text)}</blockquote>`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'✖️ Batal',callback_data:'back_menu'}]]}});
  }
  if (data.startsWith('req_info_')) {
    if(!isOwner(q.from?.id)) return bot.answerCallbackQuery(q.id,{text:'Hanya Developer.',show_alert:true}).catch(()=>{});
    const id=data.replace('req_info_','').toUpperCase(); const req=getFeatureRequest(id); if(!req) return bot.answerCallbackQuery(q.id,{text:'Request tidak ditemukan.',show_alert:true}).catch(()=>{});
    return bot.answerCallbackQuery(q.id,{text:`${id} • ${req.status} • User ${req.userId}`,show_alert:true}).catch(()=>{});
  }

  if (data.startsWith('mainchan_profile_') || data.startsWith('mainchan_detail_')) {
    const parts = data.split('_');
    const action = parts[1] === 'profile' ? 'profile' : 'detail';
    const legacyFormat = parts.length === 3;
    const channelId = legacyFormat ? String((q.message?.chat?.type === 'channel' ? q.message.chat.id : await getMainChannelId()) || '') : String(parts[2] || '');
    const targetId = Number(legacyFormat ? parts[2] : parts[3]);
    if (!channelId) return bot.answerCallbackQuery(q.id,{text:'Main Channel belum ditentukan.',show_alert:true}).catch(()=>{});
    if (!Number.isSafeInteger(targetId)) return bot.answerCallbackQuery(q.id,{text:'ID user tidak valid.',show_alert:true}).catch(()=>{});

    try {
      const member = await bot.getChatMember(channelId, targetId);
      const target = member?.user || {};
      const targetName = [target.first_name, target.last_name].filter(Boolean).join(' ') || 'Pengguna';
      const targetUsername = target.username ? `@${target.username}` : '-';

      if (action === 'profile') {
        if (target.username) {
          return bot.answerCallbackQuery(q.id,{text:'Membuka profil Telegram…',show_alert:false,url:`https://t.me/${target.username}`}).catch(()=>{});
        }
        return bot.answerCallbackQuery(q.id,{text:`Profil: ${targetName} • ID ${targetId}`,show_alert:true}).catch(()=>{});
      }

      const status = member?.status || 'unknown';
      return bot.answerCallbackQuery(q.id,{
        text:`${targetName} • ${targetUsername} • ID ${targetId} • Status: ${status}`,
        show_alert:true
      }).catch(()=>{});
    } catch (e) {
      return bot.answerCallbackQuery(q.id,{text:`Detail gagal diambil: ${String(e.message||'Telegram API error').slice(0,150)}`,show_alert:true}).catch(()=>{});
    }
  }

  if (data.startsWith('mainchan_ban_') || data.startsWith('mainchan_unban_')) {
    const parts0 = data.split('_');
    const legacyFormat = parts0.length === 3;
    const channelId = legacyFormat ? String((q.message?.chat?.type === 'channel' ? q.message.chat.id : await getMainChannelId()) || '') : String(parts0[2] || '');
    if (!channelId) return bot.answerCallbackQuery(q.id,{text:'Main Channel belum ditentukan.',show_alert:true}).catch(()=>{});
    let actor;
    try { actor = await bot.getChatMember(channelId, q.from.id); } catch (e) {
      return bot.answerCallbackQuery(q.id,{text:'Tidak bisa memeriksa admin/owner channel.',show_alert:true}).catch(()=>{});
    }
    if (!['administrator','creator'].includes(actor?.status)) {
      return bot.answerCallbackQuery(q.id,{text:'Hanya admin channel yang boleh memakai tombol ini.',show_alert:true}).catch(()=>{});
    }
    try {
      const me = await bot.getMe();
      const botActor = await bot.getChatMember(channelId, me.id);
      if (botActor.status === 'administrator' && botActor.can_restrict_members === false) {
        return bot.answerCallbackQuery(q.id,{text:'Bot belum punya izin Restrict Members di channel.',show_alert:true}).catch(()=>{});
      }
    } catch {}
    const parts = data.split('_');
    const action = parts[1] === 'ban' ? 'ban' : 'unban';
    const targetId = Number(legacyFormat ? parts[2] : parts[3]);
    if (!Number.isSafeInteger(targetId)) return bot.answerCallbackQuery(q.id,{text:'ID user tidak valid.',show_alert:true}).catch(()=>{});
    try {
      if (action === 'ban') {
        await bot.banChatMember(channelId, targetId);
        await bot.answerCallbackQuery(q.id,{text:'User berhasil di-BAN dari main channel.',show_alert:false}).catch(()=>{});
        return safeRichSendMessage( chatId, `🔨 <b>BAN BERHASIL</b>\n\nUser <code>${targetId}</code> sudah diblokir dari main channel.`, {parse_mode:'HTML'});
      }
      await bot.unbanChatMember(channelId, targetId, {only_if_banned:true});
      await bot.answerCallbackQuery(q.id,{text:'User berhasil di-UNBAN dari main channel.',show_alert:false}).catch(()=>{});
      return safeRichSendMessage( chatId, `🔓 <b>UNBAN BERHASIL</b>\n\nUser <code>${targetId}</code> sudah boleh bergabung kembali ke main channel.`, {parse_mode:'HTML'});
    } catch (e) {
      return bot.answerCallbackQuery(q.id,{text:`Aksi gagal: ${String(e.message||'Telegram API error').slice(0,170)}`,show_alert:true}).catch(()=>{});
    }
  }

  if (data === 'back_menu') {
    await safeDelete(bot, chatId, msgId);
    return sendRichStartMenu(chatId, q.from);
  }

  const groupInfoMap = {
    info_antilink: '/antilink — Toggle blokir link di grup. Link TikTok & Instagram dikecualikan. Member yang kirim link lain akan diperingatkan dan pesan dihapus.',
    info_welcome: '/welcome on — Setup pesan sambutan dengan variabel ${username}, ${name}, ${id}. Bisa tambah foto opsional.\n/welcome off — Nonaktifkan.',
    info_antiforward: '/antiforward — Toggle blokir semua pesan forward di grup.',
    info_antibot: '/antibot — Toggle kick otomatis bot baru yang ditambahkan.',
    info_kick: '/kick — Reply pesan member yang ingin dikeluarkan.',
    info_promote: '/promote — Reply pesan member untuk dijadikan admin. Bisa juga /promote <user_id>.',
    info_demote: '/demote — Reply pesan admin untuk mencabut status admin. Bisa juga /demote <user_id>.',
    info_mute: '/mute — Reply pesan member untuk dibisukan.',
    info_pin: '/pin — Reply pesan yang ingin di-pin.',
    info_link: '/link — Dapatkan link undangan grup.'
  };

  if (groupInfoMap[data]) {
    return bot.answerCallbackQuery(q.id, { text: groupInfoMap[data], show_alert: true }).catch(() => {});
  }

        // ---- Kode Rendem button ----
  if (data === 'kode_rendem') {
    const active = getFirstActiveCode();
    if (!active) {
      return safeRichSendMessage( chatId,
        `${E.cross} <b>Tidak ada kode redeem aktif saat ini.</b>\n\n<blockquote>Tunggu owner memasukan kode redeem baru.</blockquote>`,
        { parse_mode: 'HTML' });
    }
    pendingRedeemInput.set(String(q.from.id), chatId);
    return safeRichSendMessage( chatId,
      `${E.party} <b>Kode Redeem Aktif!</b>\n\n` +
      `${E.group} Sisa slot: <code>${active.data.maxUsers - active.data.claimed}</code>\n\n` +
      `<blockquote>Silakan ketik kode redeem kamu:</blockquote>`,
      { parse_mode: 'HTML' });
  }
  
    // ---- Getcelah Next ----
  if (data.startsWith('celah_next_')) {
    const targetUid = data.replace('celah_next_', '');
    const session = pendingCelah.get(targetUid);
    if (!session) {
      return bot.answerCallbackQuery(q.id, { text: 'Sesi habis. Jalankan /getcelah ulang.', show_alert: true });
    }
    session.page++;
    const { chunks, page } = session;
    if (page >= chunks.length) {
      pendingCelah.delete(targetUid);
      return bot.answerCallbackQuery(q.id, { text: 'Sudah sampai akhir!', show_alert: true });
    }
    const chunk = chunks[page];
    const hasMore = page < chunks.length - 1;
    await safeDelete(bot, chatId, msgId);
    return safeRichSendMessage( chatId,
      `${E.eyes} <b>Struktur Function</b>\n` +
      `<blockquote>Halaman ${page + 1} / ${chunks.length}</blockquote>\n\n` +
      `<pre><code class="language-javascript">${htmlEscape(chunk)}</code></pre>`,
      {
        parse_mode: 'HTML',
        reply_markup: hasMore ? {
          inline_keyboard: [[
            { 
              text: '✿ Next ✿', 
              callback_data: `celah_next_${targetUid}`, 
              style: 'primary', 
              icon_custom_emoji_id: '4956416504674386959' // Emoji Next ⏭️
            }
          ]]
        } : { 
          inline_keyboard: [[
            { 
              text: '✿ Selesai ✿', 
              callback_data: 'close_msg', 
              style: 'success', 
              icon_custom_emoji_id: '4956721670690702265' // Emoji Check ✅
            }
          ]] 
        }
      });
  }

  // ---- Close message ----
  if (data === 'close_msg') {
    return safeDelete(bot, chatId, msgId);
  }

  // ---- Rasukbot: mulai akses ----
  if (data.startsWith('rasuk_mulai_')) {
    const token = data.replace('rasuk_mulai_', '');
    const uid = String(q.from.id);
    const bots = controlledBots.get(uid) || {};
    const info = bots[token];
    if (!info) return bot.answerCallbackQuery(q.id, { text: 'Token tidak valid.', show_alert: true });
    activeControl.set(uid, { token, ...info });
    await safeDelete(bot, chatId, msgId);
    return safeRichSendMessage( chatId,
      `${E.check} <b>Mode Kontrol Aktif!</b>\n\n` +
      `${E.bot} Bot: <b>${htmlEscape(info.firstName)}</b> (@${htmlEscape(info.username || '-')})\n\n` +
      `<blockquote>Kamu sekarang mengontrol bot ini.\nGunakan perintah berikut:\n\n` +
      `• <code>/message &lt;teks&gt;</code> — broadcast pesan\n` +
      `• Reply foto + <code>/foto</code> atau <code>/fotocaption &lt;teks&gt;</code>\n` +
      `• Reply video + <code>/video</code> atau <code>/videocaption &lt;teks&gt;</code>\n` +
      `• Reply stiker + <code>/stikersend</code>\n` +
      `• Reply file + <code>/file</code> atau <code>/filecaption &lt;teks&gt;</code>\n` +
      `• Reply audio + <code>/audio</code> atau <code>/audiocaption &lt;teks&gt;</code>\n` +
      `• <code>/outcontrol</code> — keluar dari mode kontrol</blockquote>`,
      { parse_mode: 'HTML' });
  }

  // ---- Rasukbot: list command ----
  if (data.startsWith('rasuk_listcmd_')) {
    const token = data.replace('rasuk_listcmd_', '');
    await safeDelete(bot, chatId, msgId);
    return safeRichSendMessage( chatId,
      `${E.clipboard} <b>List Command Mode Kontrol</b>\n\n` +
      `<code>/message &lt;teks&gt;</code>\n└ Broadcast pesan ke semua users\n\n` +
      `Reply foto + <code>/foto</code>\n└ Kirim foto tanpa caption\n\n` +
      `Reply foto + <code>/fotocaption &lt;teks&gt;</code>\n└ Kirim foto dengan caption\n\n` +
      `Reply video + <code>/video</code>\n└ Kirim video\n\n` +
      `Reply video + <code>/videocaption &lt;teks&gt;</code>\n└ Kirim video dengan caption\n\n` +
      `Reply stiker + <code>/stikersend</code>\n└ Kirim stiker\n\n` +
      `Reply file + <code>/file</code>\n└ Kirim file/dokumen\n\n` +
      `Reply file + <code>/filecaption &lt;teks&gt;</code>\n└ Kirim file dengan caption\n\n` +
      `Reply audio + <code>/audio</code>\n└ Kirim audio\n\n` +
      `Reply audio + <code>/audiocaption &lt;teks&gt;</code>\n└ Kirim audio dengan caption\n\n` +
      `<code>/outcontrol</code>\n└ Keluar dari mode kontrol\n\n` +
      `<code>/listbot</code>\n└ Lihat daftar bot yang dirasuk`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [[
            { 
              text: '✿ Kembali ✿', 
              callback_data: `rasuk_mulai_${token}`, 
              style: 'danger', 
              icon_custom_emoji_id: '5386834131097237041' // Emoji Back/Danger 🔙
            }
          ]]
        }
      });
  }
  
  if (data === 'ai_mode_images' || data === 'ai_mode_video') return bot.answerCallbackQuery(q.id,{text:'Gunakan menu AI Multi-AI.',show_alert:true}).catch(()=>{});
  if (data === 'ai_toggle_on') {
    setAssistantEnabled(chatId,true);
    const provider = normalizeAiProvider(getAssistantProvider(chatId));
    await bot.answerCallbackQuery(q.id,{text:`AI Asisten aktif — ${aiProviderLabel(provider)}`,show_alert:false}).catch(()=>{});
    return safeRichSendMessage(chatId,menuAIText(q.from.id, chatId),{parse_mode:'HTML',reply_markup:menuAIKeyboard(chatId)});
  }
  if (data === 'ai_toggle_off') {
    setAssistantEnabled(chatId,false);
    pendingAiAction.delete(String(q.from.id));
    await bot.answerCallbackQuery(q.id,{text:'AI Asisten dimatikan.',show_alert:false}).catch(()=>{});
    return safeRichSendMessage(chatId,menuAIText(q.from.id, chatId),{parse_mode:'HTML',reply_markup:menuAIKeyboard(chatId)});
  }
  if (data === 'ai_menu') return safeRichSendMessage(chatId,menuAIText(q.from.id, chatId),{parse_mode:'HTML',reply_markup:menuAIKeyboard(chatId)});
  if (data === 'ai_providers') return safeRichSendMessage(chatId,aiProvidersText(chatId),{parse_mode:'HTML',reply_markup:aiProviderKeyboard(chatId)});
  if (data === 'ai_provider_auto') { setAssistantProvider(chatId,'auto'); return safeRichSendMessage(chatId,'🔄 <b>Auto Fallback dipilih.</b>\n\nSaat Asisten aktif, bot akan mencoba Gemini → OpenRouter jika provider sebelumnya gagal. Status Asisten tidak berubah.',{parse_mode:'HTML',reply_markup:menuAIKeyboard(chatId)}); }
  if (data === 'ai_provider_pixazo') { return safeRichSendMessage(chatId,`🎨 <b>Pixazo Studio</b> dipilih untuk fitur media.\n\n• 🖼️ Edit foto dengan prompt\n• 🎬 Edit video dengan prompt\n• 🖼️➡️🎬 Foto ke video dengan prompt\n\nGunakan tombol fitur Pixazo di menu AI. Pixazo tidak dipakai untuk chat teks.`,{parse_mode:'HTML',reply_markup:aiFeatureKeyboard()}); }
  if (data.startsWith('ai_provider_')) { const p=data.slice('ai_provider_'.length); if(!AI_PROVIDERS.includes(p)) return bot.answerCallbackQuery(q.id,{text:'Provider tidak dikenal.',show_alert:true}).catch(()=>{}); setAssistantProvider(chatId,p); const ready=Boolean(providerKey(p)); return safeRichSendMessage(chatId,`${ready?'✅':'⚠️'} <b>${htmlEscape(aiProviderLabel(p))} dipilih.</b>\n\n${ready?'API key terdeteksi. AI siap digunakan.':'API key belum diisi. Tambahkan key di .env lalu restart bot.'}`,{parse_mode:'HTML',reply_markup:menuAIKeyboard(chatId)}); }
  if (data === 'ai_features') return safeRichSendMessage(chatId,'✨ <b>FITUR AI CEPAT</b>\n\nPilih fitur lalu ikuti instruksi bot. Fitur teks memakai AI yang sedang dipilih.',{parse_mode:'HTML',reply_markup:aiFeatureKeyboard()});
  if (data.startsWith('ai_feature_')) {
    const mode=data.slice('ai_feature_'.length);
    const labels={chat:'💬 Chat AI',summarize:'📝 Ringkas Teks',rewrite:'✍️ Rewrite',translate:'🌐 Translate',code:'💻 Coding Assistant',study:'📚 Study Assistant',image:'🖼️ Analisis Gambar',pixazo_photo:'🎨 Pixazo — Edit Foto',pixazo_video:'🎬 Pixazo — Edit Video',pixazo_i2v:'🖼️➡️🎬 Pixazo — Foto ke Video'};
    if(!labels[mode]) return bot.answerCallbackQuery(q.id,{text:'Fitur AI tidak dikenal.',show_alert:true}).catch(()=>{});
    if(mode.startsWith('pixazo_')) {
      if(!pixazoReady()) return bot.answerCallbackQuery(q.id,{text:'PIXAZO_API_KEY belum diisi di .env.',show_alert:true}).catch(()=>{});
      setPendingAiAction(q.from.id,chatId,mode);
      const instructions={pixazo_photo:'Kirim <b>foto + caption prompt</b>. Contoh: <code>ubah background menjadi malam neon</code>.',pixazo_video:'Kirim <b>video + caption prompt</b>. Contoh: <code>ubah gaya menjadi cinematic</code>.',pixazo_i2v:'Kirim <b>foto + caption prompt gerakan</b>. Contoh: <code>kamera perlahan mendekat, rambut bergerak tertiup angin</code>.'};
      return safeRichSendMessage(chatId,`${labels[mode]}\n\n${instructions[mode]}\n\n<i>Pixazo memproses file secara asynchronous; tunggu sampai hasil selesai.</i>`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'❌ Batal',callback_data:'ai_features'}],[{text:'📡 Status AI',callback_data:'ai_status'}]]}});
    }
    if(mode==='image'&&!AI_CONFIG.geminiKey) return bot.answerCallbackQuery(q.id,{text:'Analisis gambar membutuhkan GEMINI_API_KEY.',show_alert:true}).catch(()=>{});
    if(mode==='image') setPendingAiAction(q.from.id,chatId,'image'); else setPendingAiAction(q.from.id,chatId,mode);
    const instruction=mode==='image'?'Kirim <b>foto</b> berikutnya. Analisis gambar memakai Gemini.':`Kirim teks berikutnya untuk <b>${labels[mode]}</b>.`;
    return safeRichSendMessage(chatId,`${labels[mode]}\n\n${instruction}`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'❌ Batal',callback_data:'ai_features'}],[{text:'🤖 Pilih AI',callback_data:'ai_providers'}]]}});
  }
  if (data === 'ai_personality') return safeRichSendMessage(chatId,`🎭 <b>AI PERSONALITY</b>\n\nSaat ini: <b>${htmlEscape(aiPersonalityLabel(q.from.id))}</b>`,{parse_mode:'HTML',reply_markup:aiPersonalityKeyboard()});
  if (data.startsWith('ai_personality_')) { const p=data.slice('ai_personality_'.length); if(!['friendly','professional','funny','expert'].includes(p)) return bot.answerCallbackQuery(q.id,{text:'Personality tidak dikenal.',show_alert:true}).catch(()=>{}); aiPersonality.set(String(q.from.id),p); return safeRichSendMessage(chatId,`✅ Personality AI diubah ke <b>${htmlEscape(aiPersonalityLabel(q.from.id))}</b>.`,{parse_mode:'HTML',reply_markup:aiFeatureKeyboard()}); }
  if (data === 'ai_status') { const rows=AI_PROVIDERS.map(p=>`• <b>${aiProviderLabel(p)}</b>: ${providerKey(p)?'SIAP ✅':'KOSONG ❌'} — <code>${htmlEscape(providerModel(p))}</code>`).join('\n'); return safeRichSendMessage(chatId,`<blockquote>📡 <b>AI STATUS</b></blockquote>\n\n${rows}\n• <b>Pixazo Studio</b>: ${pixazoReady()?'SIAP ✅':'KOSONG ❌'}\n\nStatus Asisten: <b>${isAssistantEnabled(chatId)?'🟢 AKTIF':'🔴 MATI'}</b>\nAI pilihan: <b>${htmlEscape(aiProviderLabel(normalizeAiProvider(getAssistantProvider(chatId))))}</b>\nQueue: <code>${aiQueue.length}/${AI_CONFIG.maxQueue}</code>\nAktif request: <code>${aiActive}/${AI_CONFIG.maxConcurrent}</code>\nCooldown: <code>${Math.round(AI_CONFIG.userCooldownMs/1000)} dtk/user</code>\nOutput: <code>${AI_CONFIG.maxOutputTokens} token</code>`,{parse_mode:'HTML',reply_markup:menuAIKeyboard(chatId)}); }
  if (data === 'ai_reset') { aiHistory.delete(String(chatId)); pendingAiAction.delete(String(q.from.id)); return safeRichSendMessage(chatId,'🧹 <b>Riwayat AI di-reset.</b>\n\nPercakapan berikutnya dimulai dari konteks baru.',{parse_mode:'HTML',reply_markup:menuAIKeyboard(chatId)}); }
  if (data === 'ai_mode_gemini') { setAssistantProvider(chatId,'gemini'); return bot.editMessageText(`${E.ai} <b>Gemini dipilih.</b>\n\n<blockquote>Gemini menjadi provider pilihan. Status Asisten tidak berubah.\n\nPrivate: kirim pesan biasa.\nGroup: awali pesan dengan <b>AI</b>.\nGunakan <code>/ai pertanyaan</code> untuk bertanya.</blockquote>`,{chat_id:chatId,message_id:msgId,parse_mode:'HTML',reply_markup:menuAIKeyboard(chatId)}).catch(()=>safeRichSendMessage(chatId,`${E.ai} <b>Gemini dipilih.</b>`,{parse_mode:'HTML',reply_markup:menuAIKeyboard(chatId)})); }

  // ---- /addkode pilih hadiah ----
  if (data.startsWith('addkode_pilih_')) {
    if (!isOwner(q.from.id)) return;
    const rewardId = data.replace('addkode_pilih_', '');
    const rewards = getRewards();
    const reward = rewards.find(r => r.id === rewardId);
    if (!reward) return bot.answerCallbackQuery(q.id, { text: 'Hadiah tidak ditemukan.', show_alert: true });
    const code = generateRedeemCode();
    const now = Date.now();
    const expiresAt = new Date(now + 15 * 60 * 1000).toISOString();
    setActiveCode(code, {
      rewardId: reward.id,
      rewardFileName: reward.fileName,
      rewardFileId: reward.fileId,
      rewardFileType: reward.fileType,
      maxUsers: reward.maxUsers,
      createdAt: new Date(now).toISOString(),
      expiresAt,
      claimedBy: [],
      claimed: 0
    });
    setTimeout(() => { removeActiveCode(code); }, 15 * 60 * 1000);
    await safeDelete(bot, chatId, msgId);
    await safeRichSendMessage( chatId,
      `${E.check} <b>Kode Redeem Berhasil Dibuat!</b>\n\n` +
      `${E.key} Kode: <code>${code}</code>\n` +
      `${E.folder} Hadiah: <code>${htmlEscape(reward.fileName)}</code>\n` +
      `${E.group} Limit: <code>${reward.maxUsers} Users</code>\n` +
      `${E.watch} Berlaku: <code>15 Menit</code>\n\n` +
      `<blockquote>Notifikasi sedang dikirim ke semua pengguna...</blockquote>`,
      { parse_mode: 'HTML' });
    try {
      const me = await bot.getMe();
      broadcastRedeemNotif(me.username, code, reward.fileName, reward.maxUsers, new Date(now).toISOString()).catch(() => {});
    } catch {}
    return;
  }
  
    // ---- NPM: Get Dev Dependencies ----
  if (data.startsWith('npm_deps_')) {
    const npmId = parseInt(data.replace('npm_deps_', ''), 10);
    const cached = npmCache.get(npmId);
    if (!cached) {
      // answerCallbackQuery tidak support HTML/Custom Emoji, tetap pakai bawaan
      return bot.answerCallbackQuery(q.id, {
        text: '⚠️ Data sudah kedaluwarsa (30 menit). Jalankan /npmpackage lagi.',
        show_alert: true
      });
    }
    await bot.answerCallbackQuery(q.id);

    const r = cached.result;
    const devDeps = r.dev_dependencies || {};
    const devKeys = Object.keys(devDeps);

    if (!devKeys.length) {
      return safeRichSendMessage( chatId,
        `${E.folder} <b>${htmlEscape(r.name)}</b> — Dev Dependencies\n\n<i>Tidak ada dev dependencies.</i>`,
        { parse_mode: 'HTML' });
    }

    const devText = devKeys
      .map(k => `  • <code>${htmlEscape(k)}</code>: <code>${htmlEscape(devDeps[k])}</code>`)
      .join('\n');

    // Telegram max pesan 4096 karakter — potong jika kepanjangan
    const header = `${E.folder} <b>${htmlEscape(r.name)} v${htmlEscape(r.version)}</b> — Dev Dependencies (${devKeys.length})\n\n`;
    const fullText = header + devText + `\n\n<blockquote>Powered by mellstecu Ϟ FMD</blockquote>`;

    if (fullText.length <= 4000) {
      return safeRichSendMessage( chatId, fullText, { parse_mode: 'HTML' });
    }

    // Kepanjangan → kirim sebagai file .txt
    const fileContent = `NPM Dev Dependencies — ${r.name} v${r.version}\n${'='.repeat(50)}\n\n` +
      devKeys.map(k => `${k}: ${devDeps[k]}`).join('\n');
    const fileBuffer = Buffer.from(fileContent, 'utf8');
    return bot.sendDocument(chatId, fileBuffer,
      {
        caption: `${E.folder} <b>Dev Dependencies</b> — <code>${htmlEscape(r.name)}</code>\nTotal: <code>${devKeys.length}</code> package`,
        parse_mode: 'HTML'
      },
      { filename: `${r.name}_dev-deps.txt`, contentType: 'text/plain' }
    );
  }

  // ---- NPM: Download Package ----
  if (data.startsWith('npm_dl_')) {
    const npmId = parseInt(data.replace('npm_dl_', ''), 10);
    const cached = npmCache.get(npmId);
    if (!cached) {
      // answerCallbackQuery tidak support HTML/Custom Emoji
      return bot.answerCallbackQuery(q.id, {
        text: '⚠️ Data sudah kedaluwarsa (30 menit). Jalankan /npmpackage lagi.',
        show_alert: true
      });
    }
    await bot.answerCallbackQuery(q.id, { text: '⬇️ Mengunduh package...', show_alert: false });

    const r = cached.result;
    if (!r.download_url) {
      return safeRichSendMessage( chatId,
        `${E.cross} <b>Download URL tidak tersedia</b> untuk package ini.`,
        { parse_mode: 'HTML' });
    }

    const dlLoading = await safeRichSendMessage( chatId,
      `<code>${makeBar(20)}</code>\n${E.hourglass} Mengunduh <b>${htmlEscape(r.name)} v${htmlEscape(r.version)}</b>...`,
      { parse_mode: 'HTML' });

    try {
      await safeEdit(bot, chatId, dlLoading.message_id,
        `<code>${makeBar(55)}</code>\n${E.hourglass} Mendownload dari NPM registry...`, { parse_mode: 'HTML' });

      const dlRes = await axios.get(r.download_url, {
        responseType: 'arraybuffer',
        timeout: 120000 // 2 menit
      });
      const fileBuffer = Buffer.from(dlRes.data);

      await safeEdit(bot, chatId, dlLoading.message_id,
        `<code>${makeBar(90)}</code>\n${E.hourglass} Mengirim file ke Telegram...`, { parse_mode: 'HTML' });

      const fmtSize = (bytes) => {
        if (!bytes) return 'N/A';
        if (bytes >= 1024 * 1024) return `${(bytes / 1024 / 1024).toFixed(2)} MB`;
        if (bytes >= 1024) return `${(bytes / 1024).toFixed(1)} KB`;
        return `${bytes} B`;
      };

      const deps     = r.dependencies || {};
      const depCount = Object.keys(deps).length;
      const devDeps  = r.dev_dependencies || {};
      const devCount = Object.keys(devDeps).length;

      const caption =
        `${E.box} <b>NPM Package</b>\n\n` +
        `${E.Name} <b>Name:</b> <code>${htmlEscape(r.name)}</code>\n` +
        `${E.pin} <b>Version:</b> <code>${htmlEscape(r.version)}</code>\n` +
        `${E.shield} <b>License:</b> <code>${htmlEscape(r.license || '-')}</code>\n` +
        `${E.ruler} <b>Size:</b> <code>${fmtSize(fileBuffer.length)}</code>\n` +
        `${E.add} <b>Dependencies:</b> <code>${depCount}</code> runtime, <code>${devCount}</code> dev\n\n` +
        `<blockquote>Downloaded via mellstecuu Ϟ MD × NPM Registry</blockquote>`;

      const fileName = `${r.name}-${r.version}.tgz`;
      await bot.sendDocument(chatId, fileBuffer,
        { caption, parse_mode: 'HTML' },
        { filename: fileName, contentType: 'application/gzip' }
      );
      await safeDelete(bot, chatId, dlLoading.message_id);

    } catch (e) {
      await safeEdit(bot, chatId, dlLoading.message_id,
        `${E.cross} Gagal download: <code>${htmlEscape(e.message)}</code>\n\n<blockquote>File terlalu besar atau koneksi timeout.</blockquote>`,
        { parse_mode: 'HTML' });
    }
  }
  
    // ---- WINK MODE SELECT ----
  if (data.startsWith('wink_image_') || data.startsWith('wink_video_')) {
    const mode = data.startsWith('wink_image_') ? 'image' : 'video';
    const parts = data.split('_');
    // format: wink_image_CHATID_USERID  atau  wink_video_CHATID_USERID
    const winkUserId = parts[parts.length - 1];

    // Simpan state pending
    pendingWink.set(String(winkUserId), {
      mode,
      chatId,
      msgId: msgId,
      createdAt: Date.now()
    });
    setTimeout(() => pendingWink.delete(String(winkUserId)), 5 * 60 * 1000); // auto-hapus 5 menit

    if (mode === 'image') {
      await bot.editMessageText(
        `${E.ig} <b>Wink HD Images</b>\n\n` +
        `<blockquote>Kirimkan <b>foto</b> yang ingin di-enhance.\n\nBot akan memperbaiki kualitasnya jadi HD secara otomatis.\n\n${E.watch} Batas waktu: <b>5 menit</b></blockquote>`,
        { chat_id: chatId, message_id: msgId, parse_mode: 'HTML' }
      ).catch(() => safeRichSendMessage( chatId,
        `${E.ig} <b>Wink HD Images</b>\n\n<blockquote>Kirimkan <b>foto</b> yang ingin di-enhance menjadi HD.</blockquote>`,
        { parse_mode: 'HTML' }
      ));
    } else {
      await bot.editMessageText(
        `${E.movie} <b>Wink HD Video</b>\n\n` +
        `<blockquote>Kirimkan <b>video</b> yang ingin di-enhance.\n\nBot akan memperbaiki kualitasnya jadi HD secara otomatis.\n\n${E.watch} Batas waktu: <b>5 menit</b></blockquote>`,
        { chat_id: chatId, message_id: msgId, parse_mode: 'HTML' }
      ).catch(() => safeRichSendMessage( chatId,
        `${E.movie} <b>Wink HD Video</b>\n\n<blockquote>Kirimkan <b>video</b> yang ingin di-enhance menjadi HD.</blockquote>`,
        { parse_mode: 'HTML' }
      ));
    }
    return bot.answerCallbackQuery(q.id);
  }
  
    // ---- Pinterest callback: pilih Video atau Image ----
  if (data.startsWith('pin_video_') || data.startsWith('pin_image_')) {
    const isVideo = data.startsWith('pin_video_');
    const cacheKey = isVideo ? data.replace('pin_video_', '') : data.replace('pin_image_', '');
    const item = pinterestCache.get(cacheKey);
    if (!item) return safeRichSendMessage( chatId, `<blockquote>${E.cross} Data sudah expired. Gunakan /pinterest lagi.</blockquote>`, { parse_mode: 'HTML' });
    pinterestCache.delete(cacheKey);
    const loading = await safeRichSendMessage( chatId, `<code>${makeBar(30)}</code>\n${E.hourglass} Mengunduh ${isVideo ? 'video' : 'gambar'}...`, { parse_mode: 'HTML' });
    try {
      const media = isVideo
        ? item.medias.find(m => m.type === 'video')
        : item.medias.find(m => m.type === 'image');
      if (!media) throw new Error('Media tidak tersedia.');
      await safeEdit(bot, chatId, loading.message_id, `<code>${makeBar(60)}</code>\n${E.hourglass} Mengirim...`, { parse_mode: 'HTML' });
      const caption = `${E.pin} <b>${htmlEscape(item.title)}</b>\n` +
        `${item.duration ? `Durasi: <code>${htmlEscape(item.duration)}</code>\n` : ''}` +
        `Kualitas: <code>${htmlEscape(media.quality)}</code>\n\n` +
        `<blockquote>Downloaded via mellstecuu Ϟ MD</blockquote>`;
      if (isVideo) {
        await bot.sendVideo(chatId, media.url, { caption, parse_mode: 'HTML' });
      } else {
        await bot.sendPhoto(chatId, media.url, { caption, parse_mode: 'HTML' });
      }
      await safeDelete(bot, chatId, loading.message_id);
      await safeDelete(bot, chatId, msgId);
    } catch (e) {
      await safeEdit(bot, chatId, loading.message_id,
        `${E.cross} Gagal kirim: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
    }
    return;
  }

  // ---- TTS callback: pilih model suara ----
  if (data.startsWith('tts_')) {
    const parts = data.split('_');
    const model = parts[1];
    const ck = parts.slice(2).join('_');
    const item = ttsCache.get(ck);
    if (!item) return safeRichSendMessage( chatId, `<blockquote>${E.cross} Data sudah expired. Gunakan /ttsgenerate lagi.</blockquote>`, { parse_mode: 'HTML' });
    const voice = item.voices.find(v => v.model === model);
    if (!voice) return safeRichSendMessage( chatId, `<blockquote>${E.cross} Suara tidak ditemukan.</blockquote>`, { parse_mode: 'HTML' });
    const loading = await safeRichSendMessage( chatId, `<code>${makeBar(40)}</code>\n${E.hourglass} Mengunduh audio <b>${htmlEscape(voice.voice_name)}</b>...`, { parse_mode: 'HTML' });
    try {
      await safeEdit(bot, chatId, loading.message_id, `<code>${makeBar(70)}</code>\n${E.hourglass} Mengirim audio...`, { parse_mode: 'HTML' });
      const caption = `${E.music} <b>TTS — ${htmlEscape(voice.voice_name)}</b>\n` +
        `Teks: <code>${htmlEscape(item.text)}</code>\n\n` +
        `<blockquote>Generated via mellstecuu Ϟ MD</blockquote>`;
      await bot.sendAudio(chatId, voice.url, { caption, parse_mode: 'HTML', title: `TTS - ${voice.voice_name}`, performer: 'mellstecuu BOT' });
      await safeDelete(bot, chatId, loading.message_id);
      await safeDelete(bot, chatId, msgId);
    } catch (e) {
      await safeEdit(bot, chatId, loading.message_id,
        `${E.cross} Gagal kirim audio: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
    }
    return;
  }
  
  if (data.startsWith('song_')) {
    const item = songCache.get(data);
    if (!item) return safeRichSendMessage( chatId, `<blockquote>${E.cross} Data lagu sudah expired. Gunakan /play lagi.</blockquote>`, { parse_mode: 'HTML' });
    const loading = await safeRichSendMessage( chatId, `<code>${makeBar(30)}</code>\n${E.hourglass} Mengunduh audio...\n<b>${htmlEscape(item.title)}</b>`, { parse_mode: 'HTML' });
    try {
      const audio = await getAudioFromYoutube(item.url);
      if (!audio || !audio.audio) throw new Error('Audio tidak tersedia dari server.');
      const caption = `${E.music} <b>${htmlEscape(audio.title || item.title)}</b>\n` +
        `Artist: <code>${htmlEscape(audio.author || item.channel)}</code>\n` +
        `Durasi: <code>${htmlEscape(typeof audio.duration === 'number' ? `${audio.duration}s` : (audio.duration || item.duration))}</code>\n` +
        `Kualitas: <code>${htmlEscape(audio.quality || '320k')}</code>`;
      await safeEdit(bot, chatId, loading.message_id,
        `<code>${makeBar(70)}</code>\n${E.hourglass} Mengunduh audio ke server...`, { parse_mode: 'HTML' });
      let audioPayload;
      if (typeof audio.audio === 'string' && audio.audio.startsWith('http')) {
        try {
          const aRes = await axios.get(audio.audio, { responseType: 'arraybuffer', timeout: 120000 });
          audioPayload = Buffer.from(aRes.data);
        } catch {
          audioPayload = audio.audio;
        }
      } else {
        audioPayload = audio.audio;
      }
      await safeEdit(bot, chatId, loading.message_id,
        `<code>${makeBar(95)}</code>\n${E.hourglass} Mengirim audio...`, { parse_mode: 'HTML' });
      await bot.sendAudio(chatId, audioPayload, {
        title: audio.title || item.title,
        performer: audio.author || item.channel || 'YouTube',
        caption,
        parse_mode: 'HTML'
      });
      await safeDelete(bot, chatId, loading.message_id);
    } catch (e) {
      await safeEdit(bot, chatId, loading.message_id, `${E.cross} Gagal download: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
    }
    return;
  }

  if (data.startsWith('tesfunc_rec_')) {
    const parts = data.split('_');
    const tfChatId = parts[2];
    const tfUserId = parts[3];
    const key = `${tfChatId}:${tfUserId}`;
    const pending = pendingTesfunc.get(key);
    if (!pending) return bot.answerCallbackQuery(q.id, { text: 'Sesi sudah habis. Mulai ulang /tesfunc', show_alert: true });
    if (String(q.from.id) !== String(tfUserId)) {
      return bot.answerCallbackQuery(q.id, { text: 'Tombol ini milik pengguna yang menjalankan /tesfunc.', show_alert: true });
    }
    pendingTesfunc.delete(key);
    await bot.answerCallbackQuery(q.id, { text: 'Rekomendasi dipakai: 50 loop • 700ms sleep' }).catch(() => {});
    await safeDelete(bot, chatId, msgId);
    return runTesfunc(chatId, q.from, pending.targetNumber, pending.code, 50, 700);
  }
    
   // ---- SEND AGAIN (+5 loop, +100 sleep tiap tekan) ----
  if (data.startsWith('again_')) {
    const id = parseInt(data.replace('again_', ''), 10);
    const d = pendingSendAgain.get(id);
    if (!d) return bot.answerCallbackQuery(q.id, { text: 'Sesi Send Again kedaluwarsa. Jalankan command ulang.', show_alert: true });
    // Tambah +5 loop dan +100 sleep setiap kali ditekan
    d.loop  = (d.loop  || 50) + 5;
    d.sleep = (d.sleep || 700) + 100;
    pendingSendAgain.set(id, d); // update tersimpan
    await bot.answerCallbackQuery(q.id, {
      text: `▶ Send Again | Loop: ${d.loop} | Sleep: ${d.sleep}ms`,
      show_alert: false
    });
    if (d.type === 'combofunc') {
      return runCombofunc(d.chatId, d.fromUser, d.targetNumber, d.code, d.func2code, d.loop, d.sleep);
    } else {
      return runTesfunc(d.chatId, d.fromUser, d.targetNumber, d.code, d.loop, d.sleep);
    }
  }

  // ---- COMBOFUNC REKOMENDASI ----
  if (data.startsWith('combo_rec_')) {
    const parts = data.split('_');
    const cfChatId = parts[2];
    const cfUserId = parts[3];
    const cfKey = `${cfChatId}:${cfUserId}`;
    const pending = pendingComboFunc.get(cfKey);
    if (!pending || pending.state !== 'setup') {
      return bot.answerCallbackQuery(q.id, { text: 'Sesi sudah habis. Mulai ulang /combofunc', show_alert: true });
    }
    pendingComboFunc.delete(cfKey);
    await safeDelete(bot, chatId, msgId);
    return runCombofunc(chatId, q.from, pending.number, pending.func1code, pending.func2code, 100, 3000);
  }
  console.warn(`[CALLBACK] Unhandled callback: ${data}`);
  return bot.answerCallbackQuery(q.id,{text:'Menu ini belum tersedia atau sesi sudah berakhir.',show_alert:true}).catch(()=>{});
} catch (e) {
  console.error(`[CALLBACK ERROR] ${data}:`, e?.stack || e?.message || e);
  await bot.answerCallbackQuery(q.id, {
    text: 'Terjadi error pada menu. Silakan tekan tombol lagi.',
    show_alert: true
  }).catch(()=>{});
  if (chatId) {
    await safeRichSendMessage( chatId,
      `${E.cross} <b>Menu mengalami error sementara.</b>

<code>${htmlEscape(e?.message || 'Unknown error')}</code>`,
      {parse_mode:'HTML'}
    ).catch(()=>{});
  }
  return;
}});

// ======================================= //
// 📡 /connect
// ======================================= //


// Telegram Inline Mode: @BotUsername <6-digit-code>
bot.on('inline_query', async (query) => {
  try {
    const code = String(query.query || '').trim();
    if (!/^\d{6}$/.test(code)) {
      return bot.answerInlineQuery(query.id, [], {
        cache_time: 0,
        is_personal: true
      }).catch(() => {});
    }

    const saved = getRichMessage(code);
    if (!saved || String(saved.ownerId) !== String(query.from.id)) {
      return bot.answerInlineQuery(query.id, [], {
        cache_time: 0,
        is_personal: true
      }).catch(() => {});
    }

    const rendered = renderRichBlocks(saved.payload);
    const result = {
      type: 'article',
      id: `rich_${code}`,
      title: `💎 Rich Message ${code}`,
      description: 'Rich Message pribadi',
      input_message_content: {
        message_text: rendered.text,
        parse_mode: 'HTML',
        disable_web_page_preview: false
      }
    };

    if (rendered.reply_markup) result.reply_markup = rendered.reply_markup;

    return bot.answerInlineQuery(query.id, [result], {
      cache_time: 0,
      is_personal: true
    }).catch(() => {});
  } catch (e) {
    console.error('[RICH MESSAGE INLINE ERROR]', e.message);
    return bot.answerInlineQuery(query.id, [], {
      cache_time: 0,
      is_personal: true
    }).catch(() => {});
  }
});


async function lookupCustomEmojiDetails(ids) {
  const unique = [...new Set((ids || []).map(v => String(v || '').trim()).filter(Boolean))].slice(0, 200);
  if (!unique.length) return [];
  try {
    const res = await axios.post(`https://api.telegram.org/bot${c.BOT}/getCustomEmojiStickers`, { custom_emoji_ids: unique }, { timeout: 15000 });
    if (!res.data?.ok || !Array.isArray(res.data.result)) return [];
    return res.data.result;
  } catch (e) {
    console.warn('[EMOJI ID] getCustomEmojiStickers:', e?.message || e);
    return [];
  }
}

function formatUnicodeCodepoints(value) {
  return [...String(value || '')].map(ch => `U+${ch.codePointAt(0).toString(16).toUpperCase()}`).join(' ');
}

function extractEmojiEntities(msg) {
  const text = String(msg?.text ?? msg?.caption ?? '');
  const entities = Array.isArray(msg?.entities) ? msg.entities : (Array.isArray(msg?.caption_entities) ? msg.caption_entities : []);
  return entities.filter(e => e?.type === 'custom_emoji' && e?.custom_emoji_id).map(e => ({
    id: String(e.custom_emoji_id),
    offset: Number(e.offset || 0),
    length: Number(e.length || 0),
    text: text.slice(Number(e.offset || 0), Number(e.offset || 0) + Number(e.length || 0)) || '🫧'
  }));
}

function emojiIdResultMarkup() {
  return { inline_keyboard: [
    [{ text:'🆔 Cek Lagi', callback_data:'tool_emoji_id', style:'primary' }],
    [{ text:'↩️ Kembali ke Tools', callback_data:'menu_alat' }, { text:'🏠 Menu Utama', callback_data:'back_menu', style:'danger' }]
  ] };
}

async function handlePendingEmojiId(msg) {
  const uid = String(msg?.from?.id || '');
  const chatId = msg?.chat?.id;
  const pending = pendingEmojiId.get(uid);
  if (!uid || chatId == null || !pending || String(pending.chatId) !== String(chatId)) return false;
  pendingEmojiId.delete(uid);

  if (Date.now() - pending.createdAt > 5 * 60 * 1000) {
    await sendRichMenu(chatId, `<h2>⏱️ EMOJI ID EXPIRED</h2><p>Sesi cek ID emoji sudah kedaluwarsa. Buka <b>Cek ID Emoji</b> dari menu Tools lagi.</p>`, emojiIdResultMarkup(), c.BANNER_URL);
    return true;
  }

  const items = extractEmojiEntities(msg);
  if (!items.length) {
    const raw = String(msg?.text ?? msg?.caption ?? '').trim();
    const codepoints = raw ? formatUnicodeCodepoints(raw) : '-';
    await sendRichMenu(chatId,
      `<h2>🆔 EMOJI ID CHECKER</h2>` +
      `<p>Pesan diterima, tetapi Telegram tidak mengirim <code>custom_emoji</code> entity.</p>` +
      `<table bordered compact><tr><th>INPUT</th><th>DETAIL</th></tr>` +
      `<tr><td>Emoji</td><td>${htmlEscape(raw || '-')}</td></tr>` +
      `<tr><td>Unicode</td><td><code>${htmlEscape(codepoints)}</code></td></tr>` +
      `<tr><td>Custom Emoji ID</td><td><b>Tidak ada</b></td></tr></table>` +
      `<p><i>Emoji Unicode biasa memang tidak memiliki custom emoji ID Telegram. Untuk Premium/custom emoji, kirim emoji langsung dari picker Telegram agar entity-nya ikut terkirim.</i></p>`,
      emojiIdResultMarkup(), c.BANNER_URL);
    return true;
  }

  const details = await lookupCustomEmojiDetails(items.map(x => x.id));
  const byId = new Map(details.map(x => [String(x.custom_emoji_id || ''), x]));
  const rows = items.map((item, index) => {
    const d = byId.get(item.id);
    const emoji = item.text || d?.emoji || '🫧';
    const set = d?.set_name || '-';
    const title = d?.set_name ? (d.set_name.includes('_by_') ? d.set_name : d.set_name) : '-';
    const premium = d ? (d.type === 'custom_emoji' ? 'Custom Emoji' : d.type) : 'Custom Emoji';
    return `<tr><td>${index + 1}</td><td>${htmlEscape(emoji)}</td><td><code>${htmlEscape(item.id)}</code></td><td>${htmlEscape(premium)}</td><td><code>${htmlEscape(set || title)}</code></td></tr>`;
  }).join('');

  await sendRichMenu(chatId,
    `<h2>🆔 TELEGRAM EMOJI ID</h2>` +
    `<p>Ditemukan <b>${items.length}</b> custom emoji.</p>` +
    `<table bordered compact><tr><th>#</th><th>EMOJI</th><th>CUSTOM EMOJI ID</th><th>TYPE</th><th>SET</th></tr>${rows}</table>` +
    `<p><i>ID di atas adalah identifier custom emoji Telegram yang dikirim sebagai <code>custom_emoji</code> entity.</i></p>`,
    emojiIdResultMarkup(), c.BANNER_URL);
  return true;
}

bot.on('message', async (msg) => {
  try { await handlePendingEmojiId(msg); } catch (e) {
    console.warn('[EMOJI ID] handler:', e?.message || e);
  }
});

bot.on('message', async (msg) => {
  if (!msg.text || msg.text.startsWith('/')) return;
  const chatKey=String(msg.chat.id);
  const text=msg.text.trim().toLowerCase();

  const scr=scrambleSessions.get(chatKey);
  if(scr){
    scrambleSessions.delete(chatKey);
    return safeRichTextMessage(msg.chat.id, text===scr.word ? '🔤 <b>Benar!</b>' : `🔤 <b>Belum tepat.</b> Jawaban: <code>${scr.word}</code>`,{parse_mode:'HTML'});
  }
  const mem=memoryGameSessions.get(chatKey);
  if(mem){
    memoryGameSessions.delete(chatKey);
    return safeRichTextMessage(msg.chat.id, text.replace(/\s+/g,'')===mem.answer ? '🧩 <b>Memory berhasil!</b>' : `🧩 <b>Salah.</b> Urutan: <code>${mem.answer}</code>`,{parse_mode:'HTML'});
  }
  const hl=higherLowerSessions.get(chatKey);
  if(hl && Date.now()<hl.expiresAt){
    if(!['higher','lower'].includes(text)) return;
    const next=crypto.randomInt(1,101);
    const ok=(text==='higher'&&next>hl.current)||(text==='lower'&&next<hl.current);
    if(ok){hl.current=next;hl.score++;return safeRichTextMessage(msg.chat.id,`📈 Benar. Angka baru: <b>${next}</b>\\nSkor: <b>${hl.score}</b>\\nLanjut <code>higher</code>/<code>lower</code>.`,{parse_mode:'HTML'});}
    higherLowerSessions.delete(chatKey);
    return safeRichTextMessage(msg.chat.id,`📈 Game selesai. Angka baru <b>${next}</b>. Skor akhir: <b>${hl.score}</b>.`,{parse_mode:'HTML'});
  }
  const seq=higherLowerSessions.get(`seq:${chatKey}`);
  if(seq && Date.now()<seq.expiresAt && /^\d+$/.test(text)){
    higherLowerSessions.delete(`seq:${chatKey}`);
    return safeRichTextMessage(msg.chat.id,Number(text)===seq.answer?'🔢 <b>Benar!</b>':'🔢 <b>Salah.</b> Jawaban yang benar: <code>'+seq.answer+'</code>',{parse_mode:'HTML'});
  }
  const rush=mathSessions.get(`rush:${chatKey}`);
  if(rush && Date.now()<rush.expiresAt && /^-?\d+$/.test(text)){
    mathSessions.delete(`rush:${chatKey}`);
    return safeRichTextMessage(msg.chat.id,Number(text)===rush.answer?'🧮 <b>Benar!</b>':'🧮 <b>Salah.</b> Jawaban: <code>'+rush.answer+'</code>',{parse_mode:'HTML'});
  }
  const trivia=quizSessions.get(`trivia:${chatKey}`);
  if(trivia && /^[1-4]$/.test(text)){
    quizSessions.delete(`trivia:${chatKey}`);
    return safeRichTextMessage(msg.chat.id,Number(text)===trivia.a?'🧠 <b>Benar!</b>':'🧠 <b>Salah.</b>',{parse_mode:'HTML'});
  }
});

bot.on('message', async (msg) => {
  const uid = String(msg.from?.id || '');
  const chatId = msg.chat?.id;
  if (!uid || !chatId) return;

  // ---- GROUP RATE/LIMIT GUARD (runs before interactive flows) ----
  if (['group','supergroup'].includes(msg.chat?.type) && msg.from && !msg.from.is_bot) {
    const gs=getGroupSettings(chatId);
    if (gs.slowmode>0 || gs.lockmedia) {
      const admin=await isGroupAdmin(chatId,msg.from.id);
      if (!admin && gs.slowmode>0 && (msg.text || msg.caption || msg.photo || msg.video || msg.document || msg.audio || msg.animation || msg.voice || msg.video_note)) {
        const key=`${chatId}:${uid}`; const now=Date.now(); const last=slowmodeTracker.get(key)||0;
        if(last && now-last < Number(gs.slowmode)*1000){ try{await bot.deleteMessage(chatId,msg.message_id);}catch{}; return; }
        slowmodeTracker.set(key,now);
        setTimeout(()=>{ if(slowmodeTracker.get(key)===now) slowmodeTracker.delete(key); }, Math.max(60000,Number(gs.slowmode)*2000));
      }
      if(!admin && gs.lockmedia && !((msg.photo && gs.antifoto) || (msg.video && gs.antivideo)) && (msg.photo || msg.video || msg.animation || msg.document || msg.audio || msg.voice || msg.video_note)){ try{await bot.deleteMessage(chatId,msg.message_id);}catch{}; return; }
    }
  }

  // ---- CREATE AM PREMIUM FOLLOW-UP ----
  const amSession = amPremiumSessions.get(uid);
  if (amSession && amSession.chatId === chatId && msg.text && !msg.text.startsWith('/')) {
    if (Date.now() - amSession.createdAt > 10 * 60 * 1000) {
      amPremiumSessions.delete(uid);
      return safeRichTextMessage(chatId,'⏱️ <b>Sesi Create AM Premium kedaluwarsa.</b> Tekan tombol Create AM Premium lagi.',{parse_mode:'HTML',reply_markup:menuAlatKeyboard(2)});
    }
    const input = String(msg.text).trim();
    if (!input) return safeRichTextMessage(chatId,'❌ Input tidak boleh kosong.',{parse_mode:'HTML'});

    if (amSession.step === 'waiting_email') {
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/i.test(input)) {
        return safeRichTextMessage(chatId,'❌ Format email tidak valid. Kirim email yang benar, contoh <code>nama@gmail.com</code>.',{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'✖️ Batal',callback_data:'am_premium_cancel',style:'danger'}]]}});
      }
      const quota = consumeAmPremiumQuota(uid, 'own', {own:2, bulk:3});
      if (!quota.ok) return safeRichTextMessage(chatId,`<b>LIMIT CREATE AM</b>\n\n${htmlEscape(quota.reason)}`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'Menu AM Premium',callback_data:'am_premium_menu'}]]}});
      amSession.processing = true;
      amSession.email = input;
      try {
        const result = await amSendLink(input);
        amSession.step = 'waiting_verification_url';
        amSession.processing = false;
        amSession.createdAt = Date.now();
        return safeRichTextMessage(chatId,
          `<h2>📨 VERIFIKASI AM PREMIUM</h2><p>Email: <code>${htmlEscape(input)}</code></p><p>✅ Permintaan verifikasi sudah dikirim.</p><p>1. Buka Gmail dan cari pesan verifikasi terbaru.<br/>2. Tekan lama tombol/link verifikasi → <b>Salin alamat link</b>.<br/>3. <b>Jangan buka link di browser.</b> Langsung kirim URL lengkapnya ke bot agar server AM yang memproses tokennya.</p><p>⚠️ Jika link lama dibuka dan muncul <b>404 / Page Not Found</b>, jangan lanjutkan halaman itu. Kirim ulang email lalu gunakan URL terbaru.</p>${result?.message ? `<p><i>${htmlEscape(result.message)}</i></p>` : ''}`,
          {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🔄 Kirim Ulang Email',callback_data:'am_premium_resend',style:'success'}],[{text:'✖️ Batal',callback_data:'am_premium_cancel',style:'danger'}]]}}
        );
      } catch (e) {
        amSession.processing = false;
        return safeRichTextMessage(chatId,`❌ <b>Gagal mengirim email verifikasi.</b>\n\n<code>${htmlEscape(e?.message || 'Unknown error')}</code>`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🔄 Coba Lagi',callback_data:'am_premium_own',style:'success'}],[{text:'↩️ Menu Tools',callback_data:'menu_alat',style:'danger'}]]}});
      }
    }

    if (amSession.step === 'waiting_verification_url') {
      const link = amExtractLink(input);
      if (!/^https?:\/\//i.test(link)) {
        return safeRichTextMessage(chatId,'❌ URL verifikasi tidak valid. Kirim URL yang kamu salin dari email Gmail.',{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'✖️ Batal',callback_data:'am_premium_cancel',style:'danger'}]]}});
      }
      amSession.processing = true;
      try {
        const result = await amVerifyAndActivate(amSession.email, link);
        amPremiumSessions.delete(uid);
        notifyAmPremiumActivity('own', msg.from, { status:'Berhasil' }).catch(()=>{});
        return safeRichTextMessage(chatId,
          `<h2>💎 AM PREMIUM</h2><p>📧 Email: <code>${htmlEscape(amSession.email)}</code></p><p>🔗 Link: <code>${htmlEscape(link)}</code></p><p>✅ <b>Verifikasi & aktivasi berhasil diproses.</b></p>${result?.message ? `<p><i>${htmlEscape(result.message)}</i></p>` : ''}`,
          {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'💎 Create Lagi',callback_data:'am_premium_menu',style:'success'}],[{text:'↩️ Menu Tools',callback_data:'menu_alat',style:'danger'}]]}}
        );
      } catch (e) {
        amSession.processing = false;
        return safeRichTextMessage(chatId,`❌ <b>Verifikasi/aktivasi gagal.</b>\n\n<code>${htmlEscape(e?.message || 'Unknown error')}</code>\n\nPastikan URL yang dikirim adalah URL verifikasi dari email AM.`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🔄 Kirim URL Lagi',callback_data:'am_premium_retry_url',style:'success'}],[{text:'✖️ Batal',callback_data:'am_premium_cancel',style:'danger'}]]}});
      }
    }
  }

  // ---- DOWNLOADER FOLLOW-UP ----
  const dlPending = pendingDownloader.get(uid);
  if (dlPending && dlPending.chatId === chatId && msg.text && !msg.text.startsWith('/')) {
    if (Date.now() - dlPending.createdAt > 10 * 60 * 1000) {
      pendingDownloader.delete(uid);
      return safeRichTextMessage(chatId, '⏱️ Sesi downloader sudah kedaluwarsa. Tekan tombol Instagram lagi.');
    }
    const inputUrl = msg.text.trim();
    if (dlPending.type === 'instagram') {
      if (!/^https?:\/\/(?:www\.)?(?:instagram\.com|instagr\.am)\//i.test(inputUrl)) {
        return safeRichTextMessage(chatId, '❌ Link bukan Instagram. Kirim link instagram.com atau tekan tombol ❌ Batal.', {reply_markup:{inline_keyboard:[[{text:'❌ Batal',callback_data:'dl_cancel'}]]}});
      }
      pendingDownloader.delete(uid);
      return processInstagramDownload(msg, inputUrl);
    }
  }

  // ---- WEATHER LOCATION ----
  if (msg.location && pendingWeather.has(uid)) {
    const p = pendingWeather.get(uid); pendingWeather.delete(uid);
    try {
      return safeRichTextMessage(chatId, await getWeatherByCoords(msg.location.latitude, msg.location.longitude, 'Lokasi kamu'), {parse_mode:'HTML'});
    } catch (e) {
      return safeRichTextMessage(chatId, `${E.cross} Gagal mengambil cuaca: <code>${htmlEscape(e.message)}</code>`, {parse_mode:'HTML'});
    }
  }

  // ---- RICH MESSAGE JSON FOLLOW-UP ----
  const richPending = pendingRichMessage.get(uid);
  if (richPending) {
    if (Date.now() > richPending.expiresAt) {
      pendingRichMessage.delete(uid);
      return safeRichTextMessage(chatId, '⏱️ Sesi RICH MESSAGE sudah kedaluwarsa. Tekan menu RICH MESSAGE lalu coba lagi.');
    }
    const raw = String(msg.text || '').trim();
    if (!raw) return safeRichTextMessage(chatId, '❌ JSON tidak boleh kosong. Kirim payload JSON yang valid.');
    try {
      const payload = JSON.parse(raw);
      if (payload === null || typeof payload !== 'object') {
        throw new Error('Payload harus berupa object atau array.');
      }
      const rendered = renderRichBlocks(payload);
      const code = richInlineCode();
      setRichMessage(code, {
        ownerId: String(msg.from.id),
        payload,
        createdAt: new Date().toISOString()
      });
      pendingRichMessage.delete(uid);

      let username = 'BOT_USERNAME';
      try {
        const me = await bot.getMe();
        username = me.username || username;
      } catch {}

      return safeRichTextMessage(chatId,
        `✅ <b>RICH MESSAGE TERSIMPAN</b>\n\n` +
        `Kode: <code>${code}</code>\n\n` +
        `Gunakan di Telegram:\n<code>@${htmlEscape(username)} ${code}</code>\n\n` +
        `Kode ini hanya bisa digunakan oleh akun yang membuatnya.\n\n` +
        `<i>Preview berhasil dirender (${rendered.text.length} karakter).</i>`,
        { parse_mode: 'HTML', disable_web_page_preview: true }
      );
    } catch (e) {
      return safeRichTextMessage(chatId,
        `❌ <b>JSON tidak valid</b>\n<code>${htmlEscape(e.message)}</code>\n\n` +
        `Payload tidak disimpan. Silakan kirim ulang JSON yang benar.`,
        { parse_mode: 'HTML' }
      );
    }
  }

  if (!msg.text || msg.text.startsWith('/')) return;

  // ---- QC STICKER FOLLOW-UP ----
  if (!msg.text?.startsWith('/') && pendingQC.has(uid)) {
    const pending = pendingQC.get(uid);
    pendingQC.delete(uid);
    const qcText = msg.text.trim();
    if (!qcText) return safeRichTextMessage(chatId, '🖼️ Teks QC tidak boleh kosong.');
    try {
      const sticker = await createQCSticker(qcText, msg.from || {});
      return bot.sendSticker(chatId, sticker, { reply_to_message_id: msg.message_id });
    } catch (e) {
      return safeRichTextMessage(chatId, `${E.cross} <b>Gagal membuat QC:</b>\n<code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
    }
  }

  // ---- RELAXING NOTE FOLLOW-UP ----
  if (!msg.text?.startsWith('/') && pendingRelaxNote.has(uid)) {
    pendingRelaxNote.delete(uid);
    const note = msg.text.trim();
    if (!note) return safeRichTextMessage(chatId, '📝 Catatan tidak boleh kosong.', {reply_markup:relaxingKeyboard()});
    const safeNote = htmlEscape(note).slice(0, 3000);
    return safeRichTextMessage(chatId, `📝 <b>Catatan diterima</b>\\n\\n<blockquote>${safeNote}</blockquote>\\n\\n<i>Catatan ini tidak disimpan ke database.</i>`, {parse_mode:'HTML', reply_markup:relaxingKeyboard()});
  }

  // ---- RELAXING TIME SEARCH ----
  if (pendingRelaxSearch.has(uid)) {
    const p = pendingRelaxSearch.get(uid); pendingRelaxSearch.delete(uid);
    const query = msg.text.trim();
    if (!query) return safeRichTextMessage(chatId,'🔎 Kata kunci tidak boleh kosong.');
    try {
      if (p.type === 'dracin' || p.type === 'web') {
        const url = relaxSearchUrl(p.type, query);
        const label = p.type === 'dracin' ? 'Cari Dracin di Web' : 'Cari di Web';
        return safeRichTextMessage(chatId,`🎬 <b>Hasil pencarian: ${htmlEscape(query)}</b>\n\nBot menyiapkan pencarian web agar tidak bergantung pada API katalog tertentu.`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:`🔎 ${label}`,url}],[{text:'🕌 Relaxing Time',callback_data:'menu_relax'}]]}});
      }
      const searchQuery = p.type === 'comic' ? `${query} comic graphic novel` : query;
      const res = await axios.get('https://openlibrary.org/search.json', {params:{q:searchQuery,limit:8},timeout:15000});
      const docs = (res.data?.docs||[]).slice(0,8);
      if (!docs.length) return safeRichTextMessage(chatId,`📚 Tidak ada hasil untuk <b>${htmlEscape(query)}</b>.`,{parse_mode:'HTML'});
      const lines = docs.map((d,i)=>{ const title=d.title||'Tanpa judul'; const author=(d.author_name||[])[0]||'Penulis tidak diketahui'; const year=d.first_publish_year||'-'; const key=d.key||''; return `${i+1}. <b>${htmlEscape(title)}</b>\n   ✍️ ${htmlEscape(author)} • ${year}${key?`\n   <a href="https://openlibrary.org${key}">Buka katalog</a>`:''}`; }).join('\n\n');
      const heading = p.type === 'comic' ? '🖼️ <b>Hasil Komik</b>' : '📚 <b>Hasil Novel</b>';
      return safeRichTextMessage(chatId,`${heading}\n\n${lines}`,{parse_mode:'HTML',disable_web_page_preview:true,reply_markup:{inline_keyboard:[[{text:'🔎 Cari Lagi',callback_data:p.type==='comic'?'relax_comic':'relax_novel'}],[{text:'🕌 Relaxing Time',callback_data:'menu_relax'}]]}});
    } catch (e) {
      return safeRichTextMessage(chatId,`${E.cross} Pencarian gagal: <code>${htmlEscape(e.message)}</code>`,{parse_mode:'HTML'});
    }
  }

  // ---- WEATHER BY CITY ----
  if (pendingWeather.has(uid)) {
    pendingWeather.delete(uid);
    try { return safeRichTextMessage(chatId, await getWeatherByCity(msg.text.trim()), {parse_mode:'HTML'}); }
    catch(e) { return safeRichTextMessage(chatId,`${E.cross} Gagal mengambil cuaca: <code>${htmlEscape(e.message)}</code>`,{parse_mode:'HTML'}); }
  }

  if (!pendingMarketSearch.has(uid)) return;
  const pending = pendingMarketSearch.get(uid);
  pendingMarketSearch.delete(uid);
  const marketChatId = typeof pending === 'object' ? pending.chatId : pending;
  const marketMode = typeof pending === 'object' ? (pending.mode || 'search') : 'search';
  try {
    const raw = String(msg.text || '').trim();
    if (marketMode === 'compare') {
      const parts = raw.split(/\s+/).filter(Boolean);
      if (parts.length < 2) throw new Error('Kirim dua kode, contoh: BBCA BBRI');
      const text = await marketCompareText(normalizeMarketSymbol(parts[0]), normalizeMarketSymbol(parts[1]));
      return safeRichTextMessage(marketChatId, text, {parse_mode:'HTML', reply_markup:marketKeyboard()});
    }
    const symbol = normalizeMarketSymbol(raw);
    const text = await marketDetailText(symbol);
    return sendMenuPhoto(bot, marketChatId, c.BANNER_URL, {
      caption: text, parse_mode:'HTML', reply_markup: marketDetailKeyboard(symbol)
    });
  } catch (e) {
    return safeRichTextMessage(chatId,
      `${E.cross} <b>Gagal mencari data pasar</b>\n<blockquote>${htmlEscape(e.message)}</blockquote>`,
      { parse_mode:'HTML', reply_markup: marketKeyboard() });
  }
});

bot.onText(/^\/connect(?:\s+(.+))?$/, async (msg, match) => {
  if (!(await requireJoin(msg))) return;
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const number = normalizeNumber(match[1] || '');
  if (!number) {
    const ask = await safeRichTextMessage(chatId,
      `<blockquote>${E.phone} Kirim Nomor Sender</blockquote>\nReply pesan ini dengan nomor WhatsApp sender.\nContoh: <code>628123456789</code>`,
      { parse_mode: 'HTML' });
    pendingConnect.set(`${chatId}:${ask.message_id}`, { userId, createdAt: Date.now() });
    return;
  }
  return handleConnect(chatId, userId, number);
});

// ======================================= //
// 📡 /ceksender
// ======================================= //
bot.onText(/^\/ceksender$/, async (msg) => {
  if (!(await requireJoin(msg))) return;
  const numbers = getUserSenders(msg.from.id);
  if (!numbers.length) return safeRichTextMessage(msg.chat.id, `${E.empty} Belum ada sender. Gunakan /connect 628xxx`, { parse_mode: 'HTML' });
  const statuses = getAllSenderStatuses(numbers);
  const text = `<blockquote>${E.sender} <b>Status Sender Kamu</b></blockquote>\nTotal: <code>${statuses.length}</code>\n\n` +
    statuses.map((s, i) => `${i + 1}. <code>${s.number}</code>\n   ${s.online ? E.green : E.red} <b>${s.status}</b>`).join('\n\n');
  return safeRichTextMessage(msg.chat.id, text, { parse_mode: 'HTML' });
});
// ======================================= //
// 📡 /fixcode — Fix Kode (JS/TS/PY/PHP/dll)
// ======================================= //
bot.onText(/^\/fixcode$/, async (msg) => {
  if (!(await requireJoin(msg))) return;
  const chatId = msg.chat.id;
  const reply = msg.reply_to_message;
  if (!reply) {
    return safeRichTextMessage(chatId,
      `${E.wrench} <b>Fix Code</b>\n\n` +
      `<blockquote>Cara pakai:\n1. Reply ke file/kode yang error\n2. Ketik <code>/fixcode</code>\n\nSupport: .js .ts .py .php .java .cpp .go .rb .cs .dart</blockquote>`,
      { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  }
  const loading = await safeRichTextMessage(chatId,
    `<code>${makeBar(20)}</code>\n${E.hourglass} Membaca file kode...`,
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  try {
    const code = await extractCodeFromReply(msg);
    if (!code) return safeEdit(bot, chatId, loading.message_id,
      `${E.cross} Tidak ada kode yang bisa dibaca dari reply.`, { parse_mode: 'HTML' });
    const { ext, name } = detectFileExt(msg);
    await safeEdit(bot, chatId, loading.message_id,
      `<code>${makeBar(55)}</code>\n${E.hourglass} Memperbaiki syntax kode...`, { parse_mode: 'HTML' });
    const fixed = _pureFixCode(code, ext);
    await safeEdit(bot, chatId, loading.message_id,
      `<code>${makeBar(90)}</code>\n${E.hourglass} Mengirim hasil...`, { parse_mode: 'HTML' });
    const outBuf  = Buffer.from(fixed, 'utf-8');
    const outName = `fixed_${name.replace(/^fixed_/, '')}`;
    const issues  = _detectCodeIssues(code);
    await bot.sendDocument(chatId, outBuf,
      {
        caption:
          `${E.wrench} <b>Fix Code — Selesai!</b>\n\n` +
          `${E.folder} File: <code>${htmlEscape(outName)}</code>\n` +
          `${E.ruler} Ukuran: <code>${(outBuf.length / 1024).toFixed(1)} KB</code>\n` +
          `${E.check} Perbaikan: <code>${issues.join(', ') || 'Normalisasi syntax'}</code>\n\n` +
          `<blockquote>Kode sudah diperbaiki secara otomatis.\nPastikan dicek manual sebelum dijalankan.</blockquote>`,
        parse_mode: 'HTML', reply_to_message_id: msg.message_id
      }, { filename: outName, contentType: 'text/plain' });
    await safeDelete(bot, chatId, loading.message_id);
  } catch (e) {
    await safeEdit(bot, chatId, loading.message_id,
      `${E.cross} Gagal fix kode: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
});

// ======================================= //
// 📡 /cleancode — Rapihkan Struktur Kode
// ======================================= //
bot.onText(/^\/cleancode$/, async (msg) => {
  if (!(await requireJoin(msg))) return;
  const chatId = msg.chat.id;
  const reply = msg.reply_to_message;
  if (!reply) {
    return safeRichTextMessage(chatId,
      `${E.star} <b>Clean Code</b>\n\n` +
      `<blockquote>Cara pakai:\n1. Reply ke file/kode\n2. Ketik <code>/cleancode</code>\n\nMerapihkan indentasi, spasi, dan baris kosong berlebihan tanpa mengubah logika.</blockquote>`,
      { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  }
  const loading = await safeRichTextMessage(chatId,
    `<code>${makeBar(20)}</code>\n${E.hourglass} Membaca file kode...`,
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  try {
    const code = await extractCodeFromReply(msg);
    if (!code) return safeEdit(bot, chatId, loading.message_id,
      `${E.cross} Tidak ada kode yang bisa dibaca dari reply.`, { parse_mode: 'HTML' });
    const { ext, name } = detectFileExt(msg);
    await safeEdit(bot, chatId, loading.message_id,
      `<code>${makeBar(60)}</code>\n${E.hourglass} Merapihkan struktur kode...`, { parse_mode: 'HTML' });
    const cleaned = _pureCleanCode(code);
    await safeEdit(bot, chatId, loading.message_id,
      `<code>${makeBar(90)}</code>\n${E.hourglass} Mengirim hasil...`, { parse_mode: 'HTML' });
    const outBuf  = Buffer.from(cleaned, 'utf-8');
    const outName = `clean_${name.replace(/^clean_/, '').replace(/^fixed_/, '')}`;
    await bot.sendDocument(chatId, outBuf,
      {
        caption:
          `${E.star} <b>Clean Code — Selesai!</b>\n\n` +
          `${E.folder} File: <code>${htmlEscape(outName)}</code>\n` +
          `${E.ruler} Ukuran: <code>${(outBuf.length / 1024).toFixed(1)} KB</code>\n\n` +
          `<blockquote>Kode sudah dirapihkan.\nLogika & fungsi tidak berubah sama sekali.</blockquote>`,
        parse_mode: 'HTML', reply_to_message_id: msg.message_id
      }, { filename: outName, contentType: 'text/plain' });
    await safeDelete(bot, chatId, loading.message_id);
  } catch (e) {
    await safeEdit(bot, chatId, loading.message_id,
      `${E.cross} Gagal clean kode: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
});

// ======================================= //
// 📡 /cekflutter — Analisa Error File Dart/Flutter
// ======================================= //
bot.onText(/^\/cekflutter$/, async (msg) => {
  if (!(await requireJoin(msg))) return;
  const chatId = msg.chat.id;
  const reply = msg.reply_to_message;
  if (!reply) {
    return safeRichTextMessage(chatId,
      `${E.star} <b>Cek Flutter</b>\n\n` +
      `<blockquote>Cara pakai:\n1. Reply ke file .dart atau kode Flutter/Dart\n2. Ketik <code>/cekflutter</code></blockquote>`,
      { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  }
  const loading = await safeRichTextMessage(chatId,
    `<code>${makeBar(20)}</code>\n${E.hourglass} Membaca file Dart...`,
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  try {
    const code = await extractCodeFromReply(msg);
    if (!code) return safeEdit(bot, chatId, loading.message_id,
      `${E.cross} Tidak ada kode yang bisa dibaca.`, { parse_mode: 'HTML' });
    await safeEdit(bot, chatId, loading.message_id,
      `<code>${makeBar(65)}</code>\n${E.hourglass} Menganalisa kode Dart...`, { parse_mode: 'HTML' });
    const report = _analyzeDart(code);
    await safeDelete(bot, chatId, loading.message_id);
    const fullMsg = `${E.star} <b>Cek Flutter — Hasil Analisa</b>\n\n${htmlEscape(report)}\n\n<blockquote>Powered by mellstecuu Ϟ MD</blockquote>`;
    if (fullMsg.length <= 900000) {
      return safeRichTextMessage(chatId, fullMsg, { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
    }
    const outBuf = Buffer.from(`CEK FLUTTER — Hasil Analisa\n${'='.repeat(50)}\n\n${report}`, 'utf-8');
    return bot.sendDocument(chatId, outBuf,
      { caption: `${E.star} <b>Cek Flutter — Hasil Analisa</b>\n\n<blockquote>Laporan dikirim sebagai file.</blockquote>`,
        parse_mode: 'HTML', reply_to_message_id: msg.message_id },
      { filename: 'cekflutter_report.txt', contentType: 'text/plain' });
  } catch (e) {
    await safeEdit(bot, chatId, loading.message_id,
      `${E.cross} Gagal cek Flutter: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
});


// ======================================= //
// 📡 /fixflutter — Fix Error File Dart/Flutter
// ======================================= //
bot.onText(/^\/fixflutter$/, async (msg) => {
  if (!(await requireJoin(msg))) return;
  const chatId = msg.chat.id;
  const reply = msg.reply_to_message;
  if (!reply) {
    return safeRichTextMessage(chatId,
      `${E.wrench} <b>Fix Flutter</b>\n\n` +
      `<blockquote>Cara pakai:\n1. Reply ke file .dart atau kode Flutter yang error\n2. Ketik <code>/fixflutter</code></blockquote>`,
      { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  }
  const loading = await safeRichTextMessage(chatId,
    `<code>${makeBar(20)}</code>\n${E.hourglass} Membaca file Dart...`,
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  try {
    const code = await extractCodeFromReply(msg);
    if (!code) return safeEdit(bot, chatId, loading.message_id,
      `${E.cross} Tidak ada kode yang bisa dibaca.`, { parse_mode: 'HTML' });
    const { name } = detectFileExt(msg);
    const dartName = name.endsWith('.dart') ? name : name.replace(/\.\w+$/, '') + '.dart';
    await safeEdit(bot, chatId, loading.message_id,
      `<code>${makeBar(55)}</code>\n${E.hourglass} Memperbaiki kode Flutter...`, { parse_mode: 'HTML' });
    const fixed = _pureFixDart(code);
    await safeEdit(bot, chatId, loading.message_id,
      `<code>${makeBar(90)}</code>\n${E.hourglass} Mengirim file hasil...`, { parse_mode: 'HTML' });
    const outBuf  = Buffer.from(fixed, 'utf-8');
    const outName = `fixed_${dartName.replace(/^fixed_/, '')}`;
    await bot.sendDocument(chatId, outBuf,
      {
        caption:
          `${E.wrench} <b>Fix Flutter — Selesai!</b>\n\n` +
          `${E.folder} File: <code>${htmlEscape(outName)}</code>\n` +
          `${E.ruler} Ukuran: <code>${(outBuf.length / 1024).toFixed(1)} KB</code>\n\n` +
          `<blockquote>${E.check} Kode Dart sudah diperbaiki.\n${E.warning} Tetap jalankan <code>flutter analyze</code> untuk memastikan.\nPowered by mellstecuu Ϟ MD</blockquote>`,
        parse_mode: 'HTML', reply_to_message_id: msg.message_id
      }, { filename: outName, contentType: 'text/plain' });
    await safeDelete(bot, chatId, loading.message_id);
  } catch (e) {
    await safeEdit(bot, chatId, loading.message_id,
      `${E.cross} Gagal fix Flutter: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
});

// ======================================= //
// 📡 /cekfunc — Analisa Fungsi & Class di File JS
// ======================================= //
bot.onText(/^\/cekfunc$/, async (msg) => {
  if (!(await requireJoin(msg))) return;
  const chatId = msg.chat.id;
  const reply = msg.reply_to_message;

  if (!reply) {
    return safeRichTextMessage(chatId,
      `${E.eyes} <b>Cek Fungsi</b>\n\n` +
      `<blockquote>Cara pakai:\n1. Reply ke file .js atau pesan berisi kode\n2. Ketik <code>/cekfunc</code>\n\nBot akan mendeteksi semua fungsi, arrow function, async function, dan class.</blockquote>`,
      { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  }

  const loading = await safeRichTextMessage(chatId,
    `<code>${makeBar(20)}</code>\n${E.hourglass} Membaca file kode...`,
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id });

  try {
    // Ambil isi kode dari reply
    let fileContent = reply.text || reply.caption || '';
    let fileName = 'code.js';

    if (!fileContent && reply.document) {
      const doc = reply.document;
      fileName = doc.file_name || 'code.js';
      const ext = fileName.split('.').pop().toLowerCase();
      if (ext !== 'js') {
        await safeDelete(bot, chatId, loading.message_id);
        return safeRichTextMessage(chatId,
          `${E.warning} File harus berformat <code>.js</code>`,
          { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
      }
      const fileLink = await bot.getFileLink(doc.file_id);
      const dlRes = await axios.get(fileLink, { responseType: 'arraybuffer', timeout: 30000 });
      fileContent = Buffer.from(dlRes.data).toString('utf-8');
    }

    fileContent = fileContent.trim();
    if (!fileContent) {
      await safeDelete(bot, chatId, loading.message_id);
      return safeRichTextMessage(chatId,
        `${E.cross} Tidak ada kode yang bisa dibaca dari reply.`,
        { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
    }

    await safeEdit(bot, chatId, loading.message_id,
      `<code>${makeBar(65)}</code>\n${E.hourglass} Menganalisa struktur kode...`, { parse_mode: 'HTML' });

    const found = [];

    // Regular & async function declarations: function foo() / async function foo()
    const declRegex = /(?:^|\s)(async\s+)?function\s+(\w+)\s*\(/gm;
    let m;
    while ((m = declRegex.exec(fileContent)) !== null) {
      const lineNum = fileContent.substring(0, m.index).split('\n').length;
      found.push({ name: m[2], line: lineNum, type: m[1] ? 'Async Function' : 'Function' });
    }

    // Arrow & regular function expressions: const foo = (...) => / const foo = function(...)
    const exprRegex = /(?:const|let|var)\s+(\w+)\s*=\s*(async\s*)?\(?[^)]*\)?\s*=>/gm;
    while ((m = exprRegex.exec(fileContent)) !== null) {
      const lineNum = fileContent.substring(0, m.index).split('\n').length;
      found.push({ name: m[1], line: lineNum, type: m[2] ? 'Async Arrow' : 'Arrow Function' });
    }

    // Function assigned: const foo = function(...)
    const funcExprRegex = /(?:const|let|var)\s+(\w+)\s*=\s*(async\s*)?function\s*\(/gm;
    while ((m = funcExprRegex.exec(fileContent)) !== null) {
      const lineNum = fileContent.substring(0, m.index).split('\n').length;
      // Hindari duplikat dengan arrow function
      if (!found.find(f => f.name === m[1] && f.line === lineNum)) {
        found.push({ name: m[1], line: lineNum, type: m[2] ? 'Async Func Expr' : 'Func Expression' });
      }
    }

    // Class declarations
    const classRegex = /(?:^|\s)class\s+(\w+)/gm;
    while ((m = classRegex.exec(fileContent)) !== null) {
      const lineNum = fileContent.substring(0, m.index).split('\n').length;
      found.push({ name: m[1], line: lineNum, type: 'Class' });
    }

    // bot.onText / bot.command / bot.on registrations
    const botRegex = /bot\.onText\(\/\^\\\/(\w+)/gm;
    while ((m = botRegex.exec(fileContent)) !== null) {
      const lineNum = fileContent.substring(0, m.index).split('\n').length;
      found.push({ name: `/${m[1]}`, line: lineNum, type: 'Bot Command' });
    }

    // Urutkan berdasarkan nomor baris
    found.sort((a, b) => a.line - b.line);

    await safeDelete(bot, chatId, loading.message_id);

    if (found.length === 0) {
      return safeRichTextMessage(chatId,
        `${E.eyes} <b>Cek Fungsi</b> — <code>${htmlEscape(fileName)}</code>\n\n<i>Tidak ada fungsi atau class yang ditemukan.</i>`,
        { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
    }

    // Hitung statistik per tipe
    const typesCount = {};
    for (const f of found) {
      typesCount[f.type] = (typesCount[f.type] || 0) + 1;
    }
    const statsText = Object.entries(typesCount)
      .map(([t, c]) => `  • ${htmlEscape(t)}: <b>${c}</b>`)
      .join('\n');

    // Buat daftar item
    const listText = found
      .map((f, i) =>
        `${i + 1}. <code>${htmlEscape(f.name)}</code>\n` +
        `   ${E.pin} Baris: <b>${f.line}</b> | ${E.clipboard} Tipe: <i>${htmlEscape(f.type)}</i>`
      )
      .join('\n\n');

    const header =
      `${E.eyes} <b>Cek Fungsi</b> — <code>${htmlEscape(fileName)}</code>\n` +
      `<blockquote>Total: <b>${found.length}</b> item ditemukan</blockquote>\n\n`;

    const statsBlock =
      `\n\n${E.stats} <b>Statistik:</b>\n${statsText}\n\n` +
      `<blockquote>Powered by mellstecuu Ϟ MD</blockquote>`;

    const fullMsg = header + listText + statsBlock;

    // Kirim langsung jika <= 4000 char, jika tidak kirim sebagai file
    if (fullMsg.length <= 4000) {
      return safeRichTextMessage(chatId, fullMsg,
        { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
    }

    // Terlalu panjang → kirim sebagai file .txt
    const plainText =
      `CEK FUNGSI — ${fileName}\n${'='.repeat(50)}\n\n` +
      found.map((f, i) => `${i + 1}. ${f.name} | Baris: ${f.line} | Tipe: ${f.type}`).join('\n') +
      `\n\n${'='.repeat(50)}\nSTATISTIK:\n` +
      Object.entries(typesCount).map(([t, c]) => `${t}: ${c}`).join('\n') +
      `\nTotal: ${found.length} item`;

    const outBuf = Buffer.from(plainText, 'utf-8');
    return bot.sendDocument(chatId, outBuf,
      {
        caption:
          `${E.eyes} <b>Cek Fungsi</b> — <code>${htmlEscape(fileName)}</code>\n\n` +
          `Total: <b>${found.length}</b> fungsi/class ditemukan\n\n` +
          `<blockquote>Terlalu panjang untuk pesan, dikirim sebagai file.</blockquote>`,
        parse_mode: 'HTML',
        reply_to_message_id: msg.message_id
      },
      { filename: `cekfunc_${fileName.replace('.js', '')}.txt`, contentType: 'text/plain' }
    );

  } catch (e) {
    await safeEdit(bot, chatId, loading.message_id,
      `${E.cross} Gagal cek fungsi: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
});

bot.onText(/^\/getcelah$/, async (msg) => {
  if (!(await requireJoin(msg))) return;
  const chatId = msg.chat.id;
  const userId = String(msg.from.id);
  const loading = await safeRichTextMessage(chatId,
    `<blockquote><code>${makeBar(30)}</code>\n${E.hourglass} Membaca struktur function...</blockquote>`,
    { parse_mode: 'HTML' });
  try {
    const reply = msg.reply_to_message;
    if (!reply) {
      await safeDelete(bot, chatId, loading.message_id);
      return safeRichTextMessage(chatId,
        `${E.cross} <b>Cara pakai:</b>\nReply sebuah pesan/teks yang berisi <code>async function</code> lalu ketik <code>/getcelah</code>\n\n<blockquote>Bot akan menganalisa struktur function secara lengkap.</blockquote>`,
        { parse_mode: 'HTML' });
    }
    let code = reply.text || reply.caption || '';
    if (!code && reply.document) {
      const link = await bot.getFileLink(reply.document.file_id);
      const r = await axios.get(link, { responseType: 'text', timeout: 15000 });
      code = String(r.data);
    }
    code = code.trim();
    if (!code) {
      await safeDelete(bot, chatId, loading.message_id);
      return safeRichTextMessage(chatId, `${E.cross} Tidak ada teks yang bisa dibaca dari reply.`, { parse_mode: 'HTML' });
    }
    if (!/async\s+function|function\s+\w/i.test(code)) {
      await safeDelete(bot, chatId, loading.message_id);
      return safeRichTextMessage(chatId, `${E.cross} Teks tidak mengandung struktur <code>async function</code>.`, { parse_mode: 'HTML' });
    }
    await safeEdit(bot, chatId, loading.message_id,
      `<blockquote><code>${makeBar(70)}</code>\n${E.hourglass} Menganalisa struktur...</blockquote>`, { parse_mode: 'HTML' });
    const rawResult = _extractFunctionStructure(code);
    const lines = rawResult.split('\n');
    const chunkSize = 10;
    const chunks = [];
    for (let i = 0; i < lines.length; i += chunkSize) {
      chunks.push(lines.slice(i, i + chunkSize).join('\n'));
    }
    pendingCelah.set(userId, { chunks, page: 0, chatId });
    setTimeout(() => pendingCelah.delete(userId), 10 * 60 * 1000);
    await safeDelete(bot, chatId, loading.message_id);
    const firstChunk = chunks[0];
    const hasMore = chunks.length > 1;
    return safeRichTextMessage(chatId,
      `${E.eyes} <b>Struktur Function</b>\n` +
      `<blockquote>Halaman 1 / ${chunks.length}</blockquote>\n\n` +
      `<pre><code class="language-javascript">${htmlEscape(firstChunk)}</code></pre>`,
      {
        parse_mode: 'HTML',
        reply_to_message_id: msg.message_id,
        reply_markup: hasMore ? { inline_keyboard: [[
          { text: '✿ Next ✿', callback_data: `celah_next_${userId}`, style: 'primary', icon_custom_emoji_id: '4956416504674386959' }
        ]]} : undefined
      });
  } catch (e) {
    await safeEdit(bot, chatId, loading.message_id,
      `${E.cross} Gagal analisa: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
});

// ==============================================================
// COMMAND /combofunc
// ==============================================================
bot.onText(/^\/combofunc(?:\s+(.+))?$/, async (msg) => {
  if (!(await requireJoin(msg))) return;
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const args = parseCommandArgs(msg.text);
  const targetNumber = normalizeNumber(args[0] || '');

  if (!targetNumber) {
    return safeRichTextMessage(chatId,
      `${E.cross} Format: <code>/combofunc 628123456789</code>\n\n<blockquote>Ketik nomor target setelah perintah.</blockquote>`,
      { parse_mode: 'HTML' });
  }

  const senders = getUserSenders(userId);
  if (!senders.length) {
    return safeRichTextMessage(chatId,
      `${E.cross} Kamu belum punya sender yang terhubung!\n\nGunakan /connect terlebih dahulu.`,
      { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  }

  const key = `${chatId}:${userId}`;

  // Cek apakah ada function di reply command
  let detectedCode = null;
  try { detectedCode = await getReplyJsCode(bot, msg); } catch {}

  if (detectedCode) {
    // User sudah sertakan function via reply
    const funcCount = _countFuncs(detectedCode);
    if (funcCount >= 2) {
      // File/teks sudah berisi 2 function — langsung ke setup
      const split = _splitTwoFuncs(detectedCode);
      if (!split) {
        return safeRichTextMessage(chatId,
          `${E.cross} Gagal memisahkan 2 function dari file. Kirim sebagai 2 pesan terpisah.`,
          { parse_mode: 'HTML' });
      }
      try { compileFunction(split[0]); compileFunction(split[1]); } catch (e) {
        return safeRichTextMessage(chatId,
          `${E.cross} Error compile function: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
      }
      const setupMsg = await bot.sendPhoto(chatId, c.BANNER_URL, {
        caption: `${E.check} <b>2 Function terdeteksi!</b>\n\nTarget: <code>${targetNumber}</code>\n\n` +
          `<blockquote>Atur loop dan sleep:\n• Format: <code>loop|sleep</code>\n  Contoh: <code>100|3000</code>\n\n` +
          `Rekomendasi bot: <b>100 loop</b>, <b>3000ms sleep</b></blockquote>`,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [[
            { text: '✿ Rekomendasi ✿', callback_data: `combo_rec_${chatId}_${userId}`, style: 'success', icon_custom_emoji_id: '5341498088408234504' }
          ]]
        }
      });
      pendingComboFunc.set(key, {
        state: 'setup', number: targetNumber,
        func1code: split[0], func2code: split[1],
        setupMsgId: setupMsg.message_id, createdAt: Date.now()
      });
      setTimeout(() => pendingComboFunc.delete(key), 5 * 60 * 1000);
      return;
    } else {
      // Baru 1 function dari reply — simpan func1, minta func2
      try { compileFunction(detectedCode); } catch (e) {
        return safeRichTextMessage(chatId,
          `${E.cross} Function error: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
      }
      pendingComboFunc.set(key, {
        state: 'wait2', number: targetNumber,
        func1code: detectedCode, func2code: null,
        createdAt: Date.now()
      });
      setTimeout(() => pendingComboFunc.delete(key), 5 * 60 * 1000);
      return bot.sendPhoto(chatId, c.BANNER_URL, {
        caption: `${E.check} <b>Function 1 diterima!</b>\n\nTarget: <code>${targetNumber}</code>\n\n` +
          `<blockquote>Sekarang kirimkan <b>Function 2</b>:\n• Kirim teks function langsung, atau\n• Kirim file .js berisi function</blockquote>`,
        parse_mode: 'HTML'
      });
    }
  }

  // Tidak ada reply — minta func1
  pendingComboFunc.set(key, {
    state: 'wait1', number: targetNumber,
    func1code: null, func2code: null,
    createdAt: Date.now()
  });
  setTimeout(() => pendingComboFunc.delete(key), 5 * 60 * 1000);

  return bot.sendPhoto(chatId, c.BANNER_URL, {
    caption: `${E.check} <b>Target: <code>${targetNumber}</code></b>\n\n` +
      `<blockquote>Kirimkan <b>Function 1</b>:\n\n` +
      `• Kirim teks function langsung, atau\n` +
      `• Kirim file .js (1 atau 2 function)\n\n` +
      `Jika file berisi 2 function → langsung ke setup loop/sleep\n` +
      `Jika 1 function → nanti minta function 2</blockquote>`,
    parse_mode: 'HTML'
  });
});
// ==============================================================
// 1. COMMAND /tesfunc (Pemicu Awal)
// ==============================================================
bot.onText(/^\/(?:tesfunc|testfunc)(?:\s+(.+))?$/i, async (msg) => {
  if (!(await requireJoin(msg))) return;
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const args = parseCommandArgs(msg.text);
  const targetNumber = normalizeNumber(args[0] || '');

  if (!targetNumber) {
    return safeRichTextMessage(chatId,
      `${E.cross} Format: <code>/tesfunc 628123456789</code>\n\n<blockquote>Sambil reply file .js atau pesan berisi function.</blockquote>`,
      { parse_mode: 'HTML' });
  }

  const senders = getUserSenders(userId);
  if (!senders.length) {
    return safeRichTextMessage(chatId,
      `${E.cross} Kamu belum punya sender yang terhubung!\n\nGunakan /connect terlebih dahulu untuk menambahkan sender.`,
      { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  }

  const loadingVal = await safeRichTextMessage(chatId,
    `<code>${makeBar(20)}</code>\n${E.hourglass} Memvalidasi function...`,
    { parse_mode: 'HTML' });

  let code;
  try {
    code = await getReplyJsCode(bot, msg);
    if (!code) {
      await safeDelete(bot, chatId, loadingVal.message_id);
      return safeRichTextMessage(chatId, `${E.cross} Wajib reply file .js atau pesan berisi async function.`, { parse_mode: 'HTML' });
    }
    if (!isLikelyJsFunction(code)) {
      await safeDelete(bot, chatId, loadingVal.message_id);
      return safeRichTextMessage(chatId, `${E.cross} Function tidak valid / async function tidak terdeteksi.`, { parse_mode: 'HTML' });
    }
    compileFunction(code);
  } catch (e) {
    await safeDelete(bot, chatId, loadingVal.message_id);
    return safeRichTextMessage(chatId, `${E.cross} Function error: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }

  await safeDelete(bot, chatId, loadingVal.message_id);

  const key = `${chatId}:${userId}`;
  pendingTesfunc.set(key, { targetNumber, code, createdAt: Date.now() });
  
  // Hapus sesi otomatis setelah 5 menit
  setTimeout(() => pendingTesfunc.delete(key), 5 * 60 * 1000);

  const setupMsg = await bot.sendPhoto(chatId, c.BANNER_URL, {
    caption: `${E.check} <b>Function valid!</b>\n\nTarget: <code>${targetNumber}</code>\n\n` +
      `<blockquote><b>Langkah terakhir — atur loop &amp; sleep</b>\n\n` +
      `Kirim <code>loop|sleep</code> sebagai pesan biasa di chat ini.\n` +
      `Contoh paling aman: <code>1|100</code>\n` +
      `Artinya: <b>1x loop</b> + <b>100ms sleep</b>.\n\n` +
      `Contoh lain: <code>5 | 700</code>\n` +
      `Artinya: <b>5x loop</b> + <b>700ms sleep</b>.\n\n` +
      `Atau tekan <b>Rekomendasi</b> untuk <b>50 loop + 700ms sleep</b>.\n\n` +
      `<i>Setelah mengirim format, bot langsung menjalankan tes.</i></blockquote>`,
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [[
        { text: 'Rekomendasi', callback_data: `tesfunc_rec_${chatId}_${userId}`, style: 'success', icon_custom_emoji_id: '5341498088408234504' }
      ]]
    }
  });

  pendingTesfunc.set(key, { targetNumber, code, setupMsgId: setupMsg.message_id, createdAt: Date.now() });
});
//— TES FUNC LOGIC
async function runTesfunc(chatId, fromUser, targetNumber, code, loop, sleep) {
  // Daftarkan ke activeTesfuncMap
  const _activeName = [fromUser.first_name, fromUser.last_name].filter(Boolean).join(' ') || fromUser.username || 'Unknown';
  activeTesfuncMap.set(String(fromUser.id), {
    chatId, targetNumber,
    name: _activeName,
    username: fromUser.username || '',
    startedAt: Date.now()
  });

  // Tombol Send Again + Cek Number (akan diperbarui dengan key baru tiap run)
  const againId = ++_sendAgainCounter;
  pendingSendAgain.set(againId, { type: 'tesfunc', chatId, fromUser, targetNumber, code, loop, sleep });
  setTimeout(() => pendingSendAgain.delete(againId), 6 * 60 * 60 * 1000); // auto-hapus 6 jam

  const againMarkup = () => ({
    inline_keyboard: [[
      { text: '✿ Send Again ✿', callback_data: `again_${againId}`, style: 'danger', icon_custom_emoji_id: '5053600288754107920' },
      { text: '✿ Cek Number ✿', url: `https://wa.me/${targetNumber}`, style: 'success', icon_custom_emoji_id: '5197278098835407966' }
    ]]
  });

  const loading = await bot.sendPhoto(chatId, c.BANNER_URL, {
    caption: `<code>${makeBar(5)}</code>\n${E.hourglass} Mempersiapkan eksekusi...`,
    parse_mode: 'HTML'
  });

  try {
    const func = compileFunction(code);
    const senderNum = getUserSenders(fromUser.id)[0];
    const sock = getSocket(senderNum) || getSocket();

    if (!sock || !sock.user) {
      activeTesfuncMap.delete(String(fromUser.id));
      return safeEditCaption(bot, chatId, loading.message_id,
        `${E.cross} Tidak ada sender tersambung. Cek /ceksender lalu /connect.`,
        { parse_mode: 'HTML' });
    }

    const target = `${targetNumber}@s.whatsapp.net`;

    await safeEditCaption(bot, chatId, loading.message_id,
      `<code>${makeBar(15)}</code>\n${E.check} Sender aktif!\n${E.hourglass} Mulai ${loop}x ke <code>${targetNumber}</code> | Sleep: ${sleep}ms`,
      { parse_mode: 'HTML' });

    let lastUpdate = 0;
    let consecutiveErrors = 0;
    let successCount = 0;

    for (let i = 0; i < loop; i++) {
      const now = Date.now();
      if (now - lastUpdate > 1500 || i === loop - 1) {
        const percent = Math.round(((i + 1) / loop) * 100);
        await safeEditCaption(bot, chatId, loading.message_id,
          `<blockquote><b>${E.hourglass} mellstecu Ϟ FMD</b></blockquote>\n` +
          `Target: <code>${targetNumber}</code>\n` +
          `Progress: <code>${i + 1} / ${loop}</code>\n` +
          `<code>${makeBar(percent)}</code>\n` +
          `Berhasil: <code>${successCount}</code> | Sleep: <code>${sleep}ms</code>`,
          { parse_mode: 'HTML', reply_markup: againMarkup() }).catch(() => {});
        lastUpdate = now;
      }

      try {
        if (func.length >= 2) await func(sock, target);
        else if (func.length === 1) await func(target);
        else await func();
        successCount++;
        consecutiveErrors = 0;
      } catch (iterErr) {
        consecutiveErrors++;
        if (consecutiveErrors >= 5) {
          const backoff = Math.min(consecutiveErrors * 800, 8000);
          await new Promise(r => setTimeout(r, backoff));
        }
      }

      await new Promise(r => setTimeout(r, sleep));
    }

    incrementTests(loop);
    incrementDailyTests(loop);
    addTesfuncStat(fromUser.id, fromUser.first_name || '', fromUser.username || '', loop);

    // FIX DISCONNECT: presence update setelah selesai
    try {
      const activeSock = getSocket(senderNum) || sock;
      if (activeSock?.user) {
        await activeSock.sendPresenceUpdate('available');
        await new Promise(r => setTimeout(r, 2000));
        await activeSock.sendPresenceUpdate('available');
      }
    } catch {}

    await safeEditCaption(bot, chatId, loading.message_id,
      `<blockquote>${E.check} <b>mellstecu Ϟ FMD</b></blockquote>\n` +
      `<b>Target: <code>${targetNumber}</code></b>\n` +
      `<b>Loop: <code>${loop}</code> | Berhasil: <code>${successCount}</code></b>\n` +
      `<b>Sleep: <code>${sleep}ms</code></b>\n` +
      `<b>Status: <code>Berhasil</code></b>`,
      { parse_mode: 'HTML', reply_markup: againMarkup() });

    activeTesfuncMap.delete(String(fromUser.id));

  } catch (e) {
    await safeEditCaption(bot, chatId, loading.message_id,
      `${E.cross} Test gagal: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
    activeTesfuncMap.delete(String(fromUser.id));
  }
}
//━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// Helper: hitung jumlah async function dalam kode
function _countFuncs(code) {
  const m1 = (code.match(/(?:^|\n)\s*async\s+function\s+\w+/gm) || []).length;
  const m2 = (code.match(/(?:^|\n)\s*const\s+\w+\s*=\s*async\s*(?:function\b|\()/gm) || []).length;
  return m1 + m2;
}

// Helper: pisah kode menjadi dua bagian berdasarkan fungsi ke-2
function _splitTwoFuncs(code) {
  const patterns = [
    /(?:^|\n)(\s*async\s+function\s+\w+)/gm,
    /(?:^|\n)(\s*const\s+\w+\s*=\s*async\s*(?:function\b|\())/gm
  ];
  let positions = [];
  for (const pat of patterns) {
    let m;
    const p = new RegExp(pat.source, 'gm');
    while ((m = p.exec(code)) !== null) positions.push(m.index === 0 ? 0 : m.index + 1);
  }
  positions = [...new Set(positions)].sort((a, b) => a - b);
  if (positions.length >= 2) {
    return [code.slice(0, positions[1]).trim(), code.slice(positions[1]).trim()];
  }
  return null;
}

// ======================================================================
// FUNGSI EKSEKUSI COMBOFUNC
// ======================================================================
async function runCombofunc(chatId, fromUser, targetNumber, func1code, func2code, loop, sleep) {
  const _activeName = [fromUser.first_name, fromUser.last_name].filter(Boolean).join(' ') || fromUser.username || 'Unknown';
  activeTesfuncMap.set(String(fromUser.id), {
    chatId, targetNumber,
    name: _activeName + ' [COMBO]',
    username: fromUser.username || '',
    startedAt: Date.now()
  });

  const againId = ++_sendAgainCounter;
  pendingSendAgain.set(againId, { type: 'combofunc', chatId, fromUser, targetNumber, code: func1code, func2code, loop, sleep });
  setTimeout(() => pendingSendAgain.delete(againId), 6 * 60 * 60 * 1000);

  const againMarkup = () => ({
    inline_keyboard: [[
      { text: '✿ Send Again ✿', callback_data: `again_${againId}`, style: 'danger', icon_custom_emoji_id: '5053600288754107920' },
      { text: '✿ Cek Number ✿', url: `https://wa.me/${targetNumber}`, style: 'success', icon_custom_emoji_id: '5197278098835407966' }
    ]]
  });

  const loading = await bot.sendPhoto(chatId, c.BANNER_URL, {
    caption: `<code>${makeBar(5)}</code>\n${E.hourglass} Mempersiapkan eksekusi combo...`,
    parse_mode: 'HTML'
  });

  try {
    const func1 = compileFunction(func1code);
    const func2 = compileFunction(func2code);
    const senderNum = getUserSenders(fromUser.id)[0];
    const sock = getSocket(senderNum) || getSocket();

    if (!sock || !sock.user) {
      activeTesfuncMap.delete(String(fromUser.id));
      return safeEditCaption(bot, chatId, loading.message_id,
        `${E.cross} Tidak ada sender tersambung. Cek /ceksender lalu /connect.`,
        { parse_mode: 'HTML' });
    }

    const target = `${targetNumber}@s.whatsapp.net`;

    await safeEditCaption(bot, chatId, loading.message_id,
      `<code>${makeBar(15)}</code>\n${E.check} Sender aktif!\n${E.hourglass} Mulai ${loop}x COMBO ke <code>${targetNumber}</code> | Sleep: ${sleep}ms`,
      { parse_mode: 'HTML' });

    let lastUpdate = 0;
    let consecutiveErrors = 0;
    let success1 = 0, success2 = 0;

    for (let i = 0; i < loop; i++) {
      const now = Date.now();
      if (now - lastUpdate > 1500 || i === loop - 1) {
        const percent = Math.round(((i + 1) / loop) * 100);
        await safeEditCaption(bot, chatId, loading.message_id,
          `<blockquote><b>${E.hourglass} mellstecu Ϟ FMD — ComboFUNC</b></blockquote>\n` +
          `Target: <code>${targetNumber}</code>\n` +
          `Progress: <code>${i + 1} / ${loop}</code>\n` +
          `<code>${makeBar(percent)}</code>\n` +
          `Func1 ✓: <code>${success1}</code> | Func2 ✓: <code>${success2}</code> | Sleep: <code>${sleep}ms</code>`,
          { parse_mode: 'HTML', reply_markup: againMarkup() }).catch(() => {});
        lastUpdate = now;
      }

      // Eksekusi func1
      try {
        if (func1.length >= 2) await func1(sock, target);
        else if (func1.length === 1) await func1(target);
        else await func1();
        success1++;
        consecutiveErrors = 0;
      } catch (e1) {
        consecutiveErrors++;
        if (consecutiveErrors >= 5) await new Promise(r => setTimeout(r, Math.min(consecutiveErrors * 800, 8000)));
      }

      // Eksekusi func2
      try {
        if (func2.length >= 2) await func2(sock, target);
        else if (func2.length === 1) await func2(target);
        else await func2();
        success2++;
      } catch (e2) {
        consecutiveErrors++;
      }

      await new Promise(r => setTimeout(r, sleep));
    }

    incrementTests(loop * 2);
    incrementDailyTests(loop * 2);
    addTesfuncStat(fromUser.id, fromUser.first_name || '', fromUser.username || '', loop * 2);

    try {
      const activeSock = getSocket(senderNum) || sock;
      if (activeSock?.user) {
        await activeSock.sendPresenceUpdate('available');
        await new Promise(r => setTimeout(r, 2000));
        await activeSock.sendPresenceUpdate('available');
      }
    } catch {}

    await safeEditCaption(bot, chatId, loading.message_id,
      `${E.check} <b>Combo selesai!</b>\n` +
      `Target: <code>${targetNumber}</code>\n` +
      `Loop: <code>${loop}</code> | Func1 ✓: <code>${success1}</code> | Func2 ✓: <code>${success2}</code>\n` +
      `Sleep: <code>${sleep}ms</code>\n` +
      `Status: <code>COMBO SUCCESS ✓</code>`,
      { parse_mode: 'HTML', reply_markup: againMarkup() });

    activeTesfuncMap.delete(String(fromUser.id));

  } catch (e) {
    await safeEditCaption(bot, chatId, loading.message_id,
      `${E.cross} Combo gagal: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
    activeTesfuncMap.delete(String(fromUser.id));
  }
}

// ======================================= //
// 📡 /tt — TikTok Downloader (HD)
// ======================================= //
bot.onText(/^\/tt(?:\s+(.+))?$/, async (msg, match) => {
  if (!(await requireJoin(msg))) return;
  const url = (match[1] || '').trim();
  if (!/^https?:\/\//i.test(url)) {
    return safeRichTextMessage(msg.chat.id, `${E.cross} Format: <code>/tt &lt;link tiktok&gt;</code>`, { parse_mode: 'HTML' });
  }
  const loading = await safeRichTextMessage(msg.chat.id,
    `<code>${makeBar(40)}</code>\n${E.hourglass} Mengambil video TikTok HD...`,
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  try {
    const data = await downloadTikTok(url, c.TIKTOK_ENDPOINT);
    if (!data?.status || !data?.result) throw new Error(data?.message || 'Video tidak ditemukan.');
    const r = data.result;

    const videoUrl = r.data;
    if (!videoUrl) throw new Error('URL video tidak tersedia.');

    const caption = `<blockquote>${E.tiktok} <b>TikTok Downloader HD</b></blockquote>\n` +
      `<blockquote><b>${htmlEscape(r.title || 'TikTok Video')}</b></blockquote>\n\n` +
      `<blockquote><b>メ INFORMATION メ</b></blockquote>\n${E.watch} Durasi: <code>${htmlEscape(String(r.duration || '-'))}</code>\n` +
      `${E.globe} Region: <code>${htmlEscape(r.region || '-')}</code>\n` +
      `${E.eyes} Views: <code>${htmlEscape(r.stats?.views || '-')}</code>\n` +
      `${E.heart} Likes: <code>${htmlEscape(r.stats?.likes || '-')}</code>\n` +
      `${E.chat} Komentar: <code>${htmlEscape(r.stats?.comment || '-')}</code>\n` +
      `${E.share} Share: <code>${htmlEscape(r.stats?.share || '-')}</code>\n` +
      `${E.Name} Author: <code>${htmlEscape(r.author?.nickname || r.author?.fullname || '-')}</code>`;

    await bot.sendVideo(msg.chat.id, videoUrl, {
      caption,
      parse_mode: 'HTML',
      reply_to_message_id: msg.message_id,
      supports_streaming: true
    });
    await safeDelete(bot, msg.chat.id, loading.message_id);
  } catch (e) {
    await safeEdit(bot, msg.chat.id, loading.message_id,
      `${E.cross} Gagal download TikTok: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
});

// ======================================= //
// 📡 /playvid — Download Video YouTube (MP4)
// ======================================= //
bot.onText(/^\/playvid(?:\s+(.+))?$/, async (msg, match) => {
  if (!(await requireJoin(msg))) return;
  const query = (match[1] || '').trim();
  if (!query) {
    return safeRichTextMessage(msg.chat.id,
      `${E.cross} Format: <code>/playvid &lt;judul video&gt;</code>`,
      { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  }
  const loading = await safeRichTextMessage(msg.chat.id,
    `<code>${makeBar(20)}</code>\n${E.hourglass} Mencari: <b>${htmlEscape(query)}</b>...`,
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  try {
    await safeEdit(bot, msg.chat.id, loading.message_id,
      `<code>${makeBar(50)}</code>\n${E.hourglass} Memproses video...`, { parse_mode: 'HTML' });
    const { data } = await axios.get(
      `https://api.nexray.eu.cc/downloader/ytplayvid?q=${encodeURIComponent(query)}`,
      { timeout: 90000 }
    );
    if (!data?.status || !data?.result) throw new Error(data?.message || 'Video tidak ditemukan.');
    const r = data.result;
    if (!r.download_url) throw new Error('URL download tidak tersedia.');
    await safeEdit(bot, msg.chat.id, loading.message_id,
      `<code>${makeBar(85)}</code>\n${E.hourglass} Mengirim video...`, { parse_mode: 'HTML' });
        const caption =
      `<blockquote>${E.movie} <b>YouTube Video</b></blockquote>\n` +
      `<b>${htmlEscape(r.title || query)}</b>\n\n` +
      `${E.tv} Channel: <code>${htmlEscape(r.channel || '-')}</code>\n` +
      `${E.watch} Durasi: <code>${htmlEscape(r.duration || '-')}</code>\n` +
      `${E.eyes} Views: <code>${htmlEscape(r.views || '-')}</code>`;
    await safeEdit(bot, msg.chat.id, loading.message_id,
      `<code>${makeBar(85)}</code>\n${E.hourglass} Mengunduh video ke server...`, { parse_mode: 'HTML' });
    let videoPayload;
    try {
      const vRes = await axios.get(r.download_url, { responseType: 'arraybuffer', timeout: 180000 });
      videoPayload = Buffer.from(vRes.data);
    } catch {
      videoPayload = r.download_url;
    }
    await safeEdit(bot, msg.chat.id, loading.message_id,
      `<code>${makeBar(95)}</code>\n${E.hourglass} Mengirim video...`, { parse_mode: 'HTML' });
    await bot.sendVideo(msg.chat.id, videoPayload, {
      caption, parse_mode: 'HTML',
      reply_to_message_id: msg.message_id, supports_streaming: true
    });
    await safeDelete(bot, msg.chat.id, loading.message_id);
  } catch (e) {
    await safeEdit(bot, msg.chat.id, loading.message_id,
      `${E.cross} Gagal: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
});

// ======================================= //
// 📡 /getbaseweb — Download Source Code Website
// ======================================= //
bot.onText(/^\/getbaseweb(?:\s+(.+))?$/, async (msg, match) => {
  if (!(await requireJoin(msg))) return;
  const url = (match[1] || '').trim();
  if (!url || !/^https?:\/\//i.test(url)) {
    return safeRichTextMessage(msg.chat.id,
      `${E.cross} Format: <code>/getbaseweb &lt;url website&gt;</code>`,
      { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  }
  const loading = await safeRichTextMessage(msg.chat.id,
    `<code>${makeBar(15)}</code>\n${E.hourglass} Mengambil source code:\n<code>${htmlEscape(url)}</code>`,
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  try {
    await safeEdit(bot, msg.chat.id, loading.message_id,
      `<code>${makeBar(40)}</code>\n${E.hourglass} Meng-copy semua file...`, { parse_mode: 'HTML' });
    const { data } = await axios.get(
      `https://api.nexray.eu.cc/tools/webtozip?url=${encodeURIComponent(url)}`,
      { timeout: 120000 }
    );
    if (!data?.status || !data?.result?.downloadUrl)
      throw new Error(data?.result?.error?.text || 'Gagal mengambil source code.');
    const r = data.result;
    await safeEdit(bot, msg.chat.id, loading.message_id,
      `<code>${makeBar(70)}</code>\n${E.hourglass} Mengunduh ${r.copiedFilesAmount || '?'} file...`, { parse_mode: 'HTML' });
    const zipRes = await axios.get(r.downloadUrl, { responseType: 'arraybuffer', timeout: 120000 });
    const zipBuffer = Buffer.from(zipRes.data);
    await safeEdit(bot, msg.chat.id, loading.message_id,
      `<code>${makeBar(90)}</code>\n${E.hourglass} Mengirim file...`, { parse_mode: 'HTML' });
    const domain = url.replace(/^https?:\/\//i,'').replace(/\/.*$/,'').replace(/[^a-zA-Z0-9.-]/g,'_');
        await bot.sendDocument(msg.chat.id, zipBuffer, {
      caption:
        `${E.download} <b>Source Code Berhasil!</b>\n\n` +
        `${E.web} URL: <code>${htmlEscape(url)}</code>\n` +
        `${E.folder} File: <code>${r.copiedFilesAmount || '?'} file</code>\n\n` +
        `<blockquote>Semua file website sudah dikemas dalam ZIP.</blockquote>`,
      parse_mode: 'HTML', reply_to_message_id: msg.message_id
    }, { filename: `baseweb_${domain}.zip`, contentType: 'application/zip' });
    await safeDelete(bot, msg.chat.id, loading.message_id);
  } catch (e) {
    await safeEdit(bot, msg.chat.id, loading.message_id,
      `${E.cross} Gagal: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
});
// ======================================= //
// 📡 /ig — Instagram Downloader (STABLE)
// ======================================= //
async function processInstagramDownload(msg, url) {
  const chatId = msg.chat.id;
  const loading = await safeRichTextMessage(chatId,
    `<code>${makeBar(40)}</code>\n${E.ig} <b>Mengambil media Instagram...</b>\n\n<i>Mohon tunggu sebentar.</i>`,
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id });

  try {
    const result = await downloadInstagram(url);
    const caption = `<blockquote>${E.ig} <b>Instagram Downloader</b></blockquote>\n` +
      (result.caption ? `${htmlEscape(String(result.caption).slice(0, 500))}\n\n` : '') +
      `👤 Author: <code>${htmlEscape(result.username || '-')}</code>\n` +
      `🔗 <i>Media ${result.medias.length} item</i>`;

    let sent = 0;
    for (let i = 0; i < result.medias.length; i++) {
      const media = result.medias[i];
      const mediaUrl = media.url;
      const isVideo = /video/i.test(String(media.type || '')) ||
        /\.(?:mp4|mov|m4v|webm)(?:[?#]|$)/i.test(mediaUrl);

      // Instagram CDN sering menolak direct fetch Telegram. Ambil dulu dengan
      // axios + User-Agent lalu kirim Buffer agar lebih stabil.
      const mediaRes = await axios.get(mediaUrl, {
        responseType: 'arraybuffer',
        timeout: 90000,
        maxContentLength: 80 * 1024 * 1024,
        maxBodyLength: 80 * 1024 * 1024,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/131 Mobile Safari/537.36',
          'Referer': 'https://www.instagram.com/'
        }
      });
      const buffer = Buffer.from(mediaRes.data);
      const filename = `instagram_${Date.now()}_${i + 1}.${isVideo ? 'mp4' : 'jpg'}`;
      const mediaCaption = i === 0 ? caption : `${E.ig} <b>Instagram</b>\n📦 Media ${i + 1}/${result.medias.length}`;

      if (isVideo) {
        await bot.sendVideo(chatId, buffer, {
          filename,
          caption: mediaCaption,
          parse_mode: 'HTML',
          supports_streaming: true,
          reply_to_message_id: msg.message_id
        });
      } else {
        await bot.sendPhoto(chatId, buffer, {
          filename,
          caption: mediaCaption,
          parse_mode: 'HTML',
          reply_to_message_id: msg.message_id
        });
      }
      sent++;
    }

    if (!sent) throw new Error('Media Instagram tidak bisa dikirim ke Telegram.');
    await safeDelete(bot, chatId, loading.message_id);
  } catch (e) {
    console.error('[IG DOWNLOAD]', e);
    await safeEdit(bot, chatId, loading.message_id,
      `${E.cross} <b>Download Instagram gagal</b>\n\n` +
      `<code>${htmlEscape(e.message || 'Layanan sedang tidak tersedia.')}</code>\n\n` +
      `💡 Pastikan akun/postingan dapat diakses publik dan link tidak rusak.`,
      { parse_mode: 'HTML' });
  }
}

bot.onText(/^\/ig(?:\s+(.+))?$/i, async (msg, match) => {
  if (!(await requireJoin(msg))) return;
  const url = (match[1] || '').trim();
  if (!url) {
    return safeRichTextMessage(msg.chat.id,
      `📸 <b>INSTAGRAM DOWNLOADER</b>\n\nKirim link Instagram publik.\n\nContoh:\n<code>/ig https://www.instagram.com/reel/...</code>`,
      { parse_mode: 'HTML', reply_markup: menuTambahanKeyboard() });
  }
  if (!/^https?:\/\/(?:www\.)?(?:instagram\.com|instagr\.am)\//i.test(url)) {
    return safeRichTextMessage(msg.chat.id,
      `${E.cross} Link Instagram tidak valid.\n\nGunakan link <code>instagram.com</code> atau <code>instagr.am</code>.`,
      { parse_mode: 'HTML', reply_markup: menuTambahanKeyboard() });
  }
  return processInstagramDownload(msg, url);
});

// ======================================= //
// 📡 /bratanime — Stiker Anime
// ======================================= //
bot.onText(/^\/bratanime(?:\s+(.+))?$/, async (msg, match) => {
  if (!(await requireJoin(msg))) return;
  const text = (match[1] || '').trim();
  if (!text) {
    return safeRichTextMessage(msg.chat.id,
      `${E.sticker} Format: <code>/bratanime &lt;kata-kata&gt;</code>\nContoh: <code>/bratanime Yataa!</code>`,
      { parse_mode: 'HTML' });
  }
  const loading = await safeRichTextMessage(msg.chat.id,
    `<code>${makeBar(30)}</code>\n${E.sticker} Membuat stiker anime: <b>${htmlEscape(text)}</b>`,
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  try {
    await safeEdit(bot, msg.chat.id, loading.message_id,
      `<code>${makeBar(60)}</code>\n${E.sticker} Memproses gambar dari server...`, { parse_mode: 'HTML' });
    const imgRes = await axios.get('https://api.nexray.eu.cc/maker/bratanime', {
      params: { text }, responseType: 'arraybuffer', timeout: 60000
    });
    const imgBuffer = Buffer.from(imgRes.data);
    await safeEdit(bot, msg.chat.id, loading.message_id,
      `<code>${makeBar(90)}</code>\n${E.sticker} Mengirim stiker...`, { parse_mode: 'HTML' });
    try {
      await bot.sendSticker(msg.chat.id, imgBuffer, { reply_to_message_id: msg.message_id });
    } catch {
      await bot.sendPhoto(msg.chat.id, imgBuffer, {
        caption: `${E.sticker} <b>Bratanime:</b> <code>${htmlEscape(text)}</code>`,
        parse_mode: 'HTML', reply_to_message_id: msg.message_id
      });
    }
    await safeDelete(bot, msg.chat.id, loading.message_id);
  } catch (e) {
    await safeEdit(bot, msg.chat.id, loading.message_id,
      `${E.cross} Gagal buat stiker: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
});

// ======================================= //
// 📡 /s & /stiker — Konversi Foto ke Stiker
// ======================================= //
async function handleStickerConvert(msg) {
  if (!(await requireJoin(msg))) return;
  const chatId = msg.chat.id;
  const reply = msg.reply_to_message;

  if (!reply || (!reply.photo && !reply.sticker && !reply.document)) {
    return safeRichTextMessage(chatId,
      `${E.sticker} <b>Cara pakai:</b> Reply foto/gambar lalu ketik <code>/s</code> atau <code>/stiker</code>`,
      { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  }

  const loading = await safeRichTextMessage(chatId,
    `<code>${makeBar(50)}</code>\n${E.sticker} Mengkonversi foto jadi stiker...`,
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id });

  try {
    let fileId;
    if (reply.photo) {
      fileId = reply.photo[reply.photo.length - 1].file_id;
    } else if (reply.document?.mime_type?.startsWith('image/')) {
      fileId = reply.document.file_id;
    } else if (reply.sticker) {
      fileId = reply.sticker.file_id;
    } else {
      throw new Error('File harus berupa foto atau gambar.');
    }

    const fileLink = await bot.getFileLink(fileId);
    const imgRes = await axios.get(fileLink, { responseType: 'arraybuffer', timeout: 30000 });
    const imgBuffer = Buffer.from(imgRes.data);

    await bot.sendSticker(chatId, imgBuffer, { reply_to_message_id: msg.message_id });
    await safeDelete(bot, chatId, loading.message_id);
  } catch (e) {
    await safeEdit(bot, chatId, loading.message_id,
      `${E.cross} Gagal konversi: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
}

bot.onText(/^\/s$/, handleStickerConvert);
bot.onText(/^\/stiker$/, handleStickerConvert);


// ======================================= //
// 🎵 POLISHED AUDIO SENDER
// Downloads the audio to a meaningful filename and prepares
// a Telegram-compatible cover thumbnail. This prevents Telegram
// from displaying random endpoint filenames such as abc123.mp3.
// ======================================= //
async function sendPolishedAudio(bot, chatId, audioUrl, meta = {}, extra = {}) {
  if (!audioUrl) throw new Error('URL audio tidak tersedia.');

  const tempRoot = path.join(__dirname, '..', '.tmp-play');
  const jobId = `${Date.now()}-${crypto.randomBytes(5).toString('hex')}`;
  const jobDir = path.join(tempRoot, jobId);
  const safeTitle = String(meta.title || 'Audio')
    .replace(/[\\/:*?"<>|]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 80) || 'Audio';
  const audioPath = path.join(jobDir, `${safeTitle}.mp3`);
  const thumbPath = path.join(jobDir, 'cover.jpg');

  await fs.promises.mkdir(jobDir, { recursive: true });

  try {
    // Stream audio to disk instead of buffering the whole file in RAM.
    const response = await axios.get(audioUrl, {
      responseType: 'stream',
      timeout: 120000,
      maxContentLength: Infinity,
      maxBodyLength: Infinity,
      headers: { 'User-Agent': 'Mozilla/5.0' }
    });

    await new Promise((resolve, reject) => {
      const out = fs.createWriteStream(audioPath);
      response.data.pipe(out);
      response.data.on('error', reject);
      out.on('finish', resolve);
      out.on('error', reject);
    });

    // Prefer the source's artwork/thumbnail. Resize/compress it so Telegram
    // accepts it reliably as an audio thumbnail.
    const artwork = meta.thumbnail || meta.artwork_url || meta.cover ||
      meta.cover_url || meta.image || meta.image_url || null;

    let thumb = null;
    if (artwork) {
      try {
        const imageRes = await axios.get(artwork, {
          responseType: 'arraybuffer',
          timeout: 30000,
          maxContentLength: 15 * 1024 * 1024,
          maxBodyLength: 15 * 1024 * 1024,
          headers: { 'User-Agent': 'Mozilla/5.0' }
        });
        const sharp = require('sharp');
        await sharp(Buffer.from(imageRes.data))
          .resize(320, 320, { fit: 'cover', position: 'centre' })
          .jpeg({ quality: 82, mozjpeg: true })
          .toFile(thumbPath);
        thumb = thumbPath;
      } catch (_) {
        // Cover failure must never break a valid audio download.
        thumb = null;
      }
    }

    const title = String(meta.title || safeTitle).slice(0, 128);
    const performer = String(meta.performer || meta.artist || 'Unknown Artist').slice(0, 128);

    const options = {
      ...extra,
      title,
      performer,
      parse_mode: 'HTML'
    };
    if (thumb) options.thumb = thumb;

    try {
      return await bot.sendAudio(chatId, audioPath, options);
    } catch (sendErr) {
      // A bad/unsupported cover must not make an otherwise valid audio fail.
      // Retry once without the thumbnail.
      if (thumb) {
        delete options.thumb;
        return await bot.sendAudio(chatId, audioPath, options);
      }
      throw sendErr;
    }
  } finally {
    // Cleanup after Telegram has consumed the local files.
    await fs.promises.rm(jobDir, { recursive: true, force: true }).catch(() => {});
    await fs.promises.rmdir(tempRoot).catch(() => {});
  }
}

// ======================================= //
// 📡 /play — SoundCloud Direct Download
// /play intentionally stays simple: no banner/Rich music card.
// /playv2 is the visual/Rich version with artwork banner.
// ======================================= //
bot.onText(/^\/play(?:\s+(.+))?$/, async (msg, match) => {
  if (!(await requireJoin(msg))) return;
  const query = (match[1] || '').trim();
  if (!query) return safeRichTextMessage(msg.chat.id, `${E.cross} Format: <code>/play &lt;nama lagu&gt;</code>`, { parse_mode: 'HTML' });
  const chatId = msg.chat.id;

  const loading = await safeRichTextMessage(chatId,
    `<code>${makeBar(30)}</code>\n${E.hourglass} Mencari lagu: <b>${htmlEscape(query)}</b>...`,
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id });

  try {
    let result = null;
    try {
      await safeEdit(bot, chatId, loading.message_id,
        `<code>${makeBar(50)}</code>\n${E.hourglass} Mengunduh dari SoundCloud...`, { parse_mode: 'HTML' });
      const data = await playSoundCloud(query);
      if (data?.result?.download_url) result = { type: 'soundcloud', data: data.result };
      else throw new Error('SoundCloud tidak tersedia');
    } catch {
      await safeEdit(bot, chatId, loading.message_id,
        `<code>${makeBar(55)}</code>\n${E.hourglass} Mencoba backup endpoint...`, { parse_mode: 'HTML' });
      const backupRes = await axios.get(
        `https://api.nexray.eu.cc/downloader/ytplay?q=${encodeURIComponent(query)}`,
        { timeout: 90000 }
      );
      if (!backupRes.data?.status || !backupRes.data?.result) throw new Error('Backup endpoint juga gagal.');
      result = { type: 'ytplay', data: backupRes.data.result };
    }

    await safeEdit(bot, chatId, loading.message_id,
      `<code>${makeBar(85)}</code>\n${E.hourglass} Mengirim audio...`, { parse_mode: 'HTML' });

    const r = result.data;
    const isSoundCloud = result.type === 'soundcloud';
    const duration = isSoundCloud
      ? (() => {
          const sec = r.duration ? Math.floor(r.duration / 1000) : null;
          return sec ? `${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, '0')}` : '-';
        })()
      : (r.duration || '-');
    const performer = isSoundCloud ? (r.user || 'SoundCloud') : (r.channel || 'YouTube');

    // Plain /play: native audio only. No banner, no Rich music card.
    await sendPolishedAudio(bot, chatId, r.download_url, {
      title: r.title || query,
      performer,
      thumbnail: r.thumbnail || r.artwork_url || r.cover || r.cover_url || r.image || r.image_url
    }, {
      caption: `${E.music} <b>${htmlEscape(r.title || query)}</b>\n` +
        `${E.user} ${htmlEscape(performer)} · ${htmlEscape(duration)}\n` +
        `<blockquote>${isSoundCloud ? 'SoundCloud' : 'YouTube'} · mellstecuu MD</blockquote>`,
      reply_to_message_id: msg.message_id
    });

    notifyMainChannelActivity('play', msg.from, {
      title: `${E.music} PLAY ACTIVITY`, emoji: E.music, action: '/play',
      fields: {
        'Lagu': r.title || query,
        'Artist / Channel': performer,
        'Durasi': duration,
        'Provider': isSoundCloud ? 'SoundCloud' : 'YouTube',
        'Chat ID': String(chatId)
      }
    }).catch(() => {});

    await safeDelete(bot, chatId, loading.message_id);
  } catch (e) {
    await safeEdit(bot, chatId, loading.message_id,
      `${E.cross} Gagal: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
});

// ------- /playv2 <judul lagu> — Putar musik versi 2 (sumber & alur alternatif) -------
bot.onText(/^\/playv2(?:\s+(.+))?$/i, async (msg, match) => {
  if (!(await requireJoin(msg))) return;
  const query = (match[1] || '').trim();
  if (!query) return safeRichTextMessage(msg.chat.id, `${E.cross} Format: <code>/playv2 &lt;nama lagu&gt;</code>`, { parse_mode: 'HTML' });
  const chatId = msg.chat.id;

  const loading = await safeRichTextMessage(chatId,
    `<code>${makeBar(30)}</code>\n${E.hourglass} [V2] Mencari lagu: <b>${htmlEscape(query)}</b>...`,
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id });

  try {
    // V2: langsung pakai endpoint YouTube (kualitas & metadata lebih lengkap),
    // baru fallback ke SoundCloud kalau gagal.
    let usedFallback = false;
    let result = null;
    try {
      await safeEdit(bot, chatId, loading.message_id,
        `<code>${makeBar(50)}</code>\n${E.hourglass} [V2] Mengambil dari YouTube...`, { parse_mode: 'HTML' });
      const ytRes = await axios.get(
        `https://api.nexray.eu.cc/downloader/ytplay?q=${encodeURIComponent(query)}`,
        { timeout: 90000 }
      );
      if (!ytRes.data?.status || !ytRes.data?.result) throw new Error('YouTube tidak tersedia');
      result = { type: 'ytplay', data: ytRes.data.result };
    } catch {
      usedFallback = true;
      await safeEdit(bot, chatId, loading.message_id,
        `<code>${makeBar(55)}</code>\n${E.hourglass} [V2] Fallback ke SoundCloud...`, { parse_mode: 'HTML' });
      const data = await playSoundCloud(query);
      if (!data?.result?.download_url) throw new Error('SoundCloud fallback juga gagal.');
      result = { type: 'soundcloud', data: data.result };
    }

    await safeEdit(bot, chatId, loading.message_id,
      `<code>${makeBar(85)}</code>\n${E.hourglass} [V2] Mengirim audio...`, { parse_mode: 'HTML' });

    const r = result.data;
    if (result.type === 'ytplay') {
      const caption =
        `${E.music} <b>[V2] ${htmlEscape(r.title || query)}</b>\n\n` +
        `${E.tv} Channel: <code>${htmlEscape(r.channel || '-')}</code>\n` +
        `${E.watch} Durasi: <code>${r.duration || '-'}</code>\n` +
        `${E.eyes} Views: <code>${htmlEscape(String(r.views || '-'))}</code>\n\n` +
        `<blockquote>Play V2 · mellstecu Ϟ FMD</blockquote>`;
      const keyboard = r.url ? {
        inline_keyboard: [[{ text: '✿ Buka di YouTube ✿', url: r.url, icon_custom_emoji_id: '5197589312165675604' }]]
      } : undefined;
      const musicCard = await sendMusicRichBanner(chatId, {
        title: r.title || query,
        artist: r.channel || 'YouTube',
        duration: r.duration || '',
        views: r.views || '',
        thumbnail: r.thumbnail || r.artwork_url || r.cover || r.cover_url || r.image || r.image_url
      }, keyboard, msg.message_id);
      if (r.download_url) {
        await sendPolishedAudio(bot, chatId, r.download_url, {
          title: r.title || query,
          performer: r.channel || 'YouTube',
          thumbnail: r.thumbnail || r.artwork_url || r.cover || r.cover_url || r.image || r.image_url
        }, {
          caption: `${E.music} <b>[V2] ${htmlEscape(r.title || query)}</b>\n<blockquote>mellstecuu Ϟ MD</blockquote>`,
          reply_to_message_id: musicCard?.message_id || msg.message_id
        });
      }
    } else {
      const durSec = r.duration ? Math.floor(r.duration / 1000) : null;
      const durStr = durSec ? `${Math.floor(durSec / 60)}:${String(durSec % 60).padStart(2, '0')}` : '-';
      const caption =
        `${E.music} <b>[V2 · Fallback] ${htmlEscape(r.title || query)}</b>\n` +
        `${E.user} Artist: <code>${htmlEscape(r.user || '-')}</code>\n` +
        `${E.watch} Durasi: <code>${durStr}</code>\n\n` +
        `<blockquote>SoundCloud Fallback · mellstecu Ϟ FMD</blockquote>`;
      const musicCard = await sendMusicRichBanner(chatId, {
        title: r.title || query,
        artist: r.user || 'SoundCloud',
        duration: durStr,
        thumbnail: r.thumbnail || r.artwork_url || r.cover || r.cover_url || r.image || r.image_url
      }, { inline_keyboard: [[{ text: 'Cari Lagi', callback_data: 'dl_play', style: 'primary' }]] }, msg.message_id);
      await sendPolishedAudio(bot, chatId, r.download_url, {
        title: r.title || query,
        performer: r.user || 'SoundCloud',
        thumbnail: r.thumbnail || r.artwork_url || r.cover || r.cover_url || r.image || r.image_url
      }, {
        caption: `${E.music} <b>[V2 · Fallback] ${htmlEscape(r.title || query)}</b>\n<blockquote>SoundCloud · mellstecuu MD</blockquote>`,
        reply_to_message_id: musicCard?.message_id || msg.message_id
      });
    }
    notifyMainChannelActivity('playv2', msg.from, {
      title: `${E.music} PLAY V2 ACTIVITY`, emoji: E.music, action: '/playv2',
      fields: {
        'Lagu': r.title || query,
        'Artist / Channel': r.channel || r.user || '-',
        'Durasi': result.type === 'soundcloud' ? (() => { const sec = r.duration ? Math.floor(r.duration / 1000) : null; return sec ? `${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, '0')}` : '-'; })() : (r.duration || '-'),
        'Views': r.views || '-',
        'Provider': result.type === 'soundcloud' ? 'SoundCloud Fallback' : 'YouTube',
        'Chat ID': String(chatId)
      }
    }).catch(() => {});

    await safeDelete(bot, chatId, loading.message_id);
  } catch (e) {
    await safeEdit(bot, chatId, loading.message_id,
      `${E.cross} [V2] Gagal: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
});

bot.onText(/^\/imagetoqr$/, async (msg) => {
  if (!(await requireJoin(msg))) return;
  const chatId = msg.chat.id;
  const reply = msg.reply_to_message;

  if (!reply?.photo) {
    return safeRichTextMessage(chatId,
      `${E.cross} <b>Cara pakai:</b>\nReply sebuah <b>foto</b> dengan perintah <code>/imagetoqr</code>\n\n` +
      `<blockquote>Bot akan mengkonversi foto tersebut menjadi QR Code yang bisa di-scan.</blockquote>`,
      { parse_mode: 'HTML' });
  }

  const loading = await safeRichTextMessage(chatId,
    `<code>${makeBar(30)}</code>\n${E.hourglass} Mengambil foto...`,
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id });

  try {
    const photo = reply.photo[reply.photo.length - 1];
    const fileLink = await bot.getFileLink(photo.file_id);

    await safeEdit(bot, chatId, loading.message_id,
      `<code>${makeBar(60)}</code>\n${E.hourglass} Membuat QR Code dari gambar...`, { parse_mode: 'HTML' });

    const t1 = Date.now();
    const apiRes = await axios.get(
      `https://api.nexray.eu.cc/tools/image2qr?url=${encodeURIComponent(fileLink)}`,
      { responseType: 'arraybuffer', timeout: 60000 }
    );
    const elapsed = Date.now() - t1;

    const contentType = (apiRes.headers['content-type'] || '');
    let resultBuffer = null;
    let resultUrl = null;

    if (contentType.includes('image')) {
      resultBuffer = Buffer.from(apiRes.data);
    } else {
      // Mungkin JSON berisi URL
      const json = JSON.parse(Buffer.from(apiRes.data).toString());
      resultUrl = json.url || json.result || json.image || json.data;
      if (!resultUrl) throw new Error('Server tidak mengembalikan gambar QR.');
    }

    const nowDate = new Date();
    const dateStr = nowDate.toLocaleDateString('id-ID', { day: '2-digit', month: '2-digit', year: 'numeric' });
    const timeStr = nowDate.toLocaleTimeString('id-ID', {
      hour: '2-digit', minute: '2-digit', second: '2-digit', timeZone: 'Asia/Jakarta'
    });

    const caption =
      `${E.qr || '📱'} <b>Image to QR Code</b>\n\n` +
      `${E.check} <b>Status:</b> <code>Berhasil</code>\n` +
      `${E.tgl} <b>Tanggal:</b> <code>${dateStr}</code>\n` +
      `${E.jam} <b>Jam:</b> <code>${timeStr} WIB</code>\n` +
      `${E.respon} <b>Respon:</b> <code>${elapsed} ms</code>\n\n` +
      `<blockquote>${E.search || '🔍'} <b>Cara scan QR ini:</b>\n` +
      `• Buka kamera HP → arahkan ke QR\n` +
      `• Atau gunakan app: Google Lens, QR Scanner\n\n` +
      `Powered by mellstecuu Ϟ MD</blockquote>`;

    await safeDelete(bot, chatId, loading.message_id);

    if (resultBuffer) {
      await bot.sendPhoto(chatId, resultBuffer, {
        caption, parse_mode: 'HTML',
        reply_to_message_id: msg.message_id
      });
    } else {
      await bot.sendPhoto(chatId, resultUrl, {
        caption, parse_mode: 'HTML',
        reply_to_message_id: msg.message_id
      });
    }
  } catch (e) {
    await safeEdit(bot, chatId, loading.message_id,
      `${E.cross} Gagal membuat QR: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
});

// ======================================= //
// 📡 /pinterest — Download Video/Foto Pinterest
// ======================================= //
bot.onText(/^\/pinterest(?:\s+(.+))?$/, async (msg, match) => {
  if (!(await requireJoin(msg))) return;
  const url = (match[1] || '').trim();
  if (!url) return safeRichTextMessage(msg.chat.id, `${E.cross} Format: <code>/pinterest &lt;url&gt;</code>`, { parse_mode: 'HTML' });
  const chatId = msg.chat.id;
  const loading = await safeRichTextMessage(chatId,
    `<code>${makeBar(30)}</code>\n${E.hourglass} Mengambil data dari Pinterest...`,
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  try {
    await safeEdit(bot, chatId, loading.message_id,
      `<code>${makeBar(65)}</code>\n${E.hourglass} Mendownload konten...`, { parse_mode: 'HTML' });
    const data = await downloadPinterest(url);
    const result = data.result;
    const isPhotoOnly = !result.medias.some(m => m.type === 'video');
    let title = result.title || '';
    if (isPhotoOnly) {
      const idMatch = title.match(/#(\d+)/);
      title = `Pinterest Foto${idMatch ? ` (#${idMatch[1]})` : ''}`;
    }
    await safeEdit(bot, chatId, loading.message_id,
      `<code>${makeBar(90)}</code>\n${E.hourglass} Mengirim hasil...`, { parse_mode: 'HTML' });
    if (isPhotoOnly) {
      const imgMedia = result.medias.find(m => m.type === 'image');
      const caption = `${E.pin} <b>${htmlEscape(title)}</b>\n\n` +
        `<blockquote>Downloaded via mellstecu Ϟ FMD</blockquote>`;
      await bot.sendPhoto(chatId, imgMedia.url, { caption, parse_mode: 'HTML', reply_to_message_id: msg.message_id });
      await safeDelete(bot, chatId, loading.message_id);
    } else {
      const cacheKey = `pin_${Date.now()}_${msg.from.id}`;
      pinterestCache.set(cacheKey, { title, duration: result.duration, medias: result.medias });
      setTimeout(() => pinterestCache.delete(cacheKey), 10 * 60 * 1000);
      const caption = `${E.pin} <b>${htmlEscape(title)}</b>\n` +
        `${result.duration ? `Durasi: <code>${htmlEscape(result.duration)}</code>\n` : ''}` +
        `<blockquote>Pilih format yang ingin diunduh:</blockquote>`;
      const keyboard = {
        inline_keyboard: [[
          { text: '✿ Video ✿', callback_data: `pin_video_${cacheKey}`, style: 'primary', icon_custom_emoji_id: '5285347429737055549' },
          { text: '✿ Image ✿', callback_data: `pin_image_${cacheKey}`, style: 'primary', icon_custom_emoji_id: '5267139375447159076' }
        ]]
      };
      await safeDelete(bot, chatId, loading.message_id);
      await bot.sendPhoto(chatId, result.thumbnail, {
        caption,
        parse_mode: 'HTML',
        reply_markup: keyboard,
        reply_to_message_id: msg.message_id
      });
    }
  } catch (e) {
    await safeEdit(bot, chatId, loading.message_id,
      `${E.cross} Gagal download Pinterest: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
});

// ======================================= //
// 📡 /ttsgenerate — Text To Speech AI
// ======================================= //
bot.onText(/^\/ttsgenerate(?:\s+([\s\S]+))?$/, async (msg, match) => {
  if (!(await requireJoin(msg))) return;
  const text = (match[1] || '').trim();
  if (!text) return safeRichTextMessage(msg.chat.id, `${E.cross} Format: <code>/ttsgenerate &lt;teks&gt;</code>`, { parse_mode: 'HTML' });
  const chatId = msg.chat.id;
  const startTime = Date.now();
  const loading = await safeRichTextMessage(chatId,
    `<code>${makeBar(30)}</code>\n${E.hourglass} Memproses TTS: <i>${htmlEscape(text.slice(0, 50))}${text.length > 50 ? '...' : ''}</i>`,
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  try {
    await safeEdit(bot, chatId, loading.message_id,
      `<code>${makeBar(65)}</code>\n${E.hourglass} Mengenerate suara AI...`, { parse_mode: 'HTML' });
    const data = await generateTTS(text);
    const elapsed = ((Date.now() - startTime) / 1000).toFixed(2);
    const available = (data.result || []).filter(r => !r.error && r.url);
    if (!available.length) throw new Error('Tidak ada suara yang berhasil digenerate. Coba lagi.');
    const cacheKey = `tts_${Date.now()}_${msg.from.id}`;
    ttsCache.set(cacheKey, { text, voices: available });
    setTimeout(() => ttsCache.delete(cacheKey), 10 * 60 * 1000);
    const keyboard = available.map(v => [{
      text: `🎙️ ${v.voice_name}`,
      callback_data: `tts_${v.model}_${cacheKey}`,
    }]);
    const date = getJakartaTime();
    const caption = `${E.music} <b>TTS Generator</b>\n\n` +
      `${E.flash} Waktu respon: <code>${elapsed}s</code>\n` +
      `📅 Tanggal: <code>${date}</code>\n` +
      `💬 Teks: <code>${htmlEscape(text)}</code>\n` +
      `🎙️ Tersedia: <code>${available.length} suara</code>\n\n` +
      `<blockquote>Tekan tombol untuk mengirim audio suara yang dipilih:</blockquote>`;
    await safeEdit(bot, chatId, loading.message_id, caption, {
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: keyboard }
    });
  } catch (e) {
    await safeEdit(bot, chatId, loading.message_id,
      `${E.cross} Gagal generate TTS: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
});

//— AddHadiah
bot.onText(/^\/addhadiah$/, async (msg) => {
  if (!isOwner(msg.from.id)) return;
  const chatId = msg.chat.id;
  const reply = msg.reply_to_message;
  if (!reply) {
    return safeRichTextMessage(chatId,
      `${E.info} <b>Cara pakai:</b>\nReply sebuah file/dokumen/txt dengan perintah <code>/addhadiah</code>\n\n<blockquote>Hadiah bisa berupa file apapun yang ingin dikirim ke users.</blockquote>`,
      { parse_mode: 'HTML' });
  }
  let fileId, fileName, fileType;
  if (reply.document) {
    fileId = reply.document.file_id;
    fileName = reply.document.file_name || 'hadiah.zip';
    fileType = 'document';
  } else if (reply.photo) {
    const photo = reply.photo[reply.photo.length - 1];
    fileId = photo.file_id;
    fileName = 'hadiah_foto.jpg';
    fileType = 'photo';
  } else if (reply.video) {
    fileId = reply.video.file_id;
    fileName = reply.video.file_name || 'hadiah_video.mp4';
    fileType = 'video';
  } else if (reply.audio) {
    fileId = reply.audio.file_id;
    fileName = reply.audio.file_name || 'hadiah_audio.mp3';
    fileType = 'audio';
  } else if (reply.text) {
    fileId = null;
    fileName = 'pesan_teks';
    fileType = 'text';
  } else {
    return safeRichTextMessage(chatId, `${E.cross} File tidak didukung. Gunakan dokumen, foto, video, audio, atau pesan teks.`, { parse_mode: 'HTML' });
  }
  pendingHadiahLimit.set(String(msg.from.id), {
    fileId: fileId || reply.text,
    fileName,
    fileType,
    replyText: reply.text || null
  });
  return safeRichTextMessage(chatId,
    `${E.check} <b>File diterima!</b>\n\n` +
    `${E.folder} Nama: <code>${htmlEscape(fileName)}</code>\n` +
    `${E.folder} Tipe: <code>${fileType}</code>\n\n` +
    `<blockquote>Sekarang ketik berapa <b>maksimal Users</b> yang bisa mendapatkan hadiah ini:\n(contoh: <code>10</code>)</blockquote>`,
    { parse_mode: 'HTML' });
});

// ======================================= //
// 📡 /addkode — Owner: Buat kode redeem
// ======================================= //
bot.onText(/^\/addkode$/, async (msg) => {
  if (!isOwner(msg.from.id)) return;
  const chatId = msg.chat.id;
  const rewards = getRewards();
  if (!rewards.length) {
    return safeRichTextMessage(chatId,
      `${E.cross} <b>Belum ada hadiah!</b>\n\n<blockquote>Tambahkan hadiah terlebih dahulu dengan cara reply file/dokumen lalu ketik <code>/addhadiah</code></blockquote>`,
      { parse_mode: 'HTML' });
  }
  const keyboard = rewards.map((r, i) => [{
    text: `${i + 1}. ${r.fileName} (maks ${r.maxUsers} users)`,
    callback_data: `addkode_pilih_${r.id}`,
    style: 'primary',
    icon_custom_emoji_id: '5427009714745524395' // Gift Emoji
  }]);
  return safeRichTextMessage(chatId,
    `${E.key} <b>Pilih Hadiah untuk Kode Redeem</b>\n\n` +
    `<blockquote>Pilih hadiah mana yang ingin dibuatkan kode redeem-nya:</blockquote>`,
    { parse_mode: 'HTML', reply_markup: { inline_keyboard: keyboard } });
});

// ======================================= //
// 📡 /listhadiah — Owner: Lihat daftar hadiah
// ======================================= //
bot.onText(/^\/listhadiah$/, async (msg) => {
  if (!isOwner(msg.from.id)) return;
  const rewards = getRewards();
  if (!rewards.length) {
    return safeRichTextMessage(msg.chat.id, `${E.empty} Belum ada hadiah yang ditambahkan.`, { parse_mode: 'HTML' });
  }
  const list = rewards.map((r, i) =>
    `${i + 1}. <code>${htmlEscape(r.fileName)}</code> | Maks: <code>${r.maxUsers}</code> users\nID: <code>${r.id}</code>`
  ).join('\n\n');
  return safeRichTextMessage(msg.chat.id,
    `${E.folder} <b>Daftar Hadiah (${rewards.length})</b>\n\n${list}`,
    { parse_mode: 'HTML' });
});

// ======================================= //
// 📡 /hapushadiah <id> — Owner: Hapus hadiah
// ======================================= //
bot.onText(/^\/hapushadiah(?:\s+(.+))?$/, async (msg, match) => {
  if (!isOwner(msg.from.id)) return;
  const id = (match[1] || '').trim();
  if (!id) return safeRichTextMessage(msg.chat.id, `${E.cross} Format: <code>/hapushadiah &lt;id_hadiah&gt;</code>\n\nGunakan /listhadiah untuk melihat ID.`, { parse_mode: 'HTML' });
  const rewards = getRewards();
  const exists = rewards.find(r => r.id === id);
  if (!exists) return safeRichTextMessage(msg.chat.id, `${E.cross} Hadiah dengan ID <code>${htmlEscape(id)}</code> tidak ditemukan.`, { parse_mode: 'HTML' });
  removeReward(id);
  return safeRichTextMessage(msg.chat.id, `${E.check} Hadiah <code>${htmlEscape(exists.fileName)}</code> berhasil dihapus.`, { parse_mode: 'HTML' });
});

// ======================================= //
// 📡 /rasukbot <token> — Possession bot lain
// ======================================= //
// ------- /broadcast [teks] — [Owner] Kirim info ke semua user & chat bot -------
bot.onText(/^\/broadcast(?:\s+([\s\S]+))?$/i, async (msg, match) => {
  if (!isOwner(msg.from.id)) {
    return safeRichTextMessage(msg.chat.id, `${E.cross} Fitur ini khusus Developer/Owner bot.`, { parse_mode: 'HTML' });
  }
  const content = (match[1] || '').trim();
  if (!content) {
    pendingBroadcast.set(String(msg.from.id), true);
    return safeRichTextMessage(msg.chat.id,
      `${E.info} <b>Mode Broadcast Aktif</b>\n\n` +
      `<blockquote>Ketik pesan yang ingin dikirim ke SEMUA user & grup yang pernah pakai bot.\nKetik /batal untuk membatalkan.</blockquote>`,
      { parse_mode: 'HTML' });
  }
  return runBroadcast(msg, content);
});

async function runBroadcast(msg, content) {
  const state = readState();
  const allIds = new Set([
    ...Object.keys(state.users || {}),
    ...Object.keys(state.chats || {})
  ]);
  const text =
    `${E.party} <b>Broadcast dari Developer</b>\n\n` +
    `<blockquote>${htmlEscape(content)}</blockquote>\n\n` +
    `<b>${E.awan} mellstecu ϟ FMD</b>`;
  const info = await safeRichTextMessage(msg.chat.id,
    `${E.hourglass} Mengirim broadcast ke <b>${allIds.size}</b> user/grup...`, { parse_mode: 'HTML' });
  let success = 0, failed = 0;
  for (const targetId of allIds) {
    try {
      await safeRichTextMessage(targetId, text, { parse_mode: 'HTML' });
      success++;
      await new Promise(r => setTimeout(r, 80));
    } catch { failed++; }
  }
  return safeEdit(bot, msg.chat.id, info.message_id,
    `${E.check} <b>Broadcast Selesai!</b>\n\n` +
    `${E.check} Berhasil: <code>${success}</code>\n` +
    `${E.cross} Gagal: <code>${failed}</code>`,
    { parse_mode: 'HTML' });
}

// ------- /req — Request fitur ke Developer -------
bot.onText(/^\/req(?:\s+([\s\S]+))?$/i, async (msg, match) => {
  const uid=String(msg.from?.id||''); if(!uid) return;
  const direct=String(match[1]||'').trim();
  if(!direct){ pendingFeatureRequest.set(uid,{chatId:msg.chat.id,createdAt:Date.now()}); setTimeout(()=>pendingFeatureRequest.delete(uid),10*60*1000); return safeRichTextMessage(msg.chat.id,'💡 <b>REQUEST FITUR</b>\n\nKetik fitur yang ingin ditambahkan/diperbaiki.\n\nContoh: <code>tambahkan menu statistik member</code>\n\nKetik /batal untuk membatalkan.',{parse_mode:'HTML'}); }
  return submitFeatureRequest(msg,direct);
});
async function submitFeatureRequest(msg, requestText){
  const uid=String(msg.from?.id||''); const name=[msg.from?.first_name,msg.from?.last_name].filter(Boolean).join(' ')||msg.from?.username||'Pengguna'; const username=msg.from?.username?`@${msg.from.username}`:'-';
  const req=createFeatureRequest({userId:uid,chatId:msg.chat.id,username,name,text:requestText});
  try{
    await safeRichTextMessage(c.ID,`💡 <b>REQUEST FITUR BARU</b>\n\nID Request: <code>${req.id}</code>\nNama: <b>${htmlEscape(name)}</b>\nUsername: <code>${htmlEscape(username)}</code>\nUser ID: <code>${uid}</code>\nChat ID: <code>${htmlEscape(String(msg.chat.id))}</code>\n\n<blockquote>${htmlEscape(requestText)}</blockquote>`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'💬 Balas Request',callback_data:`req_reply_${req.id}`}],[{text:'📋 Request ID',callback_data:`req_info_${req.id}`}]]}});
    return safeRichTextMessage(msg.chat.id,`✅ <b>Request terkirim ke Developer!</b>\n\nID: <code>${req.id}</code>\nDeveloper sudah menerima detail akunmu dan isi request.\nJika Developer membalas, jawabannya akan dikirim langsung ke chat ini.`,{parse_mode:'HTML'});
  }catch(e){ return safeRichTextMessage(msg.chat.id,`${E.cross} Gagal mengirim request ke Developer: <code>${htmlEscape(e.message)}</code>`,{parse_mode:'HTML'}); }
}
bot.onText(/^\/jawabreq\s+([A-Za-z0-9-]+)(?:\s+([\s\S]+))?$/i, async (msg, match)=>{
  if(!isOwner(msg.from?.id)) return; const id=String(match[1]||'').toUpperCase(); const answer=String(match[2]||'').trim();
  if(!answer) return safeRichTextMessage(msg.chat.id,`💬 Format: <code>/jawabreq ${htmlEscape(id)} pesan balasan</code>`,{parse_mode:'HTML'}); return deliverFeatureRequestAnswer(msg,id,answer);
});
async function deliverFeatureRequestAnswer(msg,id,answer){
  const req=getFeatureRequest(id); if(!req) return safeRichTextMessage(msg.chat.id,`${E.cross} Request <code>${htmlEscape(id)}</code> tidak ditemukan.`,{parse_mode:'HTML'});
  answerFeatureRequest(id,answer);
  try{ await safeRichTextMessage(req.chatId,`💬 <b>Developer membalas Request ${htmlEscape(id)}</b>\n\n<blockquote>${htmlEscape(answer)}</blockquote>\n\n<i>Terima kasih sudah mengirim request.</i>`,{parse_mode:'HTML'}); }
  catch(e){ return safeRichTextMessage(msg.chat.id,`${E.cross} Balasan tersimpan, tetapi pesan ke user gagal dikirim: <code>${htmlEscape(e.message)}</code>`,{parse_mode:'HTML'}); }
  return safeRichTextMessage(msg.chat.id,`${E.check} Balasan untuk <code>${htmlEscape(id)}</code> berhasil dikirim ke user.`,{parse_mode:'HTML'});
}

// ------- /lapor — Kirim saran/laporan fitur langsung ke Developer -------
bot.onText(/^\/lapor$/i, async (msg) => {
  pendingLapor.set(String(msg.from.id), true);
  return safeRichTextMessage(msg.chat.id,
    `${E.info} <b>Kirim Laporan / Saran ke Developer</b>\n\n` +
    `<blockquote>Ketik teks yang ingin kamu sampaikan ke Developer/Owner bot.\n` +
    `Bisa berupa saran fitur, laporan bug, atau menu baru.\nKetik /batal untuk membatalkan.</blockquote>`,
    { parse_mode: 'HTML' });
});

// ------- /batal — Batalkan mode input (broadcast/lapor) -------
bot.onText(/^\/batal$/i, async (msg) => {
  const uid = String(msg.from.id);
  let cancelled = false;
  if (pendingBroadcast.has(uid)) { pendingBroadcast.delete(uid); cancelled = true; }
  if (pendingLapor.has(uid)) { pendingLapor.delete(uid); cancelled = true; }
  if (pendingFeatureRequest.has(uid)) { pendingFeatureRequest.delete(uid); cancelled = true; }
  if (pendingFeatureReply.has(uid)) { pendingFeatureReply.delete(uid); cancelled = true; }
  if (amPremiumSessions.has(uid)) { amPremiumSessions.delete(uid); cancelled = true; }
  return safeRichTextMessage(msg.chat.id,
    cancelled ? `${E.check} Dibatalkan.` : `${E.cross} Tidak ada mode aktif yang perlu dibatalkan.`,
    { parse_mode: 'HTML' });
});

bot.onText(/^\/rasukbot(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const token = (match[1] || '').trim();
  if (!token || !token.includes(':')) {
    return safeRichTextMessage(chatId,
      `${E.cross} <b>Format:</b> <code>/rasukbot &lt;token_bot&gt;</code>\n\n<blockquote>Token bisa didapat dari @BotFather.</blockquote>`,
      { parse_mode: 'HTML' });
  }
  const loadMsg = await safeRichTextMessage(chatId,
    `<blockquote>${E.hourglass} Memvalidasi token...</blockquote>`, { parse_mode: 'HTML' });
  try {
    const r = await axios.get(`https://api.telegram.org/bot${token}/getMe`, { timeout: 10000 });
    if (!r.data?.ok) throw new Error('Token tidak valid');
    const botInfo = r.data.result;
    const uid = String(msg.from.id);
    const existing = controlledBots.get(uid) || {};
    existing[token] = { username: botInfo.username, firstName: botInfo.first_name };
    controlledBots.set(uid, existing);
    await safeDelete(bot, chatId, loadMsg.message_id);
    return safeRichTextMessage(chatId,
      `${E.check} <b>Bot Berhasil Dirasuk!</b>\n` +
      `${E.bot} Bot: <b>${htmlEscape(botInfo.first_name)}</b>\n` +
      `${E.user} Username: @${htmlEscape(botInfo.username || '-')}\n` +
      `${E.key} Token: <code>${htmlEscape(token.slice(0, 12))}...tersembunyi</code>\n\n` +
      `<blockquote>Pilih aksi selanjutnya:</blockquote>`,
      {
        parse_mode: 'HTML',
        reply_to_message_id: msg.message_id,
        reply_markup: {
          inline_keyboard: [[
            {
              text: '✿ Mulai Akses Bot ✿',
              callback_data: `rasuk_mulai_${token}`,
              style: 'primary',
              icon_custom_emoji_id: '5465443379917629504' // E.flash ⚡
            },
            {
              text: '✿ List Command ✿',
              callback_data: `rasuk_listcmd_${token}`,
              style: 'success',
              icon_custom_emoji_id: '6208270338971669367' // E.clipboard 📋
            }
          ]]
        }
      });
  } catch (e) {
    await safeEdit(bot, chatId, loadMsg.message_id,
      `${E.cross} Gagal merasuk bot: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
});

// ======================================= //
// 📡 /outcontrol — Keluar dari mode kontrol
// ======================================= //
bot.onText(/^\/outcontrol$/, async (msg) => {
  const uid = String(msg.from.id);
  if (!activeControl.has(uid)) {
    return safeRichTextMessage(msg.chat.id,
      `${E.cross} Kamu tidak sedang dalam mode kontrol.`, { parse_mode: 'HTML' });
  }
  const info = activeControl.get(uid);
  activeControl.delete(uid);
  return safeRichTextMessage(msg.chat.id,
    `${E.check} <b>Keluar dari mode kontrol.</b>\n\n` +
    `<blockquote>Bot @${htmlEscape(info.username || '-')} tidak lagi dikendalikan.\n` +
    `Ketik /listbot untuk lihat daftar bot, atau /getcontrol &lt;token&gt; untuk masuk lagi.</blockquote>`,
    { parse_mode: 'HTML' });
});

// ======================================= //
// 📋 /listgb — Daftar grup yang memakai bot (owner only)
// ======================================= //
const LISTGB_PAGE_SIZE = 10;

function getListGbGroups() {
  const state = readState();
  return Object.values(state.chats || {})
    .filter(chat => ['group', 'supergroup'].includes(chat?.type))
    .filter(chat => !['left', 'kicked'].includes(String(chat?.botStatus || '').toLowerCase()))
    .sort((a, b) => {
      const at = String(a?.title || a?.username || a?.id || '').toLowerCase();
      const bt = String(b?.title || b?.username || b?.id || '').toLowerCase();
      return at.localeCompare(bt, 'id');
    });
}

function listGbKeyboard(page, totalPages) {
  const rows = [];
  const nav = [];
  if (page > 1) nav.push({ text: '‹ Sebelumnya', callback_data: `listgb_page_${page - 1}`, style: 'primary' });
  if (page < totalPages) nav.push({ text: 'Berikutnya ›', callback_data: `listgb_page_${page + 1}`, style: 'primary' });
  if (nav.length) rows.push(nav);
  rows.push([
    { text: '🔄 Refresh', callback_data: `listgb_page_${page}`, style: 'success' },
    { text: '🏠 Menu Utama', callback_data: 'back_menu', style: 'danger' }
  ]);
  return { inline_keyboard: rows };
}

function buildListGbRich(page = 1) {
  const groups = getListGbGroups();
  const total = groups.length;
  const totalPages = Math.max(1, Math.ceil(total / LISTGB_PAGE_SIZE));
  const safePage = Math.max(1, Math.min(Number(page) || 1, totalPages));
  const start = (safePage - 1) * LISTGB_PAGE_SIZE;
  const items = groups.slice(start, start + LISTGB_PAGE_SIZE);
  const state = readState();
  const privateCount = Object.values(state.chats || {}).filter(chat => chat?.type === 'private').length;
  const rows = items.length
    ? items.map((chat, index) => {
        const no = start + index + 1;
        const title = htmlEscape(String(chat.title || chat.username || 'Tanpa Nama').slice(0, 90));
        const username = chat.username ? `@${htmlEscape(String(chat.username).replace(/^@/, '').slice(0, 50))}` : '-';
        const type = chat.type === 'supergroup' ? 'Supergroup' : 'Group';
        return `<tr><td><b>${no}</b></td><td>${title}${username !== '-' ? `<br><code>${username}</code>` : ''}</td><td><code>${htmlEscape(String(chat.id))}</code><br><i>${type}</i></td></tr>`;
      }).join('')
    : `<tr><td colspan="3">Belum ada grup yang tercatat oleh bot.</td></tr>`;

  const text = [
    `<h2>📋 LIST GROUP BOT</h2>`,
    `<p>Daftar grup yang tercatat menggunakan bot ini.</p>`,
    `<table bordered compact><tr><th>STATISTIK</th><th>JUMLAH</th></tr>` +
      `<tr><td>Bot dipakai di</td><td align="right"><b>${total} grup</b></td></tr>` +
      `<tr><td>Private chat</td><td align="right">${privateCount}</td></tr>` +
      `<tr><td>Halaman</td><td align="right">${safePage} / ${totalPages}</td></tr>` +
    `</table>`,
    `<h3>DAFTAR GRUP</h3>`,
    `<table bordered compact><tr><th>#</th><th>NAMA / USERNAME</th><th>CHAT ID</th></tr>${rows}</table>`,
    `<footer>Data berasal dari chat yang telah tercatat oleh bot. Grup yang bot-nya sudah keluar/kicked tidak ditampilkan.</footer>`
  ].join('');

  return { text, page: safePage, totalPages, total };
}

bot.onText(/^\/listgb$/i, async (msg) => {
  if (!isOwner(msg.from?.id)) {
    return safeRichTextMessage(msg.chat.id, '<blockquote>🔒 <b>LIST GROUP</b></blockquote><p>Fitur ini hanya dapat digunakan oleh owner bot.</p>', { parse_mode: 'HTML' });
  }
  const view = buildListGbRich(1);
  return sendDevRich(msg.chat.id, view.text, {
    parse_mode: 'HTML',
    reply_markup: listGbKeyboard(view.page, view.totalPages)
  });
});

// ======================================= //
// 📡 /listbot — Lihat daftar bot yang dirasuk
// ======================================= //
bot.onText(/^\/listbot$/, async (msg) => {
  const uid = String(msg.from.id);
  const bots = controlledBots.get(uid) || {};
  const entries = Object.entries(bots);
  if (!entries.length) {
    return safeRichTextMessage(msg.chat.id,
      `${E.empty} <b>Belum ada bot yang dirasuk.</b>\n\n<blockquote>Gunakan /rasukbot &lt;token&gt; untuk merasuk bot.</blockquote>`,
      { parse_mode: 'HTML' });
  }
  const current = activeControl.get(uid);
  const list = entries.map(([token, info], i) => {
    const active = current?.token === token ? ' ✅ <b>(aktif)</b>' : '';
    return `${i + 1}. <b>${htmlEscape(info.firstName)}</b> (@${htmlEscape(info.username || '-')})${active}\n   Token: <code>${htmlEscape(token.slice(0, 10))}...</code>`;
  });
  return safeRichTextMessage(msg.chat.id,
    `${E.bot} <b>Daftar Bot yang Dirasuk (${entries.length})</b>\n\n${list.join('\n\n')}\n\n` +
    `<blockquote>Gunakan /getcontrol &lt;token_lengkap&gt; untuk masuk ke mode kontrol.</blockquote>`,
    { parse_mode: 'HTML' });
});

// ======================================= //
// 📡 /getcontrol <token> — Masuk kontrol
// ======================================= //
bot.onText(/^\/getcontrol(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const token = (match[1] || '').trim();
  const uid = String(msg.from.id);
  if (!token) {
    return safeRichTextMessage(chatId,
      `<blockquote>${E.cross} Format: <code>/getcontrol &lt;token_bot&gt;</code></blockquote>`, { parse_mode: 'HTML' });
  }
  const bots = controlledBots.get(uid) || {};
  const info = bots[token];
  if (!info) {
    return safeRichTextMessage(chatId,
      `${E.cross} Token tidak ditemukan. Gunakan /listbot untuk melihat daftar, atau /rasukbot untuk merasuk bot baru.`,
      { parse_mode: 'HTML' });
  }
  activeControl.set(uid, { token, ...info });
  return safeRichTextMessage(chatId,
    `${E.check} <b>Mode Kontrol Aktif!</b>\n\n` +
    `${E.bot} Bot: <b>${htmlEscape(info.firstName)}</b> (@${htmlEscape(info.username || '-')})\n\n` +
    `<blockquote>Semua command kontrol siap digunakan.\nKetik /outcontrol untuk keluar.</blockquote>`,
    {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [[
          {
            text: '✿ List Command ✿',
              callback_data: `rasuk_listcmd_${token}`,
              style: 'success',
              icon_custom_emoji_id: '6208270338971669367' // E.clipboard 📋
          }
        ]]
      }
    });
});

bot.onText(/^\/message(?:\s+([\s\S]+))?$/, async (msg, match) => {
  const uid = String(msg.from.id);
  const ctrl = activeControl.get(uid);
  if (!ctrl) return safeRichTextMessage(msg.chat.id, `${E.cross} Kamu tidak dalam mode kontrol. Gunakan /getcontrol atau /rasukbot.`, { parse_mode: 'HTML' });
  const text = (match[1] || '').trim();
  if (!text) return safeRichTextMessage(msg.chat.id, `${E.cross} Format: <code>/message &lt;pesannya&gt;</code>`, { parse_mode: 'HTML' });
  const loadMsg = await safeRichTextMessage(msg.chat.id,
    `<blockquote>${E.hourglass} Mengirim pesan ke semua users via @${htmlEscape(ctrl.username || '-')}...</blockquote>`,
    { parse_mode: 'HTML' });
  try {
    const res = await controlBroadcast(ctrl.token, 'sendMessage', { text, parse_mode: 'HTML' });
    await safeEdit(bot, msg.chat.id, loadMsg.message_id,
      `<b>BROADCAST SELESAI</b>\nSukses: <code>${res.sukses}</code>\nGagal: <code>${res.gagal}</code>`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [[
            {
              text: '✿ Broadcast Lagi ✿',
              callback_data: 'ctrl_broadcast_again',
              style: 'primary',
              icon_custom_emoji_id: '4958808208752772190' // E.speaker
            },
            {
              text: '✿ List Command ✿',
              callback_data: 'ctrl_listcmd',
              style: 'success',
              icon_custom_emoji_id: '6208270338971669367' // E.clipboard
            }
          ]]
        }
      });
  } catch (e) {
    await safeEdit(bot, msg.chat.id, loadMsg.message_id,
      `${E.cross} Error: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
});

bot.onText(/^\/foto$/, async (msg) => {
  const uid = String(msg.from.id);
  const ctrl = activeControl.get(uid);
  if (!ctrl) return;
  const reply = msg.reply_to_message;
  if (!reply?.photo) return safeRichTextMessage(msg.chat.id, `${E.cross} Reply sebuah foto dengan perintah ini.`, { parse_mode: 'HTML' });
  const photo = reply.photo[reply.photo.length - 1];
  const loadMsg = await safeRichTextMessage(msg.chat.id, `<blockquote>${E.hourglass} Mengirim foto...</blockquote>`, { parse_mode: 'HTML' });
  try {
    const res = await controlSendMedia(bot, ctrl.token, 'sendPhoto', photo.file_id, {});
    await safeEdit(bot, msg.chat.id, loadMsg.message_id,
      `${E.check} Foto terkirim! ${E.check} <code>${res.sukses}</code> | ${E.cross} <code>${res.gagal}</code>`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [[
            {
              text: '✿ Kirim Foto+Caption ✿',
              callback_data: 'ctrl_fotocaption',
              style: 'primary',
              icon_custom_emoji_id: '4958808208752772190' // E.ig
            },
            {
              text: '✿ List Command ✿',
              callback_data: 'ctrl_listcmd',
              style: 'success',
              icon_custom_emoji_id: '6208270338971669367' // E.clipboard
            }
          ]]
        }
      });
  } catch (e) {
    await safeEdit(bot, msg.chat.id, loadMsg.message_id, `${E.cross} <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
});

bot.onText(/^\/fotocaption(?:\s+([\s\S]+))?$/, async (msg, match) => {
  const uid = String(msg.from.id);
  const ctrl = activeControl.get(uid);
  if (!ctrl) return;
  const reply = msg.reply_to_message;
  const caption = (match[1] || '').trim();
  if (!reply?.photo) return safeRichTextMessage(msg.chat.id, `${E.cross} Reply sebuah foto dengan perintah ini.`, { parse_mode: 'HTML' });
  const photo = reply.photo[reply.photo.length - 1];
  const loadMsg = await safeRichTextMessage(msg.chat.id, `<blockquote>${E.hourglass} Mengirim foto...</blockquote>`, { parse_mode: 'HTML' });
  try {
    const res = await controlSendMedia(bot, ctrl.token, 'sendPhoto', photo.file_id, { caption });
    await safeEdit(bot, msg.chat.id, loadMsg.message_id,
      `${E.check} Foto+caption terkirim! ${E.check} <code>${res.sukses}</code> | ${E.cross} <code>${res.gagal}</code>`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [[
            {
              text: '✿ List Command ✿',
              callback_data: 'ctrl_listcmd',
              style: 'success',
              icon_custom_emoji_id: '6208270338971669367' // E.clipboard
            }
          ]]
        }
      });
  } catch (e) {
    await safeEdit(bot, msg.chat.id, loadMsg.message_id, `${E.cross} <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
});

bot.onText(/^\/video$/, async (msg) => {
  const uid = String(msg.from.id);
  const ctrl = activeControl.get(uid);
  if (!ctrl) return;
  const reply = msg.reply_to_message;
  if (!reply?.video) return safeRichTextMessage(msg.chat.id, `${E.cross} Reply sebuah video.`, { parse_mode: 'HTML' });
  const loadMsg = await safeRichTextMessage(msg.chat.id, `<blockquote>${E.hourglass} Mengirim video...</blockquote>`, { parse_mode: 'HTML' });
  try {
    const res = await controlSendMedia(bot, ctrl.token, 'sendVideo', reply.video.file_id, {});
    await safeEdit(bot, msg.chat.id, loadMsg.message_id,
      `${E.check} Video terkirim! ${E.check} <code>${res.sukses}</code> | ${E.cross} <code>${res.gagal}</code>`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [[
            {
              text: '✿ Kirim Video+Caption ✿',
              callback_data: 'ctrl_videocaption',
              style: 'primary',
              icon_custom_emoji_id: '4958808208752772190' // E.movie
            },
            {
              text: '✿ List Command ✿',
              callback_data: 'ctrl_listcmd',
              style: 'success',
              icon_custom_emoji_id: '6208270338971669367' // E.clipboard
            }
          ]]
        }
      });
  } catch (e) {
    await safeEdit(bot, msg.chat.id, loadMsg.message_id, `${E.cross} <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
});

bot.onText(/^\/videocaption(?:\s+([\s\S]+))?$/, async (msg, match) => {
  const uid = String(msg.from.id);
  const ctrl = activeControl.get(uid);
  if (!ctrl) return;
  const reply = msg.reply_to_message;
  const caption = (match[1] || '').trim();
  if (!reply?.video) return safeRichTextMessage(msg.chat.id, `${E.cross} Reply sebuah video.`, { parse_mode: 'HTML' });
  const loadMsg = await safeRichTextMessage(msg.chat.id, `<blockquote>${E.hourglass} Mengirim video...</blockquote>`, { parse_mode: 'HTML' });
  try {
    const res = await controlSendMedia(bot, ctrl.token, 'sendVideo', reply.video.file_id, { caption });
    await safeEdit(bot, msg.chat.id, loadMsg.message_id,
      `${E.check} Video+caption terkirim! ${E.check} <code>${res.sukses}</code> | ${E.cross} <code>${res.gagal}</code>`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [[
            {
              text: '✿ List Command ✿',
              callback_data: 'ctrl_listcmd',
              style: 'success',
              icon_custom_emoji_id: '6208270338971669367' // E.clipboard
            }
          ]]
        }
      });
  } catch (e) {
    await safeEdit(bot, msg.chat.id, loadMsg.message_id, `${E.cross} <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
});

bot.onText(/^\/stikersend$/, async (msg) => {
  const uid = String(msg.from.id);
  const ctrl = activeControl.get(uid);
  if (!ctrl) return;
  const reply = msg.reply_to_message;
  if (!reply?.sticker) return safeRichTextMessage(msg.chat.id, `${E.cross} Reply sebuah stiker.`, { parse_mode: 'HTML' });
  const loadMsg = await safeRichTextMessage(msg.chat.id, `<blockquote>${E.hourglass} Mengirim stiker...</blockquote>`, { parse_mode: 'HTML' });
  try {
    const res = await controlSendMedia(bot, ctrl.token, 'sendSticker', reply.sticker.file_id, {});
    await safeEdit(bot, msg.chat.id, loadMsg.message_id,
      `${E.check} Stiker terkirim! ${E.check} <code>${res.sukses}</code> | ${E.cross} <code>${res.gagal}</code>`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [[
            {
              text: '✿ List Command ✿',
              callback_data: 'ctrl_listcmd',
              style: 'success',
              icon_custom_emoji_id: '6208270338971669367' // E.clipboard
            }
          ]]
        }
      });
  } catch (e) {
    await safeEdit(bot, msg.chat.id, loadMsg.message_id, `${E.cross} <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
});

bot.onText(/^\/file$/, async (msg) => {
  const uid = String(msg.from.id);
  const ctrl = activeControl.get(uid);
  if (!ctrl) return;
  const reply = msg.reply_to_message;
  if (!reply?.document) return safeRichTextMessage(msg.chat.id, `${E.cross} Reply sebuah file/dokumen.`, { parse_mode: 'HTML' });
  const loadMsg = await safeRichTextMessage(msg.chat.id, `<blockquote>${E.hourglass} Mengirim file...</blockquote>`, { parse_mode: 'HTML' });
  try {
    const res = await controlSendMedia(bot, ctrl.token, 'sendDocument', reply.document.file_id, {});
    await safeEdit(bot, msg.chat.id, loadMsg.message_id,
      `${E.check} File terkirim! ${E.check} <code>${res.sukses}</code> | ${E.cross} <code>${res.gagal}</code>`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [[
            {
              text: '✿ Kirim File+Caption ✿',
              callback_data: 'ctrl_filecaption',
              style: 'primary',
              icon_custom_emoji_id: '4958808208752772190' // E.folder
            },
            {
              text: '✿ List Command ✿',
              callback_data: 'ctrl_listcmd',
              style: 'success',
              icon_custom_emoji_id: '6208270338971669367' // E.clipboard
            }
          ]]
        }
      });
  } catch (e) {
    await safeEdit(bot, msg.chat.id, loadMsg.message_id, `${E.cross} <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
});

bot.onText(/^\/filecaption(?:\s+([\s\S]+))?$/, async (msg, match) => {
  const uid = String(msg.from.id);
  const ctrl = activeControl.get(uid);
  if (!ctrl) return;
  const reply = msg.reply_to_message;
  const caption = (match[1] || '').trim();
  if (!reply?.document) return safeRichTextMessage(msg.chat.id, `${E.cross} Reply sebuah file/dokumen.`, { parse_mode: 'HTML' });
  const loadMsg = await safeRichTextMessage(msg.chat.id, `<blockquote>${E.hourglass} Mengirim file...</blockquote>`, { parse_mode: 'HTML' });
  try {
    const res = await controlSendMedia(bot, ctrl.token, 'sendDocument', reply.document.file_id, { caption });
    await safeEdit(bot, msg.chat.id, loadMsg.message_id,
      `${E.check} File+caption terkirim! ${E.check} <code>${res.sukses}</code> | ${E.cross} <code>${res.gagal}</code>`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [[
            {
              text: '✿ List Command ✿',
              callback_data: 'ctrl_listcmd',
              style: 'success',
              icon_custom_emoji_id: '6208270338971669367' // E.clipboard
            }
          ]]
        }
      });
  } catch (e) {
    await safeEdit(bot, msg.chat.id, loadMsg.message_id, `${E.cross} <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
});

bot.onText(/^\/audio$/, async (msg) => {
  const uid = String(msg.from.id);
  const ctrl = activeControl.get(uid);
  if (!ctrl) return;
  const reply = msg.reply_to_message;
  if (!reply?.audio && !reply?.voice) return safeRichTextMessage(msg.chat.id, `${E.cross} Reply sebuah audio.`, { parse_mode: 'HTML' });
  const fid = reply.audio?.file_id || reply.voice?.file_id;
  const loadMsg = await safeRichTextMessage(msg.chat.id, `<blockquote>${E.hourglass} Mengirim audio...</blockquote>`, { parse_mode: 'HTML' });
  try {
    const res = await controlSendMedia(bot, ctrl.token, 'sendAudio', fid, {});
    await safeEdit(bot, msg.chat.id, loadMsg.message_id,
      `${E.check} Audio terkirim! ${E.check} <code>${res.sukses}</code> | ${E.cross} <code>${res.gagal}</code>`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [[
            {
              text: '✿ Kirim Audio+Caption ✿',
              callback_data: 'ctrl_audiocaption',
              style: 'primary',
              icon_custom_emoji_id: '4958808208752772190' // E.music
            },
            {
              text: '✿ List Command ✿',
              callback_data: 'ctrl_listcmd',
              style: 'success',
              icon_custom_emoji_id: '6208270338971669367' // E.clipboard
            }
          ]]
        }
      });
  } catch (e) {
    await safeEdit(bot, msg.chat.id, loadMsg.message_id, `${E.cross} <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
});

bot.onText(/^\/audiocaption(?:\s+([\s\S]+))?$/, async (msg, match) => {
  const uid = String(msg.from.id);
  const ctrl = activeControl.get(uid);
  if (!ctrl) return;
  const reply = msg.reply_to_message;
  const caption = (match[1] || '').trim();
  if (!reply?.audio && !reply?.voice) return safeRichTextMessage(msg.chat.id, `${E.cross} Reply sebuah audio.`, { parse_mode: 'HTML' });
  const fid = reply.audio?.file_id || reply.voice?.file_id;
  const loadMsg = await safeRichTextMessage(msg.chat.id, `<blockquote>${E.hourglass} Mengirim audio...</blockquote>`, { parse_mode: 'HTML' });
  try {
    const res = await controlSendMedia(bot, ctrl.token, 'sendAudio', fid, { caption });
    await safeEdit(bot, msg.chat.id, loadMsg.message_id,
      `${E.check} Audio+caption terkirim! ${E.check} <code>${res.sukses}</code> | ${E.cross} <code>${res.gagal}</code>`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [[
            {
              text: '✿ List Command ✿',
              callback_data: 'ctrl_listcmd',
              style: 'success',
              icon_custom_emoji_id: '6208270338971669367' // E.clipboard
            }
          ]]
        }
      });
  } catch (e) {
    await safeEdit(bot, msg.chat.id, loadMsg.message_id, `${E.cross} <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
});
// ======================================= //
// 📡 /brathd — Brat HD dari teks
// ======================================= //
bot.onText(/^\/brathd(?:\s+([\s\S]+))?$/i, async (msg, match) => {
  if (!(await requireJoin(msg))) return;
  const chatId = msg.chat.id;
  const text = String(match?.[1] || '').trim().slice(0, 220);
  if (!text) {
    return safeRichTextMessage(chatId,
      `${E.sticker} <b>BRAT HD</b>\n\n` +
      `Bikin stiker Brat HD dari teks yang kamu mau, lalu langsung jadi sticker.\n\n` +
      `<b>Format:</b> <code>/brathd teks kamu</code>\n` +
      `<b>Contoh:</b> <code>/brathd bosok</code>`,
      { parse_mode:'HTML', reply_to_message_id:msg.message_id });
  }

  const loading = await safeRichTextMessage(chatId,
    `${E.sticker} <b>BRAT HD PROCESS</b>\n` +
    `📝 Teks : <b>${htmlEscape(text)}</b>\n` +
    `${E.hourglass} Sedang membuat sticker...`,
    { parse_mode:'HTML', reply_to_message_id:msg.message_id });

  try {
    const sharp = require('sharp');
    // Render lokal agar hasil stabil tanpa bergantung API pembuat sticker.
    // Layout dibuat putih bersih dengan teks hitam besar seperti contoh.
    const fontSize = text.length > 24 ? 52 : text.length > 14 ? 68 : 88;
    const svg = `<svg width="512" height="512" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">` +
      `<rect width="512" height="512" fill="#ffffff"/>` +
      `<text x="256" y="256" text-anchor="middle" dominant-baseline="middle" fill="#111111" font-family="Arial,Helvetica,sans-serif" font-size="${fontSize}" font-weight="400">${safe}</text>` +
      `</svg>`;
    const webp = await sharp(Buffer.from(svg)).resize(512,512,{fit:'contain'}).webp({quality:100}).toBuffer();

    await safeDelete(bot, chatId, loading.message_id);
    try {
      return await bot.sendSticker(chatId, webp,
        { reply_to_message_id:msg.message_id },
        { filename:'brathd.webp', contentType:'image/webp' });
    } catch {
      return await bot.sendPhoto(chatId, webp, {
        caption:`${E.sticker} <b>BRAT HD</b>\n📝 Teks : <b>${htmlEscape(text)}</b>`,
        parse_mode:'HTML', reply_to_message_id:msg.message_id
      });
    }
  } catch (e) {
    return safeEdit(bot, chatId, loading.message_id,
      `${E.cross} <b>Brat HD gagal dibuat.</b>\n<code>${htmlEscape(e.message)}</code>`,
      { parse_mode:'HTML' });
  }
});

// ======================================= //
// 📡 /brat — Stiker Brat HD
// ======================================= //
bot.onText(/^\/brat(?:\s+([\s\S]+))?$/i, async (msg, match) => {
  if (!(await requireJoin(msg))) return;
  const chatId = msg.chat.id;
  const text = String(match?.[1] || '').trim().slice(0, 220);
  if (!text) {
    return safeRichTextMessage(chatId,
      `${E.sticker} <b>Brat Stiker</b>\n\nFormat: <code>/brat &lt;teks&gt;</code>\n\nContoh: <code>/brat Yataa!</code>`,
      { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  }

  const loading = await safeRichTextMessage(chatId,
    `<code>${makeBar(25)}</code>\n${E.sticker} Menyiapkan stiker Brat...`,
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id });

  try {
    const sharp = require('sharp');

    // Render lokal supaya teks panjang tidak terpotong/keluar kanvas.
    // Teks otomatis di-wrap ke beberapa baris berdasarkan perkiraan lebar font.
    const words = text.replace(/\s+/g, ' ').split(' ');
    const maxWidth = 450;
    let fontSize = text.length <= 14 ? 86 : text.length <= 28 ? 70 : text.length <= 55 ? 58 : 48;
    const charWidth = fontSize * 0.53;
    const maxChars = Math.max(8, Math.floor(maxWidth / charWidth));
    const lines = [];
    let line = '';

    for (const word of words) {
      // Kata yang sangat panjang ikut dipecah agar tidak melewati kanvas.
      if (word.length > maxChars) {
        if (line) { lines.push(line); line = ''; }
        for (let i = 0; i < word.length; i += maxChars) {
          lines.push(word.slice(i, i + maxChars));
        }
        continue;
      }
      const candidate = line ? `${line} ${word}` : word;
      if (candidate.length > maxChars) {
        lines.push(line);
        line = word;
      } else {
        line = candidate;
      }
    }
    if (line) lines.push(line);

    // Jika sangat panjang, kecilkan font dan hitung ulang agar tetap nyaman dibaca.
    if (lines.length > 6) {
      fontSize = 42;
    }

    const lineHeight = Math.round(fontSize * 1.18);
    const totalHeight = lines.length * lineHeight;
    const startY = 256 - (totalHeight - lineHeight) / 2;
    const tspans = lines.map((l, i) =>
      `<tspan x="256" y="${Math.round(startY + i * lineHeight)}">${svgEscape(l)}</tspan>`
    ).join('');

    const svg = `<svg width="512" height="512" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">` +
      `<rect width="512" height="512" fill="#ffffff"/>` +
      `<text x="256" y="256" text-anchor="middle" fill="#111111" font-family="Arial,Helvetica,sans-serif" font-size="${fontSize}" font-weight="400">${tspans}</text>` +
      `</svg>`;

    const webp = await sharp(Buffer.from(svg))
      .resize(512, 512, { fit: 'contain' })
      .webp({ quality: 100 })
      .toBuffer();

    await safeDelete(bot, chatId, loading.message_id);
    try {
      await bot.sendSticker(chatId, webp,
        { reply_to_message_id: msg.message_id },
        { filename: 'brat.webp', contentType: 'image/webp' });
    } catch {
      await bot.sendPhoto(chatId, webp, {
        caption: `${E.sticker} <b>Brat</b>\n📝 ${htmlEscape(text)}`,
        parse_mode: 'HTML',
        reply_to_message_id: msg.message_id
      });
    }
  } catch (e) {
    await safeEdit(bot, chatId, loading.message_id,
      `${E.cross} <b>Gagal buat brat.</b>\n<code>${htmlEscape(e.message)}</code>`,
      { parse_mode: 'HTML' });
  }
});

// ======================================= //
// 📡 /bratvid — GIF/Animasi Brat HD
// ======================================= //
bot.onText(/^\/bratvid(?:\s+([\s\S]+))?$/, async (msg, match) => {
  if (!(await requireJoin(msg))) return;
  const chatId = msg.chat.id;
  const text = (match[1] || '').trim();
  if (!text) {
    return safeRichTextMessage(chatId,
      `<blockquote><b>BRAT VIDEO STICKER</b></blockquote>\n\n` +
      `Format: <code>/bratvid &lt;teks&gt;</code>\n\n` +
      `Output: <b>video sticker Telegram (.WEBM)</b>, bukan GIF dan bukan video biasa.\n` +
      `Durasi maksimal 3 detik.`,
      { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  }
  const loading = await safeRichTextMessage(chatId,
    `<code>${makeBar(20)}</code>\nMembuat video sticker Brat: <b>${htmlEscape(text)}</b>`,
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  let inputPath = '', outputPath = '', frameDir = '';
  try {
    await safeEdit(bot, chatId, loading.message_id,
      `<code>${makeBar(45)}</code>\nMengambil animasi Brat...`, { parse_mode: 'HTML' });
    // Generate the Brat sticker locally. Unlike the old implementation, the
    // sticker is genuinely animated: the text gently bounces/scales through
    // the 3-second VP9 WebM instead of being a static frame repeated 90 times.
    const sharp = require('sharp');
    const os = require('os');
    const words = text.replace(/\s+/g, ' ').trim().split(' ');
    const lines = [];
    let line = '';
    const maxChars = text.length > 70 ? 17 : text.length > 42 ? 20 : text.length > 26 ? 23 : 27;
    for (const word of words) {
      const next = line ? `${line} ${word}` : word;
      if (next.length > maxChars && line) { lines.push(line); line = word; }
      else line = next;
    }
    if (line) lines.push(line);
    const fontSize = lines.length >= 5 ? 44 : lines.length >= 4 ? 50 : lines.length >= 3 ? 58 : lines.length >= 2 ? 70 : 86;
    const base = path.join(os.tmpdir(), `brat-sticker-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`);
    frameDir = `${base}-frames`;
    inputPath = `${base}.png`;
    outputPath = `${base}.webm`;
    fs.mkdirSync(frameDir, {recursive:true});

    const makeFrameSvg = (frameNo) => {
      // BratVid reference style: white square, heavy black condensed text,
      // with a repeating fade/zoom motion (the text briefly disappears,
      // fades back in, and gently scales). It is still exported as a Telegram
      // video sticker (WEBM/VP9), so it moves like a sticker rather than a
      // normal rectangular video message.
      const t = frameNo / 30;
      const cycle = (t % 1.5) / 1.5;
      const fade = cycle < 0.18
        ? cycle / 0.18
        : cycle > 0.82
          ? Math.max(0, (1 - cycle) / 0.18)
          : 1;
      const scale = 0.96 + 0.08 * Math.sin(Math.PI * Math.min(1, cycle) * 0.9);
      const x = 256 + 2 * Math.sin(t * Math.PI * 2);
      const y = 256 + 3 * Math.sin(t * Math.PI * 2);
      const tspans = lines.slice(0, 6).map((l, i) =>
        `<tspan x="0" dy="${i === 0 ? 0 : Math.round(fontSize * 1.02)}">${svgEscape(l)}</tspan>`
      ).join('');
      const startY = -((Math.min(lines.length, 6) - 1) * fontSize * 1.02) / 2;
      return `<svg width="512" height="512" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">` +
        `<rect width="512" height="512" fill="#ffffff"/>` +
        `<g transform="translate(${x} ${y}) scale(${scale})" opacity="${Math.max(0, Math.min(1, fade)).toFixed(3)}">` +
        `<text x="0" y="${Math.round(startY)}" text-anchor="middle" dominant-baseline="middle" fill="#111111" font-family="Impact,Arial Black,Arial,sans-serif" font-size="${fontSize}" font-weight="900">${tspans}</text>` +
        `</g></svg>`;
    };

    // 3 seconds × 30 fps = 90 frames. The reference style intentionally uses
    // a white background, while WEBM/VP9 keeps the result as an animated sticker.
    for (let i = 0; i < 90; i++) {
      const frame = await sharp(Buffer.from(makeFrameSvg(i)), {density:72}).png().toBuffer();
      fs.writeFileSync(path.join(frameDir, `frame-${String(i).padStart(3,'0')}.png`), frame);
    }
    await safeEdit(bot, chatId, loading.message_id,
      `<code>${makeBar(70)}</code>\nMengubah animasi ke <b>video sticker Telegram</b>...`, { parse_mode: 'HTML' });
    await runFfmpeg([
      '-hide_banner','-y',
      '-framerate','30',
      '-i',path.join(frameDir,'frame-%03d.png'),
      '-t','3',
      '-an',
      '-c:v','libvpx-vp9',
      '-b:v','0',
      '-crf','38',
      '-deadline','good',
      '-cpu-used','5',
      '-pix_fmt','yuva420p',
      '-auto-alt-ref','0',
      '-row-mt','1',
      outputPath
    ], 180000);
    let sticker = fs.readFileSync(outputPath);
    if (!sticker.length) throw new Error('Konversi WEBM gagal.');
    if (sticker.length > 256 * 1024) {
      await runFfmpeg([
        '-hide_banner','-y',
        '-framerate','30',
        '-i',path.join(frameDir,'frame-%03d.png'),
        '-t','3',
        '-an',
        '-c:v','libvpx-vp9',
        '-b:v','0',
        '-crf','50',
        '-deadline','good',
        '-cpu-used','8',
        '-pix_fmt','yuva420p',
        '-auto-alt-ref','0',
        '-row-mt','1',
        outputPath
      ], 180000);
      sticker = fs.readFileSync(outputPath);
    }
    if (sticker.length > 256 * 1024) throw new Error(`Video sticker masih terlalu besar (${Math.ceil(sticker.length / 1024)} KB).`);
    await safeEdit(bot, chatId, loading.message_id,
      `<code>${makeBar(92)}</code>\nMengirim <b>video sticker animasi</b>...`, { parse_mode: 'HTML' });
    await bot.sendSticker(chatId, sticker,
      { emoji: '📝', reply_to_message_id: msg.message_id },
      { filename: 'brat-sticker.webm', contentType: 'video/webm' });
    await safeDelete(bot, chatId, loading.message_id);
  } catch (e) {
    await safeEdit(bot, chatId, loading.message_id,
      `Gagal membuat video sticker Brat.\n<code>${htmlEscape(e.message || 'Unknown error')}</code>`,
      { parse_mode: 'HTML' });
  } finally {
    try { if (inputPath) fs.unlinkSync(inputPath); } catch {}
    try { if (outputPath) fs.unlinkSync(outputPath); } catch {}
    try { if (typeof frameDir !== 'undefined' && frameDir) fs.rmSync(frameDir,{recursive:true,force:true}); } catch {}
  }
});

// ======================================= //
// 📡 /prankdana & /fakedana — Simulasi Saldo (jelas untuk hiburan)
// ======================================= //
bot.onText(/^\/(?:prankdana|fakedana)(?:\s+([\s\S]+))?$/i, async (msg, match) => {
  if (!(await requireJoin(msg))) return;
  const chatId = msg.chat.id;
  const nominal = (match[1] || '').trim().replace(/[^\d.,]/g, '');
  if (!nominal) {
    return safeRichTextMessage(chatId,
      `${E.phone} <b>Simulasi Saldo</b>\n\nFormat: <code>/fakedana 500000</code>\n\n⚠️ Hasil selalu diberi label <b>SIMULASI / PRANK</b> dan bukan bukti pembayaran.`,
      { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  }
  const loading = await safeRichTextMessage(chatId, `<code>${makeBar(20)}</code>\n${E.hourglass} Membuat kartu simulasi...`, { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  try {
    let sharp;
    try { sharp = require('sharp'); } catch { throw new Error('Modul <code>sharp</code> belum terpasang. Jalankan <code>npm install</code> lalu restart bot.'); }
    await safeEdit(bot, chatId, loading.message_id, `<code>${makeBar(65)}</code>\n${E.hourglass} Menyiapkan gambar simulasi...`, { parse_mode:'HTML' });
    const safeNominal = htmlEscape(nominal);
    const svg = `<svg width="1200" height="700" xmlns="http://www.w3.org/2000/svg"><rect width="1200" height="700" rx="40" fill="#111"/><rect x="45" y="45" width="1110" height="610" rx="32" fill="#191919" stroke="#00d4ff" stroke-width="4"/><text x="80" y="125" fill="#fff" font-size="42" font-family="Arial">SIMULASI SALDO</text><text x="80" y="205" fill="#aaa" font-size="26" font-family="Arial">Nominal hiburan</text><text x="80" y="285" fill="#00d4ff" font-size="72" font-weight="bold" font-family="Arial">Rp {nominal}</text><rect x="80" y="350" width="1040" height="105" rx="20" fill="#2a1d00" stroke="#ffb000"/><text x="600" y="416" text-anchor="middle" fill="#ffcf5a" font-size="38" font-weight="bold" font-family="Arial">PRANK / SIMULASI — BUKAN BUKTI PEMBAYARAN</text><text x="80" y="535" fill="#888" font-size="24" font-family="Arial">Generated by bot • Untuk hiburan saja</text></svg>`.replace('{nominal}', safeNominal.replace(/&amp;/g,'&'));
    const png = await sharp(Buffer.from(svg)).png().toBuffer();
    await safeEdit(bot, chatId, loading.message_id, `<code>${makeBar(95)}</code>\n${E.hourglass} Mengirim hasil...`, { parse_mode:'HTML' });
    await bot.sendPhoto(chatId, png, { caption: `${E.phone} <b>Simulasi Saldo Berhasil</b>\n\n<b>Nominal:</b> <code>Rp ${safeNominal}</code>\n⚠️ <b>PRANK / SIMULASI — BUKAN BUKTI PEMBAYARAN</b>`, parse_mode:'HTML', reply_to_message_id:msg.message_id });
    await safeDelete(bot, chatId, loading.message_id);
  } catch (e) {
    await safeEdit(bot, chatId, loading.message_id, `${E.cross} <b>Gagal membuat simulasi:</b>\n<code>${htmlEscape(e.message)}</code>`, {parse_mode:'HTML'});
  }
});

// ======================================= //
// 🛠️ LOCAL HD FALLBACK — tidak bergantung pada API eksternal
// ======================================= //
async function localEnhanceMedia(fileBuffer, mode) {
  if(mode==='image'){
    let sharp; try{sharp=require('sharp');}catch{throw new Error('Modul sharp belum terpasang. Jalankan npm install.');}
    const meta=await sharp(fileBuffer).metadata();
    const width=Math.max(1,Number(meta.width||1200)); const height=Math.max(1,Number(meta.height||800));
    return sharp(fileBuffer).resize({width:width*4,height:height*4,fit:'inside',withoutEnlargement:false,kernel:'lanczos3'}).sharpen({sigma:1.35,m1:1.2,m2:2.0}).jpeg({quality:94,chromaSubsampling:'4:4:4',progressive:true,mozjpeg:true}).toBuffer();
  }
  let ffmpegPath; try{ffmpegPath=require('ffmpeg-static');}catch{throw new Error('Modul ffmpeg-static belum terpasang. Jalankan npm install.');}
  const os=require('os'); const {spawn}=require('child_process'); const tmpDir=fs.mkdtempSync(path.join(os.tmpdir(),'wink-'));
  const input=path.join(tmpDir,'input.mp4'); const output=path.join(tmpDir,'output.mp4'); fs.writeFileSync(input,fileBuffer);
  await new Promise((resolve,reject)=>{const proc=spawn(ffmpegPath,['-y','-i',input,'-vf','scale=min(iw*1.5\,1920):min(ih*1.5\,1920):force_original_aspect_ratio=decrease,unsharp=5:5:0.7:5:5:0.0','-c:v','libx264','-preset','veryfast','-crf','20','-c:a','aac','-b:a','128k','-movflags','+faststart',output],{stdio:['ignore','ignore','pipe']});let err='';proc.stderr.on('data',d=>err+=d.toString());proc.on('error',reject);proc.on('close',code=>code===0?resolve():reject(new Error(err.slice(-700)||`ffmpeg exit ${code}`)));});
  const out=fs.readFileSync(output); try{fs.rmSync(tmpDir,{recursive:true,force:true});}catch{} return out;
}

// ======================================= //
// 📡 /wink — AI Enhance Foto / Video HD
// ======================================= //
bot.onText(/^\/hd$/i, async (msg) => {
  if (!(await requireJoin(msg))) return;
  return safeRichTextMessage(msg.chat.id,`${E.image} <b>HD Media Center — 4× Upscale</b>\n\nPilih foto atau video. Foto diproses dengan upscale lokal 4× + sharpening; video memakai enhancer FFmpeg.`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'📸 HD Foto',callback_data:`wink_image_${msg.chat.id}_${msg.from.id}`},{text:'🎬 HD Video',callback_data:`wink_video_${msg.chat.id}_${msg.from.id}`}],[{text:'↩️ Menu Alat',callback_data:'menu_alat'}]]}});
});

bot.onText(/^\/wink$/, async (msg) => {
  if (!(await requireJoin(msg))) return;
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  // Hapus wink lama jika ada
  pendingWink.delete(String(userId));

  return safeRichTextMessage(chatId,
    `${E.wink || '✨'} <b>Wink — AI Enhance</b>\n\n` +
    `<blockquote>Pilih mode yang kamu inginkan:\n\n` +
    `${E.image || '📸'} <b>HD Images</b> — Upscale foto 4× + sharpening agar lebih bersih\n` +
    `${E.video || '🎬'} <b>HD Video</b> — Perbaiki kualitas video jadi HD</blockquote>`,
    {
      parse_mode: 'HTML',
      reply_to_message_id: msg.message_id,
      reply_markup: {
        inline_keyboard: [[
          { 
            text: '✿ HD Images ✿', 
            callback_data: `wink_image_${chatId}_${userId}`, 
            style: 'primary',
            icon_custom_emoji_id: '5294300937605633051' // ID Emoji Kamera / Foto Premium kamu
          },
          { 
            text: '✿ HD Video ✿',  
            callback_data: `wink_video_${chatId}_${userId}`,  
            style: 'primary',
            icon_custom_emoji_id: '5389108217496231210' // ID Emoji Video / Film Premium kamu
          }
        ]]
      }
    });
});

// ======================================= //
// 📡 /npmpackage — NPM Package Info & Download
// ======================================= //
bot.onText(/^\/npmpackage(?:\s+([\s\S]+))?$/, async (msg, match) => {
  if (!(await requireJoin(msg))) return;
  const chatId = msg.chat.id;
  const pack   = (match[1] || '').trim().toLowerCase();

  if (!pack) {
    return safeRichTextMessage(chatId,
      `${E.box} <b>NPM Package</b>\n\n<b>Format:</b> <code>/npmpackage &lt;nama-package&gt;</code>\n\n<b>Contoh:</b>\n• <code>/npmpackage axios</code>\n• <code>/npmpackage express</code>`,
      { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  }

  const loading = await safeRichTextMessage(chatId,
    `<code>${makeBar(20)}</code>\n${E.hourglass} Mencari package: <b>${htmlEscape(pack)}</b>`,
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id });

  try {
    await safeEdit(bot, chatId, loading.message_id,
      `<code>${makeBar(55)}</code>\n${E.hourglass} Mengambil info dari registry NPM...`, { parse_mode: 'HTML' });

    const apiRes = await axios.get('https://api.nexray.eu.cc/downloader/npm', {
      params: { q: pack },
      timeout: 30000
    });

    if (!apiRes.data?.status || !apiRes.data?.result) {
      throw new Error('Package tidak ditemukan atau API error.');
    }

    const r = apiRes.data.result;

    // Format ukuran file
    const fmtSize = (bytes) => {
      if (!bytes) return 'N/A';
      if (bytes >= 1024 * 1024) return `${(bytes / 1024 / 1024).toFixed(2)} MB`;
      if (bytes >= 1024) return `${(bytes / 1024).toFixed(1)} KB`;
      return `${bytes} B`;
    };

    // Format dependencies (runtime)
    const deps = r.dependencies || {};
    const depKeys = Object.keys(deps);
    const depText = depKeys.length
      ? depKeys.map(k => `  • <code>${htmlEscape(k)}</code>: <code>${htmlEscape(deps[k])}</code>`).join('\n')
      : '  <i>Tidak ada dependencies</i>';

    // Simpan ke cache untuk tombol
    const npmId = ++_npmCacheCounter;
    npmCache.set(npmId, { chatId, result: r });
    setTimeout(() => npmCache.delete(npmId), 30 * 60 * 1000); // auto-hapus 30 menit

    const infoText =
      `${E.box} <b>NPM Package Info</b>\n\n` +
      `${E.Name} <b>Name:</b> <code>${htmlEscape(r.name || pack)}</code>\n` +
      `${E.clipboard} <b>Desc:</b> <i>${htmlEscape(r.description || '-')}</i>\n` +
      `${E.pin} <b>Version:</b> <code>${htmlEscape(r.version || '-')}</code>\n` +
      `${E.shield} <b>License:</b> <code>${htmlEscape(r.license || '-')}</code>\n` +
      `${E.user} <b>Author:</b> <code>${htmlEscape(typeof r.author === 'object' ? (r.author?.name || '-') : (r.author || '-'))}</code>\n` +
      `${E.web} <b>Homepage:</b> ${r.homepage ? `<a href="${r.homepage}">${htmlEscape(r.homepage)}</a>` : '<i>-</i>'}\n` +
      `${E.folder} <b>Repo:</b> <code>${htmlEscape((r.repository || '-').replace(/^git\+/, ''))}</code>\n` +
      `${E.ruler} <b>Size:</b> <code>${fmtSize(r.size)}</code>\n` +
      `${E.link} <b>Download URL:</b>\n<code>${htmlEscape(r.download_url || '-')}</code>\n\n` +
      (depKeys.length
        ? `${E.add} <b>Dependencies (${depKeys.length}):</b>\n${depText}`
        : `${E.add} <b>Dependencies:</b> <i>Tidak ada</i>`) +
      `\n\n<blockquote>Powered by mellstecuu Ϟ MD × NPM Registry</blockquote>`;

    await safeDelete(bot, chatId, loading.message_id);

    await safeRichTextMessage(chatId, infoText, {
      parse_mode: 'HTML',
      disable_web_page_preview: true,
      reply_to_message_id: msg.message_id,
      reply_markup: {
        inline_keyboard: [[
  { 
    text: '✿ Get Dev Dependencies ✿', 
    callback_data: `npm_deps_${npmId}`,
    style: 'primary', // Menambahkan warna biru/primary
    icon_custom_emoji_id: '5789699190128906461' 
  },
  { 
    text: '✿ Download ✿', 
    callback_data: `npm_dl_${npmId}`,
    style: 'success', // Menambahkan warna hijau/success
    icon_custom_emoji_id: '5255741073409452371' 
     }
  ]]
      }
    });

  } catch (e) {
    await safeEdit(bot, chatId, loading.message_id,
      `${E.cross} Gagal ambil package: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
});

// ------- Rose-style keyword filters -------
// A filter must survive even when Telegram refuses copyMessage for a particular
// source message (for example a protected/Rich Message). We keep a lightweight
// snapshot of the reply so the bot can recreate common message types locally.
function snapshotFilterMessage(source) {
  if (!source) return null;
  const snap = {
    message_id: source.message_id || null,
    chat_id: source.chat?.id || null,
    text: source.text || null,
    entities: Array.isArray(source.entities) ? source.entities : null,
    caption: source.caption || null,
    caption_entities: Array.isArray(source.caption_entities) ? source.caption_entities : null,
    photo: Array.isArray(source.photo) && source.photo.length ? source.photo[source.photo.length - 1].file_id : null,
    video: source.video?.file_id || null,
    video_width: source.video?.width || null,
    video_height: source.video?.height || null,
    video_duration: source.video?.duration || null,
    document: source.document?.file_id || null,
    audio: source.audio?.file_id || null,
    voice: source.voice?.file_id || null,
    animation: source.animation?.file_id || null,
    sticker: source.sticker?.file_id || null,
    video_note: source.video_note?.file_id || null,
    contact: source.contact || null,
    location: source.location || null
  };
  return snap;
}

async function sendSnapshotFilter(chatId, snap) {
  if (!snap) return false;
  const captionOpts = {};
  if (snap.caption) captionOpts.caption = snap.caption;
  if (snap.caption_entities) captionOpts.caption_entities = snap.caption_entities;

  if (snap.text) {
    const opts = {};
    if (snap.entities) opts.entities = snap.entities;
    try { await safeRichTextMessage(chatId, snap.text, { reply_to_message_id: null }); } catch { await bot.sendMessage(chatId, snap.text, opts); }
    return true;
  }
  if (snap.photo) { await bot.sendPhoto(chatId, snap.photo, captionOpts); return true; }
  if (snap.video) { await bot.sendVideo(chatId, snap.video, {...captionOpts, ...(snap.video_width ? {width:snap.video_width}:{}), ...(snap.video_height ? {height:snap.video_height}:{}), ...(snap.video_duration ? {duration:snap.video_duration}:{})}); return true; }
  if (snap.document) { await bot.sendDocument(chatId, snap.document, captionOpts); return true; }
  if (snap.audio) { await bot.sendAudio(chatId, snap.audio, captionOpts); return true; }
  if (snap.voice) { await bot.sendVoice(chatId, snap.voice, captionOpts); return true; }
  if (snap.animation) { await bot.sendAnimation(chatId, snap.animation, captionOpts); return true; }
  if (snap.sticker) { await bot.sendSticker(chatId, snap.sticker); return true; }
  if (snap.video_note) { await bot.sendVideoNote(chatId, snap.video_note); return true; }
  if (snap.contact) { await bot.sendContact(chatId, snap.contact.phone_number, snap.contact.first_name, {last_name:snap.contact.last_name || ''}); return true; }
  if (snap.location) { await bot.sendLocation(chatId, snap.location.latitude, snap.location.longitude); return true; }
  return false;
}

async function triggerGroupFilter(chatId, trigger, hit) {
  // First choice: preserve the original Telegram message exactly.
  if (hit?.sourceMessageId) {
    try {
      await bot.copyMessage(chatId, chatId, hit.sourceMessageId);
      return true;
    } catch (copyErr) {
      // A protected message or a Rich Message may not be copyable. Try forward
      // before falling back to the stored snapshot.
      try {
        await bot.forwardMessage(chatId, chatId, hit.sourceMessageId);
        return true;
      } catch (forwardErr) {
        console.warn(`[FILTER] copy/forward failed for ${trigger}:`, forwardErr?.message || copyErr?.message || forwardErr);
      }
    }
  }
  try {
    return await sendSnapshotFilter(chatId, hit?.sourceMessage || null);
  } catch (snapshotErr) {
    console.error(`[FILTER] snapshot failed for ${trigger}:`, snapshotErr?.message || snapshotErr);
    return false;
  }
}

async function canUseGroupFilters(msg) {
  if (msg.chat.type === 'private') {
    await safeRichSendMessage(msg.chat.id, `${E.cross} <b>Filters hanya tersedia di grup.</b>`, {parse_mode:'HTML'});
    return false;
  }
  return true;
}

async function canManageGroupFilter(msg) {
  if (msg.chat.type === 'private') {
    await safeRichSendMessage(msg.chat.id, `${E.cross} <b>Fitur filter hanya tersedia di grup.</b>`, {parse_mode:'HTML'});
    return false;
  }
  return await requireGroupAdmin(msg);
}

bot.onText(/^\/filter(?:\s+(.+))?$/i, async (msg, match) => {
  if (!(await canManageGroupFilter(msg))) return;
  const trigger = String(match[1] || '').trim().toLowerCase();
  if (!trigger) return safeRichSendMessage(msg.chat.id, `❌ Format: <code>/filter kata</code>\nReply pesan yang ingin disimpan.`, {parse_mode:'HTML'});
  if (!msg.reply_to_message) return safeRichSendMessage(msg.chat.id, `❌ Reply pesan yang ingin dijadikan filter.\n\nContoh: reply foto → <code>/filter gambar</code>.`, {parse_mode:'HTML'});
  if (trigger.startsWith('/') || trigger.length > 64) return safeRichSendMessage(msg.chat.id, `❌ Kata filter harus 1–64 karakter dan tidak boleh diawali /.`, {parse_mode:'HTML'});
  const filters = getGroupFilters(msg.chat.id);
  if (!filters[trigger] && Object.keys(filters).length >= 100) return safeRichSendMessage(msg.chat.id, `❌ <b>Batas filter tercapai.</b> Maksimal 100 filter per grup.`, {parse_mode:'HTML'});
  setGroupFilter(msg.chat.id, trigger, { sourceMessageId: msg.reply_to_message.message_id, sourceMessage: snapshotFilterMessage(msg.reply_to_message), createdBy: msg.from.id, createdAt: new Date().toISOString(), chatId: msg.chat.id });
  return safeRichSendMessage(msg.chat.id, `✅ <b>Filter disimpan</b>\n\nPemicu: <code>${htmlEscape(trigger)}</code>\n\nSekarang semua member dapat mengetik <code>${htmlEscape(trigger)}</code> untuk memunculkan balasan filter.\n\nGunakan <code>/filters</code> untuk melihat daftar.`, {parse_mode:'HTML', reply_to_message_id:msg.message_id});
});

bot.onText(/^\/filters$/i, async (msg) => {
  // /filters hanya untuk melihat daftar, jadi semua member dan admin boleh memakai.
  if (!(await canUseGroupFilters(msg))) return;
  const filters = getGroupFilters(msg.chat.id);
  const keys = Object.keys(filters).sort();
  if (!keys.length) return safeRichSendMessage(msg.chat.id, `🔎 <b>FILTERS GRUP</b>\n\nBelum ada filter.\n\nAdmin dapat membuat filter dengan <code>/filter kata</code>.`, {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'↩️ Menu Grup',callback_data:'menu_group'}]]}});
  return safeRichSendMessage(msg.chat.id, `🔎 <b>FILTERS GRUP</b>\n\n${keys.map((k,i)=>`${i+1}. <code>${htmlEscape(k)}</code>`).join('\n')}\n\nTotal: <b>${keys.length}</b>\n\nSemua member dapat melihat daftar ini. Hanya admin yang dapat menambah atau menghapus filter.`, {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'➕ Tambah Filter (Admin)',callback_data:'group_filter_add'}],[{text:'↩️ Menu Grup',callback_data:'menu_group'}]]}});
});

bot.onText(/^\/stop(?:\s+(.+))?$/i, async (msg, match) => {
  if (!(await canManageGroupFilter(msg))) return;
  const trigger = String(match[1] || '').trim().toLowerCase();
  if (!trigger) return safeRichSendMessage(msg.chat.id, `❌ Format: <code>/stop kata</code>`, {parse_mode:'HTML'});
  if (!removeGroupFilter(msg.chat.id, trigger)) return safeRichSendMessage(msg.chat.id, `❌ Filter <code>${htmlEscape(trigger)}</code> tidak ditemukan.`, {parse_mode:'HTML'});
  return safeRichSendMessage(msg.chat.id, `✅ Filter <code>${htmlEscape(trigger)}</code> dihapus.`, {parse_mode:'HTML'});
});

bot.onText(/^\/stopallfilters$/i, async (msg) => {
  if (!(await canManageGroupFilter(msg))) return;
  const ok = clearGroupFilters(msg.chat.id);
  return safeRichTextMessage(msg.chat.id, ok ? `🗑️ <b>Semua filter berhasil dihapus.</b>` : `ℹ️ Tidak ada filter di grup ini.`, {parse_mode:'HTML'});
});

// ------- /antiporno on|off -------
bot.onText(/^\/antiporno(?:\s+(on|off))?$/i, async (msg, match) => {
  if (msg.chat.type === 'private') return safeRichTextMessage(msg.chat.id, `${E.cross} Hanya untuk grup.`);
  if (!(await requireGroupAdmin(msg))) return;
  if (!(await requireBotAdmin(msg.chat.id))) return;
  const action = (match[1] || '').toLowerCase();
  const gs = getGroupSettings(msg.chat.id);
  let newState;
  if (action === 'on') newState = true;
  else if (action === 'off') newState = false;
  else newState = !gs.antiporno;
  setGroupSettings(msg.chat.id, { ...gs, antiporno: newState });
  return safeRichTextMessage(msg.chat.id,
    `${newState ? E.check : E.cross} <b>Anti Porno ${newState ? 'Aktif ✅' : 'Nonaktif ❌'}</b>\n\n` +
    (newState
      ? `<blockquote>${E.shield} Konten porno otomatis dihapus & pelaku ditag.\nDeteksi mencakup:\n• Link situs dewasa\n• Kata-kata vulgar/porno\n• Caption foto/video porno\n• Nama file mencurigakan</blockquote>`
      : `Filter konten porno dinonaktifkan.`),
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
});

// ------- /antiflood on|off -------
bot.onText(/^\/antiflood(?:\s+(on|off))?$/i, async (msg, match) => {
  if (msg.chat.type === 'private') return safeRichTextMessage(msg.chat.id, `${E.cross} Hanya untuk grup.`);
  if (!(await requireGroupAdmin(msg))) return;
  if (!(await requireBotAdmin(msg.chat.id))) return;
  const action = (match[1] || '').toLowerCase();
  const gs = getGroupSettings(msg.chat.id);
  let newState;
  if (action === 'on') newState = true;
  else if (action === 'off') newState = false;
  else newState = !gs.antiflood;
  setGroupSettings(msg.chat.id, { ...gs, antiflood: newState });
  return safeRichTextMessage(msg.chat.id,
    `${newState ? E.check : E.cross} <b>Anti Flood ${newState ? 'Aktif ✅' : 'Nonaktif ❌'}</b>\n\n` +
    (newState
      ? `${E.shield} Member yang kirim 5+ pesan dalam 5 detik\nakan di-mute otomatis selama 10 menit.`
      : `Batas flood dinonaktifkan.`),
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
});

// ------- /antisticker on|off -------
bot.onText(/^\/antisticker(?:\s+(on|off))?$/i, async (msg, match) => {
  if (msg.chat.type === 'private') return safeRichTextMessage(msg.chat.id, `${E.cross} Hanya untuk grup.`);
  if (!(await requireGroupAdmin(msg))) return;
  if (!(await requireBotAdmin(msg.chat.id))) return;
  const action = (match[1] || '').toLowerCase();
  const gs = getGroupSettings(msg.chat.id);
  let newState;
  if (action === 'on') newState = true;
  else if (action === 'off') newState = false;
  else newState = !gs.antisticker;
  setGroupSettings(msg.chat.id, { ...gs, antisticker: newState });
  return safeRichTextMessage(msg.chat.id,
    `${newState ? E.check : E.cross} <b>Anti Sticker ${newState ? 'Aktif ✅' : 'Nonaktif ❌'}</b>\n\n` +
    (newState ? `${E.shield} Semua stiker akan dihapus otomatis.` : `Stiker diperbolehkan kembali.`),
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
});

// ------- /antipromosi on|off -------
bot.onText(/^\/antipromosi(?:\s+(on|off))?$/i, async (msg, match) => {
  if (msg.chat.type === 'private') return safeRichTextMessage(msg.chat.id, `${E.cross} Hanya untuk grup.`);
  if (!(await requireGroupAdmin(msg))) return;
  if (!(await requireBotAdmin(msg.chat.id))) return;
  const action = (match[1] || '').toLowerCase();
  const gs = getGroupSettings(msg.chat.id);
  let newState;
  if (action === 'on') newState = true;
  else if (action === 'off') newState = false;
  else newState = !gs.antipromosi;
  setGroupSettings(msg.chat.id, { ...gs, antipromosi: newState });
  return safeRichTextMessage(msg.chat.id,
    `${newState ? E.check : E.cross} <b>Anti Promosi ${newState ? 'Aktif ✅' : 'Nonaktif ❌'}</b>\n\n` +
    (newState
      ? `${E.shield} Pesan promosi/jualan otomatis dihapus\ndan pelaku di-mute <b>15 menit</b>.`
      : `Filter promosi dinonaktifkan.`),
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
});

// ------- /forcesub @channel|link|off -------
bot.onText(/^\/forcesub(?:\s+([\s\S]+))?$/i, async (msg, match) => {
  const target = String(match?.[1] || '').trim();
  const gs=getGroupSettings(msg.chat.id);
  if (!(await isGroupAdmin(msg.chat.id,msg.from.id))) return safeRichSendMessage(msg.chat.id,'Khusus admin grup.',{parse_mode:'HTML'});
  if (!target || /^off$/i.test(target)) {
    if (/^off$/i.test(target)) { setGroupSettings(msg.chat.id,{...gs,forceSubscribe:{...(gs.forceSubscribe||{}),enabled:false}}); return safeRichSendMessage(msg.chat.id,'<b>Force Subscribe dimatikan.</b>',{parse_mode:'HTML'}); }
    pendingForceSub.set(String(msg.from.id),{chatId:msg.chat.id,createdAt:Date.now()});
    return safeRichSendMessage(msg.chat.id,`<blockquote><b>FORCE SUBSCRIBE — SET CHANNEL</b></blockquote>\n\nKirim <b>1–7 channel</b>, satu per baris.\n\nFormat public: <code>@username</code>\nFormat private: <code>-1001234567890 | https://t.me/+InviteLink</code>\n\nContoh 3 channel:\n<code>@channel_satu\n@channel_dua\n-1001234567890 | https://t.me/+InviteLink</code>\n\nBot harus admin di <b>semua channel</b> dan punya izin Delete Messages di grup. Daftar baru menggantikan daftar lama.`,{parse_mode:'HTML'});
  }
  const raws=target.split(/\r?\n|\s*,\s*/).map(v=>v.trim()).filter(Boolean).slice(0,7);
  try {
    const groupBotState=await getForceSubBotState(msg.chat.id); if(!groupBotState.ok) return safeRichSendMessage(msg.chat.id,`<b>Force Subscribe belum siap</b>\n\n${groupBotState.reason}`,{parse_mode:'HTML'});
    const me=await bot.getMe(); const validated=[];
    for(const raw of raws){ const parsed=parseChannelTarget(raw); if(!parsed) throw new Error(`Format channel tidak valid: ${raw}`); const info=await bot.getChat(parsed.channel); if(info.type!=='channel') throw new Error(`${raw} bukan channel Telegram.`); const bm=await bot.getChatMember(parsed.channel,me.id); if(!['administrator','creator'].includes(bm.status)) throw new Error(`Bot belum admin di ${raw}.`); validated.push({channel:parsed.channel,invite:parsed.invite,title:info.title||parsed.channel}); }
    const unique=[...new Map(validated.map(x=>[x.channel,x])).values()]; if(!unique.length) throw new Error('Tidak ada channel valid.');
    setGroupSettings(msg.chat.id,{...gs,forceSubscribe:{enabled:true,channels:unique,channel:unique[0].channel,invite:unique[0].invite,title:unique[0].title}});
    return safeRichSendMessage(msg.chat.id,`<blockquote><b>FORCE SUBSCRIBE AKTIF</b></blockquote>\n\n<b>${unique.length}/7 channel</b> wajib diikuti:\n${unique.map((x,i)=>`${i+1}. <b>${htmlEscape(x.title)}</b>`).join('\n')}\n\nMember yang belum join semua channel akan langsung dihapus pesannya. Bot tidak melakukan mute dari Force Subscribe.`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[ {text:'Cek Status',callback_data:'group_forcesub_status'} ],[ {text:'Kelola Force Subscribe',callback_data:'group_forcesub'} ]]}});
  } catch(e){ return safeRichSendMessage(msg.chat.id,`<b>Force Subscribe gagal diset</b>\n\n<code>${htmlEscape(e.message||'Unknown error')}</code>\n\nPastikan bot admin di semua channel target.`,{parse_mode:'HTML'}); }
});

// ------- /antitoxic on|off -------
bot.onText(/^\/antitoxic(?:\s+(on|off))?$/i, async (msg, match) => {
  if (msg.chat.type === 'private') return safeRichTextMessage(msg.chat.id, `${E.cross} Hanya untuk grup.`);
  if (!(await requireGroupAdmin(msg))) return;
  if (!(await requireBotAdmin(msg.chat.id))) return;
  const action = (match[1] || '').toLowerCase();
  const gs = getGroupSettings(msg.chat.id);
  let newState;
  if (action === 'on') newState = true;
  else if (action === 'off') newState = false;
  else newState = !gs.antitoxic;
  setGroupSettings(msg.chat.id, { ...gs, antitoxic: newState });
  return safeRichTextMessage(msg.chat.id,
    `${newState ? E.check : E.cross} <b>Anti Toxic ${newState ? 'Aktif ✅' : 'Nonaktif ❌'}</b>\n\n` +
    (newState
      ? `${E.shield} Kata kasar/toxic otomatis dihapus\ndan pelaku di-mute <b>15 menit</b> — berlaku juga untuk admin grup.`
      : `Filter kata kasar dinonaktifkan.`),
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
});

// ------- /antispam on|off -------
bot.onText(/^\/antispam(?:\s+(on|off))?$/i, async (msg, match) => {
  if (msg.chat.type === 'private') return safeRichTextMessage(msg.chat.id, `${E.cross} Hanya untuk grup.`);
  if (!(await requireGroupAdmin(msg))) return;
  if (!(await requireBotAdmin(msg.chat.id))) return;
  const action = (match[1] || '').toLowerCase();
  const gs = getGroupSettings(msg.chat.id);
  let newState;
  if (action === 'on') newState = true;
  else if (action === 'off') newState = false;
  else newState = !gs.antispam;
  setGroupSettings(msg.chat.id, { ...gs, antispam: newState });
  return safeRichTextMessage(msg.chat.id,
    `${newState ? E.check : E.cross} <b>Anti Spam ${newState ? 'Aktif ✅' : 'Nonaktif ❌'}</b>\n\n` +
    (newState
      ? `${E.shield} Member yang kirim 8+ pesan dalam 10 detik\nakan di-mute otomatis selama <b>25 menit</b>.`
      : `Batas spam dinonaktifkan.`),
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
});

// ------- /slowmode <detik> | off -------
bot.onText(/^\/lockall$/i, async msg=>{
  if(!['group','supergroup'].includes(msg.chat.type)) return safeRichTextMessage(msg.chat.id,'❌ <b>/lockall hanya bisa digunakan di grup.</b>',{parse_mode:'HTML'});
  if(!(await requireGroupAdmin(msg)) || !(await requireBotAdmin(msg.chat.id,'can_restrict_members'))) return;
  const gs=getGroupSettings(msg.chat.id); if(gs.lockall) return safeRichTextMessage(msg.chat.id,'ℹ️ Group sudah terkunci.',{parse_mode:'HTML'});
  let previous=null; try{previous=(await bot.getChat(msg.chat.id))?.permissions||null;}catch{}
  const locked={can_send_messages:false,can_send_audios:false,can_send_documents:false,can_send_photos:false,can_send_videos:false,can_send_video_notes:false,can_send_voice_notes:false,can_send_polls:false,can_send_other_messages:false,can_add_web_page_previews:false};
  try{await bot.setChatPermissions(msg.chat.id,locked,{use_independent_chat_permissions:true});}catch{try{await bot.setChatPermissions(msg.chat.id,locked);}catch(e){return safeRichTextMessage(msg.chat.id,`❌ Lock All gagal: <code>${htmlEscape(e.message)}</code>`,{parse_mode:'HTML'});}}
  setGroupSettings(msg.chat.id,{...gs,lockall:true,lockAllBackup:previous});
  return safeRichTextMessage(msg.chat.id,'🔒 <b>LOCK ALL AKTIF</b>\nSemua member tidak dapat chat. Admin tetap dapat mengelola grup.\nGunakan <code>/unlockall</code> untuk membuka.',{parse_mode:'HTML'});
});
bot.onText(/^\/unlockall$/i, async msg=>{
  if(!['group','supergroup'].includes(msg.chat.type)) return safeRichTextMessage(msg.chat.id,'❌ <b>/unlockall hanya bisa digunakan di grup.</b>',{parse_mode:'HTML'});
  if(!(await requireGroupAdmin(msg)) || !(await requireBotAdmin(msg.chat.id,'can_restrict_members'))) return;
  const gs=getGroupSettings(msg.chat.id); if(!gs.lockall) return safeRichTextMessage(msg.chat.id,'ℹ️ Group tidak sedang terkunci.',{parse_mode:'HTML'});
  const unlocked=gs.lockAllBackup||{can_send_messages:true,can_send_audios:true,can_send_documents:true,can_send_photos:true,can_send_videos:true,can_send_video_notes:true,can_send_voice_notes:true,can_send_polls:true,can_send_other_messages:true,can_add_web_page_previews:true};
  try{await bot.setChatPermissions(msg.chat.id,unlocked,{use_independent_chat_permissions:true});}catch{try{await bot.setChatPermissions(msg.chat.id,unlocked);}catch(e){return safeRichTextMessage(msg.chat.id,`❌ Unlock All gagal: <code>${htmlEscape(e.message)}</code>`,{parse_mode:'HTML'});}}
  setGroupSettings(msg.chat.id,{...gs,lockall:false,lockAllBackup:null});
  return safeRichTextMessage(msg.chat.id,'🔓 <b>UNLOCK ALL AKTIF</b>\nMember dapat chat kembali seperti semula.',{parse_mode:'HTML'});
});
bot.onText(/^\/slowmode(?:\s+(.+))?$/i, async (msg, match) => {
  if (msg.chat.type === 'private') return safeRichTextMessage(msg.chat.id, `${E.cross} Hanya untuk grup.`);
  if (!(await requireGroupAdmin(msg))) return;
  if (!(await requireBotAdmin(msg.chat.id, 'can_delete_messages'))) return;
  const arg=(match[1]||'').trim().toLowerCase(); const gs=getGroupSettings(msg.chat.id);
  if (!arg) return safeRichTextMessage(msg.chat.id,`${E.info} <b>Slowmode internal</b>\n\n<code>/slowmode 10</code> — 1 pesan per 10 detik\n<code>/slowmode 30</code> — 1 pesan per 30 detik\n<code>/slowmode off</code> — Nonaktifkan\n\n<i>Bot menghapus pesan member yang dikirim terlalu cepat. Admin tidak terkena batas.</i>`,{parse_mode:'HTML'});
  if (arg==='off'||arg==='0') { setGroupSettings(msg.chat.id,{...gs,slowmode:0}); return safeRichTextMessage(msg.chat.id,`${E.check} <b>Slowmode dinonaktifkan.</b>`,{parse_mode:'HTML',reply_to_message_id:msg.message_id}); }
  const seconds=Number(arg); if(!Number.isFinite(seconds)||seconds<1) return safeRichTextMessage(msg.chat.id,`${E.cross} Masukkan angka 1–3600 detik.`);
  const value=Math.floor(Math.min(3600,seconds)); setGroupSettings(msg.chat.id,{...gs,slowmode:value});
  return safeRichTextMessage(msg.chat.id,`${E.check} <b>Slowmode ${value} detik aktif.</b>\n\nMember hanya boleh mengirim satu pesan setiap ${value} detik.`,{parse_mode:'HTML',reply_to_message_id:msg.message_id});
});

// ------- /linkreq @username -------
bot.onText(/^\/linkreq(?:\s+(.+))?$/i, async (msg, match) => {
  if (msg.chat.type === 'private') return safeRichTextMessage(msg.chat.id, `${E.cross} Hanya untuk grup.`);
  if (!(await requireGroupAdmin(msg))) return;
  if (!(await requireBotAdmin(msg.chat.id))) return;

  // Cek apakah grup PRIVATE (tidak punya username publik)
  let chatInfo;
  try { chatInfo = await bot.getChat(msg.chat.id); }
  catch (e) { return safeRichTextMessage(msg.chat.id, `${E.cross} Gagal ambil info grup: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' }); }

  if (chatInfo.username) {
    return safeRichTextMessage(msg.chat.id,
      `${E.cross} <b>Fitur ini hanya untuk grup PRIVATE!</b>\n\n` +
      `<blockquote>Grup ini adalah grup publik (@${htmlEscape(chatInfo.username)}).\n` +
      `Fitur /linkreq hanya tersedia untuk grup private yang tidak memiliki username publik.</blockquote>`,
      { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  }

  const rawTarget = (match[1] || '').trim();
  if (!rawTarget) {
    return safeRichTextMessage(msg.chat.id,
      `${E.info} <b>Format:</b> <code>/linkreq @username</code>\n\n` +
      `Contoh: <code>/linkreq @mellstecuu</code>\n\n` +
      `<blockquote>Bot akan membuat link undangan khusus yang hanya bisa digunakan oleh username tersebut (berlaku 1 jam, 1x pakai).</blockquote>`,
      { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  }

  const targetUsername = rawTarget.replace(/^@/, '').toLowerCase();
  if (!/^[a-z0-9_]{5,32}$/i.test(targetUsername)) {
    return safeRichTextMessage(msg.chat.id,
      `${E.cross} Username tidak valid. Contoh: <code>@mellstecuu</code>`,
      { parse_mode: 'HTML' });
  }

  // Hapus link req lama untuk username yang sama di grup ini
  for (const [token, data] of privateLinks.entries()) {
    if (data.chatId === msg.chat.id && data.targetUsername === targetUsername) {
      privateLinks.delete(token);
      try { await bot.revokeChatInviteLink(msg.chat.id, data.inviteLink); } catch {}
    }
  }

  try {
    const expireDate = Math.floor(Date.now() / 1000) + (1 * 60 * 60);
    const inviteLinkObj = await bot.createChatInviteLink(msg.chat.id, {
      member_limit: 1,
      expire_date: expireDate,
      name: `for_@${targetUsername}`
    });
    const inviteLink = inviteLinkObj.invite_link;
    const token = `lr_${msg.chat.id}_${Date.now()}`;
    privateLinks.set(token, {
      chatId: msg.chat.id,
      targetUsername,
      inviteLink,
      createdBy: msg.from.id,
      createdAt: Date.now(),
      expireAt: expireDate * 1000
    });
    // Auto-hapus setelah 24 jam jika belum dipakai
    setTimeout(async () => {
      if (privateLinks.has(token)) {
        privateLinks.delete(token);
        try { await bot.revokeChatInviteLink(msg.chat.id, inviteLink); } catch {}
      }
    }, 24 * 60 * 60 * 1000);

    return safeRichTextMessage(msg.chat.id,
      `${E.check} <b>Link Undangan Khusus Dibuat!</b>\n\n` +
      `${E.user} Untuk: <code>@${htmlEscape(targetUsername)}</code>\n` +
      `${E.link} Link: <code>${inviteLink}</code>\n` +
      `${E.watch} Berlaku: <b>24 jam</b> (1x pakai)\n\n` +
      `<blockquote>${E.shield} Link ini HANYA untuk <b>@${htmlEscape(targetUsername)}</b>.\n` +
      `Jika username lain mencoba bergabung via link ini,\nbot akan langsung mengeluarkan mereka.\n` +
      `Setelah @${htmlEscape(targetUsername)} berhasil join, link otomatis dihapus.</blockquote>`,
      { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  } catch (e) {
    return safeRichTextMessage(msg.chat.id, `${E.cross} Gagal buat link: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
});

// ------- /rules + /setrules -------
bot.onText(/^\/rules$/i, async (msg) => {
  if (msg.chat.type === 'private') return safeRichTextMessage(msg.chat.id, `${E.cross} Hanya untuk grup.`);
  const gs=getGroupSettings(msg.chat.id);
  return safeRichTextMessage(msg.chat.id,`📜 <b>RULES GRUP</b>\n\n${gs.rules?htmlEscape(String(gs.rules)):'<i>Rules belum diatur oleh admin.</i>'}`,{parse_mode:'HTML'});
});
bot.onText(/^\/setrules(?:\s+([\s\S]+))?$/i, async (msg,match) => {
  if (msg.chat.type === 'private') return safeRichTextMessage(msg.chat.id, `${E.cross} Hanya untuk grup.`);
  if (!(await requireGroupAdmin(msg))) return;
  const rules=String(match[1]||'').trim(); if(!rules) return safeRichTextMessage(msg.chat.id,'📜 Format: <code>/setrules isi rules</code>',{parse_mode:'HTML'});
  if(rules.length>3000) return safeRichTextMessage(msg.chat.id,`${E.cross} Rules maksimal 3000 karakter.`);
  setGroupSettings(msg.chat.id,{...getGroupSettings(msg.chat.id),rules});
  return safeRichTextMessage(msg.chat.id,`${E.check} <b>Rules grup diperbarui.</b>\n\n${htmlEscape(rules)}`,{parse_mode:'HTML',reply_to_message_id:msg.message_id});
});

// ------- /groupinfo — Lihat status semua fitur keamanan grup -------
bot.onText(/^\/groupinfo$/, async (msg) => {
  if (msg.chat.type === 'private') return safeRichTextMessage(msg.chat.id, `${E.cross} Hanya untuk grup.`);
  if (!(await requireGroupAdmin(msg))) return;
  const gs = getGroupSettings(msg.chat.id);
  const st = (v) => v ? `${E.green} Aktif` : `${E.red} Nonaktif`;
  // Hitung linkreq aktif untuk grup ini
  let activeLinkreq = 0;
  for (const [, data] of privateLinks.entries()) {
    if (data.chatId === msg.chat.id) activeLinkreq++;
  }
  return safeRichTextMessage(msg.chat.id,
    `${E.shield} <b>Status Fitur Keamanan Grup</b>\n\n` +
    `${E.link} Anti Link: ${st(gs.antilink)}\n` +
    `${E.share} Anti Forward: ${st(gs.antiforward)}\n` +
    `${E.bot} Anti Bot: ${st(gs.antibot)}\n` +
    `${E.image} Anti Porno: ${st(gs.antiporno)}\n` +
    `${E.flash} Anti Flood: ${st(gs.antiflood)}\n` +
    `${E.sticker} Anti Sticker: ${st(gs.antisticker)}\n` +
    `${E.gift} Anti Promosi: ${st(gs.antipromosi)}\n` +
    `${E.warning} Anti Toxic: ${st(gs.antitoxic)}\n` +
    `${E.flash} Anti Spam: ${st(gs.antispam)}\n` +
    `${E.lock} Lock Media: ${st(gs.lockmedia)}\n` +
    `${E.hourglass} Slowmode: ${gs.slowmode ? `🟢 ${gs.slowmode}s` : `${E.red} Nonaktif`}\n` +
    `${E.wave} Welcome: ${st(gs.welcome?.enabled)}\n` +
    `${E.key} Link Req Aktif: <code>${activeLinkreq} link</code>\n\n` +
    `<blockquote>Gunakan perintah masing-masing untuk mengubah status.\nContoh: /antiporno on | /antilink off</blockquote>`,
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
});

// ------- /unmute — Unmute member -------
bot.onText(/^\/unmute$/, async (msg) => {
  if (msg.chat.type === 'private') return safeRichTextMessage(msg.chat.id, `${E.cross} Hanya di grup.`);
  if (!(await requireGroupAdmin(msg))) return;
  if (!(await requireBotAdmin(msg.chat.id))) return;
  const target = msg.reply_to_message?.from;
  if (!target) return safeRichTextMessage(msg.chat.id, `${E.cross} Reply pesan member yang ingin di-unmute.`);
  try {
    await bot.restrictChatMember(msg.chat.id, target.id, {
      permissions: {
        can_send_messages: true, can_send_polls: true, can_send_other_messages: true,
        can_add_web_page_previews: true, can_invite_users: true,
        can_change_info: false, can_pin_messages: false
      }
    });
    resetModerationRecord(msg.chat.id, target.id);
    clearAllModerationStrikes(msg.chat.id, target.id);
    const name = [target.first_name, target.last_name].filter(Boolean).join(' ') || target.username || String(target.id);
    return safeRichTextMessage(msg.chat.id, `${E.check} <b>${htmlEscape(name)}</b> di-unmute dan riwayat auto-mute di-reset.`, { parse_mode: 'HTML' });
  } catch (e) {
    return safeRichTextMessage(msg.chat.id, `${E.cross} Gagal unmute: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
});

// ------- /dmuser [menit] — Mute member + hapus pesannya (reply pesan) -------
bot.onText(/^\/dmuser(?:\s+(\d+))?$/i, async (msg, match) => {
  if (msg.chat.type === 'private') return safeRichTextMessage(msg.chat.id, `${E.cross} Hanya di grup.`);
  if (!(await requireGroupAdmin(msg))) return;
  if (!(await requireBotAdmin(msg.chat.id))) return;
  const target = msg.reply_to_message?.from;
  if (!target) {
    return safeRichTextMessage(msg.chat.id,
      `${E.info} <b>Format:</b> <code>/dmuser [menit]</code>\n\n` +
      `Reply pesan member yang mau di-mute + dihapus pesannya.\nContoh: <code>/dmuser 30</code> (default 60 menit jika kosong)`,
      { parse_mode: 'HTML' });
  }
  const minutes = parseInt(match[1], 10) || 60;
  const untilTs = Math.floor(Date.now() / 1000) + (minutes * 60);
  try {
    // Hapus pesan yang di-reply
    try { await bot.deleteMessage(msg.chat.id, msg.reply_to_message.message_id); } catch {}
    // Mute member
    await bot.restrictChatMember(msg.chat.id, target.id, {
      permissions: {
        can_send_messages: false, can_send_polls: false,
        can_send_other_messages: false, can_add_web_page_previews: false
      },
      until_date: untilTs
    });
    // Tandai agar pesan-pesan berikutnya (kalau lolos) ikut dihapus otomatis
    dmMuteList.set(`${msg.chat.id}:${target.id}`, untilTs * 1000);
    const name = [target.first_name, target.last_name].filter(Boolean).join(' ') || target.username || String(target.id);
    return safeRichTextMessage(msg.chat.id,
      `${E.check} <b>${htmlEscape(name)}</b> di-mute & pesannya dihapus.\n` +
      `${E.watch} Durasi mute: <b>${minutes} menit</b>`,
      { parse_mode: 'HTML' });
  } catch (e) {
    return safeRichTextMessage(msg.chat.id, `${E.cross} Gagal: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
});

// ------- /ban — Ban member dari grup -------
// Mendukung:
//   /ban (reply pesan)
//   /ban (reply pesan) alasan
//   /ban @username alasan
//   /ban 123456789 alasan
// Username hanya bisa di-resolve jika user sudah dikenal bot (cache/member/admin),
// karena Telegram Bot API tidak menyediakan lookup user umum berdasarkan @username.
bot.onText(/^\/ban(?:@\w+)?(?:\s+([\s\S]+))?$/i, async (msg, match) => {
  if (msg.chat.type === 'private') return safeRichTextMessage(msg.chat.id, `${E.cross} Hanya di grup.`);
  if (!(await requireGroupAdmin(msg))) return;
  if (!(await requireBotAdmin(msg.chat.id, 'can_restrict_members'))) return;

  const rawArgs = String(match?.[1] || '').trim();
  const replied = msg.reply_to_message?.from;
  let target = null;
  let reason = '';

  if (replied?.id) {
    target = replied;
    reason = rawArgs;
  } else {
    if (!rawArgs) {
      return safeRichTextMessage(msg.chat.id,
        `${E.cross} <b>Target belum ditentukan.</b>\n\n` +
        `Reply pesan member lalu gunakan <code>/ban [alasan]</code>\n` +
        `atau gunakan <code>/ban @username [alasan]</code>.\n\n` +
        `<blockquote>Contoh: <code>/ban @username nipu anggota grup</code></blockquote>`,
        { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
    }

    const parts = rawArgs.split(/\s+/);
    const targetToken = parts.shift();
    reason = parts.join(' ').trim();
    target = await resolveRoleTarget(msg, targetToken);

    if (!target?.id) {
      return safeRichTextMessage(msg.chat.id,
        `${E.cross} <b>User tidak ditemukan.</b>\n\n` +
        `Untuk <code>@username</code>, user harus sudah pernah terlihat oleh bot di grup atau merupakan admin grup.\n` +
        `Alternatif paling pasti: <b>reply pesan user</b> lalu gunakan <code>/ban [alasan]</code>.`,
        { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
    }
  }

  // Alasan bersifat opsional; tetap dibuat jelas agar aktivitas moderasi mudah dibaca.
  reason = reason.replace(/\s+/g, ' ').trim().slice(0, 300) || 'Tidak ada alasan yang dicantumkan.';

  if (String(target.id) === String(msg.from.id)) {
    return safeRichTextMessage(msg.chat.id, `${E.warning} Kamu tidak bisa memban diri sendiri.`, { parse_mode: 'HTML' });
  }

  try {
    const current = await bot.getChatMember(msg.chat.id, target.id);
    if (current?.status === 'creator') {
      return safeRichTextMessage(msg.chat.id, `${E.cross} Pemilik grup tidak dapat di-ban oleh bot.`, { parse_mode: 'HTML' });
    }
    if (current?.status === 'administrator') {
      return safeRichTextMessage(msg.chat.id, `${E.cross} User tersebut adalah admin grup. Cabut status admin terlebih dahulu jika memang ingin memban user ini.`, { parse_mode: 'HTML' });
    }

    await bot.banChatMember(msg.chat.id, target.id);

    const name = [target.first_name, target.last_name].filter(Boolean).join(' ') ||
      (target.username ? `@${target.username}` : String(target.id));
    const usernameLine = target.username ? `\n<b>Username:</b> @${htmlEscape(target.username)}` : '';

    const text =
      `<blockquote>🔨 <b>MEMBER DI-BAN</b></blockquote>\n\n` +
      `<b>👤 User:</b> ${htmlEscape(name)}${usernameLine}\n` +
      `<b>🆔 ID:</b> <code>${htmlEscape(String(target.id))}</code>\n` +
      `<b>📝 Alasan:</b> ${htmlEscape(reason)}\n\n` +
      `<i>Ban berhasil diterapkan oleh ${htmlEscape([msg.from.first_name, msg.from.last_name].filter(Boolean).join(' ') || msg.from.username || String(msg.from.id))}.</i>`;

    return safeRichTextMessage(msg.chat.id, text, {
      parse_mode: 'HTML',
      reply_to_message_id: msg.message_id
    });
  } catch (e) {
    return safeRichTextMessage(msg.chat.id, `${E.cross} <b>Gagal ban.</b>\n<code>${htmlEscape(e.message)}</code>`, {
      parse_mode: 'HTML',
      reply_to_message_id: msg.message_id
    });
  }
});

// ------- /unban — Unban member -------
bot.onText(/^\/unban$/, async (msg) => {
  if (msg.chat.type === 'private') return safeRichTextMessage(msg.chat.id, `${E.cross} Hanya di grup.`);
  if (!(await requireGroupAdmin(msg))) return;
  if (!(await requireBotAdmin(msg.chat.id))) return;
  const target = msg.reply_to_message?.from;
  if (!target) return safeRichTextMessage(msg.chat.id, `${E.cross} Reply pesan member yang ingin di-unban.`);
  try {
    await bot.unbanChatMember(msg.chat.id, target.id, { only_if_banned: true });
    const name = [target.first_name, target.last_name].filter(Boolean).join(' ') || target.username || String(target.id);
    return safeRichTextMessage(msg.chat.id, `${E.check} <b>${htmlEscape(name)}</b> di-unban & bisa bergabung kembali.`, { parse_mode: 'HTML' });
  } catch (e) {
    return safeRichTextMessage(msg.chat.id, `${E.cross} Gagal unban: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
});

// ------- /cekmasadepan <nama> -------
bot.onText(/^\/cekmasadepan(?:\s+(.+))?$/i, async (msg, match) => {
  if (!(await requireJoin(msg))) return;
  const chatId = msg.chat.id;
  const nama = (match[1] || '').trim();
  if (!nama) {
    return safeRichTextMessage(chatId,
      `${E.eyes} <b>Cek Masa Depan</b>\n\n` +
      `Format: <code>/cekmasadepan &lt;nama&gt;</code>\n\n` +
      `Contoh: <code>/cekmasadepan Keira</code>\n\n` +
      `<blockquote>Nama yang sama akan selalu menghasilkan masa depan yang sama.</blockquote>`,
      { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  }
  const loading = await safeRichTextMessage(chatId,
    `${E.hourglass} <b>Membaca masa depan ${htmlEscape(nama)}...</b>\n\n` +
    `<code>${makeBar(0)}</code>\n<i>Menelusuri garis takdir...</i>`,
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  // Loading animation
  const steps = [
    [15, '🔮 Menghubungi alam semesta...'],
    [35, '✨ Membaca energi nama...'],
    [55, '🌙 Menelusuri garis takdir...'],
    [75, '⭐ Menyusun ramalan...'],
    [95, '🎯 Mengunci hasil...']
  ];
  for (const [pct, label] of steps) {
    await new Promise(r => setTimeout(r, 600));
    await safeEdit(bot, chatId, loading.message_id,
      `${E.hourglass} <b>Membaca masa depan ${htmlEscape(nama)}...</b>\n\n` +
      `<code>${makeBar(pct)}</code>\n<i>${label}</i>`, { parse_mode: 'HTML' }).catch(() => {});
  }
  const { fortune, days } = getMasaDepan(nama);
  const botMsg = getMasaDepanBotMsg(nama, days);
  const nowDate = new Date();
  const happenDate = new Date(nowDate.getTime() + days * 86400000);
  const happenStr = happenDate.toLocaleDateString('id-ID', {
    day: '2-digit', month: 'long', year: 'numeric', timeZone: 'Asia/Jakarta'
  });
  await safeDelete(bot, chatId, loading.message_id);
  return safeRichTextMessage(chatId,
    `${E.eyes} <b>Hasil Cek Masa Depan</b>\n\n` +
    `${E.user} Nama: <b>${htmlEscape(nama)}</b>\n` +
    `${E.watch} Kapan: <b>${days} hari lagi</b> (~${htmlEscape(happenStr)})\n\n` +
    `${E.star} <b>Masa Depanmu:</b>\n` +
    `<blockquote>${htmlEscape(fortune)}</blockquote>\n\n` +
    `${E.ai} <i>${htmlEscape(botMsg)}</i>`,
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
});

// ------- /cekid (diri sendiri atau @username) -------
bot.onText(/^\/cekid(?:\s+(.+))?$/i, async (msg, match) => {
  if (!(await requireJoin(msg))) return;
  const chatId = msg.chat.id;
  const arg = (match[1] || '').trim();
  const timeStr = new Date().toLocaleString('id-ID', {
    timeZone: 'Asia/Jakarta', day: '2-digit', month: 'long', year: 'numeric',
    hour: '2-digit', minute: '2-digit', second: '2-digit'
  });
  if (!arg) {
    // Cek ID sendiri
    const user = msg.from;
    const name = htmlEscape([user.first_name, user.last_name].filter(Boolean).join(' ') || 'Pengguna');
    const uname = user.username ? `@${htmlEscape(user.username)}` : '-';
    return bot.sendPhoto(chatId, c.BANNER_URL, {
      caption:
        `${E.user} <b>ID Pengguna</b>\n\n` +
        `${E.Name} Nama: <code>${name}</code>\n` +
        `${E.user} Username: <code>${uname}</code>\n` +
        `${E.id} User ID: <code>${user.id}</code>\n` +
        `${E.jam} Waktu: <code>${timeStr} WIB</code>`,
      parse_mode: 'HTML', reply_to_message_id: msg.message_id
    });
  }
  // Cek ID user lain via @username
  const targetUsername = arg.replace(/^@/, '').toLowerCase();
  // Cari di database bot kita
  const state = readState();
  const found = Object.values(state.users || {}).find(
    u => (u.username || '').toLowerCase() === targetUsername
  );
  if (found) {
    const name = htmlEscape([found.first_name, found.last_name].filter(Boolean).join(' ') || 'Pengguna');
    return bot.sendPhoto(chatId, c.BANNER_URL, {
      caption:
        `${E.user} <b>ID Pengguna</b>\n\n` +
        `${E.Name} Nama: <code>${name}</code>\n` +
        `${E.user} Username: <code>@${htmlEscape(found.username || '-')}</code>\n` +
        `${E.id} User ID: <code>${found.id}</code>\n` +
        `${E.jam} Waktu: <code>${timeStr} WIB</code>`,
      parse_mode: 'HTML', reply_to_message_id: msg.message_id
    });
  }
  // Coba via getChatMember di grup (jika di grup)
  if (msg.chat.type !== 'private') {
    try {
      const member = await bot.getChatMember(chatId, `@${targetUsername}`);
      if (member?.user) {
        const u = member.user;
        const name = htmlEscape([u.first_name, u.last_name].filter(Boolean).join(' ') || 'Pengguna');
        return bot.sendPhoto(chatId, c.BANNER_URL, {
          caption:
            `${E.user} <b>ID Pengguna</b>\n\n` +
            `${E.Name} Nama: <code>${name}</code>\n` +
            `${E.user} Username: <code>@${htmlEscape(u.username || '-')}</code>\n` +
            `${E.id} User ID: <code>${u.id}</code>\n` +
            `${E.jam} Waktu: <code>${timeStr} WIB</code>`,
          parse_mode: 'HTML', reply_to_message_id: msg.message_id
        });
      }
    } catch {}
  }
  // Coba via getChat
  try {
    const chatInfo = await bot.getChat(`@${targetUsername}`);
    if (chatInfo?.id) {
      const name = htmlEscape([chatInfo.first_name, chatInfo.last_name].filter(Boolean).join(' ') || chatInfo.title || 'Pengguna');
      return bot.sendPhoto(chatId, c.BANNER_URL, {
        caption:
          `${E.user} <b>ID Pengguna</b>\n\n` +
          `${E.Name} Nama: <code>${name}</code>\n` +
          `${E.user} Username: <code>@${htmlEscape(targetUsername)}</code>\n` +
          `${E.id} ID: <code>${chatInfo.id}</code>\n` +
          `${E.jam} Waktu: <code>${timeStr} WIB</code>`,
        parse_mode: 'HTML', reply_to_message_id: msg.message_id
      });
    }
  } catch {}
  return safeRichTextMessage(chatId,
    `${E.cross} User <code>@${htmlEscape(targetUsername)}</code> tidak ditemukan.\n\n` +
    `<blockquote>User harus pernah berinteraksi dengan bot ini, atau ketik di dalam grup yang berisi user tersebut.</blockquote>`,
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
});

// ------- /cekchatid -------
bot.onText(/^\/cekchatid$/, async (msg) => {
  if (!(await requireJoin(msg))) return;
  const chatId = msg.chat.id;
  const timeStr = new Date().toLocaleString('id-ID', {
    timeZone: 'Asia/Jakarta', day: '2-digit', month: 'long', year: 'numeric',
    hour: '2-digit', minute: '2-digit', second: '2-digit'
  });
  const chat = msg.chat;
  const type = { private: 'Private', group: 'Grup', supergroup: 'Supergrup', channel: 'Channel' }[chat.type] || chat.type;
  const chatTitle = htmlEscape(chat.title || [chat.first_name, chat.last_name].filter(Boolean).join(' ') || 'Chat');
  return bot.sendPhoto(chatId, c.BANNER_URL, {
    caption:
      `${E.group} <b>ID Chat</b>\n\n` +
      `${E.folder} Nama: <code>${chatTitle}</code>\n` +
      `${E.group} Tipe: <code>${type}</code>\n` +
      `${E.id} Chat ID: <code>${chat.id}</code>\n` +
      (chat.username ? `${E.user} Username: <code>@${htmlEscape(chat.username)}</code>\n` : '') +
      `${E.jam} Waktu: <code>${timeStr} WIB</code>`,
    parse_mode: 'HTML', reply_to_message_id: msg.message_id
  });
});

// ===== PROJECT TOOLS: DOMAIN / TOURL / DEPLOY / WA CHANNEL =====
bot.onText(/^\/gantidomain$/i, async (msg) => {
  if (!(await requireJoin(msg))) return;
  pendingDomainRename.set(String(msg.from.id), { chatId: msg.chat.id, step: 'zip', createdAt: Date.now() });
  setTimeout(() => pendingDomainRename.delete(String(msg.from.id)), 10 * 60 * 1000);
  return safeRichTextMessage(msg.chat.id, '🌐 <b>GANTI DOMAIN</b>\n\n<b>Langkah 1/3</b> — Kirim ZIP project.\n<b>Langkah 2/3</b> — Kirim domain lama; bot akan memverifikasi ke seluruh file teks.\n<b>Langkah 3/3</b> — Kirim domain baru dan bot mengirim ZIP hasil perubahan. Port baru opsional: <code>domainbaru.com 8080</code>.', { parse_mode:'HTML' });
});

bot.onText(/^\/gantiport$/i, async (msg) => {
  if (!(await requireJoin(msg))) return;
  pendingDomainRename.set(String(msg.from.id), { chatId: msg.chat.id, step:'port_zip', mode:'port', createdAt:Date.now() });
  setTimeout(()=>pendingDomainRename.delete(String(msg.from.id)),10*60*1000);
  return safeRichTextMessage(msg.chat.id,'🔌 <b>GANTI PORT PANEL</b>\n\nKirim ZIP project. Bot akan mencari port pada URL dan konfigurasi PORT/PANEL_PORT, lalu meminta port lama dan port baru.',{parse_mode:'HTML'});
});

bot.onText(/^\/tourl$/i, async (msg) => {
  if (!(await requireJoin(msg))) return;
  pendingTourl.set(String(msg.from.id), { chatId: msg.chat.id, step: 'photo', createdAt: Date.now() });
  setTimeout(() => pendingTourl.delete(String(msg.from.id)), 5 * 60 * 1000);
  return safeRichTextMessage(msg.chat.id, '🖼️ <b>TOURL FOTO</b>\n\nKirim foto. Setelah itu pilih provider URL yang tersedia.', { parse_mode:'HTML' });
});

bot.onText(/^\/deploy$/i, async (msg) => {
  if (!(await requireJoin(msg))) return;
  if (!process.env.VERCEL_TOKEN) return safeRichTextMessage(msg.chat.id, '🚀 <b>Deploy belum dikonfigurasi.</b>\n\nIsi <code>VERCEL_TOKEN</code> di environment Pterodactyl terlebih dahulu. Bot tidak menyimpan token di source code.', { parse_mode:'HTML' });
  pendingDeploy.set(String(msg.from.id), { chatId: msg.chat.id, step: 'zip', createdAt: Date.now() });
  setTimeout(() => pendingDeploy.delete(String(msg.from.id)), 10 * 60 * 1000);
  return safeRichTextMessage(msg.chat.id, '🚀 <b>DEPLOY WEBSITE</b>\n\nKirim ZIP website yang akan di-deploy ke Vercel.', { parse_mode:'HTML' });
});

bot.onText(/^\/ceksaluranwa$/i, async (msg) => {
  if (!(await requireJoin(msg))) return;
  pendingWaChannel.set(String(msg.from.id), { chatId: msg.chat.id, step: 'input', createdAt: Date.now() });
  setTimeout(() => pendingWaChannel.delete(String(msg.from.id)), 3 * 60 * 1000);
  return safeRichTextMessage(msg.chat.id, '📢 <b>CEK ID CHANNEL / SALURAN WHATSAPP</b>\n\nKirim link Channel WhatsApp yang ingin dicek.', { parse_mode:'HTML' });
});

bot.onText(/^\/recoverstate$/, async (msg) => {
  if (String(msg.from.id) !== String(c.ID)) return;
  const result = recoverFromBackup();
  return safeRichTextMessage(msg.chat.id,
    result.ok
      ? `${E.check} <b>State berhasil di-recover!</b>\n\n<code>${result.msg}</code>`
      : `${E.cross} <b>Recover gagal:</b>\n<code>${result.msg}</code>`,
    { parse_mode: 'HTML' });
});

// ======================================= //
// 🖼️ /qc — QC Sticker Generator (account-aware simulation)
// ======================================= //
function qcXmlEscape(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

function qcWrapText(text, maxChars = 24) {
  const words = String(text || '').trim().split(/\s+/).filter(Boolean);
  const lines = [];
  let line = '';
  for (const word of words) {
    if (word.length > maxChars) {
      if (line) { lines.push(line); line = ''; }
      for (let i = 0; i < word.length; i += maxChars) lines.push(word.slice(i, i + maxChars));
      continue;
    }
    const candidate = line ? `${line} ${word}` : word;
    if (candidate.length > maxChars) {
      if (line) lines.push(line);
      line = word;
    } else line = candidate;
  }
  if (line) lines.push(line);
  return lines.length ? lines : [''];
}

function qcUserName(user) {
  const first = String(user?.first_name || '').trim();
  const last = String(user?.last_name || '').trim();
  const full = `${first} ${last}`.trim();
  return full || (user?.username ? `@${user.username}` : 'Pengguna');
}

async function getQCAvatarBuffer(userId) {
  try {
    const photos = await bot.getUserProfilePhotos(userId, { limit: 1 });
    const sizes = photos?.photos?.[0];
    if (!sizes?.length) return null;
    const photo = sizes[sizes.length - 1];
    const fileUrl = await bot.getFileLink(photo.file_id);
    const res = await axios.get(fileUrl, { responseType: 'arraybuffer', timeout: 10000 });
    return Buffer.from(res.data);
  } catch {
    return null;
  }
}

async function createQCSticker(text, user = {}) {
  let sharp;
  try { sharp = require('sharp'); } catch {
    throw new Error('Modul sharp belum terpasang. Jalankan npm install lalu restart bot.');
  }

  const cleanText = String(text || '').trim().replace(/\r/g, '');
  if (!cleanText) throw new Error('Teks QC tidak boleh kosong.');
  if (cleanText.length > 180) throw new Error('Teks terlalu panjang. Maksimal 180 karakter.');

  const name = qcUserName(user);
  const username = user?.username ? `@${user.username}` : '';
  const avatarBuffer = await getQCAvatarBuffer(user?.id);
  const time = moment().tz('Asia/Jakarta').format('HH:mm');

  // QC dibuat sebagai sticker transparan: hanya avatar + message bubble.
  // Tidak ada kotak/background luar sehingga saat dikirim ke Telegram
  // tampil seperti sticker/chat-bubble pada contoh.
  const lines = [];
  for (const rawLine of cleanText.split('\n')) lines.push(...qcWrapText(rawLine, 25));
  const visibleLines = lines.slice(0, 8);

  const lineH = visibleLines.length >= 6 ? 31 : 35;
  const textSize = visibleLines.length >= 6 ? 24 : 27;
  const bubbleW = 430;
  const headerH = 43;
  const bottomH = 31;
  const bubbleH = Math.max(96, headerH + visibleLines.length * lineH + bottomH);
  const canvasW = 512;
  const canvasH = Math.max(180, bubbleH + 54);
  const bubbleX = 64;
  const bubbleY = 16;
  const avatarSize = 54;
  const avatarX = 10;
  const avatarY = bubbleY + 7;
  const radius = 24;

  const textSvg = visibleLines.map((line, i) =>
    `<text x="88" y="${bubbleY + headerH + 26 + i * lineH}" fill="#ffffff" font-size="${textSize}" font-weight="600" font-family="Arial, DejaVu Sans, sans-serif">${qcXmlEscape(line)}</text>`
  ).join('');

  const nameShort = qcXmlEscape(name).slice(0, 27);
  const usernameShort = qcXmlEscape(username).slice(0, 22);

  const svg = `<svg width="${canvasW}" height="${canvasH}" viewBox="0 0 ${canvasW} ${canvasH}" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <filter id="shadow" x="-20%" y="-20%" width="140%" height="150%">
        <feDropShadow dx="0" dy="3" stdDeviation="4" flood-color="#000000" flood-opacity="0.45"/>
      </filter>
    </defs>

    <!-- transparent canvas; Telegram shows the sticker over the real chat wallpaper -->
    <g filter="url(#shadow)">
      <!-- avatar placeholder -->
      <circle cx="${avatarX + avatarSize/2}" cy="${avatarY + avatarSize/2}" r="${avatarSize/2}" fill="#70777d"/>

      <!-- black Telegram-like message bubble, no outer rectangle -->
      <path d="M${bubbleX + radius},${bubbleY} H${bubbleX + bubbleW - radius}
               Q${bubbleX + bubbleW},${bubbleY} ${bubbleX + bubbleW},${bubbleY + radius}
               V${bubbleY + bubbleH - radius}
               Q${bubbleX + bubbleW},${bubbleY + bubbleH} ${bubbleX + bubbleW - radius},${bubbleY + bubbleH}
               H${bubbleX + 24}
               Q${bubbleX + 10},${bubbleY + bubbleH} ${bubbleX + 10},${bubbleY + bubbleH - 14}
               L${bubbleX + 10},${bubbleY + bubbleH + 7}
               L${bubbleX - 2},${bubbleY + bubbleH - 3}
               Q${bubbleX},${bubbleY + bubbleH} ${bubbleX + radius},${bubbleY} Z"
            fill="#050505"/>

      <!-- sender name -->
      <text x="88" y="${bubbleY + 29}" fill="#ff5f6d" font-size="20" font-weight="800" font-family="Arial, DejaVu Sans, sans-serif">${nameShort}</text>
      ${usernameShort ? `<text x="${Math.min(365, 88 + Math.max(120, name.replace(/&/g,'').length * 9))}" y="${bubbleY + 29}" fill="#7bd957" font-size="14" font-weight="700" font-family="Arial, DejaVu Sans, sans-serif">${usernameShort}</text>` : ''}

      ${textSvg}

      <!-- time and check marks -->
      <text x="${bubbleX + bubbleW - 18}" y="${bubbleY + bubbleH - 12}" text-anchor="end" fill="#aeb0b3" font-size="14" font-family="Arial, DejaVu Sans, sans-serif">${time} ✓✓</text>

      <!-- subtle safety label, kept inside the sticker and without a box -->
      <text x="${bubbleX + 18}" y="${bubbleY + bubbleH - 12}" fill="#8c8c8c" font-size="9" font-family="Arial, DejaVu Sans, sans-serif" opacity="0.78">SIMULASI</text>
    </g>
  </svg>`;

  let image = sharp(Buffer.from(svg));

  if (avatarBuffer) {
    try {
      const avatar = await sharp(avatarBuffer)
        .resize(avatarSize, avatarSize, { fit: 'cover', position: 'centre' })
        .png().toBuffer();
      const circleMask = Buffer.from(`<svg width="${avatarSize}" height="${avatarSize}"><circle cx="${avatarSize/2}" cy="${avatarSize/2}" r="${avatarSize/2}" fill="white"/></svg>`);
      const masked = await sharp(avatar)
        .composite([{ input: circleMask, blend: 'dest-in' }])
        .png().toBuffer();
      image = image.composite([{ input: masked, left: avatarX, top: avatarY }]);
    } catch {}
  }

  // Telegram sticker-friendly WebP with alpha channel.
  return image.webp({ quality: 92, alphaQuality: 100 }).toBuffer();
}

bot.onText(/^\/qc(?:\s+([\s\S]+))?$/i, async (msg, match) => {
  if (!(await requireJoin(msg))) return;
  const chatId = msg.chat.id;
  const uid = String(msg.from?.id || '');
  const text = (match[1] || '').trim();

  if (!text) {
    pendingQC.set(uid, { chatId, createdAt: Date.now() });
    setTimeout(() => {
      const p = pendingQC.get(uid);
      if (p && Date.now() - p.createdAt >= 110000) pendingQC.delete(uid);
    }, 120000);
    return safeRichTextMessage(chatId,
      `🖼️ <b>QC STICKER — ACCOUNT MODE</b>\n\n` +
      `Tulis teks yang ingin dijadikan QC. Nama dan foto profil akun Telegram kamu akan dipakai bila tersedia.\n\n` +
      `Contoh:\n<code>/qc HAI GUYS</code>\n\n` +
      `Hasil selalu bertanda <b>SIMULASI</b>.`,
      { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  }

  const loading = await safeRichTextMessage(chatId,
    `${E.hourglass} Membuat QC sesuai akun @${htmlEscape(msg.from?.username || msg.from?.first_name || 'user')}...`,
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  try {
    const sticker = await createQCSticker(text, msg.from || {});
    await bot.sendSticker(chatId, sticker, { reply_to_message_id: msg.message_id });
    await safeDelete(bot, chatId, loading.message_id);
  } catch (e) {
    await safeEdit(bot, chatId, loading.message_id,
      `${E.cross} <b>Gagal membuat QC:</b>\n<code>${htmlEscape(e.message)}</code>`,
      { parse_mode: 'HTML' });
  }
});

// ======================================= //
// 📡 /iqcv2 — IQC Generator v2 (+ backup endpoint)
// ======================================= //
bot.onText(/^\/iqcv2(?:\s+([\s\S]+))?$/, async (msg, match) => {
  if (!(await requireJoin(msg))) return;
  const chatId = msg.chat.id;
  const prompt = (match[1] || '').trim();

  if (!prompt) {
    return safeRichTextMessage(chatId,
      `${E.phone} <b>IQC Generator v2</b>\n\nFormat: <code>/iqcv2 &lt;teks prompt&gt;</code>\n\nContoh: <code>/iqcv2 Halo bro gimana kabar</code>`,
      { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  }

  const loading = await safeRichTextMessage(chatId,
    `<code>${makeBar(20)}</code>\n${E.hourglass} Membuat IQC v2...`,
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id });

  try {
    const encodedPrompt = encodeURIComponent(prompt);

    // ── Coba endpoint utama (api-faa) ──
    let imgBuffer = null;
    let usedBackup = false;

    try {
      await safeEdit(bot, chatId, loading.message_id,
        `<code>${makeBar(40)}</code>\n${E.hourglass} Memproses dari server FAA...`, { parse_mode: 'HTML' });

      const res = await axios.get(`https://api-faa.my.id/faa/iqc?prompt=${encodedPrompt}`, {
        responseType: 'arraybuffer',
        timeout: 90000,
        headers: { 'User-Agent': 'Mozilla/5.0' }
      });
      imgBuffer = Buffer.from(res.data);
    } catch (_) {
      // ── Endpoint utama gagal → coba backup (nexray) ──
      usedBackup = true;
      await safeEdit(bot, chatId, loading.message_id,
        `<code>${makeBar(55)}</code>\n${E.hourglass} Server utama down, mencoba backup...`, { parse_mode: 'HTML' });

      const res = await axios.get(`https://api.nexray.eu.cc/maker/iqc?text=${encodedPrompt}`, {
        responseType: 'arraybuffer',
        timeout: 90000,
        headers: { 'User-Agent': 'Mozilla/5.0' }
      });
      imgBuffer = Buffer.from(res.data);
    }

    if (!imgBuffer || imgBuffer.length < 100) {
      throw new Error('Server mengembalikan data kosong. Coba lagi.');
    }

    await safeEdit(bot, chatId, loading.message_id,
      `<code>${makeBar(90)}</code>\n${E.hourglass} Mengirim hasil...`, { parse_mode: 'HTML' });

    const nowDate = new Date();
    const dateStr = nowDate.toLocaleDateString('id-ID', { day: '2-digit', month: '2-digit', year: 'numeric', timeZone: 'Asia/Jakarta' });
    const timeStr = nowDate.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit', timeZone: 'Asia/Jakarta' });

    const caption =
      `${E.phone} <b>IQC Generator v2</b>\n\n` +
      `${E.chat} Prompt: <code>${htmlEscape(prompt)}</code>\n` +
      `<b>${E.tgl} Tanggal:</b> <code>${dateStr}</code>\n` +
      `<b>${E.jam} Jam:</b> <code>${timeStr} WIB</code>\n` +
      (usedBackup ? `<b>🔄 Server:</b> <code>Backup (Nexray)</code>\n` : '') +
      `\n<blockquote>Generated by mellstecu Ϟ FMD | IQC v2</blockquote>`;

    // Kirim foto, fallback ke dokumen jika >10MB
    if (imgBuffer.length <= 10485760) {
      await bot.sendPhoto(chatId, imgBuffer, {
        caption, parse_mode: 'HTML',
        reply_to_message_id: msg.message_id
      });
    } else {
      await bot.sendDocument(chatId, imgBuffer,
        { caption, parse_mode: 'HTML', reply_to_message_id: msg.message_id },
        { filename: 'iqcv2_result.jpg', contentType: 'image/jpeg' }
      );
    }
    await safeDelete(bot, chatId, loading.message_id);

  } catch (e) {
    await safeEdit(bot, chatId, loading.message_id,
      `${E.cross} Gagal buat IQC v2: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
});
// ======================================= //
// 📡 /iqc — IQC Generator (simple + lengkap)
// ======================================= //
async function fetchIqcImage({ text, provider, jam, baterai }) {
  const attempts = [
    {
      name: 'NexRay v1',
      url: 'https://api.nexray.eu.cc/maker/v1/iqc',
      params: { text, provider, jam, baterai }
    },
    {
      name: 'NexRay basic',
      url: 'https://api.nexray.eu.cc/maker/iqc',
      params: { text }
    },
    {
      name: 'Siputzx fallback',
      url: 'https://brat.siputzx.my.id/iphone-quoted',
      params: {
        time: jam,
        messageText: text,
        carrierName: provider,
        batteryPercentage: baterai,
        signalStrength: 4,
        emojiStyle: 'apple'
      }
    }
  ];
  let lastError = null;
  for (const attempt of attempts) {
    try {
      const res = await axios.get(attempt.url, {
        params: attempt.params,
        responseType: 'arraybuffer',
        timeout: 45000,
        headers: { 'User-Agent': 'Mozilla/5.0' }
      });
      const buf = Buffer.from(res.data || []);
      const type = String(res.headers?.['content-type'] || '').toLowerCase();
      if (buf.length < 500 || (type && !type.includes('image') && !type.includes('octet-stream'))) {
        throw new Error(`Respons ${attempt.name} bukan gambar yang valid.`);
      }
      return { buffer: buf, provider: attempt.name };
    } catch (e) {
      lastError = e;
    }
  }
  throw lastError || new Error('Semua server IQC gagal.');
}

bot.onText(/^\/iqc(?:\s+(.+))?$/i, async (msg, match) => {
  if (!(await requireJoin(msg))) return;
  const args = (match[1] || '').trim();
  if (!args) {
    return safeRichTextMessage(msg.chat.id,
      `${E.phone} <b>IQC Generator</b>\n\n` +
      `<b>Mode cepat:</b> <code>/iqc woi</code>\n` +
      `<b>Mode lengkap:</b> <code>/iqc woi,Axis,20:00,50</code>\n\n` +
      `Mode cepat otomatis memakai provider, jam WIB, dan baterai default.`,
      { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  }

  const parts = args.split(',').map(s => s.trim());
  let text = '';
  let provider = 'INDOSAT';
  let jam = new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', hour12: false, timeZone: 'Asia/Jakarta' });
  let baterai = '50';

  if (parts.length === 1) {
    text = parts[0];
  } else if (parts.length >= 4) {
    [text, provider, jam, baterai] = parts;
  } else {
    return safeRichTextMessage(msg.chat.id,
      `${E.cross} <b>Format IQC belum lengkap.</b>\n\nGunakan salah satu:\n• <code>/iqc woi</code>\n• <code>/iqc woi,Axis,20:00,50</code>`,
      { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  }

  text = text.slice(0, 1000);
  provider = (provider || 'INDOSAT').slice(0, 40);
  jam = (jam || '12:00').slice(0, 10);
  baterai = String(Math.max(0, Math.min(100, Number.parseInt(baterai, 10) || 50)));

  const loading = await safeRichTextMessage(msg.chat.id,
    `<code>${makeBar(20)}</code>\n${E.hourglass} Membuat IQC...`,
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  try {
    await safeEdit(bot, msg.chat.id, loading.message_id,
      `<code>${makeBar(50)}</code>\n${E.hourglass} Memproses IQC...`, { parse_mode: 'HTML' });

    const result = await fetchIqcImage({ text, provider, jam, baterai });
    await safeEdit(bot, msg.chat.id, loading.message_id,
      `<code>${makeBar(90)}</code>\n${E.hourglass} Mengirim hasil...`, { parse_mode: 'HTML' });

    const caption =
      `${E.phone} <b>IQC Generator</b>\n\n` +
      `${E.chat} Teks: <code>${htmlEscape(text)}</code>\n` +
      `${E.globe} Provider: <code>${htmlEscape(provider)}</code>\n` +
      `${E.watch} Jam: <code>${htmlEscape(jam)}</code>\n` +
      `🔋 Baterai: <code>${htmlEscape(baterai)}%</code>\n` +
      `<blockquote>Server: ${htmlEscape(result.provider)}</blockquote>`;

    await bot.sendPhoto(msg.chat.id, result.buffer, {
      caption,
      parse_mode: 'HTML',
      reply_to_message_id: msg.message_id
    });
    await safeDelete(bot, msg.chat.id, loading.message_id);
  } catch (e) {
    await safeEdit(bot, msg.chat.id, loading.message_id,
      `${E.cross} <b>IQC belum bisa dibuat.</b>\n\n<code>${htmlEscape(String(e?.message || 'Server IQC error').slice(0, 500))}</code>\n\n<i>Coba lagi beberapa saat lagi.</i>`, { parse_mode: 'HTML' });
  }
});
//—Aii Asistent
// — AI Asisten: Multi AI
bot.onText(/^\/asistent(?:\s+(on|off))?$/i, async (msg,match)=>{
  if(!(await requireJoin(msg))) return;
  const chatId=msg.chat.id; const action=(match[1]||'').toLowerCase();
  if(!action) return safeRichTextMessage(chatId,`${E.ai} <b>AI Asisten — Multi AI</b>\n\n🧠 Pilihan: <b>Gemini • OpenRouter • Pixazo</b>.\n\n• <code>/asistent on</code> — aktifkan auto-reply\n• <code>/asistent off</code> — matikan auto-reply\n• <code>/ai pertanyaan</code> — tanya langsung\n\nPrivate: kirim pesan biasa.\nGroup: awali pesan dengan <b>AI</b>.`,{parse_mode:'HTML',reply_to_message_id:msg.message_id,reply_markup:menuAIKeyboard(chatId)});
  if(action==='on'){
    setAssistantEnabled(chatId,true);
    const provider=normalizeAiProvider(getAssistantProvider(chatId));
    return safeRichTextMessage(chatId,`${E.ai} <b>AI Asisten AKTIF ✅</b>\n\n<blockquote>Provider: <b>${htmlEscape(aiProviderLabel(provider))}</b>. Pesan biasa akan diproses sesuai mode chat. Kamu bisa mematikannya kapan saja dari tombol AI Asisten.</blockquote>`,{parse_mode:'HTML',reply_to_message_id:msg.message_id,reply_markup:menuAIKeyboard(chatId)});
  }
  setAssistantState(chatId,false); aiHistory.delete(String(chatId));
  return safeRichTextMessage(chatId,`${E.ai} <b>AI Asisten dimatikan.</b>\n\nKetik <code>/asistent on</code> untuk mengaktifkannya lagi.`,{parse_mode:'HTML',reply_to_message_id:msg.message_id,reply_markup:menuAIKeyboard(chatId)});
});

// ======================================= //
// 📡 /totaltest
// ======================================= //
bot.onText(/^\/totaltest$/, async (msg) => {
  if (!(await requireJoin(msg))) return;
  const chatId = msg.chat.id;

  const loadMsg = await safeRichTextMessage(chatId,
    `<blockquote>${E.hourglass} <i>Menghitung statistik tesfunc...</i></blockquote>`,
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id });

  await new Promise(r => setTimeout(r, 900));

  const state = readState();
  const totalLoops = state.totalTests || 0;
  const todayLoops = getDailyTests();

  const activeList = [];
  for (const [uid, d] of activeTesfuncMap.entries()) {
    const name = htmlEscape(d.name || 'Unknown');
    const un = d.username ? ` (@${d.username})` : '';
    const dur = Math.round((Date.now() - d.startedAt) / 1000);
    // Menggunakan E.check sebagai bullet point agar senada
    activeList.push(`${E.check} <b>${name}</b>${un} → <code>${d.targetNumber}</code> | <code>${dur}s</code>`);
  }

  const stats = getTesfuncStats();
  const medals = ['🥇', '🥈', '🥉', '4️⃣', '5️⃣'];
  const leaderLines = stats.slice(0, 5).map((s, i) => {
    const name = htmlEscape(s.firstName || 'Unknown');
    const un = s.username ? ` (@${s.username})` : '';
    return `${medals[i]} <b>${name}</b>${un} — <code>${s.count}</code> loop`;
  });

  const todayDate = new Date().toLocaleDateString('id-ID', {
    weekday: 'long', day: '2-digit', month: 'long', year: 'numeric',
    timeZone: 'Asia/Jakarta'
  });

  const text =
    `${E.stats} <b>Statistik Tesfunc</b>\n` +
    `<blockquote>${E.tgl} ${todayDate}</blockquote>\n\n` +
    `${E.box} <b>Total Loop All-Time:</b> <code>${totalLoops.toLocaleString('id-ID')}</code>\n` +
    `${E.stats} <b>Loop Hari Ini:</b> <code>${todayLoops.toLocaleString('id-ID')}</code>\n\n` +
    `${E.flash} <b>Sedang Aktif (${activeList.length}):</b>\n` +
    (activeList.length ? activeList.join('\n') : `<i>  Tidak ada yang sedang aktif.</i>`) +
    `\n\n${E.respon} <b>Top Tesfunc Hari Ini:</b>\n` +
    (leaderLines.length ? leaderLines.join('\n') : `<i>  Belum ada data hari ini.</i>`);

  await safeDelete(bot, chatId, loadMsg.message_id);
  return safeRichTextMessage(chatId, text,
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
});


// ======================================= //
// 📡 /broadcastcopy (Owner only)
// ======================================= //
bot.onText(/^\/broadcastcopy$/, async (msg) => {
  if (!isOwner(msg.from.id)) return;
  if (!msg.reply_to_message) return safeRichTextMessage(msg.chat.id, `${E.info} Reply pesan yang ingin di-broadcast.`);
  const state = readState();
  const chats = Object.keys(state.chats || {});
  let ok = 0, fail = 0;
  const name = [msg.from.first_name, msg.from.last_name].filter(Boolean).join(' ') || msg.from.username || msg.from.id;
  for (const id of chats) {
    try {
      await safeRichTextMessage(id, `<blockquote>${E.speaker} Informasi</blockquote>`, { parse_mode: 'HTML' });
      await bot.copyMessage(id, msg.chat.id, msg.reply_to_message.message_id);
      ok++;
      await new Promise(r => setTimeout(r, 120));
    } catch { fail++; }
  }
  return safeRichTextMessage(msg.chat.id, `${E.check} Selesai.\nTerkirim: ${ok} | Gagal: ${fail}`);
});

// ======================================= //
// 🔐 ENCRYPTION COMMANDS
// ======================================= //

// Safe JS obfuscation presets: syntax-preserving text transforms only.
const obfConfigs = {
  obfclean: {
    label: 'Clean Obf', desc: 'Rapikan whitespace + hilangkan komentar aman',
    fn: (code) => code
      .replace(/\/\*[\s\S]*?\*\//g, '')
      .replace(/(^|[^:])\/\/[^\r\n]*/g, '$1')
      .replace(/[ \t]+\n/g, '\n')
      .replace(/\n{3,}/g, '\n\n')
      .trim() + '\n'
  },
  obfstring: {
    label: 'String Escape', desc: 'Escape string sederhana tanpa mengubah logika',
    fn: (code) => code.replace(/(['"])([^'"\r\n\\]{4,})\1/g, (m,q,v) => {
      if (/^[\w ./:-]+$/.test(v)) return q + v.split('').map(ch => {
        const n = ch.charCodeAt(0);
        return n >= 32 && n <= 126 && !/[A-Za-z0-9 _./:-]/.test(ch) ? '\\x'+n.toString(16).padStart(2,'0') : ch;
      }).join('') + q;
      return m;
    })
  },
  obfcompact: {
    label: 'Compact', desc: 'Kompresi whitespace di luar string/comment',
    fn: (code) => code
      .replace(/\/\*[\s\S]*?\*\//g, '')
      .replace(/(^|[^:])\/\/[^\r\n]*/g, '$1')
      .replace(/\s+/g, ' ')
      .replace(/\s*([{}()[\];,:])\s*/g, '$1')
      .trim() + '\n'
  },
  obfhex: {
    label: 'Char Escape', desc: 'Escape karakter non-ASCII pada string',
    fn: (code) => code.replace(/(['"])([^'"\r\n\\]*)\1/g, (m,q,v) => {
      const escaped = v.replace(/[^\x20-\x7E]/g, ch => '\\u'+ch.charCodeAt(0).toString(16).padStart(4,'0'));
      return q + escaped + q;
    })
  },
  obfpro: {
    label: 'Obf Pro', desc: 'Clean + compact + safe character escaping',
    fn: (code) => code
      .replace(/\/\*[\s\S]*?\*\//g, '')
      .replace(/(^|[^:])\/\/[^\r\n]*/g, '$1')
      .replace(/\s+/g, ' ')
      .replace(/\s*([{}()[\];,:])\s*/g, '$1')
      .trim() + '\n'
  }
};

const encConfigs = {
  encbasic:    { fn: encBasic,    label: 'Basic',     desc: 'Triple Base64 + Eval Wrapper' },
  encmedium:   { fn: encMedium,   label: 'Medium',    desc: 'Hex Array + XOR Obfuscation' },
  encarab:     { fn: encArab,     label: 'Arab',      desc: 'Arabic Variables + ROT13 + Triple Base64' },
  encinvisble: { fn: encInvisible,label: 'Invisible', desc: 'Zero-Width Character Steganography' },
  enchard:     { fn: encHard,     label: 'Hard',      desc: 'XOR Hash Key + Reverse + Double Base64 + Integrity Check' },
  encultra:    { fn: encUltra,    label: 'Hard+',     desc: 'Gzip + rotating XOR + integrity check (Node.js)' }
};

async function handleEncrypt(msg, level) {
  if (!(await requireJoin(msg))) return;
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const cfg = encConfigs[level];
  if (!cfg) return;

  // Simpan pending enc untuk user ini
  const key = `${chatId}:${userId}`;
  pendingEnc.set(key, { level, createdAt: Date.now() });

  // Auto-hapus pending setelah 5 menit
  setTimeout(() => pendingEnc.delete(key), 5 * 60 * 1000);

  const prompt = await safeRichTextMessage(chatId,
    `${E.lock2} <b>Enkripsi Level ${cfg.label}</b>\n\n` +
    `${E.shield} Metode: <code>${cfg.desc}</code>\n\n` +
    `<blockquote>Sekarang kirimkan file <b>.js</b> yang ingin dienkripsi.\n\nBot akan otomatis memproses setelah file diterima.</blockquote>`,
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id }
  );

  // Simpan juga promptMsgId (opsional untuk cleanup)
  pendingEnc.set(key, { level, promptMsgId: prompt.message_id, createdAt: Date.now() });
}

bot.onText(/^\/encbasic$/,   (msg) => handleEncrypt(msg, 'encbasic'));
bot.onText(/^\/encmedium$/,  (msg) => handleEncrypt(msg, 'encmedium'));
bot.onText(/^\/encarab$/,    (msg) => handleEncrypt(msg, 'encarab'));
bot.onText(/^\/encinvisble$/,(msg) => handleEncrypt(msg, 'encinvisble'));
bot.onText(/^\/enchard$/,    (msg) => handleEncrypt(msg, 'enchard'));


// ────────────────────────────────────────────────────────────────
// BAGIAN 3 — Tambahkan SEBELUM baris:
//   bot.onText(/^\/antilink$/, ...
// (sekitar line 1693)
// ────────────────────────────────────────────────────────────────

// ======================================= //
// 📥 DOCUMENT HANDLER — Auto-process pending enc
// ======================================= //
bot.on('document', async (msg) => {
  if (!msg.from || !msg.chat) return;
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const key    = `${chatId}:${userId}`;

  const pending = pendingEnc.get(key);
  if (!pending) return; // Tidak ada sesi enc aktif untuk user ini
  pendingEnc.delete(key);

  const doc = msg.document;
  const fileName = doc?.file_name || '';
  const mime     = doc?.mime_type || '';

  // Validasi: harus file .js
  const isJs = fileName.endsWith('.js') ||
               mime.includes('javascript') ||
               mime.includes('text/plain');

  if (!isJs) {
    return safeRichTextMessage(chatId,
      `${E.cross} <b>File harus berformat .js!</b>\n\n<blockquote>Kirim ulang file JavaScript yang valid.</blockquote>`,
      { parse_mode: 'HTML', reply_to_message_id: msg.message_id }
    );
  }

  const cfg = encConfigs[pending.level] || obfConfigs[pending.level];
  if (!cfg) return;

  const loading = await safeRichTextMessage(chatId,
    `<code>${makeBar(15)}</code>\n${E.download} Mengunduh file: <code>${htmlEscape(fileName)}</code>...`,
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id }
  );

  try {
    // Download file dari Telegram
    const fileLink = await bot.getFileLink(doc.file_id);
    const res      = await axios.get(fileLink, { timeout: 30000 });
    const code     = typeof res.data === 'string' ? res.data : JSON.stringify(res.data);

    if (!code || !code.trim()) {
      return safeEdit(bot, chatId, loading.message_id,
        `${E.cross} File kosong atau tidak bisa dibaca.`
      );
    }

    if (code.length > 90000000) {
      return safeEdit(bot, chatId, loading.message_id,
        `${E.cross} File terlalu besar! Maksimal 200.000 karakter.`
      );
    }

    await safeEdit(bot, chatId, loading.message_id,
      `<code>${makeBar(45)}</code>\n${E.lock2} Mengenkripsi dengan level <b>${cfg.label}</b>...`,
      { parse_mode: 'HTML' }
    );

    const encrypted = cfg.fn(code);

    await safeEdit(bot, chatId, loading.message_id,
      `<code>${makeBar(85)}</code>\n${E.lock2} Menyiapkan file hasil enkripsi...`,
      { parse_mode: 'HTML' }
    );

    // Nama file output
    const baseName   = fileName.replace(/\.js$/, '');
    const outName    = `${baseName}_${pending.level}_${Date.now()}.js`;
    const fileBuffer = Buffer.from(encrypted, 'utf8');

    await safeDelete(bot, chatId, loading.message_id);

    await bot.sendDocument(chatId, fileBuffer, {
      caption:
        `${E.lock2} <b>Enkripsi ${cfg.label} Berhasil!</b>\n\n` +
        `${E.folder} File asli  : <code>${htmlEscape(fileName)}</code>\n` +
        `${E.box}    Level      : <code>${cfg.label}</code>\n` +
        `${E.shield} Metode     : <code>${cfg.desc}</code>\n` +
        `${E.ruler}  Ukuran asli: <code>${code.length.toLocaleString()} chars</code>\n` +
        `${E.ruler}  Ukuran enc : <code>${encrypted.length.toLocaleString()} chars</code>\n\n` +
        `<blockquote>File sudah terenkripsi dan siap digunakan.\nKode asli tidak bisa dibaca orang lain.</blockquote>`,
      parse_mode: 'HTML',
      reply_to_message_id: msg.message_id
    }, { filename: outName, contentType: 'application/javascript' });

  } catch (e) {
    await safeEdit(bot, chatId, loading.message_id,
      `${E.cross} Gagal enkripsi: <code>${htmlEscape(e.message)}</code>`,
      { parse_mode: 'HTML' }
    );
  }
});


// ======================================= //
// 📡 GROUP MANAGEMENT COMMANDS
// ======================================= //

bot.onText(/^\/antilink(?:\s+(on|off))?$/i, async (msg, match) => {
  if (msg.chat.type === 'private') return safeRichTextMessage(msg.chat.id, `${E.cross} Hanya untuk grup.`);
  if (!(await requireGroupAdmin(msg))) return;
  if (!(await requireBotAdmin(msg.chat.id))) return;
  const action = (match[1] || '').toLowerCase();
  const gs = getGroupSettings(msg.chat.id);
  let newState;
  if (action === 'on') newState = true;
  else if (action === 'off') newState = false;
  else newState = !gs.antilink;
  setGroupSettings(msg.chat.id, { ...gs, antilink: newState });
  return safeRichSendMessage(msg.chat.id,
    `${newState ? '🟢' : '🔴'} <b>Anti Link ${newState ? 'AKTIF' : 'NONAKTIF'}</b>\n\n` +
    (newState
      ? `<blockquote>${E.shield} Semua link akan dihapus otomatis.\nSistem terus berjalan sampai admin mematikan fitur ini.</blockquote>`
      : `<blockquote>${E.check} Link kembali diperbolehkan di grup ini.</blockquote>`),
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
});

bot.onText(/^\/antiforward(?:\s+(on|off))?$/i, async (msg, match) => {
  if (msg.chat.type === 'private') return safeRichTextMessage(msg.chat.id, `${E.cross} Hanya untuk grup.`);
  if (!(await requireGroupAdmin(msg))) return;
  if (!(await requireBotAdmin(msg.chat.id))) return;
  const action = (match[1] || '').toLowerCase();
  const gs = getGroupSettings(msg.chat.id);
  let newState;
  if (action === 'on') newState = true;
  else if (action === 'off') newState = false;
  else newState = !gs.antiforward;
  setGroupSettings(msg.chat.id, { ...gs, antiforward: newState });
  return safeRichSendMessage(msg.chat.id,
    `${newState ? '🟢' : '🔴'} <b>Anti Forward ${newState ? 'AKTIF' : 'NONAKTIF'}</b>\n\n${newState ? 'Member yang forward akan mendapat warn 1/3 → 2/3 → 3/3. Pelanggaran ke-4 otomatis mute permanen. Admin dikecualikan.' : 'Forward kembali diperbolehkan.'}`,
    { parse_mode: 'HTML', reply_markup: menuGroupKeyboard(msg.chat.id) });
});

// ------- /antiadmin on|off -------
// ON  = admin/creator dikecualikan dari filter pelanggaran.
// OFF = admin/creator ikut diperiksa oleh filter Jaga Group yang aktif.
bot.onText(/^\/antiadmin(?:\s+(on|off))?$/i, async (msg, match) => {
  if (msg.chat.type === 'private') return safeRichTextMessage(msg.chat.id, `${E.cross} Hanya untuk grup.`);
  if (!(await requireGroupAdmin(msg))) return;
  if (!(await requireBotAdmin(msg.chat.id, 'can_delete_messages'))) return;
  const action = (match[1] || '').toLowerCase();
  const gs = getGroupSettings(msg.chat.id);
  let newState;
  if (action === 'on') newState = true;
  else if (action === 'off') newState = false;
  else newState = !gs.antiadmin;
  setGroupSettings(msg.chat.id, { ...gs, antiadmin: newState });
  return safeRichTextMessage(msg.chat.id,
    `<h2>${newState ? '🟢' : '🔴'} ANTIADMIN ${newState ? 'AKTIF' : 'NONAKTIF'}</h2>` +
    `<p>Pengaturan pengecualian admin pada filter pelanggaran Jaga Group.</p>` +
    `<table bordered compact>` +
    `<tr><th>SUBJEK</th><th>STATUS</th></tr>` +
    `<tr><td>👑 Admin / Creator</td><td><b>${newState ? 'Dikecualikan' : 'Ikut diperiksa'}</b></td></tr>` +
    `<tr><td>👤 Member</td><td><b>Ikut diperiksa</b></td></tr>` +
    `<tr><td>🛡️ Filter Jaga Group</td><td><b>Semua filter yang aktif</b></td></tr>` +
    `</table>` +
    `<blockquote>${newState ? 'Mode ON: admin & creator dikecualikan.' : 'Mode OFF: admin & creator ikut terkena pelanggaran sesuai filter yang aktif.'}</blockquote>` +
    `<p><code>/antiadmin on</code> = kecualikan admin\n<code>/antiadmin off</code> = periksa admin</p>`,
    { parse_mode:'HTML', reply_to_message_id: msg.message_id, reply_markup: menuGroupKeyboard(msg.chat.id) });
});

bot.onText(/^\/antibot(?:\s+(on|off))?$/i, async (msg, match) => {
  if (msg.chat.type === 'private') return safeRichTextMessage(msg.chat.id, `${E.cross} Hanya untuk grup.`);
  if (!(await requireGroupAdmin(msg))) return;
  if (!(await requireBotAdmin(msg.chat.id))) return;
  const action = (match[1] || '').toLowerCase();
  const gs = getGroupSettings(msg.chat.id);
  let newState;
  if (action === 'on') newState = true;
  else if (action === 'off') newState = false;
  else newState = !gs.antibot;
  setGroupSettings(msg.chat.id, { ...gs, antibot: newState });
  return safeRichTextMessage(msg.chat.id,
    `${newState ? E.check : E.cross} <b>Anti Bot ${newState ? 'Aktif ✅' : 'Nonaktif ❌'}</b>\n\n` +
    (newState ? `<blockquote>${E.shield} Bot baru yang ditambahkan akan di-kick otomatis.</blockquote>` : `<blockquote>Penambahan bot diperbolehkan.</blockquote>`),
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
});

bot.onText(/^\/welcome(?:\s+(on|off))?$/i, async (msg, match) => {
  if (msg.chat.type === 'private') return safeRichTextMessage(msg.chat.id, `${E.cross} Hanya untuk grup.`);
  if (!(await requireGroupAdmin(msg))) return;
  if (!isGroupBotAdder(msg.chat.id, msg.from.id)) return safeRichTextMessage(msg.chat.id, `${E.cross} Hanya yang menambahkan bot ke grup.`, { parse_mode: 'HTML' });
  const action = (match[1] || '').toLowerCase();
  const chatId = msg.chat.id;
  const userId = msg.from.id;

    if (!action) {
    const gs = getGroupSettings(chatId);
    return safeRichTextMessage(chatId,
      `<blockquote>${E.wave} Status Welcome: ${gs.welcome?.enabled ? `${E.check} Aktif` : `${E.cross} Nonaktif`}\n\n• <code>/welcome on</code> — Setup & aktifkan\n• <code>/welcome off</code> — Nonaktifkan</blockquote>`,
      { parse_mode: 'HTML' });
  }
  if (action === 'off') {
    setGroupSettings(chatId, { ...getGroupSettings(chatId), welcome: { ...getGroupSettings(chatId).welcome, enabled: false } });
    return safeRichTextMessage(chatId, `${E.cross} <b>Welcome dinonaktifkan.</b>`, { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  }
  if (action === 'on') {
    pendingWelcomeSetup.set(`welcome_msg:${chatId}:${userId}`, { step: 'message', chatId, userId });
    return safeRichTextMessage(chatId,
      `${E.wave} <b>Setup Welcome Message</b>\n\nKirim pesan sambutan. Gunakan variabel:\n• <code>{username}</code> — Username\n• <code>{name}</code> — Nama\n• <code>{id}</code> — ID\n\nContoh: <i>Halo {name}! Selamat datang 👋</i>\n\n<blockquote>Kirim pesan sambutan sekarang:</blockquote>`,
      { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  }
});

bot.onText(/^\/kick$/, async (msg) => {
  if (msg.chat.type === 'private') return safeRichTextMessage(msg.chat.id, `${E.cross} Hanya di grup.`);
  if (!(await requireGroupAdmin(msg))) return;
  if (!(await requireBotAdmin(msg.chat.id))) return;
  const target = msg.reply_to_message?.from;
  if (!target) return safeRichTextMessage(msg.chat.id, `${E.cross} Reply pesan member yang ingin di-kick.`);
  try {
    await bot.kickChatMember(msg.chat.id, target.id);
    const name = [target.first_name, target.last_name].filter(Boolean).join(' ') || target.username || target.id;
    return safeRichTextMessage(msg.chat.id, `${E.check} <b>${htmlEscape(name)}</b> telah dikeluarkan.`, { parse_mode: 'HTML' });
  } catch (e) {
    return safeRichTextMessage(msg.chat.id, `${E.cross} Gagal kick: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
});

async function resolveRoleTarget(msg, rawTarget = '') {
  const replyUser = msg.reply_to_message?.from;
  if (replyUser?.id) return replyUser;

  const raw = String(rawTarget || '').trim();
  if (!raw) return null;

  const idMatch = raw.match(/^-?\d+$/);
  if (idMatch) {
    const id = Number(raw);
    if (!Number.isSafeInteger(id)) return null;
    try {
      const member = await bot.getChatMember(msg.chat.id, id);
      return member?.user || null;
    } catch { return { id }; }
  }

  const username = raw.replace(/^@/, '').split(/\s+/)[0];
  if (!/^[A-Za-z0-9_]{5,32}$/.test(username)) return null;
  const wanted = username.toLowerCase();

  // Telegram Bot API needs a numeric user_id for promoteChatMember/getChatMember.
  // Resolve @username from the bot's local member cache first, which is populated
  // whenever a member sends a message or joins. This is much safer than guessing
  // IDs through third-party services.
  try {
    const cached = getGroupMembers(msg.chat.id).find(u =>
      u?.active !== false && String(u?.username || '').toLowerCase() === wanted
    );
    if (cached?.id) {
      try {
        const member = await bot.getChatMember(msg.chat.id, Number(cached.id));
        return member?.user || cached;
      } catch {
        return cached;
      }
    }
  } catch {}

  // Admins are always queryable from Telegram and cover users who were not
  // previously seen by the bot.
  try {
    const admins = await bot.getChatAdministrators(msg.chat.id);
    const found = admins.find(a => String(a?.user?.username || '').toLowerCase() === wanted);
    if (found?.user?.id) return found.user;
  } catch {}

  return null;
}

function roleMention(user) {
  const name = [user?.first_name, user?.last_name].filter(Boolean).join(' ') || (user?.username ? `@${user.username}` : String(user?.id || 'user'));
  return `<a href="tg://user?id=${Number(user.id)}">${htmlEscape(name)}</a>`;
}

function sanitizeAdminTitle(title) {
  return String(title || '').replace(/[\u0000-\u001F\u007F]/g, ' ').replace(/[^\p{L}\p{N} ._\-]/gu, '').replace(/\s+/g, ' ').trim().slice(0, 16);
}

async function resolveRoleTargetAndTitle(msg, rawTarget = '') {
  const raw = String(rawTarget || '').trim();
  if (msg.reply_to_message?.from?.id) return {target: msg.reply_to_message.from, title: sanitizeAdminTitle(raw)};
  if (!raw) return {target:null,title:''};
  const first = raw.split(/\s+/)[0];
  let target = null;
  if (/^-?\d+$/.test(first)) {
    const id = Number(first);
    if (!Number.isSafeInteger(id)) return {target:null,title:''};
    try { const member = await bot.getChatMember(msg.chat.id,id); target = member?.user || {id}; } catch { target = {id}; }
  } else {
    const username = first.replace(/^@/,'');
    if (!/^[A-Za-z0-9_]{5,32}$/.test(username)) return {target:null,title:''};
    const wanted = username.toLowerCase();
    try {
      const cached = getGroupMembers(msg.chat.id).find(u => u?.active !== false && String(u?.username || '').toLowerCase() === wanted);
      if (cached?.id) { try { const member = await bot.getChatMember(msg.chat.id,Number(cached.id)); target = member?.user || cached; } catch { target = cached; } }
    } catch {}
    if (!target) {
      try { const admins = await bot.getChatAdministrators(msg.chat.id); const found = admins.find(a => String(a?.user?.username || '').toLowerCase() === wanted); if (found?.user) target = found.user; } catch {}
    }
  }
  return {target,title:sanitizeAdminTitle(raw.split(/\s+/).slice(1).join(' '))};
}

async function promoteTarget(msg, target, customTitle = '') {
  if (target.id === msg.from.id) return safeRichTextMessage(msg.chat.id, `${E.warning} Kamu tidak perlu mempromote diri sendiri.`);
  try {
    const current = await bot.getChatMember(msg.chat.id, target.id);
    if (current.status === 'creator' || current.status === 'administrator') {
      if (customTitle) {
        await bot.setChatAdministratorCustomTitle(msg.chat.id,target.id,customTitle);
        return safeRichTextMessage(msg.chat.id, `${E.check} <b>JUDUL ADMIN DIPERBARUI</b>\n\n${roleMention(target)}\nJabatan: <b>${htmlEscape(customTitle)}</b>`, {parse_mode:'HTML'});
      }
      return safeRichTextMessage(msg.chat.id, `${E.info2} ${roleMention(target)} sudah berstatus admin.`, {parse_mode:'HTML'});
    }
    const botMember = await bot.getChatMember(msg.chat.id, (await bot.getMe()).id);
    const grantable = {
      can_delete_messages: botMember.can_delete_messages === true,
      can_manage_video_chats: botMember.can_manage_video_chats === true,
      can_restrict_members: botMember.can_restrict_members === true,
      can_change_info: botMember.can_change_info === true,
      can_invite_users: botMember.can_invite_users === true,
      can_pin_messages: botMember.can_pin_messages === true,
      can_manage_topics: botMember.can_manage_topics === true,
      can_post_stories: botMember.can_post_stories === true,
      can_edit_stories: botMember.can_edit_stories === true,
      can_delete_stories: botMember.can_delete_stories === true,
      can_manage_tags: botMember.can_manage_tags === true
    };
    await bot.promoteChatMember(msg.chat.id,target.id,grantable);
    if (customTitle) await bot.setChatAdministratorCustomTitle(msg.chat.id,target.id,customTitle);
    return safeRichTextMessage(msg.chat.id, `${E.crown} <b>PROMOTE BERHASIL</b>\n\n${roleMention(target)} sekarang menjadi admin grup.${customTitle ? `\nJabatan: <b>${htmlEscape(customTitle)}</b>` : ''}`, {parse_mode:'HTML'});
  } catch (e) {
    return safeRichTextMessage(msg.chat.id, `${E.cross} <b>Promote gagal</b>\n\n<code>${htmlEscape(String(e?.message || 'Telegram API error').slice(0,500))}</code>`, {parse_mode:'HTML'});
  }
}

async function demoteTarget(msg, target) {
  try {
    const current = await bot.getChatMember(msg.chat.id,target.id);
    if (current.status === 'creator') return safeRichTextMessage(msg.chat.id, `${E.cross} Creator grup tidak dapat di-demote.`);
    if (current.status !== 'administrator') return safeRichTextMessage(msg.chat.id, `${E.info2} ${roleMention(target)} bukan admin grup.`, {parse_mode:'HTML'});
    await bot.promoteChatMember(msg.chat.id,target.id,{can_manage_chat:false,can_delete_messages:false,can_manage_video_chats:false,can_restrict_members:false,can_promote_members:false,can_change_info:false,can_invite_users:false,can_pin_messages:false,can_post_stories:false,can_edit_stories:false,can_delete_stories:false});
    return safeRichTextMessage(msg.chat.id, `${E.check} <b>DEMOTE BERHASIL</b>\n\n${roleMention(target)} sudah dicabut status adminnya.`, {parse_mode:'HTML'});
  } catch (e) {
    return safeRichTextMessage(msg.chat.id, `${E.cross} <b>Demote gagal</b>\n\n<code>${htmlEscape(String(e?.message || 'Telegram API error').slice(0,500))}</code>`, {parse_mode:'HTML'});
  }
}

bot.onText(/^\/promote(?:@\w+)?(?:\s+(.+))?$/i, async (msg, match) => {
  if (msg.chat.type === 'private') return safeRichTextMessage(msg.chat.id, `${E.cross} Hanya di grup.`);
  if (!(await requireGroupAdmin(msg))) return;
  if (!(await requireBotAdmin(msg.chat.id,'can_promote_members'))) return;
  const resolved = await resolveRoleTargetAndTitle(msg,match?.[1]);
  if (!resolved.target) return safeRichTextMessage(msg.chat.id, `${E.cross} Target tidak ditemukan.\n\nGunakan:\n<code>/promote @username [Nama]</code>\n<code>/promote USER_ID [Nama]</code>\natau reply pesan member dengan <code>/promote [Nama]</code>.`, {parse_mode:'HTML'});
  if (match?.[1] && !msg.reply_to_message && match[1].trim().split(/\s+/).length > 1 && !resolved.title) return safeRichTextMessage(msg.chat.id, `${E.cross} Nama admin tidak valid. Gunakan maksimal 16 karakter tanpa emoji.`, {parse_mode:'HTML'});
  return promoteTarget(msg,resolved.target,resolved.title);
});

bot.onText(/^\/(?:demote|unpromote)(?:@\w+)?(?:\s+(.+))?$/i, async (msg, match) => {
  if (msg.chat.type === 'private') return safeRichTextMessage(msg.chat.id, `${E.cross} Hanya di grup.`);
  if (!(await requireGroupAdmin(msg))) return;
  if (!(await requireBotAdmin(msg.chat.id,'can_promote_members'))) return;
  const resolved = await resolveRoleTargetAndTitle(msg,match?.[1]);
  if (!resolved.target) return safeRichTextMessage(msg.chat.id, `${E.cross} Target tidak ditemukan.\n\nGunakan <code>/demote @username</code>, <code>/demote USER_ID</code>, atau reply pesan admin dengan <code>/demote</code>.`, {parse_mode:'HTML'});
  return demoteTarget(msg,resolved.target);
});

bot.onText(/^\/mute$/, async (msg) => {
  if (msg.chat.type === 'private') return safeRichTextMessage(msg.chat.id, `${E.cross} Hanya di grup.`);
  if (!(await requireGroupAdmin(msg))) return;
  if (!(await requireBotAdmin(msg.chat.id))) return;
  const target = msg.reply_to_message?.from;
  if (!target) return safeRichTextMessage(msg.chat.id, `${E.cross} Reply pesan member yang ingin dimute.`);
  try {
    await bot.restrictChatMember(msg.chat.id, target.id, {
      permissions: { can_send_messages: false, can_send_polls: false, can_send_other_messages: false, can_add_web_page_previews: false }
    });
    const name = [target.first_name, target.last_name].filter(Boolean).join(' ') || target.username || target.id;
    return safeRichTextMessage(msg.chat.id, `${E.mute} <b>${htmlEscape(name)}</b> dimute.`, { parse_mode: 'HTML' });
  } catch (e) {
    return safeRichTextMessage(msg.chat.id, `${E.cross} Gagal mute: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
});

bot.onText(/^\/pin$/, async (msg) => {
  if (msg.chat.type === 'private') return safeRichTextMessage(msg.chat.id, `${E.cross} Hanya di grup.`);
  if (!(await requireGroupAdmin(msg))) return;
  if (!(await requireBotAdmin(msg.chat.id))) return;
  if (!msg.reply_to_message) return safeRichTextMessage(msg.chat.id, `${E.cross} Reply pesan yang ingin di-pin.`);
  try {
    await bot.pinChatMessage(msg.chat.id, msg.reply_to_message.message_id);
    return safeRichTextMessage(msg.chat.id, `${E.pin} Pesan berhasil di-pin.`);
  } catch (e) {
    return safeRichTextMessage(msg.chat.id, `${E.cross} Gagal pin: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
});

bot.onText(/^\/link$/, async (msg) => {
  if (msg.chat.type === 'private') return safeRichTextMessage(msg.chat.id, `${E.cross} Hanya di grup.`);
  if (!(await requireGroupAdmin(msg))) return;
  if (!(await requireBotAdmin(msg.chat.id))) return;
  try {
    const link = await bot.exportChatInviteLink(msg.chat.id);
    return safeRichTextMessage(msg.chat.id, `${E.link} <b>Link Undangan Grup</b>\n\n<code>${link}</code>`, { parse_mode: 'HTML' });
  } catch (e) {
    return safeRichTextMessage(msg.chat.id, `${E.cross} Gagal: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
});

bot.onText(/^\/add(?:\s+(.+))?$/, async (msg, match) => {
  if (msg.chat.type === 'private') return safeRichTextMessage(msg.chat.id, `${E.cross} Hanya di grup.`);
  if (!(await requireGroupAdmin(msg))) return;
  if (!(await requireBotAdmin(msg.chat.id))) return;
  const number = (match[1] || '').trim();
  if (!number) return safeRichTextMessage(msg.chat.id, `${E.cross} Format: <code>/add 628123456789</code>`, { parse_mode: 'HTML' });
  return safeRichTextMessage(msg.chat.id, `${E.info} Fitur add by number memerlukan integrasi khusus. Bagikan link grup kepada mereka: gunakan /link untuk mendapatkan link undangan.`, { parse_mode: 'HTML' });
});

// ======================================= //
bot.onText(/^\/emojiid$/i, async (msg) => {
  const uid = String(msg.from?.id || '');
  const chatId = msg.chat?.id;
  pendingEmojiId.set(uid, { chatId, createdAt: Date.now() });
  setTimeout(() => {
    const cur = pendingEmojiId.get(uid);
    if (cur && Date.now() - cur.createdAt >= 5 * 60 * 1000) pendingEmojiId.delete(uid);
  }, 5 * 60 * 1000);
  return sendRichMenu(chatId,
    `<h2>🆔 EMOJI ID CHECKER</h2><p>Kirim emoji Premium/custom atau emoji Unicode biasa.</p>` +
    `<table bordered compact><tr><th>INPUT</th><th>HASIL</th></tr><tr><td>Premium / Custom</td><td>Custom emoji ID Telegram</td></tr><tr><td>Emoji biasa</td><td>Unicode; tidak ada custom emoji ID</td></tr></table>`,
    { inline_keyboard: [[{ text:'✖️ Batal', callback_data:'tool_emoji_id_cancel', style:'danger' }],[{ text:'↩️ Tools', callback_data:'menu_alat' }]] }, c.BANNER_URL);
});

// 🧰 TOOLS + 🎮 FUN EXTENSION
// ======================================= //
const FUN_8BALL = ['Bisa jadi.','Ya, kemungkinan besar.','Belum tentu.','Coba lagi nanti.','Tanda-tandanya bagus.','Aku rasa iya.','Aku rasa tidak.','Fokus dulu, hasil menyusul.'];
// ======================================= //
// 🎮 MULTIPLAYER FUN — 2 sampai 5 pemain
// ======================================= //
function playerName(user) { return htmlEscape([user.first_name, user.last_name].filter(Boolean).join(' ') || user.username || `Player ${user.id}`); }
function getPartyScoreText(chatId) {
  const t = partySessions.get(chatId);
  const q = quizPartySessions.get(chatId);
  const saved = partyScores.get(chatId) || [];
  const players = t?.players || q?.players || saved;
  if (!players.length) return '🏆 <b>Scoreboard</b>\nBelum ada sesi multiplayer aktif.';
  return '🏆 <b>Scoreboard Sesi</b>\n' + players.map((p,i)=>`${i+1}. ${p.name} — <b>${p.score||0}</b> poin`).join('\n');
}
function tttBoard(s) {
  const cells = s.board.map((v,i)=>v || String(i+1));
  return `${cells[0]} ${cells[1]} ${cells[2]}\n${cells[3]} ${cells[4]} ${cells[5]}\n${cells[6]} ${cells[7]} ${cells[8]}`;
}
function tttWinner(b) {
  for (const [a,c,d] of [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]]) if (b[a] && b[a]===b[c] && b[a]===b[d]) return b[a];
  return b.every(Boolean) ? 'draw' : null;
}
function tttMarkup(chatId) {
  const s=tttSessions.get(chatId); if(!s) return undefined;
  const rows=[];
  for(let r=0;r<3;r++) rows.push([0,1,2].map(c=>{const i=r*3+c; return {text:s.board[i]||String(i+1), callback_data:`ttt_move_${chatId}_${i}`};}));
  return {inline_keyboard:rows};
}

function mpName(user) { return playerName(user); }
function mpLobbyKeyboard(type, chatId) {
  return {inline_keyboard:[
    [{text:'➕ Join',callback_data:`mp_${type}_join_${chatId}`,style:'success'},{text:'▶️ Mulai',callback_data:`mp_${type}_start_${chatId}`,style:'primary'}],
    [{text:'🛑 Batal',callback_data:`mp_${type}_stop_${chatId}`,style:'danger'}]
  ]};
}
function mpScoreText(s) {
  return s.players.map((p,i)=>`${i+1}. ${p.name} — <b>${s.scores[p.id]||0}</b> poin`).join('\n');
}
function mpNew(chatId,user,type) {
  if (mpGameSessions.has(chatId)) return null;
  const s={type,host:user.id,players:[{id:user.id,name:mpName(user)}],max:5,createdAt:Date.now(),scores:{},answers:new Map()};
  mpGameSessions.set(chatId,s);
  setTimeout(()=>{ const cur=mpGameSessions.get(chatId); if(cur===s && Date.now()-cur.createdAt>=15*60*1000) mpGameSessions.delete(chatId); },15*60*1000);
  return s;
}
function mpQuestion(type) {
  if(type==='math') { const a=crypto.randomInt(5,21),b=crypto.randomInt(2,13),c=crypto.randomInt(1,5); const ans=a*b+c; return {q:`Berapakah ${a} × ${b} + ${c}?`,options:[String(ans),String(ans+2),String(ans-2),String(ans+5)],answer:0}; }
  if(type==='emoji') { const bank=[['🐱🐭','Tom & Jerry',['Tom & Jerry','Minecraft','Cars','Up']],['🧙‍♂️💍🌋','The Lord of the Rings',['Harry Potter','The Lord of the Rings','Frozen','Avatar']],['🦁👑','The Lion King',['The Lion King','Toy Story','Shrek','Moana']],['🚢🧊','Titanic',['Titanic','Cars','Jumanji','Aladdin']]]; const x=bank[crypto.randomInt(bank.length)]; return {q:`Tebak judul dari emoji: ${x[0]}`,options:x[2],answer:x[2].indexOf(x[1])}; }
  if(type==='choice') { const bank=[['Planet terbesar di Tata Surya?',['Bumi','Mars','Jupiter','Venus'],2],['Bahasa yang berjalan di browser?',['JavaScript','C++','SQL','Bash'],0],['Hewan mamalia terbesar?',['Gajah Afrika','Kucing','Serigala','Panda'],0],['5 × 6 = ?',['25','30','35','40'],1]]; const x=bank[crypto.randomInt(bank.length)]; return {q:x[0],options:x[1],answer:x[2]}; }
  return {q:'Pilih jawaban yang benar.',options:['A','B','C','D'],answer:0};
}
function mpAnswerKeyboard(type,chatId,options){ return {inline_keyboard:[options.map((x,i)=>({text:`${String.fromCharCode(65+i)}. ${x}`,callback_data:`mp_${type}_ans_${chatId}_${i}`}))]}; }

bot.onText(/^\/tictac$/i, async msg => {
  if (msg.chat.type === 'private') return safeRichTextMessage(msg.chat.id,'❌⭕ TicTacToe multiplayer lebih seru dimainkan di grup. Tambahkan bot ke grup lalu ketik /tictac.',{parse_mode:'HTML'});
  if (tttSessions.has(msg.chat.id)) return safeRichTextMessage(msg.chat.id,'❌⭕ Masih ada game TicTacToe aktif. Selesaikan dulu atau gunakan /stopgame.');
  const p={id:msg.from.id,name:playerName(msg.from),mark:'X'};
  const s={board:Array(9).fill(null),players:[p],turn:0}; tttSessions.set(msg.chat.id,s);
  return safeRichTextMessage(msg.chat.id,`❌⭕ <b>TicTacToe</b>\n\n${p.name} membuat game dan menjadi X.\nPemain kedua tekan Join.`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🎮 Join Game',callback_data:`ttt_join_${msg.chat.id}`}],[{text:'🛑 Stop',callback_data:`ttt_stop_${msg.chat.id}`}]]}});
});

bot.onText(/^\/party$/i, async msg => {
  const chatId=msg.chat.id;
  if(partySessions.has(chatId)) return safeRichTextMessage(chatId,'👥 Lobby sudah aktif. Tekan /joinparty untuk ikut.');
  partySessions.set(chatId,{type:'number',players:[{id:msg.from.id,name:playerName(msg.from),score:0}],max:5,target:crypto.randomInt(1,51),started:false,turn:0});
  return safeRichTextMessage(chatId,'👥 <b>Party Tebak Target 2–5</b>\n\nLobby dibuat oleh '+playerName(msg.from)+'\nPemain lain: /joinparty\nMaksimal 5 pemain.\n\nHost mulai dengan /startparty.',{parse_mode:'HTML'});
});

bot.onText(/^\/wordparty$/i, async msg => {
  const chatId=msg.chat.id; if(partySessions.has(chatId)) return safeRichTextMessage(chatId,'🔤 Lobby sudah aktif.');
  partySessions.set(chatId,{type:'word',players:[{id:msg.from.id,name:playerName(msg.from),score:0}],max:5,started:false,lastLetter:null,turn:0,used:[]});
  return safeRichTextMessage(chatId,'🔤 <b>Kata Berantai 2–5</b>\n\nHost: '+playerName(msg.from)+'\nPemain lain /joinparty\nSetelah semua masuk, host /startparty.\nJawab dengan <code>/kata rumah</code>.', {parse_mode:'HTML'});
});

bot.onText(/^\/joinparty$/i, async msg => {
  const s=partySessions.get(msg.chat.id); if(!s) return safeRichTextMessage(msg.chat.id,'Belum ada lobby. Ketik /party atau /wordparty.');
  if(s.started) return safeRichTextMessage(msg.chat.id,'Game sudah dimulai.');
  if(s.players.some(p=>p.id===msg.from.id)) return safeRichTextMessage(msg.chat.id,'Kamu sudah bergabung.');
  if(s.players.length>=s.max) return safeRichTextMessage(msg.chat.id,'Lobby penuh (maksimal 5 pemain).');
  s.players.push({id:msg.from.id,name:playerName(msg.from),score:0});
  return safeRichTextMessage(msg.chat.id,`✅ ${playerName(msg.from)} bergabung. <b>${s.players.length}/${s.max}</b> pemain.`,{parse_mode:'HTML'});
});

bot.onText(/^\/startparty$/i, async msg => {
  const s=partySessions.get(msg.chat.id); if(!s) return safeRichTextMessage(msg.chat.id,'Buat lobby dulu dengan /party atau /wordparty.');
  if(s.players[0].id!==msg.from.id) return safeRichTextMessage(msg.chat.id,'Hanya host yang bisa memulai.');
  if(s.players.length<2) return safeRichTextMessage(msg.chat.id,'Minimal 2 pemain.');
  s.started=true; s.turn=0;
  if(s.type==='number') return safeRichTextMessage(msg.chat.id,`🎯 <b>Party dimulai!</b>\nTarget rahasia antara 1–50.\nGiliran: <b>${s.players[0].name}</b>\nKetik <code>/tebakparty 1-50</code>.`,{parse_mode:'HTML'});
  return safeRichTextMessage(msg.chat.id,`🔤 <b>Kata Berantai dimulai!</b>\nKata pertama bebas.\nGiliran: <b>${s.players[0].name}</b>\nKetik <code>/kata &lt;kata&gt;</code>.`,{parse_mode:'HTML'});
});

bot.onText(/^\/tebakparty(?:\s+(\d+))?$/i, async (msg,m) => {
  const s=partySessions.get(msg.chat.id); if(!s || s.type!=='number' || !s.started) return;
  const p=s.players[s.turn]; if(p.id!==msg.from.id) return safeRichTextMessage(msg.chat.id,`⏳ Giliran ${p.name}.`);
  const n=Number(m[1]); if(!Number.isInteger(n)||n<1||n>50) return safeRichTextMessage(msg.chat.id,'Masukkan angka 1–50.');
  if(n===s.target){ p.score+=3; const winner=p.name; partySessions.delete(msg.chat.id); return safeRichTextMessage(msg.chat.id,`🏆 <b>${winner} menang!</b>\nTargetnya <b>${n}</b>. +3 poin.`,{parse_mode:'HTML'});}
  const hint=n<s.target?'lebih besar':'lebih kecil'; p.score+=1; s.turn=(s.turn+1)%s.players.length;
  return safeRichTextMessage(msg.chat.id,`🎯 ${p.name}: <b>${n}</b> — target ${hint}. +1 poin.\nGiliran: <b>${s.players[s.turn].name}</b>`);
});

bot.onText(/^\/kata(?:\s+(.+))?$/i, async (msg,m) => {
  const s=partySessions.get(msg.chat.id); if(!s || s.type!=='word' || !s.started) return;
  const p=s.players[s.turn]; if(p.id!==msg.from.id) return safeRichTextMessage(msg.chat.id,`⏳ Giliran ${p.name}.`);
  const word=(m[1]||'').trim().toLowerCase().replace(/[^a-z0-9]/g,''); if(word.length<2) return safeRichTextMessage(msg.chat.id,'Kata minimal 2 karakter.');
  if(s.used.includes(word)) return safeRichTextMessage(msg.chat.id,'Kata itu sudah dipakai.');
  if(s.lastLetter && word[0]!==s.lastLetter) return safeRichTextMessage(msg.chat.id,`Kata harus dimulai huruf <b>${s.lastLetter.toUpperCase()}</b>.`,{parse_mode:'HTML'});
  s.used.push(word); s.lastLetter=word[word.length-1]; p.score+=1; s.turn=(s.turn+1)%s.players.length;
  return safeRichTextMessage(msg.chat.id,`🔤 ${p.name}: <b>${htmlEscape(word)}</b> ✓\nGiliran: <b>${s.players[s.turn].name}</b> — kata harus mulai <b>${s.lastLetter.toUpperCase()}</b>.`,{parse_mode:'HTML'});
});

bot.onText(/^\/stopgame$/i, async msg => { tttSessions.delete(msg.chat.id); partySessions.delete(msg.chat.id); quizPartySessions.delete(msg.chat.id); duelSessions.delete(String(msg.chat.id)); mpGameSessions.delete(msg.chat.id); return safeRichTextMessage(msg.chat.id,'🛑 Semua game multiplayer di chat ini dihentikan.'); });
bot.onText(/^\/scores$/i, async msg => safeRichTextMessage(msg.chat.id,getPartyScoreText(msg.chat.id),{parse_mode:'HTML'}));

bot.onText(/^\/quizparty$/i, async msg => {
  const chatId=msg.chat.id; if(quizPartySessions.has(chatId)) return safeRichTextMessage(chatId,'🧠 Quiz Party sudah ada.');
  quizPartySessions.set(chatId,{players:[{id:msg.from.id,name:playerName(msg.from),score:0}],max:5,started:false,q:null,answered:new Set()});
  return safeRichTextMessage(chatId,'🧠 <b>Quiz Party 2–5</b>\nHost: '+playerName(msg.from)+'\nPemain lain /joinquizparty\nHost mulai /startquizparty.',{parse_mode:'HTML'});
});
bot.onText(/^\/joinquizparty$/i, async msg => { const s=quizPartySessions.get(msg.chat.id); if(!s) return safeRichTextMessage(msg.chat.id,'Buat dulu dengan /quizparty.'); if(s.started)return safeRichTextMessage(msg.chat.id,'Quiz sudah dimulai.'); if(s.players.some(p=>p.id===msg.from.id))return safeRichTextMessage(msg.chat.id,'Kamu sudah bergabung.'); if(s.players.length>=5)return safeRichTextMessage(msg.chat.id,'Lobby penuh.'); s.players.push({id:msg.from.id,name:playerName(msg.from),score:0}); return safeRichTextMessage(msg.chat.id,`✅ ${playerName(msg.from)} bergabung. ${s.players.length}/5`,{parse_mode:'HTML'}); });
bot.onText(/^\/startquizparty$/i, async msg => { const s=quizPartySessions.get(msg.chat.id); if(!s)return safeRichTextMessage(msg.chat.id,'Buat lobby dengan /quizparty.'); if(s.players[0].id!==msg.from.id)return safeRichTextMessage(msg.chat.id,'Hanya host.'); if(s.players.length<2)return safeRichTextMessage(msg.chat.id,'Minimal 2 pemain.'); s.started=true; s.q=QUIZ_BANK[crypto.randomInt(QUIZ_BANK.length)]; s.answered=new Set(); return safeRichTextMessage(msg.chat.id,`🧠 <b>Quiz Party</b>\n${htmlEscape(s.q.q)}\n\nA. ${htmlEscape(s.q.o[0])}\nB. ${htmlEscape(s.q.o[1])}\nC. ${htmlEscape(s.q.o[2])}\nD. ${htmlEscape(s.q.o[3])}\n\nJawab <code>A/B/C/D</code>.`,{parse_mode:'HTML'}); });

const QUIZ_BANK = [
  {q:'Planet terbesar di tata surya?',o:['Mars','Jupiter','Venus','Merkurius'],a:2},
  {q:'Bahasa utama yang dijalankan Node.js?',o:['JavaScript','HTML','CSS','SQL'],a:1},
  {q:'Ibu kota Indonesia saat ini?',o:['Bandung','Surabaya','Jakarta','Medan'],a:3},
  {q:'Hasil 12 × 8?',o:['86','96','108','88'],a:2},
  {q:'Simbol kimia untuk air?',o:['CO2','O2','H2O','NaCl'],a:3}
];
async function resolveInfoTarget(msg, rawTarget = '') {
  const replyUser = msg.reply_to_message?.from;
  if (replyUser?.id) return { user: replyUser, source: 'reply' };

  const raw = String(rawTarget || '').trim();
  if (!raw) return { user: msg.from, source: 'self' };

  const first = raw.split(/\s+/)[0];
  const state = readState();

  // Numeric ID: prefer our persistent user cache, then the current group's
  // member cache, then Telegram getChatMember when the bot is allowed to query it.
  if (/^\d+$/.test(first)) {
    const id = String(first);
    const cached = state.users?.[id];
    if (cached?.id) return { user: cached, source: 'id-cache' };

    const groupCached = getGroupMembers(msg.chat.id).find(u => String(u?.id) === id && u?.active !== false);
    if (groupCached?.id) return { user: groupCached, source: 'id-group-cache' };

    if (['group', 'supergroup'].includes(msg.chat.type)) {
      try {
        const member = await bot.getChatMember(msg.chat.id, Number(id));
        if (member?.user) return { user: member.user, source: 'id-telegram' };
      } catch {}
    }
    return { user: null, source: 'not-found', requested: id };
  }

  const username = first.replace(/^@/, '').toLowerCase();
  if (!/^[a-z0-9_]{5,32}$/i.test(username)) return { user: null, source: 'invalid', requested: first };

  // Telegram Bot API does not provide a generic get-user-by-username method.
  // Resolve @username from users already known by this bot, current group cache,
  // or the admin list. This avoids fake IDs and keeps /info deterministic.
  const found = Object.values(state.users || {}).find(
    u => u?.id && String(u.username || '').toLowerCase() === username
  );
  if (found) return { user: found, source: 'username-cache' };

  const groupCached = getGroupMembers(msg.chat.id).find(
    u => u?.id && u?.active !== false && String(u.username || '').toLowerCase() === username
  );
  if (groupCached) return { user: groupCached, source: 'username-group-cache' };

  if (['group', 'supergroup'].includes(msg.chat.type)) {
    try {
      const admins = await bot.getChatAdministrators(msg.chat.id);
      const admin = admins.find(a => String(a?.user?.username || '').toLowerCase() === username);
      if (admin?.user) return { user: admin.user, source: 'username-admin' };
    } catch {}
  }

  return { user: null, source: 'not-found', requested: `@${username}` };
}

async function sendUserInfo(chatId, user, targetChatId = chatId, meta = {}) {
  if (!user?.id) throw new Error('Data user tidak tersedia.');

  const name = [user.first_name, user.last_name].filter(Boolean).join(' ') || user.username || String(user.id);
  const username = user.username ? `@${user.username}` : '-';
  let status = '-';
  let statusLabel = 'Tidak diketahui';

  if (targetChatId && ['group', 'supergroup'].includes(meta.chatType || '')) {
    try {
      const member = await bot.getChatMember(targetChatId, Number(user.id));
      status = member?.status || '-';
      const labels = {
        creator: 'Owner Grup',
        administrator: 'Administrator',
        member: 'Member',
        restricted: member?.is_member === false ? 'Keluar' : 'Restricted',
        left: 'Left',
        kicked: 'Banned'
      };
      statusLabel = labels[status] || status;
    } catch {}
  } else if (String(targetChatId) === String(user.id)) {
    status = 'private';
    statusLabel = 'Private / Self';
  } else if (meta.source === 'id-cache' || meta.source === 'username-cache') {
    statusLabel = 'Dikenal bot';
  }

  const safeName = htmlEscape(name).slice(0, 180);
  const safeUsername = htmlEscape(username);
  const profileUrl = user.username
    ? `https://t.me/${String(user.username).replace(/^@/, '')}`
    : `tg://user?id=${String(user.id)}`;
  const accountType = user.is_bot ? 'Bot Telegram' : 'Pengguna';
  const sourceLabel = meta.source === 'reply' ? 'Reply' : meta.source === 'self' ? 'Akun sendiri' : 'Target';

  const usernameLine = user.username
    ? `<a href="${htmlEscape(profileUrl)}">${safeUsername}</a>`
    : '<i>Tidak ada username</i>';

  // Keep this card intentionally close to the clean reference: one title,
  // one divider, compact identity rows, and a single profile action.
  const text = [
    `<h2>${E.crown} USER INFO</h2>`,
    `<p><b>${safeName}</b>${user.username ? ` · ${usernameLine}` : ''}</p>`,
    `<hr/>`,
    `<table bordered compact>`,
    `<tr><th>DATA</th><th>INFORMASI</th></tr>`,
    `<tr><td>User ID</td><td><code>${htmlEscape(String(user.id))}</code></td></tr>`,
    `<tr><td>Username</td><td>${usernameLine}</td></tr>`,
    `<tr><td>Nama</td><td>${safeName}</td></tr>`,
    `<tr><td>Tipe</td><td>${htmlEscape(accountType)}</td></tr>`,
    `<tr><td>Status</td><td>${htmlEscape(statusLabel)}</td></tr>`,
    `<tr><td>Sumber</td><td>${htmlEscape(sourceLabel)}</td></tr>`,
    `</table>`,
    `<footer>MD RICH • User Information</footer>`
  ].join('');

  const keyboard = {
    inline_keyboard: [[{
      text: '👤 Buka Profil',
      url: profileUrl,
      style: 'primary'
    }]]
  };

  return sendRichMenu(chatId, text, keyboard, null, meta.replyToMessageId || null);
}
bot.onText(/^\/id$/i, async msg => {
  const target=msg.reply_to_message?.from || msg.from;
  const chatType=msg.chat.type;
  return safeRichTextMessage(msg.chat.id,`🆔 <b>ID INFO</b>\nUser ID: <code>${target.id}</code>\nChat ID: <code>${msg.chat.id}</code>\nChat Type: <code>${chatType}</code>`,{parse_mode:'HTML'});
});
bot.onText(/^\/info(?:@\w+)?(?:\s+([\s\S]+))?$/i, async (msg, match) => {
  try {
    const rawTarget = String(match?.[1] || '').trim();
    const resolved = await resolveInfoTarget(msg, rawTarget);
    if (!resolved.user) {
      const requested = htmlEscape(String(resolved.requested || rawTarget || 'target').slice(0, 80));
      return safeRichTextMessage(msg.chat.id,
        `<blockquote>${E.warning} <b>USER TIDAK DITEMUKAN</b></blockquote>` +
        `<p>Target <code>${requested}</code> belum dikenal oleh bot atau tidak dapat di-resolve dari chat ini.</p>` +
        `<p>Gunakan salah satu cara:</p>` +
        `<p><code>/info @username</code><br/><code>/info USER_ID</code><br/>Reply pesan user lalu <code>/info</code></p>`,
        { parse_mode:'HTML', reply_to_message_id: msg.message_id });
    }
    return sendUserInfo(msg.chat.id, resolved.user, msg.chat.id, {
      source: resolved.source,
      chatType: msg.chat.type,
      replyToMessageId: msg.message_id
    });
  } catch (e) {
    return safeRichTextMessage(msg.chat.id,
      `<blockquote>${E.cross} <b>INFO GAGAL</b></blockquote><p>${htmlEscape(String(e?.message || 'Gagal mengambil info user.').slice(0, 500))}</p>`,
      { parse_mode:'HTML', reply_to_message_id: msg.message_id });
  }
});
bot.onText(/^\/health$/i, async msg => {
  const mem=process.memoryUsage();
  return safeRichTextMessage(msg.chat.id,`🩺 <b>HEALTH CHECK</b>\n\nStatus: <b>ONLINE</b>\nNode: <code>${process.version}</code>\nUptime: <code>${Math.floor(process.uptime())} detik</code>\nRAM: <code>${Math.round(mem.rss/1024/1024)} MB</code>`,{parse_mode:'HTML'});
});

function toolKeyboardBack(){ return {inline_keyboard:[[{text:'🧰 Menu Alat',callback_data:'menu_alat'},{text:'✿ Kembali',callback_data:'back_menu',style:'danger'}]]}; }
function safeCalc(expr){
  const clean=String(expr||'').replace(/\s+/g,'');
  if(!clean || clean.length>100 || !/^[0-9+\-*/%().]+$/.test(clean)) throw new Error('Ekspresi hanya boleh berisi angka dan operator + - * / % ( ).');
  if(/[*/%]{2,}/.test(clean)) throw new Error('Operator tidak valid.');
  const result=Function('"use strict";return ('+clean+')')();
  if(!Number.isFinite(result)) throw new Error('Hasil tidak valid.');
  return result;
}
function randomPassword(len=16){
  len=Math.min(64,Math.max(8,parseInt(len,10)||16));
  const chars='ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%^&*';
  let out=''; for(let i=0;i<len;i++) out+=chars[crypto.randomInt(chars.length)]; return out;
}

bot.onText(/^\/relax$/i, async msg=>{ if(!(await requireJoin(msg)))return; return safeRichTextMessage(msg.chat.id,relaxingText(),{parse_mode:'HTML',reply_markup:relaxingKeyboard()}); });
bot.onText(/^\/alat$/i, async msg=>{ if(!(await requireJoin(msg)))return; return safeRichTextMessage(msg.chat.id,menuAlatText(),{parse_mode:'HTML',reply_markup:menuAlatKeyboard()}); });
bot.onText(/^\/ai$/i, async msg=>{ if(!(await requireJoin(msg)))return; return safeRichTextMessage(msg.chat.id,menuAIText(msg.from.id),{parse_mode:'HTML',reply_markup:menuAIKeyboard(msg.chat.id)}); });
// Explicit AI on/off commands MUST be registered before the generic /ai <prompt> handler.
bot.onText(/^\/ai\s+(on|off)$/i, async (msg, m) => {
  if (!(await requireJoin(msg))) return;
  const enabled = String(m[1]).toLowerCase() === 'on';
  setAssistantEnabled(msg.chat.id, enabled);
  pendingAiAction.delete(String(msg.from.id));
  const provider = normalizeAiProvider(getAssistantProvider(msg.chat.id));
  return safeRichTextMessage(
    msg.chat.id,
    enabled
      ? `${E.ai} <b>AI Assistant AKTIF</b>\n\nProvider: <b>${htmlEscape(aiProviderLabel(provider))}</b>\nPesan biasa sekarang dapat diproses AI sesuai aturan menu.`
      : `${E.ai} <b>AI Assistant MATI</b>\n\nAI tidak akan merespons pesan biasa, termasuk <code>/start</code> dan pesan broadcast.\nGunakan <code>/ai pertanyaan</code> jika ingin bertanya secara manual.`,
    { parse_mode: 'HTML', reply_to_message_id: msg.message_id, reply_markup: menuAIKeyboard(msg.chat.id) }
  );
});
bot.onText(/^\/ai\s+(?!(?:on|off)\s*$)([\s\S]{2,1000})$/i, async (msg,m)=>{
  if(!(await requireJoin(msg))) return;
  const prompt=m[1].trim();
  if(isJailbreak(prompt)) return safeRichTextMessage(msg.chat.id,`${E.cross} Permintaan bypass sistem ditolak.`,{parse_mode:'HTML'});
  const activeProvider=normalizeAiProvider(getAssistantState(msg.chat.id));
  const load=await safeRichTextMessage(msg.chat.id,`${E.ai} <i>${htmlEscape(aiProviderLabel(activeProvider))} sedang berpikir...</i>`,{parse_mode:'HTML'});
  try {
    const result=await callAI(msg.chat.id,prompt,activeProvider);
    await safeDelete(bot,msg.chat.id,load.message_id);
    return safeRichTextMessage(msg.chat.id,`${E.ai} <b>${htmlEscape(aiProviderLabel(result.provider))}</b>\n\n${formatAiResponse(result.answer)}`,{parse_mode:'HTML',reply_to_message_id:msg.message_id});
  } catch(e) {
    return safeEdit(bot,msg.chat.id,load.message_id,`${E.cross} AI tidak tersedia.\n<code>${htmlEscape(e.message)}</code>`,{parse_mode:'HTML'});
  }
});
bot.onText(/^\/(ringkas|summarize|rewrite|translate|code|coding|study)$/i, async (msg,m)=>{
  if(!(await requireJoin(msg))) return;
  const map={ringkas:'summarize',summarize:'summarize',rewrite:'rewrite',translate:'translate',code:'code',coding:'code',study:'study'};
  const mode=map[String(m[1]).toLowerCase()];
  if(!AI_PROVIDERS.includes(String(getAssistantState(msg.chat.id))) && getAssistantState(msg.chat.id)!=='auto') setAssistantState(msg.chat.id,'gemini');
  setPendingAiAction(msg.from.id,msg.chat.id,mode);
  const labels={summarize:'📝 Ringkas Teks',rewrite:'✍️ Rewrite',translate:'🌐 Translate',code:'💻 Coding Assistant',study:'📚 Study Assistant'};
  return safeRichTextMessage(msg.chat.id,`${labels[mode]}\n\nKirim teks atau permintaan berikutnya.`,{parse_mode:'HTML',reply_to_message_id:msg.message_id,reply_markup:{inline_keyboard:[[{text:'❌ Batal',callback_data:'ai_features'}],[{text:'🤖 Menu AI',callback_data:'ai_menu'}]]}});
});
bot.onText(/^\/pixazo$/i, async (msg)=>{
  if(!(await requireJoin(msg))) return;
  return safeRichTextMessage(msg.chat.id,`🎨 <b>PIXAZO STUDIO</b>\n\n${pixazoReady()?'🟢 API siap digunakan.':'🔴 PIXAZO_API_KEY belum diisi di .env.'}\n\n• <b>Edit Foto</b> — kirim foto + prompt di caption\n• <b>Edit Video</b> — kirim video + prompt di caption\n• <b>Foto → Video</b> — kirim foto + prompt gerakan di caption\n\nContoh prompt: <code>ubah background menjadi kota malam dengan lampu neon, pertahankan subjek utama</code>`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🎨 Buka Pixazo',callback_data:'ai_feature_pixazo_photo'},{text:'🎬 Edit Video',callback_data:'ai_feature_pixazo_video'}],[{text:'🖼️➡️🎬 Foto ke Video',callback_data:'ai_feature_pixazo_i2v'}],[{text:'🤖 Menu AI',callback_data:'ai_menu'}]]}});
});

bot.onText(/^\/imageai$/i, async (msg)=>{
  if(!(await requireJoin(msg))) return;
  setAssistantState(msg.chat.id,'gemini');
  setPendingAiAction(msg.from.id,msg.chat.id,'image');
  return safeRichTextMessage(msg.chat.id,'🖼️ <b>Analisis Gambar</b>\n\nKirim foto berikutnya. Kamu juga bisa menambahkan caption berisi pertanyaan.',{parse_mode:'HTML',reply_to_message_id:msg.message_id,reply_markup:{inline_keyboard:[[{text:'❌ Batal',callback_data:'ai_features'}]]}});
});

bot.onText(/^\/calc(?:\s+([\s\S]+))?$/i, async(msg,m)=>{ const e=m[1]; if(!e)return safeRichTextMessage(msg.chat.id,'🧮 <b>Kalkulator</b>\nContoh: <code>/calc 12*(5+3)</code>',{parse_mode:'HTML'}); try{return safeRichTextMessage(msg.chat.id,`🧮 <b>Hasil</b>\n<code>${htmlEscape(String(safeCalc(e)))}</code>`,{parse_mode:'HTML'});}catch(err){return safeRichTextMessage(msg.chat.id,`${E.cross} ${htmlEscape(err.message)}`,{parse_mode:'HTML'});} });
bot.onText(/^\/password(?:\s+(\d+))?$/i,async(msg,m)=>safeRichTextMessage(msg.chat.id,`🔐 <b>Password Generator</b>\n<code>${randomPassword(m[1]||16)}</code>`,{parse_mode:'HTML'}));
bot.onText(/^\/uuid$/i,async msg=>safeRichTextMessage(msg.chat.id,`🆔 <b>UUID v4</b>\n<code>${crypto.randomUUID()}</code>`,{parse_mode:'HTML'}));
bot.onText(/^\/base64(?:\s+([\s\S]+))?$/i,async(msg,m)=>{if(!m[1])return safeRichTextMessage(msg.chat.id,'🔤 Contoh: <code>/base64 halo dunia</code>',{parse_mode:'HTML'}); return safeRichTextMessage(msg.chat.id,`🔤 <b>Base64</b>\n<code>${Buffer.from(m[1],'utf8').toString('base64')}</code>`,{parse_mode:'HTML'});});
bot.onText(/^\/unbase64(?:\s+([\s\S]+))?$/i,async(msg,m)=>{if(!m[1])return safeRichTextMessage(msg.chat.id,'🔓 Contoh: <code>/unbase64 aGVsbG8=</code>',{parse_mode:'HTML'}); try{return safeRichTextMessage(msg.chat.id,`🔓 <b>Decoded</b>\n<code>${htmlEscape(Buffer.from(m[1].trim(),'base64').toString('utf8'))}</code>`,{parse_mode:'HTML'});}catch(e){return safeRichTextMessage(msg.chat.id,`${E.cross} Base64 tidak valid.`,{parse_mode:'HTML'});}});
bot.onText(/^\/textinfo(?:\s+([\s\S]+))?$/i,async(msg,m)=>{const t=m[1]||''; const words=t.trim()?t.trim().split(/\s+/).length:0; return safeRichTextMessage(msg.chat.id,`📊 <b>Text Info</b>\nKarakter: <code>${t.length}</code>\nKata: <code>${words}</code>\nBaris: <code>${t?t.split(/\r?\n/).length:0}</code>\nByte UTF-8: <code>${Buffer.byteLength(t,'utf8')}</code>`,{parse_mode:'HTML'});});
bot.onText(/^\/waktu$/i,async msg=>{const now=moment().tz(c.TIMEZONE); return safeRichTextMessage(msg.chat.id,`🕒 <b>${now.format('dddd, DD MMMM YYYY')}</b>\n<code>${now.format('HH:mm:ss')} WIB</code>`,{parse_mode:'HTML'});});
bot.onText(/^\/sholat(?:\s+(.+))?$/i,async(msg,m)=>{if(!(await requireJoin(msg)))return; const city=(m[1]||'Jakarta').trim(); try{return safeRichTextMessage(msg.chat.id,await getPrayerTimesByCity(city),{parse_mode:'HTML'});}catch(e){return safeRichTextMessage(msg.chat.id,`${E.cross} Gagal mengambil jadwal sholat: <code>${htmlEscape(e.message)}</code>`,{parse_mode:'HTML'});}});
bot.onText(/^\/cekcuaca(?:\s+(.+))?$/i,async(msg,m)=>{if(!(await requireJoin(msg)))return; const city=(m[1]||'').trim(); if(!city){pendingWeather.set(String(msg.from.id),{chatId:msg.chat.id,mode:'city',createdAt:Date.now()}); setTimeout(()=>pendingWeather.delete(String(msg.from.id)),2*60*1000); return safeRichTextMessage(msg.chat.id,'🌦️ Ketik nama kota untuk cek cuaca, contoh <code>Bandung</code>, atau kirim lokasi Telegram.',{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'📍 Kirim Lokasi',request_location:true}]]}});} try{return safeRichTextMessage(msg.chat.id,await getWeatherByCity(city),{parse_mode:'HTML'});}catch(e){return safeRichTextMessage(msg.chat.id,`${E.cross} Gagal mengambil cuaca: <code>${htmlEscape(e.message)}</code>`,{parse_mode:'HTML'});}});
bot.onText(/^\/jamdunia(?:\s+(.+))?$/i,async(msg,m)=>{if(!(await requireJoin(msg)))return; const raw=(m[1]||'Jakarta').trim().toLowerCase(); const tz=WORLD_TIMEZONES[raw] || (raw.includes('/') && WORLD_TIMEZONES[raw] ? WORLD_TIMEZONES[raw] : null); if(!tz){return safeRichTextMessage(msg.chat.id,'🌍 Kota belum ada di daftar. Coba: <code>Jakarta</code>, <code>Tokyo</code>, <code>London</code>, <code>New York</code>, <code>Sydney</code>.',{parse_mode:'HTML'});} return safeRichTextMessage(msg.chat.id,worldClockText(m[1]||'Jakarta',tz),{parse_mode:'HTML'});});
bot.onText(/^\/json(?:\s+([\s\S]+))?$/i,async(msg,m)=>{if(!m[1])return safeRichTextMessage(msg.chat.id,'🧾 Contoh: <code>/json {"nama":"bot"}</code>',{parse_mode:'HTML'}); try{const obj=JSON.parse(m[1]); return safeRichTextMessage(msg.chat.id,`🧾 <b>JSON Valid</b>\n<pre><code>${htmlEscape(JSON.stringify(obj,null,2))}</code></pre>`,{parse_mode:'HTML'});}catch(e){return safeRichTextMessage(msg.chat.id,`${E.cross} JSON tidak valid: <code>${htmlEscape(e.message)}</code>`,{parse_mode:'HTML'});}});
bot.onText(/^\/urlcheck(?:\s+(https?:\/\/\S+))?$/i,async(msg,m)=>{if(!m[1])return safeRichTextMessage(msg.chat.id,'🔗 Contoh: <code>/urlcheck https://example.com</code>',{parse_mode:'HTML'}); try{const u=new URL(m[1]); return safeRichTextMessage(msg.chat.id,`🔗 <b>URL Valid</b>\nHost: <code>${htmlEscape(u.hostname)}</code>\nProtocol: <code>${u.protocol.replace(':','')}</code>`,{parse_mode:'HTML'});}catch(e){return safeRichTextMessage(msg.chat.id,`${E.cross} URL tidak valid.`,{parse_mode:'HTML'});}});
bot.onText(/^\/qr(?:\s+([\s\S]+))?$/i,async(msg,m)=>{if(!m[1])return safeRichTextMessage(msg.chat.id,'📱 Contoh: <code>/qr https://example.com</code>',{parse_mode:'HTML'}); try{const QRCode=require('qrcode'); const buf=await QRCode.toBuffer(m[1],{width:600,margin:2}); return bot.sendPhoto(msg.chat.id,buf,{caption:`📱 <b>QR Code</b>\n<code>${htmlEscape(m[1].slice(0,500))}</code>`,parse_mode:'HTML'});}catch(e){return safeRichTextMessage(msg.chat.id,`${E.cross} Gagal membuat QR: <code>${htmlEscape(e.message)}</code>`,{parse_mode:'HTML'});}});
bot.onText(/^\/acak(?:\s+([\s\S]+))?$/i,async(msg,m)=>{const arr=(m[1]||'').split(',').map(x=>x.trim()).filter(Boolean); if(!arr.length)return safeRichTextMessage(msg.chat.id,'🔀 Contoh: <code>/acak merah,biru,hijau</code>',{parse_mode:'HTML'}); return safeRichTextMessage(msg.chat.id,`🔀 Pilihan acak: <b>${htmlEscape(arr[crypto.randomInt(arr.length)])}</b>`,{parse_mode:'HTML'});});
bot.onText(/^\/regex\s+([^|]+)\|\s*([\s\S]+)$/i, async(msg,m)=>{ try { const re=new RegExp(m[1].trim()); const ok=re.test(m[2]); return safeRichTextMessage(msg.chat.id,`🧪 <b>Regex Test</b>\nPattern: <code>${htmlEscape(m[1].trim())}</code>\nMatch: <b>${ok?'YA ✅':'TIDAK ❌'}</b>`,{parse_mode:'HTML'}); } catch(e){ return safeRichTextMessage(msg.chat.id,'Regex tidak valid.',{parse_mode:'HTML'}); }});
bot.onText(/^\/cleantext(?:\s+([\s\S]+))?$/i, async(msg,m)=>{ if(!m[1]) return safeRichTextMessage(msg.chat.id,'Contoh: <code>/cleantext   halo    dunia</code>',{parse_mode:'HTML'}); const out=m[1].replace(/[ \t]+/g,' ').replace(/ *\n */g,'\n').trim(); return safeRichTextMessage(msg.chat.id,`🗂️ <b>Text Cleaner</b>\n<pre>${htmlEscape(out)}</pre>`,{parse_mode:'HTML'}); });
bot.onText(/^\/percent(?:\s+(-?\d+(?:\.\d+)?)\s+(-?\d+(?:\.\d+)?)\s*)?$/i, async(msg,m)=>{ if(!m[1]) return safeRichTextMessage(msg.chat.id,'Contoh: <code>/percent 15 200</code>',{parse_mode:'HTML'}); const p=Number(m[1]),n=Number(m[2]); return safeRichTextMessage(msg.chat.id,`📊 <b>Percentage</b>\n${p}% dari ${n} = <code>${((p/100)*n).toFixed(2)}</code>`,{parse_mode:'HTML'}); });
bot.onText(/^\/convert(?:\s+(-?\d+(?:\.\d+)?)\s+(cm|m|km|kg|g|c|f)\s+(cm|m|km|kg|g|c|f))?$/i, async(msg,m)=>{ if(!m[1]) return safeRichTextMessage(msg.chat.id,'Contoh: <code>/convert 100 cm m</code>',{parse_mode:'HTML'}); const v=Number(m[1]),a=m[2].toLowerCase(),b=m[3].toLowerCase(); const len={cm:0.01,m:1,km:1000},mass={g:1,kg:1000}; let out; if(len[a]&&len[b]) out=v*len[a]/len[b]; else if(mass[a]&&mass[b]) out=v*mass[a]/mass[b]; else if(a==='c'&&b==='f') out=v*9/5+32; else if(a==='f'&&b==='c') out=(v-32)*5/9; else if(a===b) out=v; else return safeRichTextMessage(msg.chat.id,'Satuan tidak kompatibel.',{parse_mode:'HTML'}); return safeRichTextMessage(msg.chat.id,`🔄 <code>${v} ${a} = ${Number(out.toFixed(6))} ${b}</code>`,{parse_mode:'HTML'}); });

bot.onText(/^\/randomnum(?:\s+(-?\d+)\s+(-?\d+))?$/i, async (msg,m) => {
  let min = Number(m[1] ?? 1), max = Number(m[2] ?? 100);
  if (!Number.isInteger(min) || !Number.isInteger(max) || min > max || max-min > 1000000) return safeRichTextMessage(msg.chat.id,'Format: <code>/randomnum 1 100</code>',{parse_mode:'HTML'});
  return safeRichTextMessage(msg.chat.id,`🔢 <b>Random Number</b>\\nHasil: <code>${crypto.randomInt(min,max+1)}</code>`,{parse_mode:'HTML'});
});
bot.onText(/^\/hash(?:\s+(sha256|sha1|md5)\s+([\s\S]+))?$/i, async (msg,m) => {
  if (!m[1] || !m[2]) return safeRichTextMessage(msg.chat.id,'Contoh: <code>/hash sha256 halo dunia</code>',{parse_mode:'HTML'});
  const out=crypto.createHash(m[1].toLowerCase()).update(m[2],'utf8').digest('hex');
  return safeRichTextMessage(msg.chat.id,`🔐 <b>${m[1].toUpperCase()}</b>\\n<code>${out}</code>`,{parse_mode:'HTML'});
});
bot.onText(/^\/urlencode(?:\s+([\s\S]+))?$/i, async(msg,m)=>{
  if(!m[1]) return safeRichTextMessage(msg.chat.id,'Contoh: <code>/urlencode halo dunia</code>',{parse_mode:'HTML'});
  return safeRichTextMessage(msg.chat.id,`🔗 <code>${encodeURIComponent(m[1])}</code>`,{parse_mode:'HTML'});
});
bot.onText(/^\/urldecode(?:\s+([\s\S]+))?$/i, async(msg,m)=>{
  if(!m[1]) return safeRichTextMessage(msg.chat.id,'Contoh: <code>/urldecode halo%20dunia</code>',{parse_mode:'HTML'});
  try { return safeRichTextMessage(msg.chat.id,`↩️ <code>${htmlEscape(decodeURIComponent(m[1]))}</code>`,{parse_mode:'HTML'}); } catch { return safeRichTextMessage(msg.chat.id,'Format URL encoded tidak valid.',{parse_mode:'HTML'}); }
});
bot.onText(/^\/timestamp$/i, async msg=>{
  const now=Date.now();
  return safeRichTextMessage(msg.chat.id,`🕘 <b>Timestamp</b>\\nUnix ms: <code>${now}</code>\\nUnix s: <code>${Math.floor(now/1000)}</code>`,{parse_mode:'HTML'});
});
bot.onText(/^\/escapehtml(?:\s+([\s\S]+))?$/i, async(msg,m)=>{
  if(!m[1]) return safeRichTextMessage(msg.chat.id,'Contoh: <code>/escapehtml &lt;b&gt;halo&lt;/b&gt;</code>',{parse_mode:'HTML'});
  return safeRichTextMessage(msg.chat.id,`🧹 <b>Escaped</b>\\n<code>${htmlEscape(m[1])}</code>`,{parse_mode:'HTML'});
});
bot.onText(/^\/sysinfo$/i, async msg=>{
  const mem=process.memoryUsage();
  return safeRichTextMessage(msg.chat.id,`📋 <b>System Info</b>\\nNode: <code>${process.version}</code>\\nPlatform: <code>${process.platform}</code>\\nRAM: <code>${Math.round(mem.rss/1024/1024)} MB</code>\\nUptime: <code>${Math.floor(process.uptime()/60)} menit</code>`,{parse_mode:'HTML'});
});
bot.onText(/^\/zipinfo$/i, async msg=>{
  const doc=msg.reply_to_message?.document;
  if(!doc || !/\.zip$/i.test(doc.file_name||'')) return safeRichTextMessage(msg.chat.id,'Reply file <code>.zip</code> dengan <code>/zipinfo</code>.',{parse_mode:'HTML'});
  try {
    const JSZip=require('jszip');
    const link=await bot.getFileLink(doc.file_id);
    const r=await axios.get(link,{responseType:'arraybuffer',timeout:60000});
    const zip=await JSZip.loadAsync(r.data);
    const files=Object.values(zip.files).filter(x=>!x.dir);
    const dirs=Object.values(zip.files).filter(x=>x.dir);
    return safeRichTextMessage(msg.chat.id,`📦 <b>ZIP Info</b>\\nFile: <code>${htmlEscape(doc.file_name)}</code>\\nFiles: <b>${files.length}</b>\\nFolder: <b>${dirs.length}</b>\\nUkuran: <code>${Math.round(doc.file_size/1024)} KB</code>`,{parse_mode:'HTML'});
  } catch(e) { return safeRichTextMessage(msg.chat.id,`${E.cross} ZIP tidak bisa dibaca: <code>${htmlEscape(e.message)}</code>`,{parse_mode:'HTML'}); }
});

function shuffleString(s) {
  const a=String(s).split('');
  for(let i=a.length-1;i>0;i--){const j=crypto.randomInt(i+1);[a[i],a[j]]=[a[j],a[i]];}
  return a.join('');
}
const EXTRA_WORDS=['komputer','javascript','telegram','sekolah','permainan','teknologi','internet','programmer','kamera','petualangan'];
bot.onText(/^\/scramble$/i, async msg=>{
  const word=EXTRA_WORDS[crypto.randomInt(EXTRA_WORDS.length)];
  scrambleSessions.set(String(msg.chat.id),{word,startedAt:Date.now()});
  return safeRichTextMessage(msg.chat.id,`🔤 <b>Scramble</b>\\nSusun kata ini: <code>${shuffleString(word)}</code>\\nKirim jawabannya.`,{parse_mode:'HTML'});
});
bot.onText(/^\/memory$/i, async msg=>{
  const nums=[1,2,3,4].sort(()=>crypto.randomInt(3)-1);
  const answer=nums.join('');
  memoryGameSessions.set(String(msg.chat.id),{answer,expiresAt:Date.now()+60000});
  return safeRichTextMessage(msg.chat.id,`🧩 <b>Memory</b>\\nIngat urutan ini selama 3 detik:\\n<code>${answer}</code>\\n\\nSetelah itu ketik urutannya lagi.`,{parse_mode:'HTML'});
});
bot.onText(/^\/higherlower$/i, async msg=>{
  const current=crypto.randomInt(1,101);
  higherLowerSessions.set(String(msg.chat.id),{current,score:0,expiresAt:Date.now()+180000});
  return safeRichTextMessage(msg.chat.id,`📈 <b>Higher / Lower</b>\\nAngka awal: <b>${current}</b>\\nKetik <code>higher</code> atau <code>lower</code>.`,{parse_mode:'HTML'});
});
bot.onText(/^\/sequence$/i, async msg=>{
  const a=crypto.randomInt(1,10), step=crypto.randomInt(2,8);
  const seq=[a,a+step,a+step*2,a+step*3];
  const answer=seq[3]+step;
  higherLowerSessions.set(`seq:${msg.chat.id}`,{answer,expiresAt:Date.now()+120000});
  return safeRichTextMessage(msg.chat.id,`🔢 <b>Sequence</b>\\n<code>${seq.join(' , ')} , ?</code>\\n\\nKetik angka berikutnya.`,{parse_mode:'HTML'});
});
bot.onText(/^\/target24$/i, async msg=>{
  const nums=Array.from({length:4},()=>crypto.randomInt(1,10));
  return safeRichTextMessage(msg.chat.id,`🎯 <b>Target 24</b>\\nAngka: <code>${nums.join('  ')}</code>\\n\\nCoba gunakan operasi + - × ÷ untuk mencapai 24.`,{parse_mode:'HTML'});
});
bot.onText(/^\/trivia$/i, async msg=>{
  const q=QUIZ_BANK[crypto.randomInt(QUIZ_BANK.length)];
  quizSessions.set(`trivia:${msg.chat.id}`,{...q,startedAt:Date.now()});
  return safeRichTextMessage(msg.chat.id,`🧠 <b>Trivia</b>\\n${htmlEscape(q.q)}\\n\\n1. ${htmlEscape(q.o[0])}\\n2. ${htmlEscape(q.o[1])}\\n3. ${htmlEscape(q.o[2])}\\n4. ${htmlEscape(q.o[3])}\\n\\nJawab 1–4.`,{parse_mode:'HTML'});
});
bot.onText(/^\/mathrush$/i, async msg=>{
  const a=crypto.randomInt(10,50), b=crypto.randomInt(2,20), op=crypto.randomInt(2)?'+':'-';
  const answer=op==='+'?a+b:a-b;
  mathSessions.set(`rush:${msg.chat.id}`,{answer,expiresAt:Date.now()+60000});
  return safeRichTextMessage(msg.chat.id,`🧮 <b>Math Rush</b>\\n<code>${a} ${op} ${b} = ?</code>\\nJawab angka hasilnya.`,{parse_mode:'HTML'});
});
bot.onText(/^\/reaction$/i, async msg=>{
  const key=String(msg.chat.id), token=crypto.randomBytes(4).toString('hex');
  reactionSessions.set(key,{token,createdAt:Date.now()});
  setTimeout(()=>reactionSessions.delete(key),30000);
  setTimeout(()=>safeRichTextMessage(msg.chat.id,'⚡ <b>SIAP...</b>\\nTekan tombol setelah sinyal muncul.',{parse_mode:'HTML'}).then(m=>{
    setTimeout(()=>bot.editMessageText('⚡ <b>GO!</b>',{chat_id:msg.chat.id,message_id:m.message_id,parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'TEKAN!',callback_data:`reaction_${key}_${token}` }]]}}).catch(()=>{}),crypto.randomInt(1500,5000));
  }).catch(()=>{}),500);
});
bot.onText(/^\/duel$/i, async msg=>{
  if(msg.chat.type==='private') return safeRichTextMessage(msg.chat.id,'⚔️ Duel multiplayer dijalankan di grup. Buat duel dengan <code>/duel</code>.',{parse_mode:'HTML'});
  const key=String(msg.chat.id);
  if(duelSessions.has(key)) return safeRichTextMessage(msg.chat.id,'Duel sedang menunggu pemain kedua.',{parse_mode:'HTML'});
  duelSessions.set(key,{host:{id:msg.from.id,name:playerName(msg.from)},players:[]});
  return safeRichTextMessage(msg.chat.id,`⚔️ <b>DUEL</b>\\nHost: <b>${htmlEscape(playerName(msg.from))}</b>\\nPemain kedua tekan Join.`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'⚔️ Join Duel',callback_data:`duel_join_${msg.chat.id}` }]]}});
});

bot.onText(/^\/slug(?:\s+([\s\S]+))?$/i,async(msg,m)=>{ const input=String(m[1]||'').trim(); if(!input)return safeRichTextMessage(msg.chat.id,'🧹 Contoh: <code>/slug Halo Dunia 2026</code>',{parse_mode:'HTML'}); const out=input.normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,''); return safeRichTextMessage(msg.chat.id,`🧹 <b>Slugify</b>\n<code>${htmlEscape(out||'kosong')}</code>`,{parse_mode:'HTML'}); });
bot.onText(/^\/reverse(?:\s+([\s\S]+))?$/i,async(msg,m)=>{ const input=String(m[1]||''); if(!input)return safeRichTextMessage(msg.chat.id,'🔁 Contoh: <code>/reverse Halo Dunia</code>',{parse_mode:'HTML'}); const out=Array.from(input).reverse().join(''); return safeRichTextMessage(msg.chat.id,`🔁 <b>Reverse</b>\n<code>${htmlEscape(out)}</code>`,{parse_mode:'HTML'}); });
bot.onText(/^\/textstats(?:\s+([\s\S]+))?$/i,async(msg,m)=>{ const input=String(m[1]||''); if(!input)return safeRichTextMessage(msg.chat.id,'📐 Contoh: <code>/textstats Halo dunia</code>',{parse_mode:'HTML'}); const chars=Array.from(input).length, words=input.trim()?input.trim().split(/\s+/).length:0, lines=input.split(/\r?\n/).length, digits=(input.match(/\d/g)||[]).length; return safeRichTextMessage(msg.chat.id,`📐 <b>TEXT STATS</b>\n\nKarakter: <b>${chars}</b>\nKata: <b>${words}</b>\nBaris: <b>${lines}</b>\nAngka: <b>${digits}</b>`,{parse_mode:'HTML'}); });

bot.onText(/^\/dadu$/i,async msg=>safeRichTextMessage(msg.chat.id,`🎲 Hasil dadu: <b>${crypto.randomInt(1,7)}</b>`,{parse_mode:'HTML'}));
bot.onText(/^\/koin$/i,async msg=>safeRichTextMessage(msg.chat.id,`🪙 Koin: <b>${crypto.randomInt(2)?'HEADS':'TAILS'}</b>`,{parse_mode:'HTML'}));
bot.onText(/^\/8ball(?:\s+([\s\S]+))?$/i,async(msg,m)=>safeRichTextMessage(msg.chat.id,`🎱 <b>Magic 8 Ball</b>\nPertanyaan: ${htmlEscape(m[1]||'—')}\nJawaban: <b>${FUN_8BALL[crypto.randomInt(FUN_8BALL.length)]}</b>`,{parse_mode:'HTML'}));
bot.onText(/^\/rps(?:\s+(batu|gunting|kertas))?$/i,async(msg,m)=>{const choices=['batu','gunting','kertas']; if(!m[1])return safeRichTextMessage(msg.chat.id,'✊ Contoh: <code>/rps batu</code>',{parse_mode:'HTML'}); const you=m[1], botc=choices[crypto.randomInt(3)]; const win=(you==='batu'&&botc==='gunting')||(you==='gunting'&&botc==='kertas')||(you==='kertas'&&botc==='batu'); const res=you===botc?'Seri!':win?'Kamu menang!':'Bot menang!'; return safeRichTextMessage(msg.chat.id,`✊ <b>Suit</b>\nKamu: <code>${you}</code>\nBot: <code>${botc}</code>\n\n<b>${res}</b>`,{parse_mode:'HTML'});});
bot.onText(/^\/quiz$/i,async msg=>{const q=QUIZ_BANK[crypto.randomInt(QUIZ_BANK.length)]; quizSessions.set(msg.chat.id,{...q,startedAt:Date.now()}); return safeRichTextMessage(msg.chat.id,`🧠 <b>Quiz</b>\n\n${htmlEscape(q.q)}\n\n1️⃣ ${htmlEscape(q.o[0])}\n2️⃣ ${htmlEscape(q.o[1])}\n3️⃣ ${htmlEscape(q.o[2])}\n4️⃣ ${htmlEscape(q.o[3])}\n\nJawab dengan <code>1</code> sampai <code>4</code>.`,{parse_mode:'HTML'});});
bot.onText(/^\/matematika$/i,async msg=>{const a=crypto.randomInt(2,20),b=crypto.randomInt(2,20),ops=['+','-','*']; const op=ops[crypto.randomInt(ops.length)]; const ans=op==='+'?a+b:op==='-'?a-b:a*b; mathSessions.set(msg.chat.id,{answer:ans,startedAt:Date.now()}); return safeRichTextMessage(msg.chat.id,`➗ <b>Soal Matematika</b>\n\n<code>${a} ${op} ${b} = ?</code>\n\nKirim jawabannya.`,{parse_mode:'HTML'});});
bot.onText(/^\/ramalan(?:\s+(.+))?$/i,async(msg,m)=>safeRichTextMessage(msg.chat.id,`🔮 <b>Ramalan Hiburan</b>\nNama: <code>${htmlEscape(m[1]||'Kamu')}</code>\n\n${htmlEscape(MASA_DEPAN_LIST[crypto.randomInt(MASA_DEPAN_LIST.length)])}\n\n<i>Hanya untuk hiburan.</i>`,{parse_mode:'HTML'}));
bot.onText(/^\/aicode(?:\s+(fix|clean|analyze))?$/i,async(msg,m)=>{ const action=(m[1]||'analyze').toLowerCase(); const code=await extractCodeFromReply(msg).catch(()=>null); if(!code)return safeRichTextMessage(msg.chat.id,'🛠️ <b>AI Code Studio</b>\nReply pesan kode lalu gunakan <code>/aicode analyze</code>, <code>/aicode clean</code>, atau <code>/aicode fix</code>.',{parse_mode:'HTML'}); let out=''; if(action==='fix') out=_pureFixCode(code,'js'); else if(action==='clean') out=_pureCleanCode(code); else out=_detectCodeIssues(code); return safeRichTextMessage(msg.chat.id,`🛠️ <b>AI Code Studio — ${action.toUpperCase()}</b>\n<pre><code class="language-javascript">${htmlEscape(String(out).slice(0,12000))}</code></pre>`,{parse_mode:'HTML'}); });

// ======================================= //
// 📡 MESSAGE HANDLER (AI + Antilink + Antiforward + Welcome + Connect + Tesfunc)
// ======================================= //
// ======================================= //
// 🎮 MENU FUN — GAME
// ======================================= //
const TEBAK_KATA_BANK = [
  { word: 'kucing', hint: 'Hewan peliharaan yang suka bilang "meong"' },
  { word: 'komputer', hint: 'Alat elektronik untuk mengetik & browsing' },
  { word: 'indonesia', hint: 'Negara kepulauan terbesar di dunia' },
  { word: 'matahari', hint: 'Pusat tata surya, sumber cahaya siang hari' },
  { word: 'sepakbola', hint: 'Olahraga 11 lawan 11 pakai bola bundar' },
  { word: 'gunung', hint: 'Dataran tinggi yang bisa didaki, ada puncaknya' },
  { word: 'telegram', hint: 'Aplikasi chat tempat bot ini berjalan' },
  { word: 'developer', hint: 'Orang yang membuat/membangun program' },
  { word: 'bulan', hint: 'Satelit alami bumi, muncul di malam hari' },
  { word: 'internet', hint: 'Jaringan global penghubung seluruh komputer di dunia' }
];

bot.onText(/^\/hangman$/i, async (msg)=>{ const words=[['TELEGRAM','Platform chat'],['JAVASCRIPT','Bahasa pemrograman'],['KAMERA','Alat foto'],['KOMPUTER','Perangkat kerja'],['SEKOLAH','Tempat belajar']]; const pick=words[crypto.randomInt(words.length)]; if(!global.__hangmanSessions)global.__hangmanSessions=new Map(); global.__hangmanSessions.set(String(msg.chat.id),{word:pick[0],hint:pick[1],guessed:new Set(),startedAt:Date.now()}); setTimeout(()=>{ const h=global.__hangmanSessions?.get(String(msg.chat.id)); if(h && Date.now()-h.startedAt>=10*60*1000) global.__hangmanSessions.delete(String(msg.chat.id)); },10*60*1000); return safeRichTextMessage(msg.chat.id,`🧩 <b>HANGMAN DIMULAI</b>\n\nHint: <i>${htmlEscape(pick[1])}</i>\nKata: <code>${pick[0].replace(/[A-Z]/g,'•').split('').join(' ')}</code>\n\nKirim satu huruf.`,{parse_mode:'HTML',reply_markup:menuFunKeyboard(3)}); });
bot.onText(/^\/hangmanstop$/i, async(msg)=>{ if(!global.__hangmanSessions?.has(String(msg.chat.id)))return safeRichTextMessage(msg.chat.id,'🧩 Tidak ada game Hangman aktif.'); global.__hangmanSessions.delete(String(msg.chat.id)); return safeRichTextMessage(msg.chat.id,'🛑 Hangman dihentikan.'); });

bot.onText(/^\/game$/i, async (msg) => {
  return safeRichTextMessage(msg.chat.id, menuFunText(), { parse_mode: 'HTML', reply_markup: menuFunKeyboard() });
});

// ------- /tebakkata — Mulai game tebak kata -------
bot.onText(/^\/tebakkata$/i, async (msg) => {
  const chatId = msg.chat.id;
  if (tebakKataSessions.has(chatId)) {
    const s = tebakKataSessions.get(chatId);
    return safeRichTextMessage(chatId,
      `${E.warning} <b>Masih ada game berjalan!</b>\n\n` +
      `<blockquote>${E.eyes} Hint: ${htmlEscape(s.hint)}\n` +
      `Jawab langsung di chat, atau ketik /nyerah untuk menyerah.</blockquote>`,
      { parse_mode: 'HTML' });
  }
  const pick = TEBAK_KATA_BANK[Math.floor(Math.random() * TEBAK_KATA_BANK.length)];
  tebakKataSessions.set(chatId, { word: pick.word, hint: pick.hint, startedBy: msg.from.id, startedAt: Date.now() });
  return safeRichTextMessage(chatId,
    `${E.sticker} <b>Tebak Kata Dimulai!</b>\n\n` +
    `<blockquote>${E.eyes} Hint: <b>${htmlEscape(pick.hint)}</b>\n` +
    `Panjang kata: <code>${pick.word.length} huruf</code>\n\n` +
    `Ketik jawabanmu langsung di chat.\nKetik /nyerah untuk menyerah.</blockquote>`,
    { parse_mode: 'HTML' });
});

// ------- /nyerah — Menyerah dari game tebak kata -------
bot.onText(/^\/nyerah$/i, async (msg) => {
  const chatId = msg.chat.id;
  const s = tebakKataSessions.get(chatId);
  if (!s) return safeRichTextMessage(chatId, `${E.cross} Tidak ada game Tebak Kata yang sedang berjalan.`, { parse_mode: 'HTML' });
  tebakKataSessions.delete(chatId);
  const answer = s.numberGame ? String(s.target) : s.word;
  return safeRichTextMessage(chatId,
    `${E.cross} <b>Game dihentikan!</b>\n\nJawaban yang benar: <code>${htmlEscape(answer)}</code>\n\n<blockquote>Ketik /tebakkata atau /tebakangka untuk main lagi.</blockquote>`,
    { parse_mode: 'HTML' });
});

// ------- /tebakangka — Tebak angka 1-100 -------
bot.onText(/^\/tebakangka$/i, async (msg) => {
  const chatId = msg.chat.id;
  const target = Math.floor(Math.random() * 100) + 1;
  tebakKataSessions.set(chatId, { word: null, numberGame: true, target, tries: 0, maxTries: 7, startedBy: msg.from.id, startedAt: Date.now() });
  return safeRichTextMessage(chatId,
    `${E.flash} <b>Tebak Angka Dimulai!</b>\n\n` +
    `<blockquote>Aku sudah pilih angka antara <b>1-100</b>.\n` +
    `Kamu punya <b>7 kali</b> percobaan. Ketik angkamu di chat!\nKetik /nyerah untuk menyerah.</blockquote>`,
    { parse_mode: 'HTML' });
});

bot.on('message', async (msg) => {
  if (!msg.from || !msg.chat) return;
  const uid = String(msg.from.id);
  upsertUser(msg.from);
  upsertChat(msg.chat);

  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const text = msg.text || msg.caption || '';
  const isGroup = msg.chat.type !== 'private';

  if (isGroup) {
    const allowedByForceSub = await enforceForceSubscribe(msg);
    if (!allowedByForceSub) return;

    // Enhanced visual safety: AI inspects photos, videos, animations and
    // visual documents when Anti 18+ or Anti Drugs is enabled. AntiAdmin decides
    // whether admin/creator content is exempt from this moderation pass.
    const safetySettings = getGroupSettings(chatId);
    const moderationExempt = await isGroupModerationExempt(chatId, userId);
    if (!moderationExempt && !msg.is_automatic_forward) {
      const safetyCategory = await runEnhancedGroupMediaSafety(msg, safetySettings, userId);
      if (safetyCategory) {
        try { await bot.deleteMessage(chatId, msg.message_id); } catch {}
        const mention = msg.from.username
          ? `@${htmlEscape(msg.from.username)}`
          : `<a href="tg://user?id=${userId}">${htmlEscape(msg.from.first_name || 'Member')}</a>`;
        const strike = registerModerationStrike(chatId, userId, safetyCategory);
        await applyModerationAction(chatId, userId, strike, safetyCategory, mention, msg.message_id);
        return;
      }
    }
  }

  // ---- TESFUNC: TERIMA INPUT LOOP|SLEEP ----
  // Sesi dibuat setelah function lolos validasi. Sebelumnya tidak ada handler
  // yang membaca pesan berikutnya, sehingga input seperti `1|100` terlihat
  // benar tetapi tidak pernah memanggil runTesfunc().
  if (pendingTesfunc.has(`${chatId}:${userId}`) && text && !text.startsWith('/')) {
    const key = `${chatId}:${userId}`;
    const session = pendingTesfunc.get(key);
    const input = text.trim();

    // Terima `1|100`, `1 | 100`, dan variasi spasi di sekeliling |.
    const match = input.match(/^(\d+)\s*\|\s*(\d+)$/);
    if (!match) {
      return safeRichTextMessage(chatId,
        `${E.warning} <b>Format loop &amp; sleep belum benar.</b>\n\n` +
        `<blockquote>Gunakan tepat seperti ini:\n` +
        `<code>1|100</code> = 1x loop, 100ms sleep\n` +
        `<code>5|700</code> = 5x loop, 700ms sleep\n\n` +
        `Boleh pakai spasi: <code>5 | 700</code>.\n` +
        `Jangan pakai <code>/</code>, koma, atau teks tambahan.</blockquote>`,
        { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
    }

    const loop = Number(match[1]);
    const sleep = Number(match[2]);

    // Batas ini hanya untuk mencegah input typo menghasilkan loop/sleep
    // ekstrem yang dapat menggantung proses bot. Alur function lainnya tidak
    // disentuh. Nilai normal seperti 1|100, 50|700, dan 100|3000 tetap valid.
    if (!Number.isSafeInteger(loop) || loop < 1 || loop > 1000) {
      return safeRichTextMessage(chatId,
        `${E.cross} <b>Jumlah loop tidak valid.</b>\n\n` +
        `Masukkan loop <b>1–1000</b>. Contoh: <code>5|700</code>.`,
        { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
    }
    if (!Number.isSafeInteger(sleep) || sleep < 100 || sleep > 60000) {
      return safeRichTextMessage(chatId,
        `${E.cross} <b>Nilai sleep tidak valid.</b>\n\n` +
        `Masukkan sleep <b>100–60000 ms</b>. Contoh: <code>5|700</code>.\n` +
        `700 berarti jeda 700 milidetik di setiap loop.`,
        { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
    }

    pendingTesfunc.delete(key);
    await safeRichTextMessage(chatId,
      `${E.check} <b>Pengaturan Tesfunc diterima!</b>\n\n` +
      `Target: <code>${htmlEscape(session.targetNumber)}</code>\n` +
      `Loop: <code>${loop}x</code>\n` +
      `Sleep: <code>${sleep}ms</code>\n\n` +
      `<blockquote>Function akan dijalankan sekarang. Jangan kirim input loop|sleep lain sampai proses selesai.</blockquote>`,
      { parse_mode: 'HTML', reply_to_message_id: msg.message_id });

    return runTesfunc(chatId, msg.from, session.targetNumber, session.code, loop, sleep);
  }

  // ---- PHOTO LIVE / MOTION PHOTO ----
  // IMPORTANT: use the current user's id. The old code referenced `uid`, which
  // was not defined in this listener and caused the entire flow to stop when a
  // video arrived. Accept normal Telegram videos and video files sent as
  // documents as well.
  const liveFlow = pendingLivePhoto.get(String(userId));
  const liveMedia = msg.video ||
    (msg.document && /^video\//i.test(String(msg.document.mime_type || '')) ? msg.document : null) ||
    (msg.video_note ? msg.video_note : null);
  if (liveFlow && liveFlow.chatId === chatId && liveMedia) {
    pendingLivePhoto.delete(String(userId));
    if (Date.now() - liveFlow.createdAt > 10 * 60 * 1000) {
      return safeRichTextMessage(chatId,'⏱️ <b>Sesi Photo Live sudah kedaluwarsa.</b>\n\nBuka menu Photo Live lalu pilih format lagi.',{parse_mode:'HTML'});
    }

    const durationHint = Number(liveMedia.duration || 0);
    if (durationHint > 20.05) {
      return safeRichTextMessage(chatId,`❌ <b>Video terlalu panjang.</b>\n\nDurasi terdeteksi: <code>${durationHint.toFixed(2)}s</code>\nMaksimal input: <b>20 detik</b>. Hasil: <b>5 detik</b>.`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🔄 Coba Lagi',callback_data:'live_photo_menu'}]]}});
    }

    const loading = await safeRichTextMessage(chatId,
      `${E.hourglass} <b>PHOTO LIVE PROCESSING</b>\n\n` +
      `📥 Mengunduh video...\n<code>${makeBar(15)}</code>`,
      {parse_mode:'HTML',reply_to_message_id:msg.message_id});

    try {
      const fileId = liveMedia.file_id;
      if (!fileId) throw new Error('File video tidak memiliki file_id Telegram.');
      if (Number(liveMedia.file_size || 0) > 20 * 1024 * 1024) {
        throw new Error('Ukuran video lebih dari 20 MB. Bot API standar saat ini membatasi download bot hingga 20 MB. Kirim video yang lebih kecil atau gunakan Local Bot API Server.');
      }
      const link = await bot.getFileLink(fileId);
      const res = await axios.get(link,{responseType:'arraybuffer',timeout:120000,maxContentLength:25*1024*1024,maxBodyLength:25*1024*1024});
      const buffer = Buffer.from(res.data);
      if (!buffer.length) throw new Error('Video kosong.');
      if (buffer.length > 20 * 1024 * 1024) throw new Error('Video melewati batas download Bot API 20 MB.');

      await safeEdit(bot,chatId,loading.message_id,
        `${E.hourglass} <b>PHOTO LIVE PROCESSING</b>\n\n` +
        `🖼️ Membuat frame utama...\n<code>${makeBar(40)}</code>`,{parse_mode:'HTML'}).catch(()=>{});

      const result = liveFlow.mode === 'apple'
        ? await createAppleLivePhotoBundle(buffer,liveMedia.file_name || 'video.mp4')
        : await createAndroidMotionPhoto(buffer,liveMedia.file_name || 'video.mp4');

      await safeEdit(bot,chatId,loading.message_id,
        `${E.hourglass} <b>PHOTO LIVE PROCESSING</b>\n\n` +
        `✨ Menyusun format...\n<code>${makeBar(80)}</code>`,{parse_mode:'HTML'}).catch(()=>{});

      if (liveFlow.mode === 'apple') {
        // Prefer Telegram's native Live Photo transport. If the installed
        // Bot API/client rejects it, fall back to the portable JPEG/MOV bundle
        // so the user still receives a usable result instead of a silent stop.
        try {
          await sendTelegramLivePhoto(chatId, result.jpeg, result.mov, {
            caption:'🍎 <b>APPLE LIVE PHOTO</b>\n\n✨ Berhasil dibuat dari video kamu.\n⏱️ Maksimal 5 detik.',
            parse_mode:'HTML',
            reply_parameters:{message_id:msg.message_id}
          });
        } catch (nativeErr) {
          console.warn('[PHOTO LIVE] native sendLivePhoto failed:', nativeErr?.message || nativeErr);
          await bot.sendDocument(chatId,result.bundle,{caption:'🍎 <b>APPLE LIVE PHOTO</b>\n\nNative Live Photo Telegram tidak tersedia/ditolak, jadi bot mengirim bundle JPEG + MOV yang sudah dipasangkan dengan asset identifier.',parse_mode:'HTML',reply_to_message_id:msg.message_id},{filename:result.filename,contentType:'application/zip'});
        }
        // Also keep the portable source assets available for Apple import tools.
        await bot.sendDocument(chatId,result.mov,{caption:'🎞️ <b>Paired MOV</b> — asset video Live Photo',parse_mode:'HTML'},{filename:'live-photo.mov',contentType:'video/quicktime'});
      } else {
        await bot.sendDocument(chatId,result.motion,{caption:'🤖 <b>ANDROID MOTION PHOTO</b>\n\nJPEG berisi foto utama + video pendek + metadata Motion Photo.',parse_mode:'HTML',reply_to_message_id:msg.message_id},{filename:result.filename,contentType:'image/jpeg'});
      }

      notifyMainChannelActivity('photo_live', msg.from, {
        title: `PHOTO LIVE ACTIVITY`,
        emoji: liveFlow.mode === 'apple' ? E.image : E.video,
        action: liveFlow.mode === 'apple' ? 'Apple Live Photo' : 'Android Motion Photo',
        fields: {
          'Durasi sumber': `${Number(result.duration).toFixed(2)} detik`,
          'Format': liveFlow.mode === 'apple' ? 'Apple Live Photo' : 'Android Motion Photo',
          'Chat ID': String(chatId)
        }
      }).catch(() => {});

      await safeEdit(bot,chatId,loading.message_id,
        `✅ <b>PHOTO LIVE SELESAI</b>\n\n` +
        `${liveFlow.mode === 'apple' ? '🍎 Apple Live Photo' : '🤖 Android Motion Photo'}\n` +
        `⏱️ Durasi sumber: <code>${Number(result.duration).toFixed(2)}s</code>\n` +
        `✨ Hasil berhasil dibuat tanpa API pihak ketiga.`,
        {parse_mode:'HTML',reply_markup:{inline_keyboard:[
          [{text:'🔄 Buat Lagi',callback_data:'live_photo_menu',style:'success'}],
          [{text:'🧰 Tools',callback_data:'menu_alat'}]
        ]}}).catch(()=>{});
    } catch (e) {
      console.error('[PHOTO LIVE ERROR]', e?.stack || e);
      await safeEdit(bot,chatId,
        `❌ <b>Photo Live gagal diproses.</b>\n\n<code>${htmlEscape(e.message || 'Unknown error')}</code>\n\n` +
        `<i>Pastikan video valid, maksimal 20 detik, ukuran file sesuai batas download Bot API, dan format video valid.</i>`,
        {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🔄 Coba Lagi',callback_data:'live_photo_menu',style:'success'}],[{text:'🧰 Tools',callback_data:'menu_alat'}]]}}).catch(()=>{});
    }
    return;
  }

  // ---- OSINT GENERIC API FLOW ----
  const osintFlow = pendingOsint.get(uid);
  if (osintFlow && osintFlow.chatId === chatId && msg.text && !msg.text.startsWith('/')) {
    pendingOsint.delete(uid);
    if (Date.now() - osintFlow.createdAt > 10 * 60 * 1000) {
      return safeRichTextMessage(chatId,'⏱️ <b>Sesi OSINT kedaluwarsa.</b>\n\nBuka Tools → OSINT untuk memulai lagi.',{parse_mode:'HTML'});
    }
    const query = msg.text.trim();
    if (query.length < 2 || query.length > 300) {
      return safeRichTextMessage(chatId,'❌ Query OSINT harus berisi 2–300 karakter.',{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🔎 OSINT',callback_data:'osint_menu'}]]}});
    }
    const loading = await safeRichTextMessage(chatId,`${E.hourglass} <b>OSINT</b>\n\n🔎 Mencari informasi publik...\n<code>${makeBar(35)}</code>`,{parse_mode:'HTML',reply_to_message_id:msg.message_id});
    try {
      const result = await runOsintQuery(query);
      await safeEdit(bot,chatId,loading.message_id,
        `<blockquote>🔎 <b>OSINT RESULT</b></blockquote>\n\n` +
        `<b>Query:</b> <code>${htmlEscape(query)}</code>\n\n` +
        `<pre>${htmlEscape(result.slice(0,10000))}</pre>\n\n` +
        `<i>Hasil berasal dari provider OSINT yang dikonfigurasi. Verifikasi kembali data sebelum digunakan.</i>`,
        {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🔄 Cari Lagi',callback_data:'osint_menu',style:'primary'}],[{text:'🧰 Tools',callback_data:'menu_alat'}]]}}).catch(()=>{});
    } catch (e) {
      await safeEdit(bot,chatId,loading.message_id,`❌ <b>OSINT gagal.</b>\n\n<code>${htmlEscape(e.message || 'Provider error')}</code>`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🔄 Coba Lagi',callback_data:'osint_menu'}],[{text:'🧰 Tools',callback_data:'menu_alat'}]]}}).catch(()=>{});
    }
    return;
  }

  // ---- FORCE SUBSCRIBE SETUP FLOW ----
  const uidKey = String(userId);
  if (pendingForceSub.has(uidKey)) {
    const flow = pendingForceSub.get(uidKey);
    if (flow.chatId === chatId && text && !text.startsWith('/')) {
      pendingForceSub.delete(uidKey);
      const raws = String(text).split(/\r?\n|\s*,\s*/).map(v => v.trim()).filter(Boolean).slice(0, 7);
      if (!raws.length) return safeRichSendMessage(chatId, 'Channel belum dikirim.', {parse_mode:'HTML'});
      if (!(await isGroupAdmin(chatId,userId))) return safeRichSendMessage(chatId,'Hanya admin grup yang boleh mengatur Force Subscribe.',{parse_mode:'HTML'});
      try {
        const groupBotState = await getForceSubBotState(chatId);
        if (!groupBotState.ok) {
          return safeRichSendMessage(chatId, `<b>Force Subscribe belum siap</b>\n\n${groupBotState.reason}\n\nAktifkan izin <b>Delete Messages</b> pada bot di grup.`, {parse_mode:'HTML'});
        }
        const me = await bot.getMe();
        const validated = [];
        for (const raw of raws) {
          const target = parseChannelTarget(raw);
          if (!target) throw new Error(`Format channel tidak valid: ${raw}`);
          const channelInfo = await bot.getChat(target.channel);
          if (channelInfo.type !== 'channel') throw new Error(`${raw} bukan channel Telegram.`);
          const botMember = await bot.getChatMember(target.channel, me.id);
          if (!['administrator','creator'].includes(botMember.status)) {
            throw new Error(`Bot belum menjadi admin di ${raw}.`);
          }
          validated.push({ channel: target.channel, invite: target.invite, title: channelInfo.title || target.channel });
        }
        const unique = [];
        const seen = new Set();
        for (const ch of validated) {
          if (seen.has(ch.channel)) continue;
          seen.add(ch.channel); unique.push(ch);
        }
        if (!unique.length) throw new Error('Tidak ada channel valid.');
        const gs = getGroupSettings(chatId);
        setGroupSettings(chatId,{...gs,forceSubscribe:{enabled:true,channels:unique,channel:unique[0].channel,invite:unique[0].invite,title:unique[0].title}});
        return safeRichSendMessage(chatId,
          `<b>Force Subscribe aktif</b>\n\n` +
          `Channel wajib: <b>${unique.length}/7</b>\n` +
          unique.map((ch,i)=>`${i+1}. ${htmlEscape(ch.title)} — <code>${htmlEscape(ch.channel)}</code>`).join('\n') +
          `\n\nMember harus join semua channel. Pesan yang dikirim sebelum join akan dihapus.`,
          {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'Kelola Force Subscribe',callback_data:'group_forcesub'}],[{text:'Menu Grup',callback_data:'menu_group'}]]}});
      } catch(e) {
        return safeRichSendMessage(chatId, `<b>Gagal mengatur Force Subscribe</b>\n<code>${htmlEscape(e.message || 'unknown error')}</code>\n\nPastikan bot admin di semua channel yang dikirim.`, {parse_mode:'HTML'});
      }
    }
  }

  // ---- MEDIAFIRE UPLOAD FLOW ----
  const mediaFlow = pendingMediaFire.get(uidKey);
  if (mediaFlow && mediaFlow.chatId === chatId && msg.chat.type === 'private') {
    const media = msg.document || msg.video || msg.audio || msg.voice || msg.animation || (msg.photo?.length ? msg.photo[msg.photo.length - 1] : null);
    const fileId = media?.file_id;
    if (fileId) {
      pendingMediaFire.delete(uidKey);
      const rawName = media.file_name || (msg.document?.file_name) ||
        (msg.video ? `video_${Date.now()}.mp4` : msg.audio ? `audio_${Date.now()}.mp3` : msg.photo ? `photo_${Date.now()}.jpg` : `file_${Date.now()}`);
      const filename = String(rawName).replace(/[^a-zA-Z0-9._()\- ]/g,'_').slice(0,180) || `file_${Date.now()}`;
      const loading = await safeRichTextMessage(chatId, `<code>${makeBar(15)}</code>\nMengambil file dari Telegram...`, {parse_mode:'HTML',reply_to_message_id:msg.message_id});
      try {
        const link = await bot.getFileLink(fileId);
        await safeEdit(bot,chatId,loading.message_id,`<code>${makeBar(35)}</code>\nMengunduh <b>${htmlEscape(filename)}</b>...`,{parse_mode:'HTML'});
        const res = await axios.get(link,{responseType:'arraybuffer',timeout:5*60*1000,maxContentLength:50*1024*1024,maxBodyLength:50*1024*1024});
        const buffer = Buffer.from(res.data);
        if (!buffer.length) throw new Error('File kosong.');
        if (!mediaFireReady()) throw new Error(`MediaFire belum dikonfigurasi: ${mediaFireConfigNames().join(', ')}`);
        await safeEdit(bot,chatId,loading.message_id,`<code>${makeBar(60)}</code>\nMengupload ke MediaFire...\nFile: <b>${htmlEscape(filename)}</b>`,{parse_mode:'HTML'});
        const result = await uploadToMediaFire(buffer,filename);
        await safeDelete(bot,chatId,loading.message_id);
        return safeRichTextMessage(chatId,
          `<blockquote><b>MEDIAFIRE BERHASIL</b></blockquote>\n\n` +
          `<b>File:</b> <code>${htmlEscape(filename)}</code>\n` +
          `<b>Ukuran:</b> <code>${(buffer.length/1024/1024).toFixed(2)} MB</code>\n` +
          `<b>Quick Key:</b> <code>${htmlEscape(result.quickKey)}</code>\n\n` +
          `<i>Link MediaFire:</i>\n<code>${htmlEscape(result.url)}</code>`,
          {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'Buka MediaFire',url:result.url}],[{text:'Upload Lagi',callback_data:'mediafire_menu'}],[{text:'Menu Tools',callback_data:'menu_alat'}]]}});
      } catch (e) {
        return safeEdit(bot,chatId,loading.message_id,`<blockquote><b>MEDIAFIRE GAGAL</b></blockquote>\n\n<code>${htmlEscape(e.message || 'Upload gagal')}</code>\n\n<i>Jika file besar, periksa batas Telegram Bot API/server dan koneksi MediaFire.</i>`,{parse_mode:'HTML'});
      }
    }
  }

  // ---- CHANNEL MONITOR SETUP FLOW ----
  const monitorFlow = pendingChannelMonitor.get(uidKey);
  if (monitorFlow && monitorFlow.chatId === chatId && msg.chat.type === 'private' && text && !text.startsWith('/')) {
    const raw = String(text).trim();
    try {
      if (Date.now() - Number(monitorFlow.createdAt || 0) > 10 * 60 * 1000) {
        pendingChannelMonitor.delete(uidKey);
        return safeRichTextMessage(chatId,'Sesi Monitoring Channel kedaluwarsa. Tekan Tambah / Set Channel lagi.',{parse_mode:'HTML'});
      }
      const target = parseChannelTarget(raw);
      if (!target) return safeRichTextMessage(chatId,'Format channel tidak valid. Gunakan <code>@username</code> atau <code>-100...</code>.',{parse_mode:'HTML'});
      const info = await bot.getChat(target.channel);
      if (info.type !== 'channel') return safeRichTextMessage(chatId,'Target harus berupa channel Telegram.',{parse_mode:'HTML'});
      const access = await canManageMonitoredChannel(target.channel, userId);
      if (!access.ok) return safeRichTextMessage(chatId,`<b>Main Channel belum siap</b>\n\n${htmlEscape(access.reason)}\n\nJadikan bot admin di channel tersebut, lalu kirim ulang.`,{parse_mode:'HTML'});

      if (monitorFlow.step === 'source') {
        pendingChannelMonitor.set(uidKey,{...monitorFlow,step:'output',source:{channelId:String(target.channel),title:info.title || target.channel,username:info.username || '',invite:target.invite || ''}});
        return safeRichTextMessage(chatId,
          `<blockquote><b>LANGKAH 2/2 — CHANNEL MONITORING</b></blockquote>\n\n` +
          `Main Channel: <b>${htmlEscape(info.title || target.channel)}</b>\n\n` +
          `Sekarang kirim <b>@username</b> atau <b>ID -100...</b> dari channel tempat bot harus mengirim notifikasi member masuk/keluar.\n\n` +
          `Contoh: <code>@allinformation</code> atau <code>-1009876543210</code>\n\n` +
          `<i>Bot dan kamu juga harus admin di channel monitoring.</i>`,
          {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'Batal',callback_data:'channel_monitor'}]]}});
      }

      const source = monitorFlow.source;
      if (!source?.channelId) {
        pendingChannelMonitor.delete(uidKey);
        return safeRichTextMessage(chatId,'Sesi setup tidak lengkap. Mulai lagi dari Monitoring Channel.',{parse_mode:'HTML'});
      }
      const outputAccess = await canManageMonitoredChannel(target.channel, userId);
      if (!outputAccess.ok) return safeRichTextMessage(chatId,`<b>Channel Monitoring belum siap</b>\n\n${htmlEscape(outputAccess.reason)}\n\nPastikan bot admin dan boleh posting di channel tersebut.`,{parse_mode:'HTML'});
      setChannelMonitor(source.channelId,{
        channelId:source.channelId, title:source.title, username:source.username, ownerId:userId, enabled:true, antiDrugs:true,
        outputChannelId:String(target.channel), outputTitle:info.title || target.channel, outputUsername:info.username || ''
      });
      pendingChannelMonitor.delete(uidKey);
      return safeRichTextMessage(chatId,
        `<blockquote><b>MONITORING AKTIF</b></blockquote>\n\n` +
        `<b>Main Channel</b>\n${htmlEscape(source.title)}\n<code>${htmlEscape(source.channelId)}</code>\n\n` +
        `<b>Channel Monitoring</b>\n${htmlEscape(info.title || target.channel)}\n<code>${htmlEscape(target.channel)}</code>\n\n` +
        `Output Rich Message sudah tersambung.\n\n` +
        `<b>Catatan:</b> Telegram Bot API tidak mengirim event subscriber join/leave channel secara umum, jadi kartu member otomatis tidak dapat dijamin dari bot token saja.\n\n` +
        `<i>Gunakan Tes Monitoring untuk memeriksa output. Untuk subscriber penuh diperlukan User API/MTProto atau channel dengan join-request.</i>`,
        {parse_mode:'HTML',reply_markup:channelMonitorKeyboard(getUserChannelMonitors(userId))});
    } catch (e) {
      return safeRichTextMessage(chatId,`<b>Gagal mengatur monitoring</b>\n<code>${htmlEscape(e.message || 'Telegram API error')}</code>`,{parse_mode:'HTML'});
    }
  }

  // ---- WELCOME SETUP FLOW ----
  // ---- GOODBYE SETUP FLOW ----
  const goodbyeMsgKey = `goodbye_msg:${chatId}:${userId}`;
  const goodbyePhotoKey = `goodbye_photo:${chatId}:${userId}`;
  const goodbyeFlow = pendingWelcomeSetup.get(goodbyeMsgKey) || pendingWelcomeSetup.get(goodbyePhotoKey);
  if (goodbyeFlow && goodbyeFlow.chatId === chatId && goodbyeFlow.userId === userId) {
    if (Date.now() - Number(goodbyeFlow.createdAt || 0) > 10 * 60 * 1000) { pendingWelcomeSetup.delete(goodbyeMsgKey); pendingWelcomeSetup.delete(goodbyePhotoKey); return safeRichTextMessage(chatId,'Sesi Setup Goodbye kedaluwarsa.',{parse_mode:'HTML'}); }
    if (!(await isGroupAdmin(chatId,userId))) { pendingWelcomeSetup.delete(goodbyeMsgKey); pendingWelcomeSetup.delete(goodbyePhotoKey); return safeRichTextMessage(chatId,'Hanya admin grup yang boleh mengatur Goodbye.',{parse_mode:'HTML'}); }
    if (goodbyeFlow.step === 'message' && text && !String(text).trim().startsWith('/')) {
      const message=String(text).trim().slice(0,4000); if(!message) return safeRichTextMessage(chatId,'Teks Goodbye tidak boleh kosong.',{parse_mode:'HTML'});
      pendingWelcomeSetup.delete(goodbyeMsgKey); pendingWelcomeSetup.set(goodbyePhotoKey,{step:'photo',chatId,userId,message,createdAt:Date.now(),goodbye:true});
      return safeRichTextMessage(chatId,`<blockquote><b>TEKS GOODBYE DITERIMA</b></blockquote>\n\n<blockquote>${htmlEscape(message)}</blockquote>\n\nPilih apakah ingin memakai foto.`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[ {text:'Tanpa Foto',callback_data:`goodbye_nophoto_${chatId}`} ],[ {text:'Pakai Foto',callback_data:`goodbye_photo_prompt_${chatId}`},{text:'Batal',callback_data:`goodbye_cancel_${chatId}`} ]]}});
    }
    if (goodbyeFlow.step === 'photo' && Array.isArray(msg.photo) && msg.photo.length) {
      const photo=msg.photo[msg.photo.length-1].file_id; pendingWelcomeSetup.delete(goodbyePhotoKey); const gs=getGroupSettings(chatId); setGroupSettings(chatId,{...gs,goodbye:{enabled:true,message:goodbyeFlow.message,photo}});
      return safeRichTextMessage(chatId,'<b>Goodbye aktif.</b>\n\nTeks dan foto berhasil disimpan.',{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'Status Welcome/Goodbye',callback_data:'welcome_goodbye_status'}],[{text:'Menu Grup',callback_data:'menu_group'}]]}});
    }
    if (goodbyeFlow.step === 'photo' && text && !String(text).trim().startsWith('/')) return safeRichTextMessage(chatId,'Sekarang kirim FOTO atau tekan Tanpa Foto.',{parse_mode:'HTML'});
  }

  // Handler ini sengaja berada di listener pesan utama supaya teks biasa yang
  // dikirim setelah menekan Setup Welcome tidak terlewat oleh handler lain.
  const welcomeMsgKey = `welcome_msg:${chatId}:${userId}`;
  const welcomePhotoKey = `welcome_photo:${chatId}:${userId}`;
  const welcomeFlow = pendingWelcomeSetup.get(welcomeMsgKey) || pendingWelcomeSetup.get(welcomePhotoKey);
  if (welcomeFlow && welcomeFlow.chatId === chatId && welcomeFlow.userId === userId) {
    if (Date.now() - Number(welcomeFlow.createdAt || 0) > 10 * 60 * 1000) {
      pendingWelcomeSetup.delete(welcomeMsgKey);
      pendingWelcomeSetup.delete(welcomePhotoKey);
      return safeRichTextMessage(chatId,'⏰ <b>Sesi Setup Welcome kedaluwarsa.</b> Tekan tombol <b>Setup Welcome</b> lagi.',{parse_mode:'HTML'});
    }
    if (!(await isGroupAdmin(chatId,userId))) {
      pendingWelcomeSetup.delete(welcomeMsgKey);
      pendingWelcomeSetup.delete(welcomePhotoKey);
      return safeRichTextMessage(chatId,'❌ Hanya admin grup yang boleh mengatur Welcome.',{parse_mode:'HTML'});
    }

    // Tahap 1: terima teks biasa. Jangan proses command sebagai teks welcome.
    if (welcomeFlow.step === 'message' && text && !String(text).trim().startsWith('/')) {
      const message = String(text).trim().slice(0,4000);
      if (!message) return safeRichTextMessage(chatId,'❌ Teks welcome tidak boleh kosong.',{parse_mode:'HTML'});
      pendingWelcomeSetup.delete(welcomeMsgKey);
      pendingWelcomeSetup.set(welcomePhotoKey,{step:'photo',chatId,userId,message,createdAt:Date.now()});
      return safeRichTextMessage(chatId,
        `👋 <b>TEKS WELCOME DITERIMA</b>\n\n<b>Preview:</b>\n<blockquote>${htmlEscape(message)}</blockquote>\n\nSekarang pilih:\n• <b>Tanpa Foto</b> → langsung aktif\n• <b>Pakai Foto</b> → kirim foto berikutnya`,
        {parse_mode:'HTML',reply_markup:{inline_keyboard:[
          [{text:'✅ Tanpa Foto',callback_data:`welcome_nophoto_${chatId}`}],
          [{text:'🖼️ Pakai Foto',callback_data:`welcome_photo_prompt_${chatId}`},{text:'✖️ Batal',callback_data:`welcome_cancel_${chatId}`}],
          [{text:'↩️ Menu Grup',callback_data:'menu_group'}]
        ]}});
    }

    // Tahap 2: foto opsional. Simpan file_id Telegram, tidak perlu download.
    if (welcomeFlow.step === 'photo') {
      if (Array.isArray(msg.photo) && msg.photo.length) {
        const photo = msg.photo[msg.photo.length - 1].file_id;
        pendingWelcomeSetup.delete(welcomePhotoKey);
        const gs = getGroupSettings(chatId);
        setGroupSettings(chatId,{...gs,welcome:{enabled:true,message:welcomeFlow.message,photo}});
        return safeRichTextMessage(chatId,
          `👋 <b>WELCOME AKTIF!</b>\n\n${E.check} Teks dan foto berhasil disimpan.\n\n<b>Preview teks:</b>\n<blockquote>${htmlEscape(welcomeFlow.message)}</blockquote>\n\nMember baru akan menerima welcome otomatis saat masuk.`,
          {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'📋 Status Welcome',callback_data:'welcome_status'}],[{text:'↩️ Menu Grup',callback_data:'menu_group'}]]}});
      }
      // Jangan menghapus sesi hanya karena user mengirim teks lain pada tahap foto.
      if (text && !String(text).trim().startsWith('/')) {
        return safeRichTextMessage(chatId,'🖼️ <b>Sekarang kirim FOTO</b> untuk welcome, atau tekan <b>Tanpa Foto</b>.',{parse_mode:'HTML'});
      }
    }
  }

  // ---- PROJECT TOOL FLOWS ----
  if (pendingDomainRename.has(uidKey)) {
    const flow = pendingDomainRename.get(uidKey);
    if (Date.now() - Number(flow.createdAt||0) > 10*60*1000) {
      pendingDomainRename.delete(uidKey);
      return safeRichTextMessage(chatId,'⏱️ <b>Sesi Ganti Domain/Port sudah kedaluwarsa.</b> Silakan buka fiturnya lagi.',{parse_mode:'HTML'});
    }

    // 1) ZIP upload for domain/port inspection.
    if (msg.document && (flow.step === 'zip' || flow.step === 'port_zip')) {
      const name=msg.document.file_name || 'project.zip';
      if (!/\.zip$/i.test(name)) return safeRichTextMessage(chatId,'❌ File harus berformat <code>.zip</code>.',{parse_mode:'HTML'});
      try {
        const link=await bot.getFileLink(msg.document.file_id);
        const res=await axios.get(link,{responseType:'arraybuffer',timeout:120000,maxContentLength:25*1024*1024,maxBodyLength:25*1024*1024});
        const zipBuffer=Buffer.from(res.data);
        if (flow.step === 'zip') {
          const domains=await extractDomainsFromZip(zipBuffer);
          if (!domains.length) {
            pendingDomainRename.delete(uidKey);
            return safeRichTextMessage(chatId,'⚠️ <b>DOMAIN TIDAK DITEMUKAN</b>\n\nBot tidak menemukan domain valid di dalam file teks ZIP. Pastikan ZIP berisi source/config project yang benar.',{parse_mode:'HTML',reply_markup:toolKeyboardBack()});
          }
          flow.step='olddomain'; flow.zip=zipBuffer; flow.fileName=name; flow.domains=domains; flow.createdAt=Date.now();
          pendingDomainRename.set(uidKey,flow);
          const list=domains.slice(0,40).map((d,i)=>`${i+1}. <code>${htmlEscape(d)}</code>`).join('\n');
          return safeRichTextMessage(chatId,`🌐 <b>GANTI DOMAIN — LANGKAH 2/3</b>\n\n<b>${domains.length}</b> domain/host ditemukan:\n\n${list}\n\n<hr/>\n🔎 Sekarang <b>kirim domain lama</b> yang ingin diganti.\nContoh: <code>api.oldapp.com</code>\n\n<i>Bot akan mengecek domain tersebut ke seluruh file ZIP sebelum melanjutkan.</i>`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'✖️ Batal',callback_data:'domain_cancel'}]]}});
        }

        const ports=[];
        for (const d of await extractDomainsFromZip(zipBuffer)) { const m=d.match(/:(\d+)$/); if(m) ports.push(m[1]); }
        flow.step='oldport'; flow.zip=zipBuffer; flow.fileName=name; flow.portCandidates=[...new Set(ports)]; flow.createdAt=Date.now();
        pendingDomainRename.set(uidKey,flow);
        const hint=flow.portCandidates.length ? `\nPort yang terlihat pada host: <code>${flow.portCandidates.join('</code>, <code>')}</code>` : '';
        return safeRichTextMessage(chatId,`🔌 <b>GANTI PORT PANEL — LANGKAH 1/2</b>\n\nZIP berhasil dibaca.${hint}\n\nKirim <b>port lama</b> yang ingin diganti. Contoh: <code>3000</code>`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'✖️ Batal',callback_data:'domain_cancel'}]]}});
      } catch(e) {
        const message=String(e?.message||e);
        pendingDomainRename.delete(uidKey);
        return safeRichTextMessage(chatId,`❌ <b>Gagal membaca ZIP.</b>\n\n<code>${htmlEscape(message)}</code>\n\nJika file sangat besar, Bot API Telegram dapat membatasi pengunduhan file dari bot. Gunakan ZIP yang lebih kecil atau jalankan Local Bot API.`,{parse_mode:'HTML',reply_markup:toolKeyboardBack()});
      }
    }

    // 2) User supplies the old domain. Do NOT require choosing from a button.
    if (flow.mode === 'domain' && flow.step === 'olddomain' && msg.text && !msg.text.startsWith('/')) {
      const oldDomain=msg.text.trim();
      try {
        const check=await findDomainInZip(flow.zip,oldDomain);
        if (!check.found) {
          return safeRichTextMessage(chatId,`❌ <b>DOMAIN NOT FOUND</b>\n\nDomain lama <code>${htmlEscape(oldDomain)}</code> tidak ditemukan di dalam file ZIP.\n\n💡 Pastikan penulisan domain lama <b>persis</b> sama dengan yang ada di coding/config project.`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🔄 Kirim Domain Lama Lagi',callback_data:'domain_retry_old'}],[{text:'✖️ Batal',callback_data:'domain_cancel'}]]}});
        }
        flow.selected=check.domain; flow.matches=check; flow.step='newdomain'; flow.createdAt=Date.now(); pendingDomainRename.set(uidKey,flow);
        const files=check.files.slice(0,20).map(x=>`• <code>${htmlEscape(x.name)}</code> — ${x.count}x`).join('\n');
        return safeRichTextMessage(chatId,`🔎 <b>DOMAIN LAMA DITEMUKAN</b>\n\nDomain: <code>${htmlEscape(check.domain)}</code>\nKemunculan: <b>${check.occurrences}</b>\nFile terdampak: <b>${check.files.length}</b>\n\n${files}\n\n<hr/>\n🌐 <b>LANGKAH 3/3</b>\nSekarang kirim <b>domain baru</b>.\nContoh: <code>newapp.example.com</code>\n\nJika sekaligus ingin mengganti port pada URL, gunakan: <code>newapp.example.com 8080</code>`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'✖️ Batal',callback_data:'domain_cancel'}]]}});
      } catch(e) {
        return safeRichTextMessage(chatId,`❌ <b>Gagal mengecek domain.</b>\n<code>${htmlEscape(e.message)}</code>`,{parse_mode:'HTML'});
      }
    }

    // 3) User supplies the new domain (+ optional new port).
    if (flow.mode === 'domain' && flow.step === 'newdomain' && msg.text && !msg.text.startsWith('/')) {
      const parts=msg.text.trim().split(/\s+/);
      const newDomain=parts[0]; const port=parts[1]||'';
      if (parts.length>2) return safeRichTextMessage(chatId,'❌ Format tidak valid. Gunakan <code>newapp.example.com</code> atau <code>newapp.example.com 8080</code>.',{parse_mode:'HTML'});
      if (!/^(?:https?:\/\/)?[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)+$/i.test(newDomain.replace(/^https?:\/\//i,'').replace(/\/$/,''))) return safeRichTextMessage(chatId,'❌ Domain baru tidak valid. Contoh: <code>newapp.example.com</code>.',{parse_mode:'HTML'});
      if (port && (!/^\d{1,5}$/.test(port) || Number(port)<1 || Number(port)>65535)) return safeRichTextMessage(chatId,'❌ Port baru tidak valid. Gunakan angka 1–65535.',{parse_mode:'HTML'});
      try {
        await safeRichTextMessage(chatId,`⚙️ <b>Memproses Ganti Domain...</b>\n\n<code>${htmlEscape(flow.selected)}</code> → <code>${htmlEscape(newDomain)}${port?':'+port:''}</code>\n\n<i>Bot sedang mengganti hanya kecocokan domain yang tepat pada file teks.</i>`,{parse_mode:'HTML'});
        const out=await replaceDomainInZip(flow.zip,flow.selected,newDomain,port);
        const outName=flow.fileName.replace(/\.zip$/i,'')+'-domain-updated.zip';
        pendingDomainRename.delete(uidKey);
        return bot.sendDocument(chatId,out,{caption:`✅ <b>GANTI DOMAIN SELESAI</b>\n\nLama: <code>${htmlEscape(flow.selected)}</code>\nBaru: <code>${htmlEscape(newDomain)}${port?':'+port:''}</code>\n\n📦 File hasil sudah dikirim kembali.`,parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🌐 Ganti Domain Lagi',callback_data:'tool_domain'}],[{text:'🧰 Menu Tools',callback_data:'menu_alat'}]]}},{filename:outName,contentType:'application/zip'});
      } catch(e) {
        return safeRichTextMessage(chatId,`❌ <b>Ganti Domain gagal.</b>\n<code>${htmlEscape(e.message)}</code>`,{parse_mode:'HTML'});
      }
    }

    // 4) Port panel flow.
    if (flow.mode === 'port' && flow.step === 'oldport' && msg.text && !msg.text.startsWith('/')) {
      const oldPort=msg.text.trim();
      try {
        const check=await findPortInZip(flow.zip,oldPort);
        if (!check.found) return safeRichTextMessage(chatId,`❌ <b>PORT NOT FOUND</b>\n\nPort <code>${htmlEscape(oldPort)}</code> tidak ditemukan pada URL/config port yang dikenali di ZIP.\n\nPastikan port lama benar.`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🔄 Kirim Port Lama Lagi',callback_data:'port_retry_old'}],[{text:'✖️ Batal',callback_data:'domain_cancel'}]]}});
        flow.selectedPort=oldPort; flow.portMatches=check; flow.step='newport'; flow.createdAt=Date.now(); pendingDomainRename.set(uidKey,flow);
        const files=check.files.slice(0,20).map(x=>`• <code>${htmlEscape(x.name)}</code> — ${x.count}x`).join('\n');
        return safeRichTextMessage(chatId,`🔎 <b>PORT LAMA DITEMUKAN</b>\n\nPort: <code>${htmlEscape(oldPort)}</code>\nKemunculan: <b>${check.occurrences}</b>\nFile terdampak: <b>${check.files.length}</b>\n\n${files}\n\n🔌 Sekarang kirim <b>port baru</b>. Contoh: <code>8080</code>`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'✖️ Batal',callback_data:'domain_cancel'}]]}});
      } catch(e) { return safeRichTextMessage(chatId,`❌ <b>Gagal mengecek port.</b>\n<code>${htmlEscape(e.message)}</code>`,{parse_mode:'HTML'}); }
    }

    if (flow.mode === 'port' && flow.step === 'newport' && msg.text && !msg.text.startsWith('/')) {
      const newPort=msg.text.trim();
      if (!/^\d{1,5}$/.test(newPort) || Number(newPort)<1 || Number(newPort)>65535) return safeRichTextMessage(chatId,'❌ Port baru tidak valid. Gunakan angka 1–65535.',{parse_mode:'HTML'});
      try {
        await safeRichTextMessage(chatId,`⚙️ <b>Memproses Ganti Port Panel...</b>\n\n<code>${htmlEscape(flow.selectedPort)}</code> → <code>${htmlEscape(newPort)}</code>`,{parse_mode:'HTML'});
        const out=await replacePortInZip(flow.zip,flow.selectedPort,newPort);
        const outName=flow.fileName.replace(/\.zip$/i,'')+'-port-updated.zip';
        pendingDomainRename.delete(uidKey);
        return bot.sendDocument(chatId,out,{caption:`✅ <b>GANTI PORT PANEL SELESAI</b>\n\nLama: <code>${htmlEscape(flow.selectedPort)}</code>\nBaru: <code>${htmlEscape(newPort)}</code>\n\n📦 File hasil sudah dikirim kembali.`,parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🔌 Ganti Port Lagi',callback_data:'domain_port_menu'}],[{text:'🧰 Menu Tools',callback_data:'menu_alat'}]]}},{filename:outName,contentType:'application/zip'});
      } catch(e) { return safeRichTextMessage(chatId,`❌ <b>Ganti Port gagal.</b>\n<code>${htmlEscape(e.message)}</code>`,{parse_mode:'HTML'}); }
    }
  }

  if (pendingTourl.has(uidKey) && msg.photo) {
    const flow=pendingTourl.get(uidKey);
    const photo=msg.photo[msg.photo.length-1];
    try {
      const link=await bot.getFileLink(photo.file_id);
      const res=await axios.get(link,{responseType:'arraybuffer',timeout:60000});
      flow.buffer=Buffer.from(res.data); flow.fileName='photo.jpg'; flow.step='provider'; pendingTourl.set(uidKey,flow);
      return safeRichSendMessage(chatId,'🖼️ <b>PILIH PROVIDER TOURL</b>\n\n<b>⚡ Auto</b> mencoba provider lain otomatis jika server provider pilihan sedang down.',{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'⚡ Auto (Recommended)',callback_data:`tourl_auto_${userId}`,style:'success'}],[{text:'🐱 Catbox',callback_data:`tourl_catbox_${userId}`},{text:'🪣 Uguu',callback_data:`tourl_uguu_${userId}`}],[{text:'📦 Litterbox',callback_data:`tourl_litterbox_${userId}`},{text:'0️⃣ 0x0.st',callback_data:`tourl_0x0_${userId}`}],[{text:'✖️ Batal',callback_data:'tourl_cancel'}]]}});
    } catch(e) { pendingTourl.delete(uidKey); return safeRichTextMessage(chatId,`❌ Gagal mengambil foto: <code>${htmlEscape(e.message)}</code>`,{parse_mode:'HTML'}); }
  }

  if (pendingDeploy.has(uidKey) && msg.document && /\.zip$/i.test(msg.document.file_name||'')) {
    const flow=pendingDeploy.get(uidKey);
    try {
      const link=await bot.getFileLink(msg.document.file_id);
      const res=await axios.get(link,{responseType:'arraybuffer',timeout:120000});
      const load=await safeRichTextMessage(chatId,'🚀 <b>Mempersiapkan deployment...</b>',{parse_mode:'HTML'});
      const result=await deployToVercel(Buffer.from(res.data), msg.document.file_name, process.env.VERCEL_TOKEN, process.env.VERCEL_PROJECT_NAME || 'telegram-deploy');
      pendingDeploy.delete(uidKey); await safeDelete(bot,chatId,load.message_id);
      const protectionNote = result.protectionConfigured
        ? 'Vercel Authentication project dinonaktifkan melalui API.'
        : 'Deployment Protection tidak diubah oleh bot; status akses tetap mengikuti pengaturan Vercel.';
      const aliasLine = Array.isArray(result.aliases) && result.aliases.length
        ? `\nAlias: <code>${htmlEscape(result.aliases.slice(0,3).join(', '))}</code>` : '';
      return safeRichTextMessage(chatId,`✅ <b>DEPLOY BERHASIL & TERUJI</b>\n\n🌐 <b>Website:</b> <a href="${htmlEscape(result.url)}">${htmlEscape(result.url)}</a>\n\n<blockquote>Mode: <code>Production</code>\nProject: <code>${htmlEscape(result.name)}</code>\nHTTP: <code>${htmlEscape(String(result.httpStatus))}</code>${aliasLine}\n\n${htmlEscape(protectionNote)}\nWebsite sudah diuji dari server bot sebelum hasil dikirim.</blockquote>`,{parse_mode:'HTML'});
    } catch(e) { return safeRichTextMessage(chatId,`❌ <b>Deploy gagal</b>\n<code>${htmlEscape(e.message)}</code>`,{parse_mode:'HTML'}); }
  }

  if (pendingWaChannel.has(uidKey) && text && !text.startsWith('/')) {
    const flow=pendingWaChannel.get(uidKey); pendingWaChannel.delete(uidKey);
    try { const info=await extractWhatsAppChannelInfo(text, getSocket()); return safeRichSendMessage(chatId,`📢 <b>INFO CHANNEL WHATSAPP</b>\n\nNama: <code>${htmlEscape(info.name||'-')}</code>\nID: <code>${htmlEscape(info.id||'-')}</code>\nInvite: <code>${htmlEscape(info.inviteCode||'-')}</code>${info.status?`\nStatus: <code>${htmlEscape(info.status)}</code>`:''}${info.source?`\nSumber: <code>${htmlEscape(info.source)}</code>`:''}${info.note?`\n\n⚠️ ${htmlEscape(info.note)}`:''}`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🔎 Cek Link Lagi',callback_data:'tool_wachannel'}],[{text:'🧰 Menu Tools',callback_data:'menu_alat'}]]}}); }
    catch(e) { return safeRichSendMessage(chatId,`❌ <b>Gagal cek channel</b>\n\n<code>${htmlEscape(e.message)}</code>\n\nKirim link publik WhatsApp Channel yang valid. Fitur ini tidak mewajibkan sesi WhatsApp.`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'🔄 Coba Lagi',callback_data:'tool_wachannel'}],[{text:'🧰 Menu Tools',callback_data:'menu_alat'}]]}}); }
  }

  if (text && !text.startsWith('/') && global.__hangmanSessions?.has(String(chatId))) { const hs=global.__hangmanSessions.get(String(chatId)); const guess=text.trim().toUpperCase(); if(/^[A-Z]$/.test(guess)){ hs.guessed.add(guess); const masked=hs.word.split('').map(ch=>hs.guessed.has(ch)?ch:'•').join(' '); if(!masked.includes('•')){global.__hangmanSessions.delete(String(chatId)); return safeRichTextMessage(chatId,`🏆 <b>Hangman selesai!</b>\nJawaban: <code>${hs.word}</code>`,{parse_mode:'HTML',reply_to_message_id:msg.message_id});} const misses=[...hs.guessed].filter(ch=>!hs.word.includes(ch)).length; if(misses>=6){global.__hangmanSessions.delete(String(chatId)); return safeRichTextMessage(chatId,`💥 <b>Game over!</b>\nJawaban: <code>${hs.word}</code>`,{parse_mode:'HTML',reply_to_message_id:msg.message_id});} global.__hangmanSessions.set(String(chatId),hs); return safeRichTextMessage(chatId,`🧩 <b>Hangman</b>\nKata: <code>${masked}</code>\nSalah: <code>${misses}/6</code>\nHuruf: <code>${[...hs.guessed].join(', ')}</code>`,{parse_mode:'HTML'}); } }

  if (text && !text.startsWith('/')) {
    const qz=quizSessions.get(chatId);
    if(qz && /^[1-4]$/.test(text.trim())) { quizSessions.delete(chatId); const n=Number(text.trim()); const ok=n===qz.a; return safeRichTextMessage(chatId, ok ? `🧠 <b>Benar!</b> Jawaban: <code>${qz.o[qz.a-1]}</code> 🎉` : `🧠 <b>Belum tepat.</b> Jawaban: <code>${qz.o[qz.a-1]}</code>`, {parse_mode:'HTML',reply_to_message_id:msg.message_id}); }
    const ms=mathSessions.get(chatId);
    if(ms && /^-?\d+(?:\.\d+)?$/.test(text.trim())) { mathSessions.delete(chatId); const n=Number(text.trim()); const ok=n===ms.answer; return safeRichTextMessage(chatId, ok ? `➗ <b>Benar!</b> Hasilnya <code>${ms.answer}</code> 🎉` : `➗ <b>Salah.</b> Jawaban yang benar <code>${ms.answer}</code>`, {parse_mode:'HTML',reply_to_message_id:msg.message_id}); }
  }

  // ---- DMUSER: auto-hapus pesan yang lolos selama masih dalam masa mute ----
  if (isGroup) {
    const dmKey = `${chatId}:${userId}`;
    const dmUntil = dmMuteList.get(dmKey);
    if (dmUntil) {
      if (Date.now() < dmUntil) {
        try { await bot.deleteMessage(chatId, msg.message_id); } catch {}
        return;
      }
      dmMuteList.delete(dmKey);
    }
  }
  
    if (isOwner(userId) && pendingHadiahLimit.has(String(userId)) && text && !text.startsWith('/')) {
    const limit = parseInt(text.trim(), 10);
    if (isNaN(limit) || limit < 1) {
      return safeRichTextMessage(chatId,
        `${E.cross} Masukan angka yang valid! Contoh: <code>10</code>`, { parse_mode: 'HTML' });
    }
    const pending = pendingHadiahLimit.get(String(userId));
    pendingHadiahLimit.delete(String(userId));
    const reward = {
      id: `reward_${Date.now()}`,
      fileId: pending.fileId,
      fileName: pending.fileName,
      fileType: pending.fileType,
      replyText: pending.replyText || null,
      maxUsers: limit,
      addedAt: new Date().toISOString()
    };
    addReward(reward);
    return safeRichTextMessage(chatId,
      `${E.check} <b>Hadiah Berhasil Ditambahkan!</b>\n\n` +
      `${E.folder} Nama: <code>${htmlEscape(pending.fileName)}</code>\n` +
      `${E.folder} Tipe: <code>${pending.fileType}</code>\n` +
      `${E.group} Maks Users: <code>${limit}</code>\n\n` +
      `<blockquote>Gunakan /addkode untuk membuat kode redeem dari hadiah ini.</blockquote>`,
      { parse_mode: 'HTML' });
  }

  // ---- GAME: Tebak Kata / Tebak Angka ----
  if (tebakKataSessions.has(chatId) && text && !text.startsWith('/')) {
    const s = tebakKataSessions.get(chatId);
    const guess = text.trim();
    if (s.numberGame) {
      const num = parseInt(guess, 10);
      if (!isNaN(num)) {
        s.tries++;
        if (num === s.target) {
          tebakKataSessions.delete(chatId);
          return safeRichTextMessage(chatId,
            `${E.party} <b>Benar!</b> Angkanya memang <code>${s.target}</code>!\n` +
            `Ditebak dalam <b>${s.tries}</b> kali percobaan. ${E.crown}`,
            { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
        }
        if (s.tries >= s.maxTries) {
          tebakKataSessions.delete(chatId);
          return safeRichTextMessage(chatId,
            `${E.cross} <b>Kesempatan habis!</b> Jawaban yang benar: <code>${s.target}</code>`,
            { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
        }
        tebakKataSessions.set(chatId, s);
        return safeRichTextMessage(chatId,
          `${num < s.target ? '⬆️ Lebih besar!' : '⬇️ Lebih kecil!'} (Percobaan ${s.tries}/${s.maxTries})`,
          { reply_to_message_id: msg.message_id });
      }
    } else if (s.word) {
      if (guess.toLowerCase() === s.word.toLowerCase()) {
        tebakKataSessions.delete(chatId);
        const name = [msg.from.first_name, msg.from.last_name].filter(Boolean).join(' ') || msg.from.username || 'Pemain';
        return safeRichTextMessage(chatId,
          `${E.party} <b>Benar!</b> Jawabannya <code>${htmlEscape(s.word)}</code>!\n` +
          `Selamat, <b>${htmlEscape(name)}</b>! ${E.crown}`,
          { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
      }
    }
  }

  // ---- FEATURE REQUEST INPUT ----
  if (pendingFeatureRequest.has(String(userId)) && text && !text.startsWith('/')) { pendingFeatureRequest.delete(String(userId)); return submitFeatureRequest(msg,text.trim()); }
  // ---- FEATURE REQUEST DEVELOPER REPLY INPUT ----
  if (isOwner(userId) && pendingFeatureReply.has(String(userId)) && text && !text.startsWith('/')) { const reqId=pendingFeatureReply.get(String(userId)); pendingFeatureReply.delete(String(userId)); return deliverFeatureRequestAnswer(msg,reqId,text.trim()); }

  // ---- BROADCAST INPUT (Owner mengetik isi broadcast) ----
  if (pendingBroadcast.has(String(userId)) && text && !text.startsWith('/')) {
    pendingBroadcast.delete(String(userId));
    return runBroadcast(msg, text.trim());
  }

  // ---- LAPOR INPUT (User mengetik teks laporan/saran ke Developer) ----
  if (pendingLapor.has(String(userId)) && text && !text.startsWith('/')) {
    pendingLapor.delete(String(userId));
    const name = [msg.from.first_name, msg.from.last_name].filter(Boolean).join(' ') || msg.from.username || 'Pengguna';
    const username = msg.from.username ? `@${msg.from.username}` : '-';
    try {
      await safeRichTextMessage(c.ID,
        `${E.info} <b>Laporan / Saran Fitur Baru</b>\n\n` +
        `${E.Name} Dari: <code>${htmlEscape(name)}</code>\n` +
        `${E.user} Username: <code>${htmlEscape(username)}</code>\n` +
        `${E.id} ID: <code>${userId}</code>\n\n` +
        `<blockquote>${htmlEscape(text.trim())}</blockquote>`,
        { parse_mode: 'HTML' });
      return safeRichTextMessage(chatId,
        `${E.check} <b>Laporan kamu sudah dikirim ke Developer!</b>\n\n` +
        `<blockquote>Terima kasih atas masukannya. Developer akan segera meninjau.</blockquote>`,
        { parse_mode: 'HTML' });
    } catch (e) {
      return safeRichTextMessage(chatId, `${E.cross} Gagal mengirim laporan: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
    }
  }

  // ---- REDEEM CODE INPUT (User mengetik kode FMD-XXXXX) ----
  if (pendingRedeemInput.has(String(userId)) && text && !text.startsWith('/')) {
    const inputCode = text.trim().toUpperCase();
    pendingRedeemInput.delete(String(userId));
    const codeData = getActiveCode(inputCode);
    const now = Date.now();
    if (!codeData) {
      return safeRichTextMessage(chatId,
        `${E.cross} <b>Kode tidak valid!</b>\n\n<blockquote>Pastikan kode yang kamu masukan benar.\nFormat: <code>FMD-XXXXX</code></blockquote>`,
        { parse_mode: 'HTML' });
    }
    if (new Date(codeData.expiresAt).getTime() < now) {
      removeActiveCode(inputCode);
      return safeRichTextMessage(chatId,
        `${E.cross} <b>Kode sudah kadaluarsa!</b>\n\n<blockquote>Kode redeem ini sudah melewati batas 15 menit. Tunggu kode baru dari owner.</blockquote>`,
        { parse_mode: 'HTML' });
    }
    if (codeData.claimed >= codeData.maxUsers) {
      return safeRichTextMessage(chatId,
        `${E.cross} <b>Kode sudah habis!</b>\n\n<blockquote>Kuota ${codeData.maxUsers} users sudah penuh. Tunggu kode baru dari owner.</blockquote>`,
        { parse_mode: 'HTML' });
    }
    if ((codeData.claimedBy || []).includes(String(userId))) {
      return safeRichTextMessage(chatId,
        `${E.cross} <b>Kamu sudah pernah mengklaim kode ini!</b>\n\n<blockquote>Setiap users hanya bisa mengklaim sekali per kode.</blockquote>`,
        { parse_mode: 'HTML' });
    }
    const claimed = claimCode(inputCode, userId);
    if (!claimed) {
      return safeRichTextMessage(chatId, `${E.cross} Gagal mengklaim. Coba lagi.`, { parse_mode: 'HTML' });
    }
    const updatedData = getActiveCode(inputCode);
    const remaining = (updatedData?.maxUsers || codeData.maxUsers) - (updatedData?.claimed || codeData.claimed + 1);
    const name = [msg.from.first_name, msg.from.last_name].filter(Boolean).join(' ') || msg.from.username || 'Pengguna';
    await safeRichTextMessage(chatId,
      `${E.party} <b>Selamat! Kamu berhasil mengklaim hadiah!</b>\n\n` +
      `${E.Name} Nama: <code>${htmlEscape(name)}</code>\n` +
      `${E.key} Kode: <code>${htmlEscape(inputCode)}</code>\n` +
      `${E.gift} Hadiah: <code>${htmlEscape(codeData.rewardFileName)}</code>\n\n` +
      `<blockquote>Hadiahmu sedang dikirimkan di bawah ini 👇</blockquote>`,
      { parse_mode: 'HTML' });
    try {
      if (codeData.rewardFileType === 'document') {
        await bot.sendDocument(chatId, codeData.rewardFileId, {
          caption: `${E.party} Hadiah kamu dari Team Lavender!\n<blockquote>Kode: <code>${htmlEscape(inputCode)}</code></blockquote>`,
          parse_mode: 'HTML'
        });
      } else if (codeData.rewardFileType === 'photo') {
        await bot.sendPhoto(chatId, codeData.rewardFileId, {
          caption: `${E.party} Hadiah kamu dari Team Lavender!\n<blockquote>Kode: <code>${htmlEscape(inputCode)}</code></blockquote>`,
          parse_mode: 'HTML'
        });
      } else if (codeData.rewardFileType === 'video') {
        await bot.sendVideo(chatId, codeData.rewardFileId, {
          caption: `${E.party} Hadiah kamu dari Team Lavender!\n<blockquote>Kode: <code>${htmlEscape(inputCode)}</code></blockquote>`,
          parse_mode: 'HTML'
        });
      } else if (codeData.rewardFileType === 'audio') {
        await bot.sendAudio(chatId, codeData.rewardFileId, {
          caption: `${E.party} Hadiah kamu dari Team Lavender!\n<blockquote>Kode: <code>${htmlEscape(inputCode)}</code></blockquote>`,
          parse_mode: 'HTML'
        });
      } else if (codeData.rewardFileType === 'text') {
        await safeRichTextMessage(chatId,
          `${E.party} <b>Hadiah kamu dari Team Lavender:</b>\n\n${htmlEscape(codeData.rewardFileId)}\n\n<blockquote>Dari Bot</blockquote>`,
          { parse_mode: 'HTML' });
      }
    } catch (e) {
      await safeRichTextMessage(chatId, `${E.warning} Hadiah gagal dikirim: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
    }
    if (remaining <= 0) removeActiveCode(inputCode);
    broadcastClaimNotif(msg.from, inputCode, Math.max(0, remaining)).catch(() => {});
    safeRichTextMessage(c.ID,
      `${E.check} Kode <code>${htmlEscape(inputCode)}</code> diklaim oleh:\n` +
      `Nama: <b>${htmlEscape(name)}</b>\nID: <code>${userId}</code>\nSisa: <code>${Math.max(0, remaining)}</code>`,
      { parse_mode: 'HTML' }).catch(() => {});
    return;
  }
 
 if (pendingPasswordInput.has(String(userId)) && text && !text.startsWith('/')) {
    const { number, chatId: pwChatId, msgId: pwMsgId } = pendingPasswordInput.get(String(userId));
    pendingPasswordInput.delete(String(userId));
    if (text.length < 4) {
      return safeRichTextMessage(chatId,
        `${E.cross} Password minimal 4 karakter! Coba lagi dengan /ceksender atau sambungkan ulang.`,
        { parse_mode: 'HTML' });
    }
    setSenderPassword(number, text.trim());
    return safeRichTextMessage(chatId,
      `${E.check} <b>Password Berhasil Dipasang!</b>\n\n` +
      `Nomor: <code>${number}</code>\n` +
      `Password: <code>${'•'.repeat(text.length)}</code>\n\n` +
      `<blockquote>Sender kamu sekarang dilindungi password.\nUser lain yang ingin memakai sender ini harus memasukan password yang benar.</blockquote>`,
      { parse_mode: 'HTML' });
  }

  // ---- PASSWORD INPUT: Tesfunc dengan sender pinjaman ----
  if (pendingTesfuncPw.has(String(userId)) && text && !text.startsWith('/')) {
    const session = pendingTesfuncPw.get(String(userId));
    pendingTesfuncPw.delete(String(userId));
    const storedPw = getSenderPassword(session.senderNumber);
    if (!storedPw || text.trim() !== storedPw) {
      return safeRichTextMessage(chatId,
        `${E.cross} <b>Password salah!</b>\n\n<blockquote>Tesfunc dibatalkan. Password sender tidak cocok.</blockquote>`,
        { parse_mode: 'HTML' });
    }
    return runTesfunc(chatId, msg.from, session.targetNumber, session.code, session.loop, session.sleep);
  }
  
  // ---- QUIZ PARTY: jawaban A/B/C/D ----
  if (msg.text && !msg.text.startsWith('/') && quizPartySessions.has(chatId)) {
    const qs = quizPartySessions.get(chatId);
    if (qs.started && qs.q) {
      const p = qs.players.find(x => x.id === userId);
      const ans = msg.text.trim().toUpperCase();
      if (p && /^[ABCD]$/.test(ans) && !qs.answered.has(userId)) {
        qs.answered.add(userId);
        const idx = 'ABCD'.indexOf(ans);
        if (idx + 1 === qs.q.a) { p.score += 2; await safeRichTextMessage(chatId, `✅ ${p.name} benar! +2 poin.`); }
        else { await safeRichTextMessage(chatId, `❌ ${p.name} kurang tepat.`); }
        if (qs.answered.size >= qs.players.length) {
          const result = qs.players.slice().sort((a,b)=>(b.score||0)-(a.score||0)).map((x,i)=>`${i+1}. ${x.name} — ${x.score||0}`).join('\n');
          partyScores.set(chatId, qs.players.map(x=>({...x})));
          quizPartySessions.delete(chatId);
          await safeRichTextMessage(chatId, `🏆 <b>Quiz Party selesai!</b>\n\n${result}`, {parse_mode:'HTML'});
        }
        return;
      }
    }
  }

  // ---- WINK: proses foto/video dari user ----
  if (pendingWink.has(String(userId))) {
    const winkData = pendingWink.get(String(userId));
    const { mode, chatId: winkChatId } = winkData;

    const isWinkPhoto = msg.photo && msg.photo.length > 0;
    const isWinkVideo = msg.video || msg.document?.mime_type?.startsWith('video/');

    if ((mode === 'image' && isWinkPhoto) || (mode === 'video' && isWinkVideo)) {
      pendingWink.delete(String(userId));

      const modeLabel = mode === 'image' ? `${E.ig} HD Images 4×` : `${E.movie} HD Video`;
      const loading = await safeRichTextMessage(winkChatId,
        `<code>${makeBar(20)}</code>\n${E.hourglass} Mengambil file...`,
        { parse_mode: 'HTML', reply_to_message_id: msg.message_id });

      try {
        // Ambil file link dari Telegram
        let fileId;
        if (mode === 'image') {
          fileId = msg.photo[msg.photo.length - 1].file_id;
        } else {
          fileId = msg.video ? msg.video.file_id : msg.document.file_id;
        }
        const fileLink = await bot.getFileLink(fileId);

        await safeEdit(bot, winkChatId, loading.message_id,
          `<code>${makeBar(40)}</code>\n${E.hourglass} Mengunduh media...`, { parse_mode: 'HTML' });

        const rawRes = await axios.get(fileLink, { responseType:'arraybuffer', timeout:90000 });
        const rawBuffer = Buffer.from(rawRes.data);
        let resultBuffer;
        if (mode === 'image') {
          // Foto selalu memakai 4× local upscale agar hasil konsisten dan tidak
          // bergantung pada API eksternal.
          await safeEdit(bot, winkChatId, loading.message_id,
            `<code>${makeBar(65)}</code>\n${E.hourglass} Upscale foto 4× + sharpening...`, { parse_mode:'HTML' });
          resultBuffer = await localEnhanceMedia(rawBuffer, 'image');
        } else {
          // Video tetap mencoba API eksternal lalu fallback ke FFmpeg lokal.
          try {
            await safeEdit(bot, winkChatId, loading.message_id,
              `<code>${makeBar(55)}</code>\n${E.hourglass} Meningkatkan kualitas video...`, { parse_mode:'HTML' });
            const winkRes = await axios.get('https://api.nexray.eu.cc/tools/wink', {
              params: { url: fileLink, type: mode }, timeout: 90000, headers: { 'User-Agent':'Mozilla/5.0' }
            });
            const resultUrl = winkRes.data?.result;
            if (!resultUrl) throw new Error('API Wink tidak mengembalikan hasil');
            const dlRes = await axios.get(resultUrl, { responseType:'arraybuffer', timeout:90000 });
            resultBuffer = Buffer.from(dlRes.data);
          } catch (remoteErr) {
            await safeEdit(bot, winkChatId, loading.message_id,
              `<code>${makeBar(65)}</code>\n${E.hourglass} Server video tidak tersedia, memakai enhancer lokal...`, { parse_mode:'HTML' });
            resultBuffer = await localEnhanceMedia(rawBuffer, 'video');
          }
        }

        await safeEdit(bot, winkChatId, loading.message_id,
          `<code>${makeBar(90)}</code>\n${E.hourglass} Mengirim hasil HD...`, { parse_mode: 'HTML' });

        await safeEdit(bot, winkChatId, loading.message_id,
          `<code>${makeBar(95)}</code>\n${E.hourglass} Mengirim hasil...`, { parse_mode: 'HTML' });

        const nowDate = new Date();
        const dateStr = nowDate.toLocaleDateString('id-ID', { day: '2-digit', month: '2-digit', year: 'numeric', timeZone: 'Asia/Jakarta' });
        const timeStr = nowDate.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit', timeZone: 'Asia/Jakarta' });
        const sizeKb  = (resultBuffer.length / 1024).toFixed(1);

        if (mode === 'image') {
          const caption =
            `${E.sticker} <b>Wink — HD Images 4×</b>\n\n` +
            `${E.folder} <b>Size:</b> <code>${sizeKb} KB</code>\n` +
            `${E.tgl} <b>Tanggal:</b> <code>${dateStr}</code>\n` +
            `${E.jam} <b>Jam:</b> <code>${timeStr} WIB</code>\n\n` +
            `<blockquote>4× Upscale + Sharpening • mellstecu Ϟ FMD</blockquote>`;
          try {
            await bot.sendPhoto(winkChatId, resultBuffer, {
              caption, parse_mode: 'HTML',
              reply_to_message_id: msg.message_id
            });
          } catch (photoErr) {
            // Telegram dapat menolak foto yang terlalu besar; kirim sebagai file agar
            // hasil 4× tetap tidak hilang.
            await bot.sendDocument(winkChatId, resultBuffer, {
              caption: caption + '\n\n<i>Foto dikirim sebagai dokumen karena ukurannya besar.</i>',
              parse_mode:'HTML', reply_to_message_id: msg.message_id
            }, { filename:'wink-hd-4x.jpg', contentType:'image/jpeg' });
          }
        } else {
          const caption =
            `${E.sticker} <b>Wink — HD Video</b>\n\n` +
            `${E.folder} <b>Size:</b> <code>${sizeKb} KB</code>\n` +
            `${E.tgl} <b>Tanggal:</b> <code>${dateStr}</code>\n` +
            `${E.jam} <b>Jam:</b> <code>${timeStr} WIB</code>\n\n` +
            `<blockquote>4× Upscale + Sharpening • mellstecu Ϟ FMD</blockquote>`;
          await bot.sendVideo(winkChatId, resultBuffer, {
            caption, parse_mode: 'HTML',
            reply_to_message_id: msg.message_id,
            supports_streaming: true
          }, {}, { filename: 'wink_hd.mp4', contentType: 'video/mp4' });
        }
        await safeDelete(bot, winkChatId, loading.message_id);

      } catch (e) {
        await safeEdit(bot, winkChatId, loading.message_id,
          `${E.cross} <b>Gagal enhance ${mode === 'image' ? 'foto' : 'video'}:</b>\n\n<code>${htmlEscape(e.message)}</code>\n\n<blockquote>Coba lagi dengan file yang lebih kecil atau /wink ulang.</blockquote>`,
          { parse_mode: 'HTML' });
      }
      return;

    } else if ((mode === 'image' && isWinkVideo) || (mode === 'video' && isWinkPhoto)) {
      // Salah kirim tipe file
      return safeRichTextMessage(winkChatId,
        `${E.warning} <b>Mode aktif:</b> <code>${mode === 'image' ? 'HD Images' : 'HD Video'}</code>\n` +
        `Kirimkan ${mode === 'image' ? '<b>foto</b>' : '<b>video</b>'}, bukan ${mode === 'image' ? 'video' : 'foto'}.\n\n` +
        `<blockquote>Atau ketik /wink ulang untuk ganti mode.</blockquote>`,
        { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
    }
  }
    // ---- ANTIDRUGS ----
  if (isGroup) {
    const gs = getGroupSettings(chatId);
    if (gs.antidrugs) {
      const exempt = await isGroupModerationExempt(chatId, userId);
      if (!exempt) {
        const fileName = msg.document?.file_name || msg.video?.file_name || msg.audio?.file_name || msg.animation?.file_name || '';
        const checkText = [msg.text || '', msg.caption || '', fileName].filter(Boolean).join('\n');
        if (containsDrugContent(checkText, msg)) {
          try { await bot.deleteMessage(chatId, msg.message_id); } catch {}
          const mention = msg.from.username
            ? `@${htmlEscape(msg.from.username)}`
            : `<a href="tg://user?id=${userId}">${htmlEscape(msg.from.first_name || 'Member')}</a>`;
          const strike = registerModerationStrike(chatId, userId, 'antidrugs');
          await applyModerationAction(chatId, userId, strike, 'antidrugs', mention, msg.message_id);
          return;
        }
      }
    }
  }

  // ---- ANTIFOTO / ANTIVIDEO ----
  if (isGroup && (msg.photo || msg.video)) {
    const gs = getGroupSettings(chatId);
    const category = msg.photo && gs.antifoto ? 'antifoto' : (msg.video && gs.antivideo ? 'antivideo' : null);
    if (category) {
      const exempt = await isGroupModerationExempt(chatId, userId);
      if (!exempt) {
        try { await bot.deleteMessage(chatId, msg.message_id); } catch {}
        const mention = msg.from.username
          ? `@${htmlEscape(msg.from.username)}`
          : `<a href="tg://user?id=${userId}">${htmlEscape(msg.from.first_name || 'Member')}</a>`;
        const strike = registerModerationStrike(chatId, userId, category);
        await applyModerationAction(chatId, userId, strike, category, mention, msg.message_id);
        return;
      }
    }
  }

  // ---- ANTIFORWARD ----
  // Admin/creator dikecualikan sepenuhnya: tidak dihapus dan tidak mendapat warn.
  // Member: delete -> warn 1/3, 2/3, 3/3 -> pelanggaran ke-4 auto mute permanen.
  if (isGroup) {
    const gs = getGroupSettings(chatId);
    const isForwarded = Boolean(
      msg.forward_origin ||
      msg.forward_from ||
      msg.forward_from_chat ||
      msg.forward_date ||
      msg.is_automatic_forward
    );
    if (gs.antiforward && isForwarded) {
      const exempt = await isGroupModerationExempt(chatId, userId);
      if (!exempt) {
        const mention = msg.from.username
          ? `@${htmlEscape(msg.from.username)}`
          : `<a href="tg://user?id=${userId}">${htmlEscape(msg.from.first_name || 'Member')}</a>`;
        try { await bot.deleteMessage(chatId, msg.message_id); } catch {}
        const strike = registerModerationStrike(chatId, userId, 'antiforward');
        await applyModerationAction(chatId, userId, strike, 'antiforward', mention, msg.message_id);
        return;
      }
    }
  }

  // ---- ANTISTICKER / 18+ STICKER ----
  if (isGroup && msg.sticker) {
    const gs = getGroupSettings(chatId);
    const exempt = await isGroupModerationExempt(chatId, userId);
    if (!exempt) {
      const mention = msg.from.username
        ? `@${htmlEscape(msg.from.username)}`
        : `<a href="tg://user?id=${userId}">${htmlEscape(msg.from.first_name || 'Member')}</a>`;
      const adultSticker = gs.antiporno ? await analyzeStickerForAdultContent(msg.sticker,userId) : false;
      const blocked = adultSticker || Boolean(gs.antisticker);
      if (blocked) {
        try { await bot.deleteMessage(chatId,msg.message_id); } catch {}
        const category = adultSticker ? 'antiporno' : 'antisticker';
        const strike = registerModerationStrike(chatId,userId,category);
        await applyModerationAction(chatId,userId,strike,category,mention,msg.message_id);
        return;
      }
    }
  }

  // ---- ANTITOXIC ----
  if (isGroup) {
    const gs = getGroupSettings(chatId);
    if (gs.antitoxic && containsToxicContent(text)) {
      const exempt = await isGroupModerationExempt(chatId, userId);
      if (!exempt) {
        try { await bot.deleteMessage(chatId, msg.message_id); } catch {}
        const mention = msg.from.username ? `@${msg.from.username}` : `<a href="tg://user?id=${userId}">${htmlEscape(msg.from.first_name || 'Member')}</a>`;
        const strike = registerModerationStrike(chatId, userId, 'antitoxic');
        await applyModerationAction(chatId, userId, strike, 'antitoxic', mention, msg.message_id);
        return;
      }
    }
  }

  // ---- ANTIPORNO (teks, link, caption, nama file media) ----
  if (isGroup) {
    const gs = getGroupSettings(chatId);
    if (gs.antiporno) {
      const exempt = await isGroupModerationExempt(chatId, userId);
      if (!exempt) {
        const textToCheck = msg.text || msg.caption || '';
        const fileName = msg.document?.file_name || msg.video?.file_name || msg.audio?.file_name || '';
        const mediaCaption = msg.caption || '';
        const isMedia = Boolean(msg.photo || msg.video || msg.animation || msg.document || msg.audio);
        const isPorno = containsPornoContent(textToCheck) || containsPornoContent(fileName) || (isMedia && containsPornoContent(mediaCaption));
        if (isPorno) {
          try { await bot.deleteMessage(chatId, msg.message_id); } catch {}
          const mention = msg.from.username ? `@${msg.from.username}` : `<a href="tg://user?id=${userId}">${htmlEscape(msg.from.first_name || 'Member')}</a>`;
          const strike = registerModerationStrike(chatId, userId, 'antiporno');
          await applyModerationAction(chatId, userId, strike, 'antiporno', mention, msg.message_id);
          return;
        }
      }
    }
  }

  // ---- ROSE-STYLE FILTER TRIGGER ----
  // Only exact normal-text/caption matches; commands are excluded. Security checks above still run first.
  if (isGroup && !String(msg.text || '').trim().startsWith('/')) {
    const incoming = String(msg.text || msg.caption || '').trim().toLowerCase();
    if (incoming) {
      const filters = getGroupFilters(chatId);
      const hit = filters[incoming];
      if (hit) {
        const delivered = await triggerGroupFilter(chatId, incoming, hit);
        if (delivered) return;
        // No source message/snapshot is usable anymore. Remove only after both
        // Telegram copy/forward and local recreation have failed.
        removeGroupFilter(chatId, incoming);
        await safeRichSendMessage(chatId, `⚠️ <b>Filter <code>${htmlEscape(incoming)}</code> tidak dapat dipanggil.</b>

Pesan sumber sudah tidak bisa diakses. Buat ulang filter dengan <code>/filter ${htmlEscape(incoming)}</code>.`, {parse_mode:'HTML'}).catch(()=>{});
        return;
      }
    }
  }

  // ---- ANTIPROMOSI ----
  // Dijalankan sebelum flow media/fake feature supaya caption foto/video/document
  // tidak bisa melewati filter hanya karena tipe pesannya bukan msg.text.
  if (isGroup) {
    const gs = getGroupSettings(chatId);
    if (gs.antipromosi) {
      const exempt = await isGroupModerationExempt(chatId, userId);
      const promoText = [msg.text || '', msg.caption || '', msg.document?.file_name || '', msg.video?.file_name || '', msg.audio?.file_name || '', msg.animation?.file_name || ''].filter(Boolean).join('\n');
      const promoEntities = [...(msg.entities || []), ...(msg.caption_entities || [])];
      const promoDetected = !exempt && (
        containsPromoContent(promoText, msg) ||
        promoEntities.some(e => e.type === 'text_link') ||
        /(?:^|\s)@[a-z0-9_]{4,32}\b/i.test(promoText) && /(order|jual|shop|toko|admin|dm|wa|whatsapp|promo|diskon|harga|ready|stok)/i.test(promoText)
      );
      if (promoDetected) {
        try { await bot.deleteMessage(chatId, msg.message_id); } catch {}
        const mention = msg.from.username ? `@${htmlEscape(msg.from.username)}` : `<a href="tg://user?id=${userId}">${htmlEscape(msg.from.first_name || 'Member')}</a>`;
        const strike = registerModerationStrike(chatId, userId, 'antipromosi');
        // Strike tetap dicatat walau Telegram gagal menghapus pesan.
        await applyModerationAction(chatId, userId, strike, 'antipromosi', mention, msg.message_id);
        return;
      }
    }
  }

   // ---- ANTILINK ----
  if (isGroup && (msg.text || msg.caption)) {
    const gs = getGroupSettings(chatId);
    if (gs.antilink) {
      const exempt = await isGroupModerationExempt(chatId, userId);
      if (!exempt) {
        const urlPattern = /https?:\/\/[^\s]+|t\.me\/[^\s]+|www\.[^\s]+/gi;
        const links = ((msg.text || msg.caption || '').match(urlPattern) || []).filter(l => !/tiktok\.com|vm\.tiktok\.com|instagram\.com|instagr\.am/i.test(l));
        if (links.length > 0) {
          try { await bot.deleteMessage(chatId, msg.message_id); } catch {}
          const mention = msg.from.username ? `@${msg.from.username}` : `<a href="tg://user?id=${userId}">${htmlEscape(msg.from.first_name || 'Member')}</a>`;
          const strike = registerModerationStrike(chatId, userId, 'antilink');
          await applyModerationAction(chatId, userId, strike, 'antilink', mention, msg.message_id);
          return;
        }
      }
    }
  }
  // ---- AI QUICK FEATURES ----
  const pendingAi = pendingAiAction.get(String(userId));
  if (pendingAi && pendingAi.chatId === chatId && Date.now() - pendingAi.createdAt < 10 * 60 * 1000 && !text.startsWith('/')) {
    if (pendingAi.mode !== 'image' && text.trim()) {
      pendingAiAction.delete(String(userId));
      const mode=pendingAi.mode;
      const activeProvider=normalizeAiProvider(getAssistantState(chatId));
      const load=await safeRichTextMessage(chatId,`${E.ai} <i>${htmlEscape(aiProviderLabel(activeProvider))} sedang menyiapkan ${htmlEscape(mode)}...</i>`,{parse_mode:'HTML',reply_to_message_id:msg.message_id});
      try {
        const result=await callAI(chatId,buildAiTaskPrompt(mode,text,userId),activeProvider); const ans=result.answer;
        await safeDelete(bot,chatId,load.message_id);
        return safeRichTextMessage(chatId,`${E.ai} <b>${htmlEscape(({chat:'Chat AI',summarize:'Ringkasan',rewrite:'Rewrite',translate:'Terjemahan',code:'Coding Assistant',study:'Study Assistant'})[mode] || 'AI Assistant')}</b> <i>(${htmlEscape(aiProviderLabel(result.provider))})</i>\n\n${formatAiResponse(ans)}`,{parse_mode:'HTML',reply_to_message_id:msg.message_id});
      } catch(e) {
        return safeEdit(bot,chatId,load.message_id,`${E.cross} AI tidak tersedia.\n<code>${htmlEscape(e.message)}</code>`,{parse_mode:'HTML'});
      }
    }
  }

  if (pendingAi && pendingAi.chatId === chatId && pendingAi.mode.startsWith('pixazo_') && (msg.photo?.length || msg.video)) {
    const mode=pendingAi.mode;
    const prompt=String(msg.caption||'').trim();
    if(prompt.length<2) return safeRichTextMessage(chatId,'✏️ Tambahkan <b>prompt di caption</b> pada foto/video yang dikirim, lalu kirim ulang.',{parse_mode:'HTML',reply_to_message_id:msg.message_id});
    pendingAiAction.delete(String(userId));
    const load=await safeRichTextMessage(chatId,`${E.ai} <i>Pixazo sedang memproses ${mode==='pixazo_photo'?'foto':mode==='pixazo_video'?'video':'foto → video'}...</i>`,{parse_mode:'HTML',reply_to_message_id:msg.message_id});
    try {
      const media=msg.photo?.length ? msg.photo[msg.photo.length-1] : msg.video;
      const fileUrl=await bot.getFileLink(media.file_id);
      let resultUrl;
      if(mode==='pixazo_photo') resultUrl=await pixazoImageEditFromUrl(fileUrl,prompt);
      else if(mode==='pixazo_video') resultUrl=await pixazoVideoEditFromUrl(fileUrl,prompt);
      else resultUrl=await pixazoImageToVideoFromUrl(fileUrl,prompt);
      await safeDelete(bot,chatId,load.message_id);
      const caption=`🎨 <b>PIXAZO STUDIO</b>\n\n📝 Prompt: <i>${htmlEscape(prompt.slice(0,500))}</i>`;
      if(mode==='pixazo_photo') return bot.sendPhoto(chatId,resultUrl,{caption,parse_mode:'HTML',reply_to_message_id:msg.message_id});
      return bot.sendVideo(chatId,resultUrl,{caption,parse_mode:'HTML',reply_to_message_id:msg.message_id,supports_streaming:true});
    } catch(e) {
      return safeEdit(bot,chatId,load.message_id,`${E.cross} <b>Pixazo gagal.</b>\n\n<code>${htmlEscape(e.message)}</code>`,{parse_mode:'HTML'});
    }
  }

  if (pendingAi && pendingAi.chatId === chatId && pendingAi.mode === 'image' && msg.photo && msg.photo.length) {
    pendingAiAction.delete(String(userId));
    const load=await safeRichTextMessage(chatId,`${E.ai} <i>Gemini sedang menganalisis gambar...</i>`,{parse_mode:'HTML',reply_to_message_id:msg.message_id});
    try {
      const photo=msg.photo[msg.photo.length-1];
      const link=await bot.getFileLink(photo.file_id);
      const imgRes=await axios.get(link,{responseType:'arraybuffer',timeout:60000});
      const ans=await analyzeImageWithGemini(Buffer.from(imgRes.data),imgRes.headers['content-type'] || 'image/jpeg',msg.caption || 'Jelaskan isi gambar ini.',userId);
      await safeDelete(bot,chatId,load.message_id);
      return safeRichTextMessage(chatId,`${E.ai} <b>Analisis Gambar</b>\n\n${formatAiResponse(ans)}`,{parse_mode:'HTML',reply_to_message_id:msg.message_id});
    } catch(e) {
      return safeEdit(bot,chatId,load.message_id,`${E.cross} Analisis gambar gagal.\n<code>${htmlEscape(e.message)}</code>`,{parse_mode:'HTML'});
    }
  }

  // ---- AI ASSISTANT (MULTI AI) ----
  // Never let the automatic assistant consume slash commands such as /start, /broadcast, /ai off, etc.
  // Those commands belong to their own handlers.
  if (text.startsWith('/')) return;
  const aiEnabled=getAssistantState(chatId);
  if(!AI_PROVIDERS.includes(String(aiEnabled)) && aiEnabled!=='auto' && aiEnabled!==true) return;
  let aiPrompt='';
  if(isGroup){
    if(!/\bai\b/i.test(text)) return;
    aiPrompt=text.replace(/\bai\b/gi,'').trim() || text;
  }else aiPrompt=text;
  if(!aiPrompt || aiPrompt.length<2) return;
  if(isJailbreak(aiPrompt)) return safeRichTextMessage(chatId,`${E.cross} <b>Permintaan tidak dapat diproses.</b>\n\n<blockquote>Instruksi yang mencoba bypass sistem keamanan tidak diizinkan.</blockquote>`,{parse_mode:'HTML',reply_to_message_id:msg.message_id});
  const activeProvider=normalizeAiProvider(aiEnabled);
  const aiLoad=await safeRichTextMessage(chatId,`<blockquote>${E.ai} <i>${htmlEscape(aiProviderLabel(activeProvider))} sedang memproses...</i></blockquote>`,{parse_mode:'HTML',reply_to_message_id:msg.message_id});
  try{
    const tAi=Date.now();
    const result=await callAI(chatId,aiPrompt,activeProvider); const rawAnswer=result.answer;
    const responseTime=`${Date.now()-tAi} ms`;
    await safeDelete(bot,chatId,aiLoad.message_id);
    return safeRichTextMessage(chatId,`${E.ai} <b>${htmlEscape(aiProviderLabel(result.provider))}</b>\n\n${formatAiResponse(rawAnswer)}\n\n<blockquote>AI Assistant | ${responseTime}</blockquote>`,{parse_mode:'HTML',reply_to_message_id:msg.message_id});
  }catch(e){
    return safeEdit(bot,chatId,aiLoad.message_id,`${E.cross} AI tidak tersedia: <code>${htmlEscape(e.message)}</code>`,{parse_mode:'HTML'});
  }

});

// ======================================= //
// 👤 NEW MEMBER EVENT (Welcome + Antibot)
// ======================================= //
bot.on('new_chat_members', async (msg) => {
  const chatId = msg.chat.id;
  const gs = getGroupSettings(chatId);

  for (const member of msg.new_chat_members) {

    // ---- ANTI BOT ----
    if (gs.antibot && member.is_bot) {
      const me = await bot.getMe().catch(() => null);
      if (me && member.id !== me.id) {
        try {
          await bot.kickChatMember(chatId, member.id);
          await safeRichTextMessage(chatId,
            `${E.shield} Bot <b>${htmlEscape(member.first_name)}</b> di-kick otomatis (Anti Bot aktif).`,
            { parse_mode: 'HTML' });
        } catch {}
        continue;
      }
    }

    // ---- LINKREQ CHECK ----
    // Cek apakah ada pending linkreq untuk grup ini
    if (!member.is_bot) {
      const joinedUsername = (member.username || '').toLowerCase();

      for (const [token, data] of privateLinks.entries()) {
        if (data.chatId !== chatId) continue;

        // Cek apakah sudah kadaluarsa
        if (Date.now() > data.expireAt) {
          privateLinks.delete(token);
          try { await bot.revokeChatInviteLink(chatId, data.inviteLink); } catch {}
          continue;
        }

        // User yang bergabung BUKAN target linkreq
        if (joinedUsername && joinedUsername !== data.targetUsername) {
          try {
            await bot.banChatMember(chatId, member.id);
            await bot.unbanChatMember(chatId, member.id, { only_if_banned: true });
            const name = htmlEscape(
              [member.first_name, member.last_name].filter(Boolean).join(' ') ||
              member.username || String(member.id)
            );
            await safeRichTextMessage(chatId,
              `${E.cross} <b>Akses Ditolak!</b>\n\n` +
              `<a href="tg://user?id=${member.id}">${name}</a> mencoba masuk menggunakan link yang bukan untuknya.\n\n` +
              `<blockquote>${E.shield} Member langsung dikeluarkan otomatis oleh sistem.</blockquote>`,
              { parse_mode: 'HTML' });
          } catch {}
          break;
        }

        // User yang bergabung ADALAH target linkreq
        if (!joinedUsername || joinedUsername === data.targetUsername) {
          const memberName = htmlEscape(
            [member.first_name, member.last_name].filter(Boolean).join(' ') ||
            member.username || String(member.id)
          );
          const adminMention = `<a href="tg://user?id=${data.createdBy}">[Admin]</a>`;
          try {
            await safeRichTextMessage(chatId,
              `${E.check} <b>Anggota Baru via Link Khusus!</b>\n\n` +
              `${E.user} <a href="tg://user?id=${member.id}">@${htmlEscape(member.username || memberName)}</a> ` +
              `berhasil bergabung menggunakan link privat yang dibuat oleh ${adminMention}.\n\n` +
              `<blockquote>${E.shield} Link sekali pakai sudah dihapus otomatis.</blockquote>`,
              { parse_mode: 'HTML' });
          } catch {}
          privateLinks.delete(token);
          try { await bot.revokeChatInviteLink(chatId, data.inviteLink); } catch {}
          break;
        }
      }
    }

    // ---- WELCOME ----
    if (gs.welcome?.enabled && !member.is_bot) {
      const username = member.username ? `@${member.username}` : (member.first_name || 'Member Baru');
      const name = [member.first_name, member.last_name].filter(Boolean).join(' ') || 'Member Baru';
      // Template disimpan sebagai plain text agar teks user tidak bisa merusak parse_mode HTML.
      let wMsg = htmlEscape(gs.welcome.message || 'Selamat datang ${name}!')
        .replace(/\{username\}|\$\{username\}/g, htmlEscape(username))
        .replace(/\{name\}|\$\{name\}/g, htmlEscape(name))
        .replace(/\{id\}|\$\{id\}/g, htmlEscape(member.id));
      try {
        if (gs.welcome.photo) await bot.sendPhoto(chatId, gs.welcome.photo, { caption: wMsg, parse_mode: 'HTML' });
        else await safeRichTextMessage(chatId, wMsg, { parse_mode: 'HTML' });
      } catch (e) {
        console.warn('[WELCOME] gagal mengirim welcome:', e.message);
      }
    }
  }
});

// ======================================= //
// 👋 GOODBYE EVENT
// ======================================= //
bot.on('left_chat_member', async (msg) => {
  try {
    if (!['group','supergroup'].includes(msg?.chat?.type) || !msg.left_chat_member) return;
    const gs=getGroupSettings(msg.chat.id); const goodbye=gs.goodbye || {};
    if (!goodbye.enabled) return;
    const member=msg.left_chat_member;
    if (member.is_bot) return;
    const username=member.username ? `@${member.username}` : (member.first_name || 'Member');
    const name=[member.first_name,member.last_name].filter(Boolean).join(' ') || 'Member';
    const rendered=htmlEscape(goodbye.message || '${name} keluar dari grup.')
      .replace(/\{username\}|\$\{username\}/g,htmlEscape(username))
      .replace(/\{name\}|\$\{name\}/g,htmlEscape(name))
      .replace(/\{id\}|\$\{id\}/g,htmlEscape(member.id));
    if (goodbye.photo) {
      try { await sendRichMenu(msg.chat.id, rendered, null, goodbye.photo); }
      catch { await bot.sendPhoto(msg.chat.id, goodbye.photo, {caption:rendered,parse_mode:'HTML'}); }
    } else {
      await safeRichTextMessage(msg.chat.id, rendered, {parse_mode:'HTML'});
    }
  } catch (e) { console.warn('[GOODBYE] gagal:',e.message); }
});

// ======================================= //
// 🤖 BOT ADDED TO GROUP — track siapa yang nambahkan
// ======================================= //
bot.on('my_chat_member', (update) => {
  const chatId = update.chat?.id;
  if (!chatId) return;
  const newStatus = update.new_chat_member?.status;
  if (update.chat?.type === 'channel') {
    if (newStatus === 'administrator' || newStatus === 'creator') {
      const addedBy = update.from?.id || c.ID;
      setChannelMonitor(chatId, {
        channelId: chatId,
        title: update.chat.title || 'Monitored Channel',
        username: update.chat.username || '',
        ownerId: addedBy,
        enabled: true,
        antiDrugs: true,
        // Channel notifications stay in the same channel by default.
        // Separate monitoring destinations are configured through the bot's UI/store,
        // not through MONITORING_CHANNEL_* environment variables.
        outputChannelId: String(chatId),
        outputTitle: update.chat.title || 'Monitoring Channel'
      });
      console.log(`[CHANNEL MONITOR] Auto-enabled for ${chatId}`);
    } else if (['left','kicked'].includes(newStatus)) {
      const existing = getChannelMonitor(chatId);
      if (existing) removeChannelMonitor(chatId);
    }
    return;
  }
  if (['group', 'supergroup'].includes(update.chat?.type)) {
    upsertChat({ ...update.chat, botStatus: newStatus });
  }
  if (newStatus === 'member' || newStatus === 'administrator') {
    const addedBy = update.from?.id;
    if (addedBy) {
      const gs = getGroupSettings(chatId);
      if (!gs.addedBy) setGroupSettings(chatId, { ...gs, addedBy });
    }
  }
});

// ======================================= //
// 🔗 handleConnect
// ======================================= //
async function handleConnect(chatId, userId, number) {
  const loading = await safeRichTextMessage(chatId,
    `<code>${makeBar(20)}</code>\n${E.hourglass} Meminta pairing untuk <code>${number}</code>...`,
    { parse_mode: 'HTML' });
  try {
    await startWhatsAppConnection({
      number, userId,
      pairingPrefix: c.PAIRING_CODE_PREFIX,
      onConnecting: async () => safeEdit(bot, chatId, loading.message_id,
        `<code>${makeBar(50)}</code>\n${E.hourglass} Inisialisasi sesi...\nNomor: <code>${number}</code>`, { parse_mode: 'HTML' }),
      onCode: async (formatted) => safeEdit(bot, chatId, loading.message_id,
        `<blockquote><b>${E.key} PAIRING CODE</b></blockquote>\nNomor: <code>${number}</code>\nKode: <code>${formatted}</code>\n<blockquote>Masukkan di WhatsApp → Linked Devices → Link with phone number</blockquote>`,
        { parse_mode: 'HTML' }),
      onOpen: async () => {
        const pw = getSenderPassword(number);
        await bot.editMessageText(
          `${E.check} <b>Sender Berhasil Tersambung!</b>\n` +
          `Nomor: <code>${number}</code>\nStatus: <code>ONLINE ${E.check}</code>\n\n` +
          `<blockquote>${pw ? `${E.lock} Password aktif.\nSender ini dilindungi password.` : `${E.warning} Sender belum dipassword.\nKlik tombol untuk mengamankan sender kamu.`}</blockquote>`,
          {
            chat_id: chatId,
            message_id: loading.message_id,
            parse_mode: 'HTML',
            reply_markup: {
              inline_keyboard: [[
                pw
                  ? { text: '✿ Ganti Password ✿', callback_data: `set_sender_pw_${number}`, style: 'primary', icon_custom_emoji_id: '5296369303661067030' }
                  : { text: '✿ Tambahkan Password ✿', callback_data: `set_sender_pw_${number}`, style: 'primary', icon_custom_emoji_id: '5251203410396458957' },
                { text: '✿ Detele Password ✿', callback_data: `rm_sender_pw_${number}`, style: 'danger', icon_custom_emoji_id: '4958534924278694938' }
              ]]
            }
          }).catch(() => {});
      },
      onClose: async (err) => safeEdit(bot, chatId, loading.message_id,
        `${E.warning} <b>Koneksi terputus</b>\nNomor: <code>${number}</code>\nDetail: <code>${htmlEscape(err.message || 'closed')}</code>`, { parse_mode: 'HTML' })
    });
  } catch (e) {
    await safeEdit(bot, chatId, loading.message_id,
      `${E.cross} Gagal connect: <code>${htmlEscape(e.message)}</code>`, { parse_mode: 'HTML' });
  }
}


// Unfollow detection otomatis dinonaktifkan. Membership hanya diverifikasi saat user mengakses bot.
// ======================================= //
// 🕌 AUTO ADZAN — Jadwal Sholat Jakarta
// ======================================= //

// Cache jadwal harian { date:'YYYY-MM-DD', times:{Fajr,Dhuhr,Asr,Maghrib,Isha} }
let _adzanScheduleCache = null;
// Set key yang sudah di-broadcast hari ini (cegah double kirim)
const _adzanFired = new Set();
// Path file audio (letakkan Adzan.mp3 di folder assets/ dalam project)
const ADZAN_AUDIO_PATH = path.join(__dirname, '..', 'assets', 'Adzan.mp3');

const PRAYER_NAMES = {
  Fajr:    'Subuh',
  Dhuhr:   'Dzuhur',
  Asr:     'Ashar',
  Maghrib: 'Maghrib',
  Isha:    'Isya'
};

// Fetch jadwal dari aladhan.com, dicache per hari
async function fetchAdzanSchedule() {
  const todayStr = moment().tz(c.TIMEZONE).format('YYYY-MM-DD');
  if (_adzanScheduleCache && _adzanScheduleCache.date === todayStr) {
    return _adzanScheduleCache.times;
  }
  try {
    const res = await axios.get('https://api.aladhan.com/v1/timingsByCity', {
      params: { city: 'Jakarta', country: 'Indonesia', method: 11 },
      timeout: 15000
    });
    const t = res.data?.data?.timings;
    if (!t) throw new Error('Format API tidak sesuai');
    const times = {
      Fajr:    (t.Fajr    || '').replace(/ \(WIB\)/g, ''),
      Dhuhr:   (t.Dhuhr   || '').replace(/ \(WIB\)/g, ''),
      Asr:     (t.Asr     || '').replace(/ \(WIB\)/g, ''),
      Maghrib: (t.Maghrib || '').replace(/ \(WIB\)/g, ''),
      Isha:    (t.Isha    || '').replace(/ \(WIB\)/g, '')
    };
    _adzanScheduleCache = { date: todayStr, times };
    console.log('[ADZAN] Jadwal hari ini:', JSON.stringify(times));
    return times;
  } catch (err) {
    console.error('[ADZAN] Gagal fetch jadwal:', err.message);
    return null;
  }
}

async function broadcastAdzan(prayerKey) {
  const prayerName = PRAYER_NAMES[prayerKey] || prayerKey;
  const nowStr   = moment().tz(c.TIMEZONE).format('HH:mm');
  const tanggal  = moment().tz(c.TIMEZONE).format('dddd, DD MMMM YYYY');

  const photoCaption =
    `${E.masjid} <b>Waktu ${prayerName} - Jakarta Dan Sekitarnya</b>\n` +
    `${E.tgl} ${tanggal} | ${E.jam} ${nowStr} WIB\n\n` +
    `<i>Segera berwudhu dan tunaikan sholat ${prayerName}.</i>\n` +
    `<blockquote>اَللهُ أَكْبَرُ — Allahu Akbar</blockquote>`;

  const audioCaption =
    `${E.lonceng} <b>Adzan ${prayerName} telah berkumandang</b>\n` +
    `<i>Sholatlah sebelum kamu disholatkan.</i>`;

  const users = getAllUsers();
  console.log(`[ADZAN] Broadcast ${prayerName} ke ${users.length} user...`);

  // Baca audio sekali sebagai Buffer
  let audioBuffer = null;
  if (fs.existsSync(ADZAN_AUDIO_PATH)) {
    try { audioBuffer = fs.readFileSync(ADZAN_AUDIO_PATH); } catch (e) {
      console.error('[ADZAN] Gagal baca file audio:', e.message);
    }
  } else {
    console.warn('[ADZAN] File audio tidak ditemukan:', ADZAN_AUDIO_PATH);
  }

  const DELETE_DELAY = 30 * 60 * 1000; // 30 menit

  for (const user of users) {
    const chatId = user.id;
    try {
      // 1. Kirim foto + caption (pakai c.BANNER_URL — sudah pasti ada di config)
      let photoMsg = null;
      try {
        photoMsg = await bot.sendPhoto(chatId, c.BANNER_URL, {
          caption: photoCaption,
          parse_mode: 'HTML'
        });
      } catch (photoErr) {
        console.error(`[ADZAN] Gagal kirim foto ke ${chatId}:`, photoErr.message);
      }

      await new Promise(r => setTimeout(r, 120));

      // 2. Kirim audio
      let audioMsg = null;
      if (audioBuffer) {
        try {
          audioMsg = await bot.sendAudio(chatId, audioBuffer, {
            caption: audioCaption,
            parse_mode: 'HTML',
            title: `Adzan ${prayerName}`,
            performer: 'mellstecuu Fix Multi Device'
          }, { filename: 'Adzan.mp3', contentType: 'audio/mpeg' });
        } catch (audioErr) {
          console.error(`[ADZAN] Gagal kirim audio ke ${chatId}:`, audioErr.message);
        }
      }

      // 3. Auto-delete setelah 30 menit
      if (photoMsg?.message_id) {
        setTimeout(() => bot.deleteMessage(chatId, photoMsg.message_id).catch(() => {}), DELETE_DELAY);
      }
      if (audioMsg?.message_id) {
        setTimeout(() => bot.deleteMessage(chatId, audioMsg.message_id).catch(() => {}), DELETE_DELAY);
      }

      await new Promise(r => setTimeout(r, 80));
    } catch (e) {
      console.error(`[ADZAN] Error kirim ke ${chatId}:`, e.message);
    }
  }

  console.log(`[ADZAN] Selesai broadcast ${prayerName}.`);
}

// Cek setiap menit apakah waktu sholat sudah tiba
async function checkAdzanTime() {
  const now      = moment().tz(c.TIMEZONE);
  const todayStr = now.format('YYYY-MM-DD');
  const hhMm     = now.format('HH:mm');

  if (!_adzanScheduleCache || _adzanScheduleCache.date !== todayStr) {
    _adzanFired.clear();
  }

  const times = await fetchAdzanSchedule();
  if (!times) return;

  for (const [key, timeStr] of Object.entries(times)) {
    if (!timeStr) continue;
    const fireKey = `${todayStr}_${key}`;
    if (_adzanFired.has(fireKey)) continue;

    // Cocokkan menit sekarang dengan jadwal
    if (hhMm === timeStr.substring(0, 5)) {
      _adzanFired.add(fireKey);
      console.log(`[ADZAN] ⏰ ${PRAYER_NAMES[key] || key} (${timeStr}) — broadcast dimulai`);
      broadcastAdzan(key).catch(e => console.error('[ADZAN] Error broadcast:', e.message));
    }
  }
}

// Sinkronkan ke menit berikutnya agar tepat waktu (tidak telat)
function scheduleAdzanChecker() {
  fetchAdzanSchedule().catch(() => {}); // pre-fetch saat start

  const msUntilNextMinute = (60 - moment().seconds()) * 1000 - moment().milliseconds() + 500;
  setTimeout(() => {
    checkAdzanTime();
    setInterval(checkAdzanTime, 60 * 1000);
  }, msUntilNextMinute);

  console.log('[ADZAN] ✅ Scheduler aktif — Jakarta.');
}

scheduleAdzanChecker();

// Reset jadwal & cache tiap hari jam 00:01 WIB
const _msUntilMidnight = moment().tz(c.TIMEZONE).endOf('day').diff(moment()) + 60000;
setTimeout(function _refreshAdzanDaily() {
  _adzanScheduleCache = null;
  _adzanFired.clear();
  fetchAdzanSchedule().catch(() => {});
  setInterval(() => {
    _adzanScheduleCache = null;
    _adzanFired.clear();
    fetchAdzanSchedule().catch(() => {});
  }, 24 * 60 * 60 * 1000);
}, _msUntilMidnight);

// ======================================= //
// 🧰 EXTRA STABLE TOOLS — TAGALL / BACKUP / RINEM
// ======================================= //

function mentionUserForTag(user) {
  const name = [user.first_name, user.last_name].filter(Boolean).join(' ').trim() || 'Member';
  return `<a href="tg://user?id=${String(user.id)}">${htmlEscape(name)}</a>`;
}

function chunkText(text, max = 3800) {
  const out = [];
  let current = '';
  for (const line of String(text).split('\n')) {
    if ((current + (current ? '\n' : '') + line).length > max) {
      if (current) out.push(current);
      current = line;
    } else {
      current += (current ? '\n' : '') + line;
    }
  }
  if (current) out.push(current);
  return out;
}

function toolBackKeyboard() {
  return { inline_keyboard: [
    [{ text: '🧰 Tools', callback_data: 'menu_alat' }],
    [{ text: '↩️ Menu Utama', callback_data: 'back_menu' }]
  ]};
}

function getBackupSummary() {
  const dataDir = path.join(__dirname, '..', 'data');
  const state = readState();
  const summary = { files: 0, bytes: 0, users: Object.keys(state.users || {}).length, groups: Object.values(state.chats || {}).filter(chat => ['group','supergroup'].includes(chat.type)).length, privateChats: Object.values(state.chats || {}).filter(chat => chat.type === 'private').length };
  const scan = dir => {
    if (!fs.existsSync(dir)) return;
    for (const name of fs.readdirSync(dir)) {
      if (name === '.DS_Store') continue;
      const lower = name.toLowerCase();
      if (['.env', '.env.local', '.env.production', 'token.txt', 'bot_token.txt', 'api_keys.json', 'secrets.json'].includes(lower)) continue;
      const full = path.join(dir, name);
      const st = fs.statSync(full);
      if (st.isDirectory()) scan(full);
      else { summary.files += 1; summary.bytes += st.size; }
    }
  };
  scan(dataDir);
  return summary;
}

function formatBytes(bytes) {
  const n = Number(bytes || 0);
  if (n < 1024) return `${n} B`;
  if (n < 1024 ** 2) return `${(n / 1024).toFixed(1)} KB`;
  if (n < 1024 ** 3) return `${(n / 1024 ** 2).toFixed(2)} MB`;
  return `${(n / 1024 ** 3).toFixed(2)} GB`;
}

async function makeDataBackupZip() {
  const zip = new JSZip();
  const dataDir = path.join(__dirname, '..', 'data');
  const summary = getBackupSummary();
  if (fs.existsSync(dataDir)) {
    const addDir = (dir, prefix = '') => {
      for (const name of fs.readdirSync(dir)) {
        if (name === '.DS_Store') continue;
        const lower = name.toLowerCase();
        if (['.env', '.env.local', '.env.production', 'token.txt', 'bot_token.txt', 'api_keys.json', 'secrets.json'].includes(lower)) continue;
        const full = path.join(dir, name);
        const rel = path.join(prefix, name).replace(/\\/g, '/');
        const st = fs.statSync(full);
        if (st.isDirectory()) addDir(full, rel);
        else zip.file(rel, fs.readFileSync(full));
      }
    };
    addDir(dataDir);
  }
  zip.file('BACKUP-INFO.txt',
    `MELLSTECUU MD — BACKUP\n` +
    `Created: ${new Date().toISOString()}\n` +
    `Source: data/\n` +
    `Files: ${summary.files}\n` +
    `Users: ${summary.users}\n` +
    `Groups: ${summary.groups}\n` +
    `Private chats: ${summary.privateChats}\n` +
    `Source size: ${formatBytes(summary.bytes)}\n` +
    `Note: .env, bot token, API keys, and other runtime secrets are intentionally excluded.\n`
  );
  return zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE', compressionOptions: { level: 6 } });
}

async function sendAutoBackupStateToOwner(stamp, reason = 'scheduled') {
  const ownerId = String(process.env.OWNER_ID || c.OWNER_ID || c.ID || '').trim();
  const statePath = path.join(__dirname, '..', 'data', 'bot-state.json');
  if (!ownerId) throw new Error('OWNER_ID belum dikonfigurasi.');
  if (!fs.existsSync(statePath)) throw new Error('data/bot-state.json belum tersedia.');

  // Kirim salinan state mentah ke owner sebagai JSON. Tidak menyertakan .env/token/API key.
  const stateBuffer = await fs.promises.readFile(statePath);
  const filename = `bot-state-${stamp}.json`;
  const caption =
    `💾 <b>AUTO BACKUP STATE</b>\n\n` +
    `📄 File: <code>${htmlEscape(filename)}</code>\n` +
    `🕒 Alasan: <code>${htmlEscape(reason)}</code>\n` +
    `📦 Ukuran: <code>${formatBytes(stateBuffer.length)}</code>\n\n` +
    `🔐 Ini hanya berisi <code>data/bot-state.json</code>; credential <code>.env</code>, token bot, API key, dan secret runtime tidak ikut dikirim.`;

  await bot.sendDocument(ownerId, stateBuffer, {
    caption,
    parse_mode: 'HTML'
  }, { filename, contentType: 'application/json' });

  return { filename, bytes: stateBuffer.length };
}

async function runAutoBackup(reason = 'scheduled') {
  const backupDir = path.join(__dirname, '..', 'backups');
  const retention = Math.max(1, Number(process.env.AUTO_BACKUP_RETENTION || 7));
  try {
    await fs.promises.mkdir(backupDir, { recursive: true });
    const zip = await makeDataBackupZip();
    const stamp = moment().tz(c.TIMEZONE).format('YYYYMMDD-HHmmss');
    const filename = `mellstecuu-auto-${stamp}.zip`;
    await fs.promises.writeFile(path.join(backupDir, filename), zip);
    const files = (await fs.promises.readdir(backupDir)).filter(name => /^mellstecuu-auto-\d{8}-\d{6}\.zip$/.test(name)).sort().reverse();
    for (const old of files.slice(retention)) { try { await fs.promises.unlink(path.join(backupDir, old)); } catch {} }

    // Local ZIP tetap dibuat seperti sebelumnya. Pengiriman bot-state.json ke owner
    // dibuat sebagai langkah terpisah agar kegagalan Telegram tidak menggagalkan backup lokal.
    let ownerDelivery = { ok: false };
    try {
      const sent = await sendAutoBackupStateToOwner(stamp, reason);
      ownerDelivery = { ok: true, ...sent };
      console.log(`[AUTO BACKUP] STATE TERKIRIM KE OWNER — ${sent.filename}`);
    } catch (sendErr) {
      console.error(`[AUTO BACKUP] STATE GAGAL TERKIRIM KE OWNER — ${reason}:`, sendErr.message);
    }

    console.log(`[AUTO BACKUP] OK — ${reason} — ${filename}`);
    return { ok:true, filename, ownerDelivery };
  } catch (e) { console.error(`[AUTO BACKUP] GAGAL — ${reason}:`, e.message); return { ok:false, error:e.message }; }
}

function scheduleAutoBackup() {
  const hours = Math.max(1, Number(process.env.AUTO_BACKUP_HOURS || 6));
  const interval = hours * 60 * 60 * 1000;
  setTimeout(() => {
    runAutoBackup('startup').catch(()=>{});
    setInterval(() => runAutoBackup('scheduled').catch(()=>{}), interval);
  }, 2 * 60 * 1000);
  console.log(`[AUTO BACKUP] Scheduler aktif — setiap ${hours} jam, retention ${Math.max(1, Number(process.env.AUTO_BACKUP_RETENTION || 7))}.`);
}

scheduleAutoBackup();

class SimpleChess {
  constructor() {
    const back = ['r','n','b','q','k','b','n','r'];
    this._board = [
      back.map(type => ({type,color:'b'})),
      Array.from({length:8},()=>({type:'p',color:'b'})),
      Array(8).fill(null), Array(8).fill(null), Array(8).fill(null), Array(8).fill(null),
      Array.from({length:8},()=>({type:'p',color:'w'})),
      back.map(type => ({type,color:'w'}))
    ];
    this._turn = 'w';
    this._history = [];
  }
  turn() { return this._turn; }
  board() { return this._board.map(row => row.map(p => p ? {...p} : null)); }
  _coord(square) {
    if (!/^[a-h][1-8]$/i.test(square || '')) throw new Error('Kotak tidak valid.');
    return [8-Number(square[1]), square.toLowerCase().charCodeAt(0)-97];
  }
  _square(r,c) { return String.fromCharCode(97+c)+(8-r); }
  _pathClear(fr,fc,tr,tc) {
    const dr=Math.sign(tr-fr), dc=Math.sign(tc-fc);
    let r=fr+dr,c=fc+dc;
    while(r!==tr || c!==tc) {
      if(this._board[r][c]) return false;
      r+=dr; c+=dc;
    }
    return true;
  }
  _legal(from,to) {
    const [fr,fc]=this._coord(from), [tr,tc]=this._coord(to);
    const p=this._board[fr][fc], target=this._board[tr][tc];
    if(!p || p.color!==this._turn || (target && target.color===p.color)) return false;
    const dr=tr-fr, dc=tc-fc, adr=Math.abs(dr), adc=Math.abs(dc);
    if(p.type==='p') {
      const dir=p.color==='w'?-1:1, start=p.color==='w'?6:1;
      if(dc===0 && dr===dir && !target) return true;
      if(dc===0 && dr===2*dir && fr===start && !target && !this._board[fr+dir][fc]) return true;
      return adr===1 && dr===dir && !!target;
    }
    if(p.type==='n') return (adr===2&&adc===1)||(adr===1&&adc===2);
    if(p.type==='b') return adr===adc && this._pathClear(fr,fc,tr,tc);
    if(p.type==='r') return (dr===0||dc===0) && this._pathClear(fr,fc,tr,tc);
    if(p.type==='q') return ((dr===0||dc===0)||(adr===adc)) && this._pathClear(fr,fc,tr,tc);
    if(p.type==='k') return Math.max(adr,adc)===1;
    return false;
  }
  moves(opts={}) {
    const out=[];
    if(opts.square) {
      const [r,c]=this._coord(opts.square);
      const p=this._board[r][c];
      if(!p || p.color!==this._turn) return out;
      for(let tr=0;tr<8;tr++) for(let tc=0;tc<8;tc++) {
        const to=this._square(tr,tc);
        if(this._legal(opts.square,to)) out.push({from:opts.square.toLowerCase(),to});
      }
      return out;
    }
    return out;
  }
  move({from,to,promotion='q'}) {
    from=String(from).toLowerCase(); to=String(to).toLowerCase();
    if(!this._legal(from,to)) throw new Error('Langkah tidak legal.');
    const [fr,fc]=this._coord(from), [tr,tc]=this._coord(to);
    const p=this._board[fr][fc];
    const captured=this._board[tr][tc];
    this._board[tr][tc]={type:p.type,color:p.color};
    this._board[fr][fc]=null;
    if(p.type==='p' && (tr===0||tr===7)) this._board[tr][tc].type=['q','r','b','n'].includes(String(promotion).toLowerCase())?String(promotion).toLowerCase():'q';
    this._history.push({from,to,piece:p.type,captured});
    this._turn=this._turn==='w'?'b':'w';
    return {from,to};
  }
  isGameOver() {
    const hasKing = ['w','b'].every(color => this._board.some(row => row.some(p => p?.type==='k' && p.color===color)));
    if(!hasKing) return true;
    for(let r=0;r<8;r++) for(let c=0;c<8;c++) {
      const p=this._board[r][c];
      if(p?.color===this._turn) {
        const sq=this._square(r,c);
        if(this.moves({square:sq}).length) return false;
      }
    }
    return true;
  }
}

function chessBoardText(chess) {
  const map = { p:'♟', n:'♞', b:'♝', r:'♜', q:'♛', k:'♚',
                P:'♙', N:'♘', B:'♗', R:'♖', Q:'♕', K:'♔' };
  const board = chess.board();
  const lines = ['<pre>  a b c d e f g h'];
  for (let r = 0; r < 8; r++) {
    lines.push(`${8-r} ${board[r].map(p => p ? map[p.color === 'w' ? p.type.toUpperCase() : p.type] : '·').join(' ')} ${8-r}`);
  }
  lines.push('  a b c d e f g h</pre>');
  return lines.join('\n');
}

function chessKeyboard(game, selected = null) {
  if (selected) {
    let moves = [];
    try { moves = game.chess.moves({ square: selected, verbose: true }); } catch {}
    const rows = moves.map(m => [{ text: `${m.from} → ${m.to}${m.promotion ? '='+m.promotion.toUpperCase() : ''}`, callback_data: `chess_move_${game.chatId}_${m.from}_${m.to}` }]);
    rows.push([{ text: '↩️ Pilih Bidak Lain', callback_data: `chess_select_${game.chatId}` }]);
    rows.push([{ text: '🛑 Hentikan', callback_data: `chess_stop_${game.chatId}` }]);
    return { inline_keyboard: rows.slice(0, 12) };
  }
  const board = game.chess.board();
  const rows = [];
  for (let r = 0; r < 8; r++) {
    const row = [];
    for (let c = 0; c < 8; c++) {
      const p = board[r][c];
      if (p && p.color === game.chess.turn()) {
        const sq = String.fromCharCode(97+c) + (8-r);
        row.push({ text: `${p.type.toUpperCase()} ${sq}`, callback_data: `chess_pick_${game.chatId}_${sq}` });
      }
    }
    if (row.length) rows.push(row.slice(0, 4));
  }
  rows.push([{ text: '🛑 Hentikan', callback_data: `chess_stop_${game.chatId}` }]);
  return { inline_keyboard: rows };
}

async function sendChessState(chatId, game, extra = '') {
  const turn = game.chess.turn() === 'w' ? 'Putih' : 'Hitam';
  const status = game.chess.isGameOver()
    ? `🏁 <b>Game selesai.</b>`
    : `Giliran: <b>${turn}</b>`;
  return safeRichSendMessage(chatId,
    `♟️ <b>CATUR</b>\n\n${status}\n${extra ? extra + '\n\n' : ''}${chessBoardText(game.chess)}`,
    { parse_mode: 'HTML', reply_markup: chessKeyboard(game) });
}

function svgEscape(value='') {
  return String(value).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&apos;');
}

function normalizeCallDuration(raw='') {
  const v=String(raw).trim();
  let m=v.match(/^(\d{1,4}):(\d{2})$/);
  if(m){
    const totalMinutes=Number(m[1]), seconds=Number(m[2]);
    if(seconds>59) throw new Error('Detik harus 00–59.');
    const h=Math.floor(totalMinutes/60), min=totalMinutes%60;
    return `${String(h).padStart(2,'0')}:${String(min).padStart(2,'0')}:${String(seconds).padStart(2,'0')}`;
  }
  m=v.match(/^(\d{1,3}):(\d{2}):(\d{2})$/);
  if(m){
    const h=Number(m[1]), min=Number(m[2]), sec=Number(m[3]);
    if(min>59 || sec>59) throw new Error('Menit dan detik harus 00–59.');
    return `${String(h).padStart(2,'0')}:${String(min).padStart(2,'0')}:${String(sec).padStart(2,'0')}`;
  }
  const plain=v.match(/^(\d+)$/);
  if(plain){
    const totalMinutes=Number(plain[1]);
    if(totalMinutes>5999) throw new Error('Durasi terlalu panjang. Maksimal 99:59 menit.');
    const h=Math.floor(totalMinutes/60), min=totalMinutes%60;
    return `${String(h).padStart(2,'0')}:${String(min).padStart(2,'0')}:00`;
  }
  throw new Error('Durasi tidak valid. Gunakan mm:ss atau hh:mm:ss, contoh 06:50:00.');
}

bot.onText(/^\/devlog$/i, async (msg) => {
  if (String(msg.from?.id) !== String(c.ID) && !(await isGroupAdmin(msg.chat.id,msg.from.id))) return safeRichTextMessage(msg.chat.id,'🔒 Dev log hanya untuk owner atau admin grup.');
  const rows = devErrorLog.slice(-15).reverse().map(e => `[${new Date(e.time).toLocaleString('id-ID')}] ${e.type}\n${e.message}`).join('\n\n');
  return safeRichTextMessage(msg.chat.id, `<b>🐞 DEV LOG</b>\n\n<pre>${htmlEscape(rows || 'Belum ada runtime error tercatat.')}</pre>`, {parse_mode:'HTML'});
});

bot.onText(/^\/devcheck$/i, async (msg) => {
  if (String(msg.from?.id) !== String(c.ID) && !(await isGroupAdmin(msg.chat.id,msg.from.id))) {
    return safeRichTextMessage(msg.chat.id,'🔒 Dev Check hanya untuk owner atau admin grup.',{parse_mode:'HTML'});
  }
  const checks = [
    ['Node.js',process.version],
    ['Platform',`${process.platform}/${process.arch}`],
    ['FFmpeg',ffmpegPath?'OK':'TIDAK TERSEDIA'],
    ['BOT_TOKEN',process.env.BOT_TOKEN?'TERISI':'KOSONG'],
    ['GEMINI_API_KEY', process.env.GEMINI_API_KEY ? 'TERISI' : 'KOSONG'],
      ['GEMINI_MODEL', AI_CONFIG.geminiModel],
    ['OPENROUTER_API_KEY', process.env.OPENROUTER_API_KEY ? 'TERISI' : 'KOSONG'],
    ['OPENROUTER_MODEL', AI_CONFIG.openrouterModel],
        ['Data directory',fs.existsSync(path.join(__dirname,'..','data'))?'OK':'BELUM ADA'],
    ['Runtime',runtime()]
  ];
  return safeRichTextMessage(msg.chat.id,`🩺 <b>DEV CHECK</b>\n\n${checks.map(([k,v])=>`• <b>${htmlEscape(k)}</b>: <code>${htmlEscape(v)}</code>`).join('\n')}`,{parse_mode:'HTML'});
});


// /tonaked tidak melakukan transformasi/generasi nudity. Alias aman ini membuat
// sticker teks bergaya clean/meme sehingga nama command tetap mudah ditemukan.
bot.onText(/^\/tonaked(?:\s+([\s\S]+))?$/i, async (msg, match) => {
  const text = (match?.[1] || '').trim();
  if (!text) return safeRichTextMessage(msg.chat.id,
    `📝 <b>TONAKED — SAFE TEXT MAKER</b>\n\n` +
    `Fitur ini hanya membuat teks/meme sticker dan tidak mengubah foto menjadi telanjang.\n` +
    `Format: <code>/tonaked teks kamu</code>\n\nContoh: <code>/tonaked coding dulu, panik kemudian</code>`,
    {parse_mode:'HTML'});
  // Reuse existing Brat endpoint through a direct internal call by sending a
  // clear instruction; no nudity processing is performed here.
  return safeRichTextMessage(msg.chat.id,`📝 <b>TONAKED / SAFE MEME</b>\n\n<blockquote>${htmlEscape(text)}</blockquote>\n\n<i>Mode aman: teks saja.</i>`,{parse_mode:'HTML'});
});

// /callone — mention anggota satu per satu. Telegram tidak menyediakan get-all-members,
// jadi sumber anggota adalah cache anggota yang terlihat bot + daftar admin Telegram.
const callOneRunning = new Set();
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

async function collectTagMembers(chatId) {
  const members = new Map();
  for (const u of getGroupMembers(chatId)) {
    if (u?.id && u.active !== false && !u.is_bot) members.set(String(u.id), u);
  }
  try {
    const admins = await bot.getChatAdministrators(chatId);
    for (const a of admins || []) {
      if (a?.user?.id && !a.user.is_bot) members.set(String(a.user.id), {...a.user, active:true});
    }
  } catch (e) {
    console.warn('[CALLONE] getChatAdministrators:', e?.message || e);
  }
  return [...members.values()].filter(u => u?.id && !u.is_bot && u.active !== false);
}

async function sendCallOneMessage(chatId, text, options = {}) {
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      return await safeRichTextMessage(chatId, text, options);
    } catch (e) {
      const retry = Number(e?.response?.body?.parameters?.retry_after || e?.parameters?.retry_after || 0);
      if (retry > 0 && attempt < 2) {
        await sleep(Math.min(Math.max(retry * 1000, 1000), 15000));
        continue;
      }
      throw e;
    }
  }
}

async function runCallOne(chatId, requesterId, prefix = 'Panggilan anggota grup') {
  const key = String(chatId);
  if (callOneRunning.has(key)) {
    return safeRichTextMessage(chatId, '⏳ <b>Call One sedang berjalan.</b> Tunggu sampai selesai.', {parse_mode:'HTML'}).catch(()=>{});
  }
  callOneRunning.add(key);
  try {
    const list = await collectTagMembers(chatId);
    if (!list.length) return safeRichTextMessage(chatId, 'ℹ️ <b>Belum ada anggota yang terdeteksi.</b>', {parse_mode:'HTML'});
    await safeRichTextMessage(chatId, `📣 <b>${htmlEscape(prefix)}</b>\n\nMenandai ${list.length} anggota satu per satu…`, {parse_mode:'HTML'});
    let sent = 0;
    let failed = 0;
    for (const u of list) {
      try {
        await sendCallOneMessage(chatId, mentionUserForTag(u), {parse_mode:'HTML', disable_web_page_preview:true});
        sent++;
      } catch (e) {
        failed++;
        console.warn('[CALLONE] send:', e?.message || e);
      }
      // Telegram flood control: one separate message per member, deliberately paced.
      await sleep(120);
    }
    return safeRichTextMessage(chatId, `✅ <b>CALL ONE selesai.</b>\n\n👥 Terkirim: <b>${sent}</b>\n⚠️ Gagal: <b>${failed}</b>\n🤖 Bot: tidak ditag.`, {parse_mode:'HTML'}).catch(()=>{});
  } finally {
    callOneRunning.delete(key);
  }
}

bot.onText(/^\/callone(?:\s+([\s\S]+))?$/i, async (msg, match) => {
  if (!['group','supergroup'].includes(msg.chat.type)) return safeRichTextMessage(msg.chat.id, '❌ <b>/callone hanya bisa digunakan di grup.</b>', {parse_mode:'HTML'});
  if (!(await requireGroupAdmin(msg))) return;
  const prefix = String(match?.[1] || 'Panggilan anggota grup').trim().slice(0, 180);
  return runCallOne(msg.chat.id, msg.from.id, prefix || 'Panggilan anggota grup');
});

// /tagall — men-tag seluruh anggota yang diketahui bot di grup ini.
// Catatan API: Telegram Bot API tidak menyediakan endpoint untuk mengambil
// daftar seluruh member grup. Agar daftar selalu diperbarui, bot mencatat
// pengirim pesan, anggota baru, dan perubahan status anggota.
bot.onText(/^\/tagall(?:\s+([\s\S]+))?$/i, async (msg, match) => {
  if (!['group','supergroup'].includes(msg.chat.type)) {
    return safeRichTextMessage(msg.chat.id, '❌ <b>/tagall hanya bisa digunakan di grup.</b>', { parse_mode:'HTML' });
  }
  if (!(await requireGroupAdmin(msg))) return;

  const chatId = msg.chat.id;
  const members = new Map();
  for (const u of getGroupMembers(chatId)) {
    if (u?.id && u.active !== false) members.set(String(u.id), u);
  }

  // Admin selalu dicoba ulang karena Telegram menyediakan daftar admin.
  try {
    const admins = await bot.getChatAdministrators(chatId);
    for (const a of admins || []) {
      if (a?.user?.id && !a.user.is_bot) members.set(String(a.user.id), {...a.user, active:true});
    }
  } catch (e) {
    console.warn('[TAGALL] getChatAdministrators:', e.message);
  }

  const list = [...members.values()].filter(u => u && !u.is_bot && u.active !== false);
  if (!list.length) {
    return safeRichTextMessage(chatId,
      'ℹ️ <b>Belum ada anggota yang terdeteksi.</b>\n\n' +
      'Pastikan bot sudah aktif di grup dan memiliki izin yang diperlukan.',
      {parse_mode:'HTML'});
  }

  const prefix = String(match?.[1] || 'Panggilan anggota grup').trim().slice(0, 180);
  const lines = [`📢 <b>${htmlEscape(prefix || 'Panggilan anggota grup')}</b>`, ''];
  for (const u of list) lines.push(mentionUserForTag(u));

  // Kirim bertahap agar tidak melewati batas 4096 karakter Telegram.
  const chunks = chunkText(lines.join('\n'));
  let sent = 0;
  for (const part of chunks) {
    try {
      await safeRichTextMessage(chatId, part, {
        parse_mode:'HTML',
        disable_web_page_preview:true,
        allow_sending_without_reply:true
      });
      sent++;
    } catch (e) {
      console.error('[TAGALL] send chunk error:', e.message);
      // Jangan membuat bot crash hanya karena satu chunk gagal.
    }
  }

  if (!sent) {
    return safeRichTextMessage(chatId, '❌ <b>Tag All gagal dikirim.</b> Coba lagi dan pastikan bot masih memiliki izin mengirim pesan.', {parse_mode:'HTML'});
  }
});

// Channel posts: setiap channel yang terdaftar/auto-terdaftar mendapat Anti Drugs.
// Admin tidak perlu mengaktifkan toggle grup karena channel berjalan sebagai broadcast.
async function handleMonitoredChannelPost(post) {
  try {
    const channelId = post?.chat?.id;
    if (!channelId || post.chat.type !== 'channel') return;
    const monitor = await getEffectiveChannelMonitor(channelId);
    if (!monitor?.enabled || monitor.antiDrugs === false) return;
    const fileName = post.document?.file_name || post.video?.file_name || post.audio?.file_name || post.animation?.file_name || '';
    const combined = [post.text || '', post.caption || '', fileName].filter(Boolean).join('\n');
    if (!containsDrugContent(combined, post)) return;
    try { await bot.deleteMessage(channelId, post.message_id); } catch (e) {
      console.warn('[CHANNEL ANTIDRUGS] delete:', e.message);
      return;
    }
    await safeRichTextMessage(channelId,
      `<blockquote><b>POST DIHAPUS OTOMATIS</b></blockquote>\n\n` +
      `Sistem keamanan channel menghapus posting yang terdeteksi melanggar filter otomatis.`,
      {parse_mode:'HTML'}).catch(()=>{});
  } catch (e) {
    console.warn('[CHANNEL ANTIDRUGS] handler:', e.message);
  }
}

bot.on('channel_post', handleMonitoredChannelPost);
bot.on('edited_channel_post', handleMonitoredChannelPost);

// Re-check edited group messages so a clean message cannot be edited into
// unsafe visual/text content after the first moderation pass.
bot.on('edited_message', async (msg) => {
  try {
    if (!msg?.chat || !['group','supergroup'].includes(msg.chat.type) || !msg.from || msg.from.is_bot) return;
    const userId=msg.from.id, chatId=msg.chat.id;
    const gs=getGroupSettings(chatId);
    if (!(gs.antiporno || gs.antidrugs)) return;
    if (await isGroupModerationExempt(chatId,userId)) return;
    const category=await runEnhancedGroupMediaSafety(msg,gs,userId);
    if (!category) {
      const textCheck=[msg.text||'',msg.caption||'',msg.document?.file_name||msg.video?.file_name||msg.animation?.file_name||''].filter(Boolean).join('\n');
      if (category===null && ((gs.antiporno && containsPornoContent(textCheck)) || (gs.antidrugs && containsDrugContent(textCheck,msg)))) {
        const fallbackCategory=gs.antiporno && containsPornoContent(textCheck) ? 'antiporno' : 'antidrugs';
        try { await bot.deleteMessage(chatId,msg.message_id); } catch {}
        const mention=msg.from.username?`@${htmlEscape(msg.from.username)}`:`<a href="tg://user?id=${userId}">${htmlEscape(msg.from.first_name||'Member')}</a>`;
        const strike=registerModerationStrike(chatId,userId,fallbackCategory);
        await applyModerationAction(chatId,userId,strike,fallbackCategory,mention,msg.message_id);
      }
      return;
    }
    try { await bot.deleteMessage(chatId,msg.message_id); } catch {}
    const mention=msg.from.username?`@${htmlEscape(msg.from.username)}`:`<a href="tg://user?id=${userId}">${htmlEscape(msg.from.first_name||'Member')}</a>`;
    const strike=registerModerationStrike(chatId,userId,category);
    await applyModerationAction(chatId,userId,strike,category,mention,msg.message_id);
  } catch(e) { console.warn('[EDITED GROUP SAFETY]',e?.message||e); }
});

// Sinkronisasi anggota: setiap pengirim pesan grup otomatis dicatat.
// Ini membuat database Tag All terus bertambah tanpa mengganggu command lain.
bot.on('message', (msg) => {
  try {
    if (!msg?.chat || !['group','supergroup'].includes(msg.chat.type)) return;
    if (msg.from?.id) addGroupMember(msg.chat.id, msg.from);
    for (const u of (msg.new_chat_members || [])) {
      if (u?.id) addGroupMember(msg.chat.id, u);
    }
  } catch (e) {
    console.warn('[TAGALL TRACKER] message:', e.message);
  }
});

// Join request pada channel/group adalah event resmi yang bisa dipakai sebagai fallback
// monitoring subscriber. Ini bukan pengganti subscriber event biasa, tetapi memberi
// identitas user ketika channel menggunakan mode persetujuan masuk.
bot.on('chat_join_request', (update) => {
  try {
    const chat = update?.chat;
    const user = update?.from;
    if (!chat?.id || !user?.id || chat.type !== 'channel') return;
    getEffectiveChannelMonitor(chat.id).then(monitor => {
      if (!monitor?.enabled) return;
      const text = `<h2>JOIN REQUEST</h2><p><b>${htmlEscape(formatUserIdentity(user).name)}</b> ${htmlEscape(formatUserIdentity(user).username)}</p><p>User mengirim permintaan bergabung ke <b>${htmlEscape(chat.title || 'Main Channel')}</b>.</p>`;
      return sendRichMenu(monitor.outputChannelId || chat.id, text, {inline_keyboard:[[{text:'Buka Profil',url:user.username ? `https://t.me/${String(user.username).replace(/^@/,'')}` : `tg://user?id=${user.id}`}]]}, null);
    }).catch(e => console.warn('[CHANNEL MONITOR] join_request:', e.message));
  } catch (e) { console.warn('[CHANNEL MONITOR] join_request:', e.message); }
});

// Perubahan status anggota: tandai anggota keluar/terblokir agar tidak lagi
// disebut oleh /tagall, dan aktifkan kembali saat mereka masuk.
bot.on('chat_member', (update) => {
  try {
    const chat = update?.chat;
    const oldStatus = update?.old_chat_member?.status;
    const newStatus = update?.new_chat_member?.status;
    const user = update?.new_chat_member?.user || update?.old_chat_member?.user;
    if (!chat?.id || !user?.id) return;

    // Existing group member tracker.
    if (['group','supergroup'].includes(chat.type)) {
      if (['left','kicked'].includes(newStatus)) markGroupMemberInactive(chat.id, user.id);
      else if (['member','administrator','creator','restricted'].includes(newStatus)) addGroupMember(chat.id, user);
    }

    // Channel monitoring: supports any channel that has been registered by its admin.
    if (chat.type !== 'channel') return;
    getEffectiveChannelMonitor(chat.id).then(monitor => {
      if (!monitor?.enabled) return;
      if (channelMemberJoined(oldStatus, newStatus)) {
        notifyMainChannelMember('join', user, '', chat.id).catch(e => console.warn('[CHANNEL MONITOR] join:', e.message));
      } else if (channelMemberLeft(oldStatus, newStatus)) {
        notifyMainChannelMember('leave', user, '', chat.id).catch(e => console.warn('[CHANNEL MONITOR] leave:', e.message));
      }
    }).catch(e => console.warn('[CHANNEL MONITOR] lookup:', e.message));
  } catch (e) {
    console.warn('[CHAT MEMBER TRACKER] chat_member:', e.message);
  }
});

// /backup — hanya owner. Credential rahasia tidak disertakan.
bot.onText(/^\/backup$/i, async (msg) => {
  if (String(msg.from?.id) !== String(c.ID)) {
    return safeRichTextMessage(msg.chat.id, '🔒 Fitur backup penuh hanya tersedia untuk owner bot.', { parse_mode:'HTML' });
  }
  const s = getBackupSummary();
  const loading = await safeRichTextMessage(msg.chat.id,
    `💾 <b>BACKUP CENTER</b>\n\n` +
    `📦 Menyiapkan <b>${s.files}</b> file data (${formatBytes(s.bytes)}).\n` +
    `👤 Users: <b>${s.users}</b> • 🏘️ Groups: <b>${s.groups}</b>\n\n` +
    `<i>Credential rahasia tidak dimasukkan.</i>`,
    { parse_mode:'HTML' });
  try {
    const zip = await makeDataBackupZip();
    const filename = `mellstecuu-backup-${moment().tz(c.TIMEZONE).format('YYYYMMDD-HHmmss')}.zip`;
    await bot.sendDocument(msg.chat.id, zip, {
      caption: `✅ <b>BACKUP BERHASIL</b>\n\n` +
        `📦 File: <code>${htmlEscape(filename)}</code>\n` +
        `📄 Data: <code>${s.files}</code> file\n` +
        `👤 Users: <code>${s.users}</code>\n` +
        `🏘️ Groups: <code>${s.groups}</code>\n` +
        `💽 Sumber: <code>${formatBytes(s.bytes)}</code>\n\n` +
        `🔐 <b>.env, token bot, API key, dan secret runtime tidak disertakan.</b>`,
      parse_mode:'HTML'
    }, { filename, contentType:'application/zip' });
    await safeDelete(bot, msg.chat.id, loading.message_id);
  } catch (e) {
    await safeEdit(bot, msg.chat.id, loading.message_id,
      `❌ <b>Backup gagal</b>\n<code>${htmlEscape(e.message)}</code>`, { parse_mode:'HTML' });
  }
});

// /rinem — inspeksi ZIP/file. /rinem old => new dengan reply file akan
// membuat salinan ZIP yang telah diganti namanya.
bot.onText(/^\/rinem$/i, async (msg) => {
  const reply = msg.reply_to_message;
  if (!reply?.document) {
    return safeRichTextMessage(msg.chat.id,
      '🧪 <b>RINEM / FILE INSPECTOR</b>\\n\\nReply sebuah file dengan <code>/rinem</code>.\\nUntuk rename isi ZIP: <code>/rinem nama-lama.js =&gt; nama-baru.js</code>.',
      { parse_mode:'HTML', reply_markup:toolBackKeyboard() });
  }
  const loading = await safeRichTextMessage(msg.chat.id, '🔎 <b>Mengecek file…</b>', { parse_mode:'HTML' });
  try {
    const doc = reply.document;
    const link = await bot.getFileLink(doc.file_id);
    const res = await axios.get(link, { responseType:'arraybuffer', timeout:60000, maxContentLength:50*1024*1024 });
    const buffer = Buffer.from(res.data);
    const isZip = (doc.file_name || '').toLowerCase().endsWith('.zip') ||
      buffer.subarray(0,4).equals(Buffer.from([0x50,0x4b,0x03,0x04]));
    if (!isZip) {
      const preview = buffer.toString('utf8', 0, Math.min(buffer.length, 1800)).replace(/[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F]/g,' ');
      return safeEdit(bot, msg.chat.id, loading.message_id,
        `📄 <b>FILE INFO</b>\\n\\nNama: <code>${htmlEscape(doc.file_name || '-')}</code>\\nUkuran: <code>${(buffer.length/1024).toFixed(1)} KB</code>\\nMIME: <code>${htmlEscape(doc.mime_type || '-')}</code>\\n\\n<b>Preview:</b>\\n<pre>${htmlEscape(preview.slice(0,1400))}</pre>`,
        { parse_mode:'HTML' });
    }
    const zip = await JSZip.loadAsync(buffer);
    const entries = Object.values(zip.files);
    const dirs = entries.filter(e => e.dir).length;
    const files = entries.filter(e => !e.dir);
    const interesting = files.filter(e => /\.(js|ts|jsx|tsx|json|md|env|yml|yaml|py|dart|php|html|css|sh)$/i.test(e.name));
    const lines = files.slice(0,80).map((e,i) => `${i+1}. <code>${htmlEscape(e.name)}</code>`);
    const summary =
      `🧪 <b>RINEM / ZIP INSPECTOR</b>\\n\\n` +
      `File: <code>${htmlEscape(doc.file_name || '-')}</code>\\n` +
      `Total entry: <b>${entries.length}</b>\\nFolder: <b>${dirs}</b>\\nFile: <b>${files.length}</b>\\n` +
      `Kode/config penting: <b>${interesting.length}</b>\\n\\n` +
      `<b>Isi utama:</b>\\n${lines.join('\\n') || '-'}\\n\\n` +
      `<i>Reply ZIP ini lagi dengan /rinem nama-lama =&gt; nama-baru untuk rename satu file di dalam ZIP.</i>`;
    pendingRinem.set(String(msg.from.id), { buffer, fileName: doc.file_name || 'project.zip', chatId: msg.chat.id, createdAt: Date.now() });
    setTimeout(() => pendingRinem.delete(String(msg.from.id)), 10*60*1000);
    return safeEdit(bot, msg.chat.id, loading.message_id, summary, { parse_mode:'HTML' });
  } catch (e) {
    return safeEdit(bot, msg.chat.id, loading.message_id, `❌ <b>Rinem gagal</b>\\n<code>${htmlEscape(e.message)}</code>`, { parse_mode:'HTML' });
  }
});

// Rename request after an inspection.
bot.onText(/^\/rinem\s+(.+?)\s*(?:=>|->|\|)\s*(.+)$/i, async (msg, match) => {
  const session = pendingRinem.get(String(msg.from.id));
  if (!session || session.chatId !== msg.chat.id || Date.now()-session.createdAt > 10*60*1000) {
    return safeRichTextMessage(msg.chat.id, 'ℹ️ Sesi Rinem sudah habis. Reply file ZIP lalu gunakan /rinem lagi.', { parse_mode:'HTML' });
  }
  const oldName = match[1].trim().replace(/^['"]|['"]$/g,'');
  const newName = match[2].trim().replace(/^['"]|['"]$/g,'');
  if (!oldName || !newName || newName.length > 180 || newName.includes('\\') || newName.includes('/') || newName.includes('..')) {
    return safeRichTextMessage(msg.chat.id, '❌ Nama baru tidak valid. Gunakan nama file sederhana tanpa path.', { parse_mode:'HTML' });
  }
  try {
    const zip = await JSZip.loadAsync(session.buffer);
    const entry = zip.file(oldName);
    if (!entry) return safeRichTextMessage(msg.chat.id, `❌ File <code>${htmlEscape(oldName)}</code> tidak ditemukan di ZIP.`, {parse_mode:'HTML'});
    const data = await entry.async('nodebuffer');
    zip.remove(oldName);
    zip.file(newName, data);
    const out = await zip.generateAsync({type:'nodebuffer',compression:'DEFLATE',compressionOptions:{level:6}});
    pendingRinem.delete(String(msg.from.id));
    await bot.sendDocument(msg.chat.id, out, {
      caption:`✅ <b>Rename berhasil</b>\\n<code>${htmlEscape(oldName)}</code> → <code>${htmlEscape(newName)}</code>`,
      parse_mode:'HTML'
    }, {filename:session.fileName.replace(/\.zip$/i,'')+'-renamed.zip',contentType:'application/zip'});
  } catch (e) {
    return safeRichTextMessage(msg.chat.id, `❌ <b>Rename gagal</b>\\n<code>${htmlEscape(e.message)}</code>`, {parse_mode:'HTML'});
  }
});

// /catur — multiplayer sederhana berbasis chess.js.
bot.onText(/^\/catur$/i, async (msg) => {
  if (!['group','supergroup'].includes(msg.chat.type)) return safeRichTextMessage(msg.chat.id,'❌ Catur multiplayer hanya tersedia di grup.',{parse_mode:'HTML'});
  if (chessGames.has(String(msg.chat.id))) return safeRichTextMessage(msg.chat.id,'ℹ️ Sudah ada game catur di grup ini. Gunakan /catur join atau /catur stop.',{parse_mode:'HTML'});
  const game = { chatId:msg.chat.id, white:msg.from.id, black:null, chess:new SimpleChess(), createdAt:Date.now(), messageId:null };
  chessGames.set(String(msg.chat.id), game);
  const sent = await safeRichTextMessage(msg.chat.id,
    `♟️ <b>CATUR — LOBBY</b>\\n\\n${mentionUserForTag(msg.from)} membuat game. Pemain kedua tekan <b>Join</b>.`,
    {parse_mode:'HTML',reply_markup:{inline_keyboard:[
      [{text:'♟️ Join Catur',callback_data:`chess_join_${msg.chat.id}`}],
      [{text:'🛑 Stop',callback_data:`chess_stop_${msg.chat.id}`}]
    ]}});
  game.messageId = sent.message_id;
});

bot.onText(/^\/catur\s+(join|stop)$/i, async (msg, match) => {
  const game = chessGames.get(String(msg.chat.id));
  if (!game) return safeRichTextMessage(msg.chat.id,'ℹ️ Belum ada game catur. Gunakan /catur untuk membuat lobby.');
  if (match[1].toLowerCase() === 'stop') {
    if (msg.from.id !== game.white) return safeRichTextMessage(msg.chat.id,'❌ Hanya pembuat game yang bisa menghentikan game.');
    chessGames.delete(String(msg.chat.id));
    return safeRichTextMessage(msg.chat.id,'🛑 Game catur dihentikan.');
  }
  if (game.black && game.black !== msg.from.id) return safeRichTextMessage(msg.chat.id,'❌ Lobby sudah penuh.');
  if (game.white === msg.from.id) return safeRichTextMessage(msg.chat.id,'ℹ️ Kamu sudah menjadi pemain Putih.');
  game.black = msg.from.id;
  return sendChessState(msg.chat.id, game, `${mentionUserForTag({id:game.white,first_name:'Putih'})} vs ${mentionUserForTag({id:game.black,first_name:'Hitam'})}`);
});


// Chess/dev callback handler kept separate so existing callback routing remains untouched.
bot.on('callback_query', async (q) => {
  try {
  const data = q.data || '';
  if (!data.startsWith('chess_') && !['tagall_menu','tagall_help','callone_menu','callone_help','backup_menu','backup_info','backup_run','rinem_menu','brathd_menu','tonaked_menu'].includes(data)) return;
  await bot.answerCallbackQuery(q.id).catch(() => {});
  const chatId = q.message?.chat?.id;
  if (!chatId) return;
  if (data === 'brathd_menu') {
    return safeRichSendMessage(chatId,
      `🎨 <b>BRAT HD</b>\n\n` +
      `Bikin sticker Brat HD dari teks yang kamu mau.\n` +
      `Kirim perintah <code>/brathd teks</code>, misalnya <code>/brathd bosok</code>.\n\n` +
      `Hasil dibuat lokal agar proses lebih stabil dan langsung dikirim sebagai sticker.`,
      {parse_mode:'HTML',reply_markup:toolBackKeyboard()});
  }
  if (data === 'tonaked_menu') {
    return safeRichSendMessage(chatId,'📝 <b>SAFE MEME MAKER</b>\n\nGunakan <code>/tonaked teks</code> untuk membuat kartu teks sederhana. Fitur ini tidak melakukan nudity/undressing pada foto.',{parse_mode:'HTML',reply_markup:toolBackKeyboard()});
  }
  if (data === 'callone_help') {
    return safeRichSendMessage(chatId,
      '📣 <b>CALL ONE</b>\n\n' +
      'Fungsinya mirip Tag All, tetapi setiap anggota dikirim sebagai <b>mention terpisah</b> satu per satu.\n\n' +
      '• Admin tetap ikut disebut.\n' +
      '• Bot otomatis dikecualikan.\n' +
      '• Daftar anggota berasal dari anggota yang sudah terdeteksi bot + seluruh admin yang dapat dibaca Telegram.\n' +
      '• Ada jeda pengiriman dan retry saat Telegram memberi rate-limit agar bot tidak crash.\n\n' +
      '<i>Telegram Bot API tidak menyediakan endpoint untuk mengambil seluruh anggota grup secara bebas. Jadi akun yang sama sekali belum pernah terlihat bot tidak dapat ditemukan secara ajaib.</i>',
      {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'📣 Call One',callback_data:'callone_menu'}],[{text:'↩️ Menu Group',callback_data:'menu_group'}]]}});
  }
  if (data === 'callone_menu') {
    return safeRichSendMessage(chatId,
      '📣 <b>CALL ONE</b>\n\n' +
      'Tag anggota grup <b>satu per satu</b> seperti contoh.\n\n' +
      'Gunakan <code>/callone</code> untuk memulai.\n' +
      'Bisa ditambah pesan pembuka, contoh: <code>/callone Rapat dimulai</code>.\n\n' +
      '<b>Yang ikut:</b> member + admin yang terdeteksi. <b>Bot tidak ikut.</b>\n' +
      '<i>Pengiriman diberi jeda agar lebih aman terhadap rate-limit Telegram.</i>',
      {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'▶️ Mulai Call One',callback_data:'callone_start'}],[{text:'ℹ️ Cara Kerja',callback_data:'callone_help'}],[{text:'↩️ Menu Group',callback_data:'menu_group'}]]}});
  }
  if (data === 'callone_start') {
    if (!q.message?.chat || !['group','supergroup'].includes(q.message.chat.type)) return bot.answerCallbackQuery(q.id,{text:'Buka fitur ini dari grup.',show_alert:true}).catch(()=>{});
    if (!(await isGroupAdmin(chatId, q.from.id))) return bot.answerCallbackQuery(q.id,{text:'Khusus admin grup.',show_alert:true}).catch(()=>{});
    return runCallOne(chatId, q.from.id, 'Panggilan anggota grup');
  }
  if (data === 'tagall_help') {
    return safeRichSendMessage(chatId,'👥 <b>TAG ALL</b>\n\nDi grup, admin cukup kirim <code>/tagall</code>. Bot akan men-tag anggota non-bot yang sudah terdeteksi.\n\n<i>Telegram Bot API tidak menyediakan daftar semua member secara bebas, jadi anggota yang belum pernah terlihat bot tidak dapat ditag.</i>',{parse_mode:'HTML',reply_markup:toolBackKeyboard()});
  }
  if (data === 'tagall_menu') {
    return safeRichSendMessage(chatId,
      `👥 <b>TAG ALL</b>\n\n` +
      `Gunakan <code>/tagall</code> di grup. Bot akan men-tag anggota non-bot yang sudah terdeteksi.\n\n` +
      `<i>Telegram tidak menyediakan API untuk mengambil daftar seluruh anggota grup secara bebas.</i>`,
      {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'👥 Cara Pakai /tagall',callback_data:'tagall_help'}],[{text:'🧰 Tools',callback_data:'menu_alat'}]]}});
  }
  if (data === 'backup_menu') {
    if (String(q.from.id) !== String(c.ID)) {
      return bot.answerCallbackQuery(q.id,{text:'Backup penuh hanya untuk owner.',show_alert:true}).catch(()=>{});
    }
    const s = getBackupSummary();
    return sendDevRich(chatId,
      `<h2>💾 BACKUP CENTER</h2>` +
      `<p>🟢 <b>STATUS: READY</b></p>` +
      `<table bordered compact><tr><th>DATA</th><th>VALUE</th></tr>` +
      `<tr><td>Users</td><td><b>${s.users}</b></td></tr>` +
      `<tr><td>Groups</td><td><b>${s.groups}</b></td></tr>` +
      `<tr><td>Private chats</td><td><b>${s.privateChats}</b></td></tr>` +
      `<tr><td>File data</td><td><b>${s.files}</b></td></tr>` +
      `<tr><td>Ukuran</td><td><b>${formatBytes(s.bytes)}</b></td></tr>` +
      `</table>` +
      `<p>Backup mengambil seluruh isi <code>data/</code>. <b>.env, token bot, API key, dan secret runtime tidak disertakan.</b></p>` +
      `<p><i>Tekan <b>Buat Backup</b> untuk membuat ZIP baru.</i></p>`,
      {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'💾 Buat Backup',callback_data:'backup_run'}],[{text:'📋 Detail Backup',callback_data:'backup_info'}],[{text:'🧰 Tools',callback_data:'menu_alat'}]]}});
  }
  if (data === 'backup_info') {
    if (String(q.from.id) !== String(c.ID)) return;
    const s = getBackupSummary();
    return sendDevRich(chatId,
      `<h2>📋 DETAIL BACKUP</h2>` +
      `<table bordered compact><tr><th>DATA</th><th>VALUE</th></tr>` +
      `<tr><td>File data</td><td><code>${s.files}</code></td></tr>` +
      `<tr><td>Ukuran sumber</td><td><code>${formatBytes(s.bytes)}</code></td></tr>` +
      `<tr><td>Users</td><td><code>${s.users}</code></td></tr>` +
      `<tr><td>Groups</td><td><code>${s.groups}</code></td></tr>` +
      `<tr><td>Private chats</td><td><code>${s.privateChats}</code></td></tr>` +
      `</table>` +
      `<p>Backup ZIP berisi folder <code>data/</code> beserta manifest. Credential rahasia seperti <code>.env</code>, token bot, dan API key tidak dimasukkan.</p>`,
      {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'💾 Buat Backup',callback_data:'backup_run'}],[{text:'↩️ Backup Center',callback_data:'backup_menu'}]]}});
  }
  if (data === 'backup_run') {
    if (String(q.from.id) !== String(c.ID)) return;
    try {
      const s = getBackupSummary();
      const zip = await makeDataBackupZip();
      const filename = `mellstecuu-backup-${moment().tz(c.TIMEZONE).format('YYYYMMDD-HHmmss')}.zip`;
      await bot.sendDocument(chatId, zip, {
        caption: `✅ <b>BACKUP BERHASIL</b>\n\n` +
          `📦 ZIP: <code>${htmlEscape(filename)}</code>\n` +
          `📄 File data: <code>${s.files}</code>\n` +
          `👤 Users: <code>${s.users}</code>\n` +
          `🏘️ Groups: <code>${s.groups}</code>\n` +
          `💽 Sumber: <code>${formatBytes(s.bytes)}</code>\n\n` +
          `🔐 <b>.env, token bot, API key, dan secret runtime tidak disertakan.</b>`,
        parse_mode: 'HTML'
      }, { filename, contentType: 'application/zip' });
      return;
    } catch (e) {
      return safeRichSendMessage(chatId, `${E.cross} <b>Backup gagal dibuat.</b>\n<code>${htmlEscape(e.message || 'Unknown error')}</code>`, {parse_mode:'HTML'});
    }
  }
  if (data === 'rinem_menu') {
    return safeRichSendMessage(chatId,
      `🧪 <b>RINEM / FILE INSPECTOR</b>\n\n` +
      `Reply file atau ZIP dengan <code>/rinem</code> untuk melihat nama, jumlah entry, dan file kode/config di dalamnya.\n\n` +
      `Rename satu file dalam ZIP: <code>/rinem lama.js =&gt; baru.js</code>.`,
      {parse_mode:'HTML',reply_markup:toolBackKeyboard()});
  }
  const parts = data.split('_');
  const action = parts[1];
  const gameChat = parts[2];

  // chess_start is a menu action, so it must be handled BEFORE looking up
  // an existing game. The previous order made the Start button appear dead.
  if (action === 'start') {
    // chess_start has no chat id suffix; it comes directly from the Fun menu.
    if (!['group','supergroup'].includes(q.message?.chat?.type)) {
      return bot.answerCallbackQuery(q.id,{text:'Catur multiplayer hanya tersedia di grup.',show_alert:true}).catch(()=>{});
    }
    if (chessGames.has(String(chatId))) {
      return bot.answerCallbackQuery(q.id,{text:'Game catur sudah ada di grup ini.',show_alert:true}).catch(()=>{});
    }
    const newGame = { chatId, white:q.from.id, black:null, chess:new SimpleChess(), createdAt:Date.now(), messageId:null };
    chessGames.set(String(chatId),newGame);
    try {
      const sent = await safeRichSendMessage(chatId,`♟️ <b>CATUR — LOBBY</b>\n\n${mentionUserForTag(q.from)} membuat game. Pemain kedua tekan <b>Join Catur</b>.`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[
        [{text:'♟️ Join Catur',callback_data:`chess_join_${chatId}`}],
        [{text:'🛑 Stop',callback_data:`chess_stop_${chatId}`}]
      ]}});
      newGame.messageId=sent.message_id;
      return;
    } catch (e) {
      chessGames.delete(String(chatId));
      return bot.answerCallbackQuery(q.id,{text:'Gagal membuat lobby catur. Coba lagi.',show_alert:true}).catch(()=>{});
    }
  }

  const game = chessGames.get(String(gameChat));
  if (!game || String(gameChat) !== String(chatId)) return bot.answerCallbackQuery(q.id,{text:'Game sudah tidak aktif.',show_alert:true}).catch(()=>{});
  if (action === 'join') {
    if (game.black && game.black !== q.from.id) return bot.answerCallbackQuery(q.id,{text:'Lobby sudah penuh.',show_alert:true}).catch(()=>{});
    if (game.white === q.from.id) return bot.answerCallbackQuery(q.id,{text:'Kamu sudah menjadi Putih.',show_alert:true}).catch(()=>{});
    game.black = q.from.id;
    return sendChessState(chatId,game,`${mentionUserForTag({id:game.white,first_name:'Putih'})} vs ${mentionUserForTag({id:game.black,first_name:'Hitam'})}`);
  }
  if (action === 'stop') {
    if (q.from.id !== game.white) return bot.answerCallbackQuery(q.id,{text:'Hanya pembuat game yang bisa menghentikan.',show_alert:true}).catch(()=>{});
    chessGames.delete(String(chatId));
    return safeRichSendMessage(chatId,'🛑 Game catur dihentikan.');
  }
  if (action === 'pick') {
    if (!game.black) return bot.answerCallbackQuery(q.id,{text:'Tunggu pemain kedua join.',show_alert:true}).catch(()=>{});
    const expected = game.chess.turn() === 'w' ? game.white : game.black;
    if (q.from.id !== expected) return bot.answerCallbackQuery(q.id,{text:'Bukan giliranmu.',show_alert:true}).catch(()=>{});
    const square = parts[3];
    try {
      const moves = game.chess.moves({square,verbose:true});
      if (!moves.length) return bot.answerCallbackQuery(q.id,{text:'Tidak ada langkah legal dari bidak itu.',show_alert:true}).catch(()=>{});
      return safeRichSendMessage(chatId,`♟️ <b>Pilih langkah untuk ${square}</b>`,{parse_mode:'HTML',reply_markup:chessKeyboard(game,square)});
    } catch {
      return bot.answerCallbackQuery(q.id,{text:'Bidak tidak valid.',show_alert:true}).catch(()=>{});
    }
  }
  if (action === 'select') return sendChessState(chatId,game);
  if (action === 'move') {
    if (!game.black) return bot.answerCallbackQuery(q.id,{text:'Tunggu pemain kedua join.',show_alert:true}).catch(()=>{});
    const expected = game.chess.turn() === 'w' ? game.white : game.black;
    if (q.from.id !== expected) return bot.answerCallbackQuery(q.id,{text:'Bukan giliranmu.',show_alert:true}).catch(()=>{});
    const from = parts[3], to = parts[4];
    try {
      const moved = game.chess.move({from,to,promotion:'q'});
      if (!moved) throw new Error('Langkah tidak legal.');
      const turnName = game.chess.turn() === 'w' ? 'Putih' : 'Hitam';
      const extra = game.chess.isGameOver() ? '🏁 <b>Permainan selesai.</b>' : `✅ Langkah <code>${from} → ${to}</code> diterima. Giliran <b>${turnName}</b>.`;
      if (game.chess.isGameOver()) chessGames.delete(String(chatId));
      return sendChessState(chatId,game,extra);
    } catch (e) {
      return bot.answerCallbackQuery(q.id,{text:`Langkah tidak valid: ${e.message}`,show_alert:true}).catch(()=>{});
    }
  }
  } catch (e) {
    const callbackData = q?.data || '';
    console.error('[SECOND CALLBACK ERROR]', callbackData || '-', e?.stack || e?.message || e);
    await bot.answerCallbackQuery(q.id,{text:'Terjadi error pada tombol. Coba tekan lagi.',show_alert:true}).catch(()=>{});
    if (q.message?.chat?.id) {
      await safeRichSendMessage(q.message.chat.id, `${E.cross} <b>Tombol mengalami error sementara.</b>\n<code>${htmlEscape(e?.message || 'Unknown error')}</code>`, {parse_mode:'HTML'}).catch(()=>{});
    }
  }
});

bot.onText(/^\/catur\s+([a-h][1-8])\s+([a-h][1-8])$/i, async (msg, match) => {
  const game = chessGames.get(String(msg.chat.id));
  if (!game || !game.black) return safeRichTextMessage(msg.chat.id,'ℹ️ Game catur belum siap. Gunakan /catur lalu Join.');
  const expected = game.chess.turn() === 'w' ? game.white : game.black;
  if (msg.from.id !== expected) return safeRichTextMessage(msg.chat.id,'❌ Bukan giliranmu.');
  try {
    game.chess.move({from:match[1].toLowerCase(),to:match[2].toLowerCase(),promotion:'q'});
    const over = game.chess.isGameOver();
    const out = await sendChessState(msg.chat.id,game,over?'🏁 <b>Permainan selesai.</b>':'');
    if (over) chessGames.delete(String(msg.chat.id));
    return out;
  } catch (e) {
    return safeRichTextMessage(msg.chat.id,`❌ Langkah tidak valid: <code>${htmlEscape(e.message)}</code>`,{parse_mode:'HTML'});
  }
});

// ======================================= //
// 🚨 ERROR HANDLERS
// ======================================= //
bot.on('polling_error', e => { recordDevError('POLLING', e); console.error('[POLL ERR]', e.message); });
process.on('uncaughtException', e => { recordDevError('UNCAUGHT', e); console.error('[UNCAUGHT]', e); });
process.on('unhandledRejection', e => { recordDevError('UNHANDLED', e); console.error('[UNHANDLED]', e); });

initializeWhatsAppConnections().catch(e => console.error('[WA INIT]', e));
console.log(chalk.green('✅ mellstecuu Bot Online — Ready!'));

module.exports = bot;
