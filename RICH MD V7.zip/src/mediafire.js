const axios = require('axios');
const crypto = require('crypto');
const FormData = require('form-data');

const BASE_URL = process.env.MEDIAFIRE_API_BASE || 'https://www.mediafire.com';

function configReady() {
  return Boolean(
    process.env.MEDIAFIRE_EMAIL &&
    process.env.MEDIAFIRE_PASSWORD &&
    process.env.MEDIAFIRE_APP_ID &&
    process.env.MEDIAFIRE_API_KEY
  );
}

function requiredConfigNames() {
  return ['MEDIAFIRE_EMAIL', 'MEDIAFIRE_PASSWORD', 'MEDIAFIRE_APP_ID', 'MEDIAFIRE_API_KEY'];
}

function responseData(data) {
  return data?.response || data || {};
}

async function getSessionToken() {
  if (!configReady()) throw new Error('MediaFire belum dikonfigurasi.');
  const email = process.env.MEDIAFIRE_EMAIL;
  const password = process.env.MEDIAFIRE_PASSWORD;
  const appId = process.env.MEDIAFIRE_APP_ID;
  const apiKey = process.env.MEDIAFIRE_API_KEY;
  const signature = crypto
    .createHash('sha1')
    .update(`${email}${password}${appId}${apiKey}`)
    .digest('hex');

  const res = await axios.post(`${BASE_URL}/api/user/get_session_token.php`, null, {
    params: {
      email,
      password,
      application_id: appId,
      signature,
      version: '1',
      response_format: 'json'
    },
    timeout: 30000
  });
  const data = responseData(res.data);
  if (data.result !== 'Success' || !data.session_token) {
    throw new Error(data.message || data.error || 'MediaFire gagal membuat session token.');
  }
  return data.session_token;
}

async function preUpload(sessionToken, filename, folderKey = 'myfiles') {
  const res = await axios.get(`${BASE_URL}/api/upload/pre_upload.php`, {
    params: {
      session_token: sessionToken,
      filename,
      response_format: 'json',
      action_on_duplicate: 'keep',
      upload_folder_key: folderKey
    },
    timeout: 30000
  });
  const data = responseData(res.data);
  if (data.result !== 'Success') throw new Error(data.message || data.error || 'MediaFire pre-upload gagal.');
  if (data.storage_limit_exceeded === 'yes') throw new Error('Storage MediaFire tidak mencukupi.');
  return data;
}

async function uploadBuffer(sessionToken, buffer, filename, folderKey = 'myfiles') {
  const form = new FormData();
  form.append('Filedata', buffer, { filename });
  const url = `${BASE_URL}/api/upload/upload.php`;
  const res = await axios.post(url, form, {
    params: {
      session_token: sessionToken,
      action_on_duplicate: 'keep',
      response_format: 'json',
      ...(folderKey ? { uploadkey: folderKey } : {})
    },
    headers: {
      ...form.getHeaders(),
      'x-filename': filename,
      'x-size': String(buffer.length)
    },
    maxBodyLength: Infinity,
    maxContentLength: Infinity,
    timeout: 10 * 60 * 1000
  });
  const data = responseData(res.data);
  if (data.result !== 'Success') throw new Error(data.message || data.error || 'MediaFire upload gagal.');
  return data.key || data.doupload?.key;
}

async function pollUpload(sessionToken, uploadKey, timeoutMs = 10 * 60 * 1000) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    const res = await axios.get(`${BASE_URL}/api/upload/poll_upload.php`, {
      params: { session_token: sessionToken, response_format: 'json', key: uploadKey },
      timeout: 30000
    });
    const data = responseData(res.data);
    if (data.result !== 'Success') throw new Error(data.message || data.error || 'MediaFire polling gagal.');
    const status = String(data.status ?? data.doupload?.status ?? '');
    if (status === '99') {
      const quickKey = data.quickkey || data.doupload?.quickkey;
      if (!quickKey) throw new Error('MediaFire selesai tetapi quick key tidak ditemukan.');
      return quickKey;
    }
    await new Promise(r => setTimeout(r, 2500));
  }
  throw new Error('Upload MediaFire terlalu lama dan dihentikan.');
}

async function getFileLink(sessionToken, quickKey) {
  const res = await axios.get(`${BASE_URL}/api/file/get_links.php`, {
    params: {
      quick_key: quickKey,
      session_token: sessionToken,
      link_type: 'normal_download',
      response_format: 'json'
    },
    timeout: 30000
  });
  const data = responseData(res.data);
  if (data.result !== 'Success') throw new Error(data.message || data.error || 'MediaFire gagal mengambil link.');
  const links = data.links || data.link || [];
  const first = Array.isArray(links) ? links[0] : links;
  const url = first?.direct_download || first?.normal_download || first?.view || first?.url || first?.href;
  if (!url) throw new Error('Link MediaFire tidak ditemukan pada respons API.');
  return url;
}

async function uploadToMediaFire(buffer, filename, options = {}) {
  if (!Buffer.isBuffer(buffer) || !buffer.length) throw new Error('File kosong atau tidak valid.');
  const session = await getSessionToken();
  await preUpload(session, filename, options.folderKey || 'myfiles');
  const uploadKey = await uploadBuffer(session, buffer, filename, options.folderKey || 'myfiles');
  if (!uploadKey) throw new Error('MediaFire tidak mengembalikan upload key.');
  const quickKey = await pollUpload(session, uploadKey, options.timeoutMs || 10 * 60 * 1000);
  const url = await getFileLink(session, quickKey);
  return { url, quickKey, filename };
}

module.exports = {
  configReady,
  requiredConfigNames,
  uploadToMediaFire
};
