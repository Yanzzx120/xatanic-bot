const axios = require('axios');

// AM Premium API configuration.
// Put the secret in .env; never hard-code it in source control.
const API_KEY = process.env.AM_PREMIUM_API_KEY || '';
const BASE_URL = (process.env.AM_PREMIUM_BASE_URL || 'https://api.jerexd.my.id/api/am').replace(/\/$/, '');

const client = axios.create({
  timeout: 180000,
  headers: {
    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
    'Accept': 'application/json, text/plain, */*'
  }
});

function requireKey() {
  if (!API_KEY) throw new Error('AM_PREMIUM_API_KEY belum diisi di .env.');
}

function responseMessage(data, fallback = 'API AM Premium mengembalikan respons yang tidak dikenali.') {
  if (!data) return fallback;
  return String(data.message || data.error || data.msg || data.reason || fallback);
}

function responseFailed(data) {
  if (!data || typeof data !== 'object') return false;
  // JERE-API and similar endpoints normally expose an explicit status flag.
  // Only reject an explicit negative status; do not reject responses that omit it.
  if (data.status === false || data.success === false || data.ok === false) return true;
  if (typeof data.status === 'string' && /^(false|failed|error)$/i.test(data.status)) return true;
  return false;
}

function assertApiSuccess(data, action) {
  if (responseFailed(data)) {
    throw new Error(`${action}: ${responseMessage(data)}`);
  }
  return data;
}

async function sendLink(email) {
  requireKey();
  try {
    const res = await client.get(`${BASE_URL}/send`, {
      params: { apikey: API_KEY, email }
    });
    return assertApiSuccess(res.data, 'Gagal mengirim email verifikasi');
  } catch (e) {
    const status = e?.response?.status;
    const body = e?.response?.data;
    if (body && responseFailed(body)) throw new Error(responseMessage(body, `HTTP ${status || ''}`));
    throw e;
  }
}

async function verifyAndActivate(email, link) {
  requireKey();
  const payload = { email, link };

  try {
    const res = await client.post(
      `${BASE_URL}/verif`,
      payload,
      { params: { apikey: API_KEY }, headers: { 'Content-Type': 'application/json' } }
    );
    return assertApiSuccess(res.data, 'Verifikasi AM Premium gagal');
  } catch (e) {
    const status = Number(e?.response?.status || 0);
    const body = e?.response?.data;
    if (body && responseFailed(body)) throw new Error(responseMessage(body, `HTTP ${status}`));

    // Some deployments of the endpoint expose /verif as GET instead of POST.
    // Retry only for method/schema-style failures so a genuine API rejection
    // is not hidden by a second request.
    if ([400, 404, 405, 415].includes(status)) {
      try {
        const retry = await client.get(`${BASE_URL}/verif`, {
          params: { apikey: API_KEY, email, link }
        });
        return assertApiSuccess(retry.data, 'Verifikasi AM Premium gagal');
      } catch (retryErr) {
        const retryBody = retryErr?.response?.data;
        if (retryBody && responseFailed(retryBody)) {
          throw new Error(responseMessage(retryBody, 'Verifikasi AM Premium gagal.'));
        }
        throw retryErr;
      }
    }
    throw e;
  }
}

async function bulkGenerate(amount, onEvent) {
  requireKey();
  const res = await client.get(`${BASE_URL}/bulk`, {
    params: { apikey: API_KEY, amount },
    responseType: 'stream',
    headers: { 'Accept': 'text/event-stream' }
  });

  return new Promise((resolve, reject) => {
    const accounts = [];
    let summary = null;
    let buffer = '';

    const handlePart = (part) => {
      const line = part.split('\n').find(l => l.startsWith('data: '));
      if (!line) return;
      try {
        const json = JSON.parse(line.slice(6));
        if (onEvent) {
          try { onEvent(json); } catch {}
        }
        if (json.type === 'success' && json.account) {
          const [email, status] = String(json.account).split('|');
          accounts.push({ email, status, orderId: json.orderId, login_url: json.login_url });
        }
        if (json.type === 'done') summary = json;
      } catch {}
    };

    res.data.on('data', chunk => {
      buffer += chunk.toString();
      const parts = buffer.split('\n\n');
      buffer = parts.pop();
      for (const part of parts) handlePart(part);
    });
    res.data.on('end', () => {
      if (buffer.trim()) handlePart(buffer);
      resolve({ accounts, summary });
    });
    res.data.on('error', reject);
  });
}

function extractLink(input) {
  const value = String(input || '').trim();
  if (/^https?:\/\//i.test(value)) return value;
  const urlMatch = value.match(/https?:\/\/[^\s"']+/i);
  if (urlMatch) return urlMatch[0].replace(/&amp;/g, '&');
  return value;
}

module.exports = { sendLink, verifyAndActivate, bulkGenerate, extractLink };
