const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { spawn } = require('child_process');
const sharp = require('sharp');
const ffmpegPath = require('ffmpeg-static');

function runFfmpeg(args, timeoutMs = 120000) {
  return new Promise((resolve, reject) => {
    const child = spawn(ffmpegPath, args, {stdio:['ignore','pipe','pipe']});
    let stdout = '', stderr = '';
    const timer = setTimeout(() => {
      try { child.kill('SIGKILL'); } catch {}
      reject(new Error('FFmpeg timeout.'));
    }, timeoutMs);
    child.stdout.on('data', d => { stdout += d.toString(); });
    child.stderr.on('data', d => { stderr += d.toString(); });
    child.on('error', err => { clearTimeout(timer); reject(err); });
    child.on('close', code => {
      clearTimeout(timer);
      if (code === 0) return resolve({stdout, stderr});
      reject(new Error(`FFmpeg gagal (code ${code}). ${stderr.slice(-2500)}`));
    });
  });
}

async function getVideoDurationSeconds(inputPath) {
  const { stderr } = await runFfmpeg(['-hide_banner','-i',inputPath,'-f','null','-'], 60000);
  const m = stderr.match(/Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)/);
  if (!m) throw new Error('Durasi video tidak dapat dibaca.');
  return Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3]);
}

function makeXmpPacket(xml) {
  const header = Buffer.from('http://ns.adobe.com/xap/1.0/\0', 'ascii');
  const body = Buffer.from(xml, 'utf8');
  const length = header.length + body.length;
  if (length + 2 > 0xffff) throw new Error('XMP metadata terlalu panjang.');
  const seg = Buffer.alloc(2 + 2 + length);
  seg.writeUInt16BE(0xffe1, 0);
  seg.writeUInt16BE(length + 2, 2);
  header.copy(seg, 4);
  body.copy(seg, 4 + header.length);
  return seg;
}

function injectXmp(jpegBuffer, xml) {
  if (!jpegBuffer.subarray(0,2).equals(Buffer.from([0xff,0xd8]))) {
    throw new Error('Frame bukan JPEG valid.');
  }
  return Buffer.concat([jpegBuffer.subarray(0,2), makeXmpPacket(xml), jpegBuffer.subarray(2)]);
}

function appleXmp(assetId) {
  return `<?xpacket begin="\uFEFF" id="W5M0MpCehiHzreSzNTczkc9d"?>` +
    `<x:xmpmeta xmlns:x="adobe:ns:meta/">` +
    `<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">` +
    `<rdf:Description rdf:about="" xmlns:apple="http://ns.apple.com/photos/1.0/" apple:assetIdentifier="${assetId}"/>` +
    `</rdf:RDF></x:xmpmeta><?xpacket end="w"?>`;
}

// Android Motion Photo 1.0 metadata. The older MicroVideoOffset-only metadata
// used by the previous build was not enough for current Motion Photo readers.
// The current spec uses Camera:MotionPhoto + MotionPhotoVersion and a
// GContainer directory whose MotionPhoto item stores the exact appended video
// byte length. See Android's Motion Photo 1.0 specification.
function androidXmp(videoLength, presentationTimestampUs) {
  return `<?xpacket begin="\uFEFF" id="W5M0MpCehiHzreSzNTczkc9d"?>` +
    `<x:xmpmeta xmlns:x="adobe:ns:meta/">` +
    `<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">` +
    `<rdf:Description rdf:about="" ` +
    `xmlns:Camera="http://ns.google.com/photos/1.0/camera/" ` +
    `xmlns:Container="http://ns.google.com/photos/1.0/container/" ` +
    `xmlns:Item="http://ns.google.com/photos/1.0/container/item/" ` +
    `Camera:MotionPhoto="1" ` +
    `Camera:MotionPhotoVersion="1" ` +
    `Camera:MotionPhotoPresentationTimestampUs="${Math.max(0, Math.round(presentationTimestampUs))}">` +
    `<Container:Directory>` +
    `<rdf:Seq>` +
    `<rdf:li Item:Semantic="Primary" Item:Mime="image/jpeg"/>` +
    `<rdf:li Item:Semantic="MotionPhoto" Item:Mime="video/mp4" Item:Length="${videoLength}"/>` +
    `</rdf:Seq>` +
    `</Container:Directory>` +
    `</rdf:Description>` +
    `</rdf:RDF></x:xmpmeta><?xpacket end="w"?>`;
}

async function extractStillFrame(inputPath, duration, outputPath) {
  const timestamp = Math.max(0, Math.min(Math.max(0, duration - 0.1), Math.min(4.9, Math.max(0.1, duration / 2))));
  await runFfmpeg([
    '-hide_banner','-y','-ss',String(timestamp),'-i',inputPath,
    '-frames:v','1','-q:v','2',
    '-vf','scale=w=min(iw\\,1920):h=min(ih\\,1920):force_original_aspect_ratio=decrease',
    outputPath
  ], 90000);
  if (!fs.existsSync(outputPath) || fs.statSync(outputPath).size < 1000) throw new Error('Frame utama gagal dibuat.');
  const normalized = await sharp(outputPath, {failOn:'none'})
    .rotate().jpeg({quality:95,chromaSubsampling:'4:4:4',mozjpeg:true}).toBuffer();
  fs.writeFileSync(outputPath, normalized);
  return normalized;
}

async function encodeMov(inputPath, outputPath, assetId) {
  await runFfmpeg([
    '-hide_banner','-y','-i',inputPath,'-t','5','-an','-map_metadata','-1',
    '-c:v','libx264','-preset','medium','-crf','18','-pix_fmt','yuv420p',
    '-movflags','+faststart+use_metadata_tags',
    '-metadata',`com.apple.quicktime.content.identifier=${assetId}`,
    '-metadata','com.apple.quicktime.still-image-time=0',outputPath
  ],180000);
  if (!fs.existsSync(outputPath) || fs.statSync(outputPath).size < 1000) throw new Error('Video MOV gagal dibuat.');
}

async function createAppleLivePhotoBundle(inputBuffer, originalName = 'video.mp4') {
  const id = crypto.randomUUID().replace(/-/g, '').toUpperCase();
  const base = path.join(os.tmpdir(), `apple-live-${Date.now()}-${crypto.randomBytes(5).toString('hex')}`);
  const input = `${base}-input.mp4`, jpg = `${base}.jpg`, mov = `${base}.mov`, zip = `${base}.zip`;
  try {
    fs.writeFileSync(input, inputBuffer);
    const duration = await getVideoDurationSeconds(input);
    if (!Number.isFinite(duration) || duration <= 0) throw new Error('Video tidak valid.');
    if (duration > 20.05) throw new Error(`Video terlalu panjang (${duration.toFixed(2)} detik). Maksimal input 20 detik.`);
    const frame = await extractStillFrame(input, duration, jpg);
    fs.writeFileSync(jpg, injectXmp(frame, appleXmp(id)));
    await encodeMov(input, mov, id);
    await new Promise((resolve,reject) => {
      const child = spawn('zip',['-j','-q',zip,jpg,mov],{stdio:['ignore','ignore','pipe']});
      let err=''; child.stderr.on('data',d=>err+=d.toString()); child.on('error',reject);
      child.on('close',c=>c===0?resolve():reject(new Error(err||`zip exited ${c}`)));
    });
    return {type:'apple',duration,assetId:id,jpeg:fs.readFileSync(jpg),mov:fs.readFileSync(mov),bundle:fs.readFileSync(zip),filename:`apple-live-photo-${Date.now()}.zip`};
  } finally { for (const f of [input,jpg,mov,zip]) { try{fs.unlinkSync(f);}catch{} } }
}

async function createAndroidMotionPhoto(inputBuffer, originalName = 'video.mp4') {
  const base = path.join(os.tmpdir(), `android-motion-${Date.now()}-${crypto.randomBytes(5).toString('hex')}`);
  const input = `${base}-input.mp4`, jpg = `${base}.jpg`, mov = `${base}.mp4`;
  try {
    fs.writeFileSync(input, inputBuffer);
    const duration = await getVideoDurationSeconds(input);
    if (!Number.isFinite(duration) || duration <= 0) throw new Error('Video tidak valid.');
    if (duration > 20.05) throw new Error(`Video terlalu panjang (${duration.toFixed(2)} detik). Maksimal input 20 detik.`);
    const frame = await extractStillFrame(input, duration, jpg);
    const presentationTimestampUs = Math.round(Math.max(0, Math.min(duration * 0.5, duration - 0.001)) * 1000000);
    // No audio: this keeps the Motion Photo compact and maximizes compatibility.
    await runFfmpeg([
      '-hide_banner','-y','-i',input,'-t','5','-an',
      '-c:v','libx264','-preset','medium','-crf','18','-pix_fmt','yuv420p',
      '-movflags','+faststart',mov
    ],180000);
    const video = fs.readFileSync(mov);
    const xmp = androidXmp(video.length, presentationTimestampUs);
    const motion = Buffer.concat([injectXmp(frame,xmp), video]);
    return {
      type:'android',duration,jpeg:frame,video,motion,
      filename:`android-motion-photo-${Date.now()}MP.jpg`
    };
  } finally { for (const f of [input,jpg,mov]) { try{fs.unlinkSync(f);}catch{} } }
}

module.exports = {createAppleLivePhotoBundle,createAndroidMotionPhoto,getVideoDurationSeconds};
