const axios = require('axios');
const vm = require('vm');
const zlib = require('zlib');
const crypto = require('crypto');

const startTime = Date.now();

function htmlEscape(text = '') {
  return String(text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function runtime() {
  const ms = Date.now() - startTime;
  const d = Math.floor(ms / 86400000);
  const h = Math.floor(ms / 3600000) % 24;
  const m = Math.floor(ms / 60000) % 60;
  const s = Math.floor(ms / 1000) % 60;
  return `${d}d ${h}h ${m}m ${s}s`;
}

function normalizeNumber(input = '') {
  return String(input).replace(/[^0-9]/g, '').replace(/^0/, '62');
}

function parseCommandArgs(text = '') {
  return String(text).trim().split(/\s+/).slice(1);
}

function isLikelyJsFunction(code = '') {
  const value = String(code).trim();
  return /async\s+function\s+[a-zA-Z_$][\w$]*\s*\(/.test(value) ||
    /function\s+[a-zA-Z_$][\w$]*\s*\(/.test(value) ||
    /^async\s*\([^)]*\)\s*=>/.test(value) ||
    /^\([^)]*\)\s*=>/.test(value);
}

function compileFunction(code = '') {
  const funcCode = String(code).trim();
  const matchName = funcCode.match(/async\s+function\s+([a-zA-Z_$][\w$]*)/) ||
    funcCode.match(/function\s+([a-zA-Z_$][\w$]*)/);
  const sandbox = { func: undefined, console, Buffer, setTimeout, clearTimeout };
  vm.createContext(sandbox);
  if (matchName && matchName[1]) {
    vm.runInContext(`${funcCode}; func = ${matchName[1]};`, sandbox, { timeout: 2000 });
  } else {
    vm.runInContext(`func = (${funcCode});`, sandbox, { timeout: 2000 });
  }
  if (typeof sandbox.func !== 'function') throw new Error('Kode tidak menghasilkan function valid.');
  return sandbox.func;
}

// ─── FIX UTAMA: responseType: 'text' agar tidak jadi Buffer/JSON ───────────
async function getReplyJsCode(bot, msg) {
  const reply = msg.reply_to_message;
  if (!reply) return null;

  if (reply.document) {
    const doc  = reply.document;
    const name = doc.file_name || '';
    const mime = doc.mime_type || '';
    const isJs = name.endsWith('.js') ||
                 mime.includes('javascript') ||
                 mime.includes('text');
    if (!isJs && doc.file_size > 0) return null;
    try {
      const fileLink = await bot.getFileLink(doc.file_id);
      // ← responseType: 'text' adalah fix kritis: tanpa ini axios bisa
      //   kembalikan Buffer, lalu JSON.stringify(buffer) merusak kode asli
      const res = await axios.get(fileLink, { responseType: 'text', timeout: 30000 });
      return res.data || null;
    } catch (e) {
      throw new Error('Gagal mengunduh file: ' + e.message);
    }
  }

  if (reply.text)    return reply.text;
  if (reply.caption) return reply.caption;
  return null;
}

async function safeEdit(bot, chatId, messageId, text, options = {}) {
  try {
    return await bot.editMessageText(text, { chat_id: chatId, message_id: messageId, ...options });
  } catch (e) {
    if (!/message is not modified/i.test(e.message || '')) throw e;
  }
}

async function safeDelete(bot, chatId, messageId) {
  try { await bot.deleteMessage(chatId, messageId); } catch {}
}



// Consistent Telegram button styling.  Telegram accepts the optional
// `style` field on inline keyboard buttons.  Menus should use a predictable
// palette instead of mixing colors randomly from row to row.
function tidyMenuKeyboard(keyboard, { main = false } = {}) {
  if (!keyboard || !Array.isArray(keyboard.inline_keyboard)) return keyboard;

  const rows = keyboard.inline_keyboard.map((row, rowIndex) => {
    if (!Array.isArray(row)) return row;
    const buttons = row.map((button) => ({ ...button }));

    if (main) {
      // Main menu follows the visual rhythm requested by the reference:
      // red → blue → green, then repeat.  A two-button row keeps left/right
      // paired, while full-width rows use the row's accent color.
      const palette = ['danger', 'primary', 'success'];
      const style = palette[rowIndex % palette.length];
      return buttons.map((b) => ({ ...b, style }));
    }

    const text = buttons.map(b => String(b.text || '')).join(' ').toLowerCase();
    const isBackRow = buttons.length > 0 && buttons.every(b => {
      const t = String(b.text || '').toLowerCase();
      return /kembali|back|menu utama|menu grup|menu alat|batal|cancel|previously|sebelumnya/.test(t);
    });
    if (isBackRow) return buttons.map(b => ({ ...b, style: 'danger' }));

    // State/destructive controls get their semantic color.  Otherwise the
    // entire row stays blue so the menu looks clean and intentional.
    const hasDanger = /hapus|delete|kick|ban\b|stop\b|matikan|nonaktif|off\b|batal|cancel|keluar/.test(text);
    const hasSuccess = /tambah|add\b|setup|mulai|start|refresh|cek\b|check|status|join|claim|aktif|on\b|simpan|save|buka/.test(text);
    const style = hasDanger && !hasSuccess ? 'danger' : hasSuccess && !hasDanger ? 'success' : 'primary';
    return buttons.map(b => ({ ...b, style }));
  });

  return { ...keyboard, inline_keyboard: rows };
}

// Safe Telegram message sender. Retries without HTML when Telegram rejects
// an entity/tag so callback menus never die because of formatting.
async function safeSendMessage(bot, chatId, text, options = {}) {
  try {
    const normalizedOptions = options?.reply_markup?.inline_keyboard
      ? { ...options, reply_markup: tidyMenuKeyboard(options.reply_markup) }
      : options;
    return await bot.sendMessage(chatId, text, normalizedOptions);
  } catch (e) {
    const msg = String(e?.message || '');
    if (options?.parse_mode === 'HTML' && /can't parse entities|parse entities|unsupported start tag|can't find end tag/i.test(msg)) {
      const fallback = { ...options };
      delete fallback.parse_mode;
      if (fallback.reply_markup?.inline_keyboard) fallback.reply_markup = tidyMenuKeyboard(fallback.reply_markup);
      return bot.sendMessage(chatId, String(text).replace(/<[^>]*>/g, ''), fallback);
    }
    throw e;
  }
}

// ─── FIX: sendPhoto dengan caption > 1024 char ditolak Telegram (silent fail) ───
// Kalau caption kepanjangan, fallback: kirim foto tanpa caption lalu kirim
// teksnya sebagai pesan biasa (limit 4096 char) dengan keyboard yang sama.
async function sendMenuPhoto(bot, chatId, photo, options = {}) {
  const { caption, ...rest } = options;
  try {
    const normalizedOptions = options?.reply_markup?.inline_keyboard
      ? { ...options, reply_markup: tidyMenuKeyboard(options.reply_markup) }
      : options;
    return await bot.sendPhoto(chatId, photo, normalizedOptions);
  } catch (e) {
    const msg = e.message || '';
    if (/caption is too long|MEDIA_CAPTION_TOO_LONG/i.test(msg) && caption) {
      await bot.sendPhoto(chatId, photo, {}).catch(() => {});
      return bot.sendMessage(chatId, caption, {
        parse_mode: rest.parse_mode,
        reply_markup: rest.reply_markup?.inline_keyboard ? tidyMenuKeyboard(rest.reply_markup) : rest.reply_markup
      });
    }
    throw e;
  }
}

// ======================================= //
// 🔐 ENCRYPTION FUNCTIONS (Fixed)
// ======================================= //

// ─── Level 1 — Basic: Triple Base64 + eval ──────────────────────────────────
function encBasic(code) {
  const b1 = Buffer.from(code,       'utf8').toString('base64');
  const b2 = Buffer.from(b1,         'utf8').toString('base64');
  const b3 = Buffer.from(b2,         'utf8').toString('base64');
  return (
    `(function(){` +
    `var _0x1a=['${b3}'];` +
    `var _d=function(s){` +
    `return Buffer.from(Buffer.from(Buffer.from(s,'base64').toString('utf8'),'base64').toString('utf8'),'base64').toString('utf8');` +
    `};` +
    `eval(_d(_0x1a[0]));` +
    `})();`
  );
}


// ─── Level 2 — Medium: XOR per-char + Hex Array ─────────────────────────────
function encMedium(code) {
  // Encode ke base64 dulu supaya hanya ASCII (0-127), XOR aman
  const b64  = Buffer.from(code, 'utf8').toString('base64');
  const seed = 0xA3C1 ^ (b64.length & 0xFF); // seed dinamis berdasar panjang

  const hexArr = b64.split('').map((c, i) => {
    const xored = c.charCodeAt(0) ^ ((seed + i) & 0xFF);
    return '0x' + xored.toString(16).padStart(2, '0');
  });

  const arrName = '_0x' + Math.floor(Math.random() * 0xFFFF).toString(16).padStart(4, '0');
  const sdName  = '_s'  + seed.toString(16);

  return (
    `(function(){` +
    `var ${arrName}=[${hexArr.join(',')}];` +
    `var ${sdName}=0x${seed.toString(16)};` +
    `var _r=${arrName}.map(function(c,i){` +
    `return String.fromCharCode(c^((${sdName}+i)&0xFF));` +
    `}).join('');` +
    `eval(Buffer.from(_r,'base64').toString('utf8'));` +
    `})();`
  );
}


// ─── Level 3 — Arab: Nama variabel Arab + ROT13 + Triple Base64 ─────────────
function encArab(code) {
  const arabNames = [
    '\uFE99\uFE83\uFE8D',
    '\uFEAE\uFED4\uFEB8',
    '\uFE9D\uFEAE\uFEA7',
    '\uFEB8\uFEB2',
    '\uFEE0\uFEE4\uFEB7',
    '\uFE90\uFEE0\uFEAB',
    '\uFEAD\uFED4\uFEB7',
    '\uFED2\uFEB8\uFEA9',
    '\uFED1\uFEAE\uFEB7',
    '\uFEB4\uFED4\uFEAC',
    '\uFEE2\uFEE0\uFEB7',
    '\uFEAE\uFEEC\uFEDC'
  ];

  const rot13 = s => s.replace(/[a-zA-Z]/g, c =>
    String.fromCharCode(c.charCodeAt(0) + (c.toLowerCase() < 'n' ? 13 : -13))
  );

  const b64_1 = Buffer.from(code,       'utf8').toString('base64');
  const b64_2 = Buffer.from(rot13(b64_1),'utf8').toString('base64');
  const b64_3 = Buffer.from(b64_2,       'utf8').toString('base64');

  const [v1, v2, v3, v4, v5] = arabNames;

  return (
    `(function(){` +
    `var ${v1}='${b64_3}';` +
    `var ${v2}=function(s){return Buffer.from(s,'base64').toString('utf8');};` +
    `var ${v3}=function(s){` +
    `return s.replace(/[a-zA-Z]/g,function(c){` +
    `return String.fromCharCode(c.charCodeAt(0)+(c.toLowerCase()<'n'?13:-13));` +
    `});};` +
    `var ${v4}=${v2}(${v2}(${v1}));` +
    `var ${v5}=${v2}(${v3}(${v4}));` +
    `eval(${v5});` +
    `})();`
  );
}


// ─── Level 4 — Invisible: Zero-Width Steganography ──────────────────────────
function encInvisible(code) {
  const ZWJ  = '\u200D'; // bit 1
  const ZWNJ = '\u200C'; // bit 0
  const ZWS  = '\u200B'; // separator antar char

  // Encode ke base64 dulu (ASCII-safe)
  const b64 = Buffer.from(code, 'utf8').toString('base64');

  let zwEncoded = '';
  for (const ch of b64) {
    const bits = ch.charCodeAt(0).toString(2).padStart(8, '0');
    for (const bit of bits) zwEncoded += bit === '1' ? ZWJ : ZWNJ;
    zwEncoded += ZWS;
  }

  // Decoy visible agar file tidak tampak kosong
  const decoy = `var _lavender=0;/* protected */`;

  return (
    `(function(){` +
    `${decoy}` +
    `var _zw="${zwEncoded}";` +
    `var _sp="\u200B",_one="\u200D",_zero="\u200C";` +
    `var _parts=_zw.split(_sp).filter(function(x){return x.length>0;});` +
    `var _b64=_parts.map(function(p){` +
    `var _bits=p.split('').map(function(c){return c===_one?'1':'0';}).join('');` +
    `return _bits.length===8?String.fromCharCode(parseInt(_bits,2)):'';` +
    `}).join('');` +
    `eval(Buffer.from(_b64,'base64').toString('utf8'));` +
    `})();`
  );
}


// ─── Level 5 — Hard: XOR + Reverse + Double Base64 + Integrity Check ────────
function encHard(code) {
  // FIX: encode ke base64 dulu sebelum XOR, supaya semua char ASCII (0-127)
  // sehingga XOR + Buffer.from tidak corrupt Unicode chars
  const b64src = Buffer.from(code, 'utf8').toString('base64');

  // Hash untuk XOR key unik per file
  let hash = 0;
  for (let i = 0; i < b64src.length; i++) {
    hash = ((hash << 5) - hash + b64src.charCodeAt(i)) >>> 0;
  }
  const xorKey = (hash % 200) + 50; // 50–249

  // XOR (aman karena b64src hanya ASCII 0-127, hasil XOR max 0-254)
  const xored   = b64src.split('').map(c =>
    String.fromCharCode(c.charCodeAt(0) ^ xorKey)
  ).join('');

  // Reverse
  const reversed = xored.split('').reverse().join('');

  // Double Base64 (FIX: gunakan 'latin1' bukan 'binary' — keduanya sama
  // tapi 'latin1' lebih eksplisit dan tidak deprecated)
  const b64_1 = Buffer.from(reversed, 'latin1').toString('base64');
  const b64_2 = Buffer.from(b64_1,    'utf8'  ).toString('base64');

  // Split chunks 100 char
  const chunks = [];
  for (let i = 0; i < b64_2.length; i += 100) {
    chunks.push(b64_2.slice(i, i + 100));
  }

  // Integrity hash dari b64_2
  let encHash = 0;
  for (let i = 0; i < b64_2.length; i++) {
    encHash = ((encHash << 5) - encHash + b64_2.charCodeAt(i)) >>> 0;
  }

  const arrName  = '_0x' + hash.toString(16).padStart(8, '0');
  const keyName  = '_k'  + xorKey.toString(16);
  const hashName = '_h'  + (encHash >>> 0).toString(16).slice(-8);

  return (
    `(function(){` +
    `var ${arrName}=${JSON.stringify(chunks)};` +
    `var ${keyName}=${xorKey};` +
    `var ${hashName}=${encHash}>>>0;` +
    `var _j=${arrName}.join('');` +
    `var _chk=(function(s){var h=0;for(var i=0;i<s.length;i++){h=((h<<5)-h+s.charCodeAt(i))>>>0;}return h;})(_j);` +
    `if(_chk!==${hashName}){throw new Error('Integrity check failed: file tampered');}` +
    `var _b1=Buffer.from(_j,'base64').toString('utf8');` +
    `var _b2=Buffer.from(_b1,'base64').toString('latin1');` +
    `var _rev=_b2.split('').reverse().join('');` +
    `var _dec=_rev.split('').map(function(c){return String.fromCharCode(c.charCodeAt(0)^${keyName});}).join('');` +
    `eval(Buffer.from(_dec,'base64').toString('utf8'));` +
    `})();`
  );
}


// ─── Level 6 — Hard+: gzip + rotating XOR + integrity check ─────────────────
// Ini tetap obfuscation, bukan enkripsi absolut: key/decryptor berada di file output.
function encUltra(code) {
  const compressed = zlib.gzipSync(Buffer.from(code, 'utf8'));
  const key = crypto.randomBytes(24);
  const out = Buffer.allocUnsafe(compressed.length);
  let checksum = 2166136261 >>> 0;
  for (let i = 0; i < compressed.length; i++) {
    const k = key[i % key.length] ^ ((i * 31) & 0xff) ^ ((i >>> 3) & 0xff);
    out[i] = compressed[i] ^ k;
    checksum ^= out[i];
    checksum = Math.imul(checksum, 16777619) >>> 0;
  }
  const payload = out.toString('base64');
  const keyB64 = key.toString('base64');
  const a = '_0x' + crypto.randomBytes(4).toString('hex');
  const k = '_k' + crypto.randomBytes(3).toString('hex');
  const h = '_h' + crypto.randomBytes(3).toString('hex');
  return `(function(){var ${a}=Buffer.from(${JSON.stringify(payload)},'base64'),${k}=Buffer.from(${JSON.stringify(keyB64)},'base64'),${h}=${checksum}>>>0;` +
    `var c=2166136261>>>0;for(var i=0;i<${a}.length;i++){c^=${a}[i];c=Math.imul(c,16777619)>>>0;}if(c!==${h})throw new Error('Integrity check failed');` +
    `for(var j=0;j<${a}.length;j++){${a}[j]^=${k}[j%${k}.length]^((j*31)&255)^((j>>>3)&255);}` +
    `eval(require('zlib').gunzipSync(${a}).toString('utf8'));})();`;
}

module.exports = {
  startTime,
  htmlEscape,
  runtime,
  normalizeNumber,
  parseCommandArgs,
  isLikelyJsFunction,
  compileFunction,
  getReplyJsCode,
  safeEdit,
  safeDelete,
  safeSendMessage,
  sendMenuPhoto,
  tidyMenuKeyboard,
  encBasic,
  encMedium,
  encArab,
  encInvisible,
  encHard,
  encUltra
};
