const fs = require('fs-extra');
const path = require('path');
const axios = require('axios');
const P = require('pino');
const {
  makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  generateWAMessageFromContent,
  prepareWAMessageMedia,
  proto,
  jidEncode,
  jidDecode,
  encodeWAMessage,
  encodeSignedDeviceIdentity
} = require('@whiskeysockets/baileys');
const { addSender, removeSender } = require('./store');

const SESSIONS_DIR = path.join(__dirname, '..', 'sessions');
const SESSIONS_FILE = path.join(SESSIONS_DIR, 'active_sessions.json');
const sessions = new Map();
const senderOwners = new Map();
const _reconnecting = new Set(); // cegah double reconnect

function ensureSessionsFile() {
  fs.ensureDirSync(SESSIONS_DIR);
  if (!fs.existsSync(SESSIONS_FILE)) fs.writeJsonSync(SESSIONS_FILE, []);
}

function createSessionDir(number) {
  const dir = path.join(SESSIONS_DIR, `device${number}`);
  fs.ensureDirSync(dir);
  return dir;
}

function readActiveSessions() {
  ensureSessionsFile();
  try { return fs.readJsonSync(SESSIONS_FILE); } catch { return []; }
}

function saveActiveSession(number) {
  ensureSessionsFile();
  const list = readActiveSessions();
  if (!list.includes(number)) list.push(number);
  fs.writeJsonSync(SESSIONS_FILE, list, { spaces: 2 });
}

function deleteActiveSession(number) {
  ensureSessionsFile();
  const list = readActiveSessions().filter(n => n !== number);
  fs.writeJsonSync(SESSIONS_FILE, list, { spaces: 2 });
  removeSender(number);
}

function getSocket(number) {
  if (number) return sessions.get(String(number));
  return sessions.values().next().value;
}

function getSenderStatus(number) {
  const sock = sessions.get(String(number));
  const connected = Boolean(sock?.user);
  return {
    number: String(number),
    online: connected,
    status: connected ? 'TERSAMBUNG' : 'DISCONNECT',
    user: sock?.user || null
  };
}

function getAllSenderStatuses(numbers = []) {
  return numbers.map(getSenderStatus);
}

// ======================================= //
// SENDER ANTI-DISCONNECT — Versi Stabil
// ======================================= //
async function startWhatsAppConnection({
  number, userId, onCode, onConnecting, onOpen, onClose,
  pairingPrefix = 'KEIRAA01',
  _retryCount = 0
}) {
  const cleanNumber = String(number).replace(/[^0-9]/g, '');
  const sessionDir = createSessionDir(cleanNumber);

  // Cegah double reconnect
  if (_reconnecting.has(cleanNumber)) {
    console.log(`[WA] Reconnect ${cleanNumber} sudah dalam antrian, skip.`);
    return;
  }

  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  const sock = makeWASocket({
    auth: state,
    logger: P({ level: 'silent' }),
    printQRInTerminal: false,
    browser: ['Ubuntu', 'Chrome', '113.0.5672.126'],
    markOnlineOnConnect: false,
    syncFullHistory: false,
    defaultQueryTimeoutMs: 60000,
    connectTimeoutMs: 60000,
    keepAliveIntervalMs: 30000,     // 30 detik — stabil, tidak terlalu agresif
    retryRequestDelayMs: 250,       // delay antar retry request
    emitOwnEvents: false,
    generateHighQualityLinkPreview: false,
    // Dibutuhkan saat restore session agar Baileys tidak error
    getMessage: async () => ({ conversation: '' })
  });

  sessions.set(cleanNumber, sock);
  if (userId) senderOwners.set(cleanNumber, String(userId));
  sock.ev.on('creds.update', saveCreds);

  // ── PRESENCE KEEPALIVE: kirim "available" tiap 4 menit ──
  // Ini mencegah WhatsApp memutus koneksi idle
  const presenceInterval = setInterval(async () => {
    const liveSock = sessions.get(cleanNumber);
    if (liveSock?.user) {
      try {
        await liveSock.sendPresenceUpdate('available');
      } catch {}
    } else {
      clearInterval(presenceInterval);
    }
  }, 4 * 60 * 1000); // setiap 4 menit

  // ── WATCHDOG: cek socket hidup tiap 2 menit ──
  // Jika sock di sessions tapi user null → socket zombie → force reconnect
  const watchdogInterval = setInterval(() => {
    const liveSock = sessions.get(cleanNumber);
    if (!liveSock) {
      clearInterval(watchdogInterval);
      clearInterval(presenceInterval);
      return;
    }
    if (!liveSock.user && !_reconnecting.has(cleanNumber)) {
      const isRegistered = readActiveSessions().includes(cleanNumber);
      if (isRegistered) {
        console.log(`[WA WATCHDOG] ${cleanNumber} socket zombie — reconnect...`);
        clearInterval(watchdogInterval);
        clearInterval(presenceInterval);
        sessions.delete(cleanNumber);
        _scheduleReconnect({ number, userId, onCode, onConnecting, onOpen, onClose, pairingPrefix }, 0, cleanNumber);
      }
    }
  }, 2 * 60 * 1000); // setiap 2 menit

  let codeRequested = false;

  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === 'connecting') {
      if (onConnecting) await onConnecting(update).catch(() => {});
      if (!codeRequested && !fs.existsSync(path.join(sessionDir, 'creds.json'))) {
        codeRequested = true;
        setTimeout(async () => {
          try {
            const code = await sock.requestPairingCode(cleanNumber, pairingPrefix);
            const formatted = code.match(/.{1,4}/g)?.join('-') || code;
            if (onCode) await onCode(formatted, code).catch(() => {});
          } catch (e) {
            if (onClose) await onClose(e).catch(() => {});
          }
        }, 1500);
      }
    }

    if (connection === 'open') {
      _reconnecting.delete(cleanNumber); // hapus flag reconnect
      sessions.set(cleanNumber, sock);
      saveActiveSession(cleanNumber);
      if (userId) addSender(userId, cleanNumber);
      if (onOpen) await onOpen(sock).catch(() => {});
      console.log(`[WA] ✅ ${cleanNumber} tersambung.`);
    }

    if (connection === 'close') {
      clearInterval(presenceInterval);
      clearInterval(watchdogInterval);

      const statusCode = lastDisconnect?.error?.output?.statusCode;
      const reason = lastDisconnect?.error?.message || '';
      const loggedOut = statusCode === DisconnectReason.loggedOut;
      const conflicted = statusCode === 440; // HP membuka WA lain
      const restartNeeded = statusCode === 515;

      sessions.delete(cleanNumber);

      if (loggedOut) {
        _reconnecting.delete(cleanNumber);
        deleteActiveSession(cleanNumber);
        fs.rmSync(sessionDir, { recursive: true, force: true });
        console.log(`[WA] 🔴 ${cleanNumber} Logged Out — sesi dihapus.`);
        if (onClose) await onClose(lastDisconnect?.error || new Error('Logged out')).catch(() => {});
        return;
      }

      if (conflicted) {
        // HP buka WA lain → tunggu lebih lama baru reconnect
        console.log(`[WA] ⚠️ ${cleanNumber} konflik (HP buka WA) — reconnect 30s...`);
        if (onClose) await onClose(lastDisconnect?.error || new Error('Conflicted')).catch(() => {});
        _scheduleReconnect({ number, userId, onCode, onConnecting, onOpen, onClose, pairingPrefix }, 30000, cleanNumber);
        return;
      }

      if (restartNeeded) {
        console.log(`[WA] 🔄 ${cleanNumber} server restart diperlukan — reconnect...`);
      } else {
        console.log(`[WA] 🔌 ${cleanNumber} terputus (${statusCode || reason}) — reconnect...`);
      }

      if (onClose) await onClose(lastDisconnect?.error || new Error('Connection closed')).catch(() => {});

      // Exponential backoff: 5s → 10s → 20s → 40s → max 60s
      const delay = Math.min(5000 * Math.pow(2, _retryCount), 60000);
      _scheduleReconnect({ number, userId, onCode, onConnecting, onOpen, onClose, pairingPrefix, _retryCount: _retryCount + 1 }, delay, cleanNumber);
    }
  });

  return sock;
}

// Helper: jadwalkan reconnect dengan flag anti-double
function _scheduleReconnect(params, delayMs, cleanNumber) {
  if (_reconnecting.has(cleanNumber)) return;
  _reconnecting.add(cleanNumber);
  setTimeout(() => {
    _reconnecting.delete(cleanNumber);
    startWhatsAppConnection(params).catch(e => {
      console.error(`[WA] Reconnect gagal ${cleanNumber}:`, e.message);
      // Coba lagi setelah 30 detik jika reconnect error
      _scheduleReconnect(params, 30000, cleanNumber);
    });
  }, delayMs);
}

async function initializeWhatsAppConnections() {
  const active = readActiveSessions();
  for (const number of active) {
    try {
      await startWhatsAppConnection({ number });
      console.log(`[WA] Menyambung ulang sesi ${number}`);
    } catch (e) {
      console.error(`[WA] Gagal sambung ulang ${number}:`, e.message);
    }
  }
}

async function checkFixError(code, endpoint) {
  try {
    const prompt = `Perbaiki kode Javascript berikut. HANYA balas dengan script kode yang sudah diperbaiki tanpa penjelasan, tanpa format markdown, dan tanpa backticks.\n\n${code}`;
    const res = await axios.get(endpoint, { timeout: 30000, params: { code: prompt, lang: 'javascript' } });
    let dataApi = res.data;
    if (dataApi?.result?.fixed) {
      dataApi.result.fixed = dataApi.result.fixed
        .replace(/```javascript/gi, '').replace(/```js/gi, '').replace(/```/g, '').trim();
    }
    return dataApi;
  } catch (error) {
    console.error('[FIX ERROR] API Gagal:', error.message);
    return { error: true, message: error.message };
  }
}


async function downloadInstagram(url) {
  const cleanUrl = String(url || '').trim();
  if (!/^https?:\/\/(?:www\.)?(?:instagram\.com|instagr\.am)\//i.test(cleanUrl)) {
    throw new Error('Link Instagram tidak valid.');
  }

  const endpoints = [
    {
      name: 'NexRay',
      url: 'https://api.nexray.eu.cc/downloader/v1/instagram',
      params: { url: cleanUrl }
    },
    {
      name: 'Nekorinn',
      url: 'https://api.nekorinn.my.id/downloader/instagram',
      params: { url: cleanUrl }
    }
  ];

  let lastError = null;
  for (const ep of endpoints) {
    try {
      const { data } = await axios.get(ep.url, {
        params: ep.params,
        timeout: 75000,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/131 Mobile Safari/537.36',
          'Accept': 'application/json,text/plain,*/*'
        },
        validateStatus: s => s >= 200 && s < 500
      });

      if (!data || data.status === false) {
        throw new Error(data?.message || `${ep.name}: respons API tidak valid.`);
      }

      const root = data.result ?? data.data ?? data;
      const raw = [];

      const add = (item, fallbackType = '') => {
        if (!item) return;
        if (typeof item === 'string') {
          raw.push({ url: item, type: fallbackType });
          return;
        }
        if (Array.isArray(item)) {
          for (const x of item) add(x, fallbackType);
          return;
        }
        const u = item.url || item.src || item.download_url || item.downloadUrl ||
                  item.video_url || item.videoUrl || item.image_url || item.imageUrl;
        if (u) raw.push({ ...item, url: u, type: item.type || item.media_type || fallbackType });
      };

      add(root?.medias || root?.media || root?.items);
      add(root?.carousel);
      add(root?.video, 'video');
      add(root?.image, 'image');
      add(root, root?.type || '');

      const seen = new Set();
      const medias = raw.filter(x => {
        const u = String(x.url || '').trim();
        if (!/^https?:\/\//i.test(u) || seen.has(u)) return false;
        seen.add(u);
        return true;
      }).slice(0, 10);

      if (!medias.length) throw new Error(`${ep.name}: media tidak ditemukan.`);

      return {
        source: ep.name,
        caption: root?.caption || root?.title || '',
        username: root?.username || root?.owner?.username || root?.author?.username || '',
        medias
      };
    } catch (e) {
      lastError = e;
      console.warn(`[IG] ${ep.name} gagal: ${e.message}`);
    }
  }

  throw new Error(lastError?.message || 'Semua layanan Instagram sedang tidak tersedia.');
}

async function downloadTikTok(url, endpoint) {
  try {
    const res = await axios.get(`${endpoint}${encodeURIComponent(url)}`, { timeout: 60000 });
    return res.data;
  } catch {
    throw new Error('Gagal mendownload, API sedang down atau link tidak valid.');
  }
}

async function searchSongs(query) {
  const q = encodeURIComponent(query);
  const endpoints = [
    { url: `https://api.nexray.eu.cc/search/youtube?q=${q}`, parser: (d) => d?.result || d?.data || [] },
    { url: `https://api.ryzendesu.vip/api/search/ytsearch?query=${q}`, parser: (d) => d?.result || d?.data || [] },
    { url: `https://api.diioffc.web.id/api/search/youtube?query=${q}`, parser: (d) => d?.result || d?.data || [] },
    { url: `https://api.agatz.xyz/api/ytsearch?message=${q}`, parser: (d) => d?.result || d?.data || [] },
    { url: `https://api.siputzx.my.id/api/s/youtube?q=${q}`, parser: (d) => d?.data || d?.result || [] }
  ];
  for (const ep of endpoints) {
    try {
      const { data } = await axios.get(ep.url, { timeout: 30000 });
      const raw = ep.parser(data);
      const list = Array.isArray(raw) ? raw : (raw?.all || raw?.videos || raw?.items || []);
      const mapped = list.map((x, i) => ({
        title: x.title || x.name || `Lagu ${i + 1}`,
        url: x.url || x.link || x.videoUrl || x.webpage_url || (x.id ? `https://www.youtube.com/watch?v=${x.id}` : null),
        duration: x.duration || x.timestamp || x.duration_raw || x.length || '-',
        channel: x.author?.name || x.author || x.channel || x.creator || x.channelTitle || '-',
        thumbnail: x.thumbnail || x.image || x.thumb || ''
      })).filter(x => x.url && x.title).slice(0, 5);
      if (mapped.length) return mapped;
    } catch {}
  }
  return [];
}

async function getAudioFromYoutube(videoUrl) {
  const encoded = encodeURIComponent(videoUrl);
  try {
    const { data } = await axios.get(`https://api.nexray.eu.cc/downloader/v1/ytmp3?url=${encoded}`, { timeout: 90000 });
    if (data?.status && data?.result?.url) {
      return {
        audio: data.result.url,
        title: data.result.title || 'Audio',
        author: data.result.author || '-',
        duration: data.result.duration || '-',
        quality: data.result.quality || '320k',
        raw: data
      };
    }
  } catch {}
  const fallbacks = [
    `https://api.ryzendesu.vip/api/downloader/ytmp3?url=${encoded}`,
    `https://api.diioffc.web.id/api/download/ytmp3?url=${encoded}`,
    `https://api.agatz.xyz/api/ytmp3?url=${encoded}`,
    `https://api.siputzx.my.id/api/d/ytmp3?url=${encoded}`,
    `https://api.nekorinn.my.id/downloader/ytmp3?url=${encoded}`,
    `https://api.lolhuman.xyz/api/ymp3?url=${encoded}&apikey=lolhuman`,
    `https://api.tikcdn.io/youtube/audio?url=${encoded}`,
    `https://yt-mp3.8mb.pages.dev/?url=${encoded}`,
    `https://api.qraved.live/yt/mp3?url=${encoded}`
  ];
  for (const url of fallbacks) {
    try {
      const { data } = await axios.get(url, { timeout: 60000 });
      const result = data?.result || data?.data || data;
      const audio = result?.downloadUrl || result?.url || result?.audio || result?.mp3 ||
        result?.download?.url || result?.link || result?.file_url;
      if (audio && typeof audio === 'string' && audio.startsWith('http')) {
        return { audio, title: result?.title || data?.title || 'Audio', author: '-', duration: '-', quality: '-', raw: data };
      }
    } catch {}
  }
  throw new Error('Audio tidak tersedia dari semua endpoint. Coba lagu lain.');
}

async function downloadPinterest(url) {
  const res = await axios.get(`https://api-faa.my.id/faa/pin-down?url=${encodeURIComponent(url)}`, { timeout: 60000 });
  if (!res.data?.status) throw new Error(res.data?.message || 'Gagal mendownload dari Pinterest.');
  return res.data;
}

async function playSoundCloud(query) {
  const res = await axios.get(`https://api-faa.my.id/faa/soundcloud-play?query=${encodeURIComponent(query)}`, { timeout: 60000 });
  if (!res.data?.status) throw new Error(res.data?.message || 'Lagu tidak ditemukan di SoundCloud.');
  return res.data;
}

async function generateTTS(text) {
  const res = await axios.get(`https://api-faa.my.id/faa/tts-generate?text=${encodeURIComponent(text)}`, { timeout: 60000 });
  if (!res.data?.status) throw new Error(res.data?.message || 'Gagal generate TTS.');
  return res.data;
}


// ======================================= //
// MARKET MONITOR — Yahoo Finance
// ======================================= //
const MARKET_CACHE = new Map();
const MARKET_TTL = 30 * 1000;

const MARKET_SYMBOLS = {
  '^JKSE': 'IHSG',
  '^GSPC': 'S&P 500',
  '^IXIC': 'NASDAQ',
  '^DJI': 'Dow Jones',
  'BBCA.JK': 'BBCA',
  'BBRI.JK': 'BBRI',
  'BMRI.JK': 'BMRI',
  'TLKM.JK': 'TLKM',
  'ASII.JK': 'ASII',
  'GOTO.JK': 'GOTO',
  'AAPL': 'AAPL',
  'NVDA': 'NVDA',
  'MSFT': 'MSFT',
  'TSLA': 'TSLA'
};

function normalizeMarketSymbol(input = '') {
  let s = String(input).trim().toUpperCase().replace(/^\$/, '');
  if (!s) return '';
  if (MARKET_SYMBOLS[s]) return s;
  if (/^[A-Z]{4}$/.test(s) && !s.endsWith('.JK')) s += '.JK';
  return s.replace(/[^A-Z0-9.^=-]/g, '').slice(0, 20);
}

async function fetchYahooChart(symbol, range = '5d', interval = '15m') {
  const key = `${symbol}|${range}|${interval}`;
  const cached = MARKET_CACHE.get(key);
  if (cached && Date.now() - cached.at < MARKET_TTL) return cached.data;

  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}`;
  const res = await axios.get(url, {
    params: { range, interval, includePrePost: false, events: 'div,splits' },
    timeout: 12000,
    headers: { 'User-Agent': 'Mozilla/5.0' }
  });
  const result = res.data?.chart?.result?.[0];
  if (!result) throw new Error(res.data?.chart?.error?.description || 'Data pasar tidak tersedia.');
  const data = { result, fetchedAt: Date.now() };
  MARKET_CACHE.set(key, { at: Date.now(), data });
  return data;
}

async function getMarketQuote(symbol) {
  const normalized = normalizeMarketSymbol(symbol);
  if (!normalized) throw new Error('Kode saham kosong.');
  const { result } = await fetchYahooChart(normalized, '5d', '15m');
  const meta = result.meta || {};
  const q = result.indicators?.quote?.[0] || {};
  const closes = (q.close || []).filter(v => Number.isFinite(v));
  const highs = (q.high || []).filter(v => Number.isFinite(v));
  const lows = (q.low || []).filter(v => Number.isFinite(v));
  const price = Number(meta.regularMarketPrice ?? closes.at(-1));
  const previous = Number(meta.previousClose ?? meta.chartPreviousClose);
  if (!Number.isFinite(price)) throw new Error(`Kode ${normalized} tidak ditemukan.`);
  const change = Number.isFinite(previous) ? price - previous : null;
  const changePct = Number.isFinite(previous) && previous !== 0 ? (change / previous) * 100 : null;
  return {
    symbol: normalized,
    name: MARKET_SYMBOLS[normalized] || meta.shortName || normalized,
    exchange: meta.exchangeName || meta.fullExchangeName || '-',
    currency: meta.currency || 'USD',
    price, previous, change, changePct,
    dayHigh: Number(meta.regularMarketDayHigh ?? highs.at(-1) ?? price),
    dayLow: Number(meta.regularMarketDayLow ?? lows.at(-1) ?? price),
    volume: Number(meta.regularMarketVolume ?? (q.volume || []).filter(Number.isFinite).at(-1) ?? 0),
    marketState: meta.marketState || 'UNKNOWN',
    asOf: meta.regularMarketTime ? new Date(meta.regularMarketTime * 1000).toISOString() : new Date().toISOString()
  };
}

async function getMarketHistory(symbol, range = '1mo', interval = '1d') {
  const normalized = normalizeMarketSymbol(symbol);
  const { result } = await fetchYahooChart(normalized, range, interval);
  const timestamps = result.timestamp || [];
  const closes = result.indicators?.quote?.[0]?.close || [];
  return timestamps.map((ts, i) => ({
    time: ts * 1000,
    close: Number(closes[i])
  })).filter(x => Number.isFinite(x.close));
}

async function getMarketQuotes(symbols = Object.keys(MARKET_SYMBOLS)) {
  const out = [];
  for (const symbol of symbols) {
    try { out.push(await getMarketQuote(symbol)); }
    catch (e) { out.push({ symbol, name: MARKET_SYMBOLS[symbol] || symbol, error: e.message }); }
  }
  return out;
}

module.exports = {
  normalizeMarketSymbol,
  getMarketQuote,
  getMarketQuotes,
  getMarketHistory,
  sessions,
  SESSIONS_DIR,
  SESSIONS_FILE,
  initializeWhatsAppConnections,
  startWhatsAppConnection,
  getSocket,
  getSenderStatus,
  getAllSenderStatuses,
  checkFixError,
  downloadTikTok,
  downloadInstagram,
  searchSongs,
  getAudioFromYoutube,
  downloadPinterest,
  playSoundCloud,
  generateTTS
};