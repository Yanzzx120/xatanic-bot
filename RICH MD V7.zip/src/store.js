const fs = require('fs-extra');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', 'data');
const DB_FILE = path.join(DATA_DIR, 'bot-state.json');

const defaultState = {
  users: {},
  chats: {},
  senders: {},
  totalTests: 0,
  groupSettings: {},
  groupFilters: {},
  assistantChats: {},
  assistantProviders: {},
  assistantEnabled: {},
  groupMembers: {},
  richMessages: {},
  featureRequests: {},
  channelMonitors: {},
  moderationRecords: {},
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
  amPremiumUsage: {},
  startNotifications: {}
};

function ensureStore() {
  fs.ensureDirSync(DATA_DIR);
  if (!fs.existsSync(DB_FILE)) {
    fs.writeJsonSync(DB_FILE, defaultState, { spaces: 2 });
  }
}

function _handleCorruptState(reason) {
  try {
    // Cek apakah file ada dan punya data
    if (fs.existsSync(DB_FILE)) {
      const stat = fs.statSync(DB_FILE);
      if (stat.size > 100) {
        // Ada data penting → BACKUP dulu sebelum apapun
        const backupPath = DB_FILE + '.bak.' + Date.now();
        fs.copySync(DB_FILE, backupPath);
        // Log ke console agar owner tau
        const logMsg = `[STORE WARNING] bot-state.json corrupt/invalid: ${reason}\n` +
                       `[STORE WARNING] Backup disimpan ke: ${backupPath}\n` +
                       `[STORE WARNING] Menjalankan dengan state kosong (in-memory only)\n` +
                       `[STORE WARNING] Silakan restore dari backup secara manual.`;
        console.error(logMsg);
        // Simpan warning ke file log
        const logPath = path.join(DATA_DIR, 'store-errors.log');
        const logEntry = `\n[${new Date().toISOString()}] ${logMsg}\n`;
        try { fs.appendFileSync(logPath, logEntry); } catch {}
        // JANGAN OVERWRITE bot-state.json dengan defaultState
        // Biarkan file backup dan state in-memory kosong sampai owner fix
        return;
      }
    }
    // File tidak ada atau kosong → aman untuk buat baru
    fs.writeJsonSync(DB_FILE, defaultState, { spaces: 2 });
  } catch (backupErr) {
    console.error('[STORE ERROR] Gagal backup state:', backupErr.message);
  }
}

function recoverFromBackup() {
  try {
    // Cari backup terbaru
    const files = fs.readdirSync(DATA_DIR)
      .filter(f => f.startsWith('bot-state.json.bak.'))
      .sort()
      .reverse();
    if (!files.length) return { ok: false, msg: 'Tidak ada backup ditemukan.' };
    const latest = path.join(DATA_DIR, files[0]);
    const raw = fs.readFileSync(latest, 'utf8');
    const parsed = JSON.parse(raw);
    // Validasi minimal
    if (!parsed.users) return { ok: false, msg: 'Backup tidak valid (tidak ada users).' };
    // Overwrite bot-state.json dengan backup
    fs.writeJsonSync(DB_FILE, parsed, { spaces: 2 });
    return { ok: true, msg: `Berhasil recover dari: ${files[0]}\nTotal users: ${Object.keys(parsed.users).length}` };
  } catch (e) {
    return { ok: false, msg: `Gagal recover: ${e.message}` };
  }
}

function readState() {
  ensureStore();
  try {
    const raw = fs.readFileSync(DB_FILE, 'utf8');
    // Cek apakah file kosong atau sangat kecil (< 10 bytes = pasti corrupt)
    if (!raw || raw.trim().length < 10) {
      _handleCorruptState('File terlalu kecil atau kosong');
      return { ...defaultState };
    }
    const s = JSON.parse(raw);
    // Patch missing keys tanpa overwrite yang sudah ada
    if (!s.groupSettings)    s.groupSettings = {};
    if (!s.assistantChats)   s.assistantChats = {};
    if (!s.assistantProviders) s.assistantProviders = {};
    if (!s.assistantEnabled) s.assistantEnabled = {};
    if (!s.richMessages)     s.richMessages = {};
    if (!s.featureRequests)  s.featureRequests = {};
    if (!s.channelMonitors) s.channelMonitors = {};
    for (const [cid, mon] of Object.entries(s.channelMonitors)) {
      if (mon && !mon.outputChannelId) mon.outputChannelId = mon.monitoringChannelId || '';
      if (mon && !Object.prototype.hasOwnProperty.call(mon, 'antiDrugs')) mon.antiDrugs = true;
    }
    if (!s.moderationRecords) s.moderationRecords = {};
    if (!s.bannedUsers)      s.bannedUsers = {};
    if (!s.forceSubWarnings) s.forceSubWarnings = {};
    if (!s.rewards)          s.rewards = [];
    if (!s.activeCodes)      s.activeCodes = {};
    if (!s.senderPasswords)  s.senderPasswords = {};
    if (!s.dailyTests)       s.dailyTests = {};
    if (!s.tesfuncStats)     s.tesfuncStats = {};
    if (!s.amPremiumUsage)   s.amPremiumUsage = {};
    if (!s.startNotifications) s.startNotifications = {};
    return s;
  } catch (e) {
    // JANGAN langsung reset — backup dulu!
    _handleCorruptState(e.message);
    // Return empty state di memory saja, TIDAK ditulis ke disk
    return { ...defaultState };
  }
}

function writeState(state) {
  ensureStore();
  state.updatedAt = new Date().toISOString();
  fs.writeJsonSync(DB_FILE, state, { spaces: 2 });
}

function upsertUser(user = {}, chatId = null) {
  const state = readState();
  const id = String(user.id);
  if (!id || id === 'undefined') return state;
  state.users[id] = {
    id,
    username: user.username || state.users[id]?.username || '',
    first_name: user.first_name || state.users[id]?.first_name || '',
    last_name: user.last_name || state.users[id]?.last_name || '',
    firstStartAt: state.users[id]?.firstStartAt || new Date().toISOString(),
    startNotifiedAt: state.users[id]?.startNotifiedAt || '',
    lastSeenAt: new Date().toISOString()
  };
  if (chatId != null) addGroupMemberToState(state, chatId, user);
  writeState(state);
  return state;
}

function addGroupMemberToState(state, chatId, user = {}) {
  if (chatId == null || !user?.id) return;
  const cid = String(chatId), uid = String(user.id);
  if (!state.groupMembers) state.groupMembers = {};
  if (!state.groupMembers[cid]) state.groupMembers[cid] = {};
  state.groupMembers[cid][uid] = {
    id: uid,
    username: user.username || state.groupMembers[cid][uid]?.username || '',
    first_name: user.first_name || state.groupMembers[cid][uid]?.first_name || '',
    last_name: user.last_name || state.groupMembers[cid][uid]?.last_name || '',
    active: true,
    lastSeenAt: new Date().toISOString()
  };
}

function addGroupMember(chatId, user) {
  const state = readState();
  addGroupMemberToState(state, chatId, user);
  writeState(state);
}

function markGroupMemberInactive(chatId, userId) {
  const state = readState();
  const cid = String(chatId), uid = String(userId);
  const member = state.groupMembers?.[cid]?.[uid];
  if (member) {
    member.active = false;
    member.lastSeenAt = new Date().toISOString();
    writeState(state);
  }
}

function getGroupMembers(chatId) {
  const state = readState();
  return Object.values((state.groupMembers || {})[String(chatId)] || {});
}

function upsertChat(chat = {}) {
  const state = readState();
  const id = String(chat.id);
  if (!id || id === 'undefined') return state;
  state.chats[id] = {
    id,
    type: chat.type || state.chats[id]?.type || 'private',
    title: chat.title || chat.username || state.chats[id]?.title || '',
    username: chat.username || state.chats[id]?.username || '',
    botStatus: chat.botStatus || state.chats[id]?.botStatus || '',
    botStatusAt: chat.botStatus ? new Date().toISOString() : (state.chats[id]?.botStatusAt || ''),
    firstSeenAt: state.chats[id]?.firstSeenAt || new Date().toISOString(),
    lastSeenAt: new Date().toISOString()
  };
  writeState(state);
  return state;
}

function addSender(userId, number) {
  const state = readState();
  const uid = String(userId);
  const num = String(number).replace(/[^0-9]/g, '');
  if (!state.senders[uid]) state.senders[uid] = [];
  if (!state.senders[uid].includes(num)) state.senders[uid].push(num);
  writeState(state);
}

function removeSender(number) {
  const state = readState();
  const num = String(number).replace(/[^0-9]/g, '');
  Object.keys(state.senders).forEach(uid => {
    state.senders[uid] = (state.senders[uid] || []).filter(n => n !== num);
  });
  writeState(state);
}

function getUserSenders(userId) {
  const state = readState();
  return state.senders[String(userId)] || [];
}

function incrementTests(count = 1) {
  const state = readState();
  state.totalTests = Number(state.totalTests || 0) + Number(count || 1);
  writeState(state);
  return state.totalTests;
}

function getGroupSettings(chatId) {
  const state = readState();
  const defaults = {
    antilink: false,
    antiforward: false,
    antiflood: false,
    antispam: false,
    antipromosi: false,
    antiporno: false,
    antitoxic: false,
    antisticker: false,
    antibot: false,
    antidrugs: false,
    antifoto: false,
    antivideo: false,
    // Preserve the existing safety behaviour by default: admins/creator are exempt.
    // /antiadmin off explicitly makes admins subject to active group safety filters.
    antiadmin: true,
    lockmedia: false,
    lockall: false,
    lockAllBackup: null,
    slowmode: 0,
    rules: '',
    forceSubscribe: { enabled: false, channel: null, invite: null, title: '', channels: [] },
    welcome: { enabled: false, message: '', photo: null },
    goodbye: { enabled: false, message: '', photo: null },
    addedBy: null
  };
  const current = state.groupSettings[String(chatId)] || {};
  return {
    ...defaults,
    ...current,
    forceSubscribe: { ...defaults.forceSubscribe, ...(current.forceSubscribe || {}) },
    welcome: { ...defaults.welcome, ...(current.welcome || {}) },
    goodbye: { ...defaults.goodbye, ...(current.goodbye || {}) }
  };
}



function setGroupSettings(chatId, settings) {
  const state = readState();
  const id = String(chatId);
  state.groupSettings[id] = { ...(state.groupSettings[id] || {}), ...settings };
  writeState(state);
}



function getChannelMonitor(channelId) {
  const state = readState();
  return state.channelMonitors?.[String(channelId)] || null;
}

function getChannelMonitors() {
  const state = readState();
  return { ...(state.channelMonitors || {}) };
}

function getUserChannelMonitors(userId) {
  const uid = String(userId);
  return Object.values(getChannelMonitors()).filter(v => String(v?.ownerId || '') === uid);
}

function setChannelMonitor(channelId, monitor = {}) {
  const state = readState();
  const id = String(channelId);
  state.channelMonitors[id] = {
    channelId: id,
    title: monitor.title || state.channelMonitors[id]?.title || '',
    username: monitor.username || state.channelMonitors[id]?.username || '',
    ownerId: String(monitor.ownerId || state.channelMonitors[id]?.ownerId || ''),
    outputChannelId: String(monitor.outputChannelId || monitor.monitoringChannelId || state.channelMonitors[id]?.outputChannelId || ''),
    outputTitle: monitor.outputTitle || state.channelMonitors[id]?.outputTitle || '',
    outputUsername: monitor.outputUsername || state.channelMonitors[id]?.outputUsername || '',
    enabled: monitor.enabled !== false,
    antiDrugs: monitor.antiDrugs !== false,
    createdAt: state.channelMonitors[id]?.createdAt || new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  writeState(state);
  return state.channelMonitors[id];
}

function removeChannelMonitor(channelId) {
  const state = readState();
  const id = String(channelId);
  const old = state.channelMonitors?.[id] || null;
  if (state.channelMonitors) delete state.channelMonitors[id];
  writeState(state);
  return old;
}

function getModerationRecord(chatId, userId) {
  const state = readState();
  const key = `${String(chatId)}:${String(userId)}`;
  return state.moderationRecords?.[key] || { autoMutes: 0, warnings: 0, permanent: false };
}

function recordModerationWarning(chatId, userId) {
  const state = readState();
  const key = `${String(chatId)}:${String(userId)}`;
  if (!state.moderationRecords) state.moderationRecords = {};
  const current = state.moderationRecords[key] || { autoMutes: 0, warnings: 0, permanent: false };
  current.warnings = Number(current.warnings || 0) + 1;
  current.lastWarningAt = new Date().toISOString();
  state.moderationRecords[key] = current;
  writeState(state);
  return current;
}

function recordModerationAutoMute(chatId, userId) {
  const state = readState();
  const key = `${String(chatId)}:${String(userId)}`;
  const current = state.moderationRecords?.[key] || { autoMutes: 0, permanent: false };
  current.autoMutes = Number(current.autoMutes || 0) + 1;
  current.lastMuteAt = new Date().toISOString();
  state.moderationRecords[key] = current;
  writeState(state);
  return current;
}

function resetModerationRecord(chatId, userId) {
  const state = readState();
  const key = `${String(chatId)}:${String(userId)}`;
  if (!state.moderationRecords) state.moderationRecords = {};
  state.moderationRecords[key] = { autoMutes: 0, warnings: 0, permanent: false, resetAt: new Date().toISOString() };
  writeState(state);
  return state.moderationRecords[key];
}

function markModerationPermanent(chatId, userId) {
  const state = readState();
  const key = `${String(chatId)}:${String(userId)}`;
  const current = state.moderationRecords?.[key] || { autoMutes: 0, warnings: 0, permanent: false };
  current.permanent = true;
  current.permanentAt = new Date().toISOString();
  state.moderationRecords[key] = current;
  writeState(state);
  return current;
}

function getAssistantProvider(chatId) {
  const state = readState();
  const id = String(chatId);
  const saved = state.assistantProviders[id];
  if (saved === 'gemini' || saved === 'openrouter' || saved === 'auto') return saved;
  const legacy = state.assistantChats[id];
  if (legacy === 'gemini' || legacy === 'openrouter' || legacy === 'auto') return legacy;
  return 'gemini';
}

function isAssistantEnabled(chatId) {
  const state = readState();
  return state.assistantEnabled[String(chatId)] === true;
}

function getAssistantState(chatId) {
  return isAssistantEnabled(chatId) ? getAssistantProvider(chatId) : false;
}

function setAssistantProvider(chatId, provider) {
  const state = readState();
  const id = String(chatId);
  state.assistantProviders[id] = provider;
  // Keep the legacy field synchronized for compatibility, but do not change on/off state.
  state.assistantChats[id] = provider;
  writeState(state);
}

function setAssistantEnabled(chatId, enabled) {
  const state = readState();
  const id = String(chatId);
  state.assistantEnabled[id] = Boolean(enabled);
  if (!state.assistantProviders[id]) state.assistantProviders[id] = 'gemini';
  state.assistantChats[id] = state.assistantProviders[id];
  writeState(state);
}

function setAssistantState(chatId, enabled) {
  // Backward-compatible wrapper used by older handlers. A provider string means ON; false means OFF.
  if (enabled === false) return setAssistantEnabled(chatId, false);
  if (enabled === true) return setAssistantEnabled(chatId, true);
  setAssistantProvider(chatId, enabled);
  return setAssistantEnabled(chatId, true);
}

// ======================================= //
// BAN SYSTEM — TAMBAHKAN INI
// ======================================= //
function getAmPremiumUsage(userId, dateKey = null) {
  const state = readState();
  const uid = String(userId);
  const key = dateKey || new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Jakarta' }).format(new Date());
  const usage = state.amPremiumUsage?.[uid];
  if (!usage || usage.date !== key) return { date: key, own: 0, bulk: 0 };
  return { date: key, own: Number(usage.own || 0), bulk: Number(usage.bulk || 0) };
}

function consumeAmPremiumQuota(userId, kind, limits = { own: 2, bulk: 3 }, dateKey = null) {
  const state = readState();
  if (!state.amPremiumUsage) state.amPremiumUsage = {};
  const uid = String(userId);
  const key = dateKey || new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Jakarta' }).format(new Date());
  const current = state.amPremiumUsage[uid]?.date === key
    ? { date: key, own: Number(state.amPremiumUsage[uid].own || 0), bulk: Number(state.amPremiumUsage[uid].bulk || 0) }
    : { date: key, own: 0, bulk: 0 };
  if (!['own','bulk'].includes(kind)) return { ok:false, reason:'Jenis kuota tidak valid.', usage:current, limit:Number(limits?.[kind] || 0) };
  const limit = Number(limits?.[kind] || 0);
  if (current[kind] >= limit) return { ok:false, reason:`Batas ${kind === 'own' ? 'Create Email Sendiri' : 'Bulk'} hari ini sudah habis (${limit}/${limit}).`, usage:current, limit };
  current[kind] += 1;
  state.amPremiumUsage[uid] = current;
  writeState(state);
  return { ok:true, usage:current, limit };
}

function isNewUser(userId) {
  const state = readState();
  return !state.users[String(userId)];
}

// Returns true exactly once per Telegram user for the /start owner alert.
// This is intentionally separate from isNewUser(): a user may already exist
// in state because of group activity or older versions of the bot, but can
// still be a first-time /start user. Missing markers are migrated lazily.
function claimStartNotification(userId) {
  const state = readState();
  const uid = String(userId || '').trim();
  if (!uid) return false;
  if (!state.startNotifications) state.startNotifications = {};
  return !state.startNotifications[uid];
}

function markStartNotificationSent(userId) {
  const state = readState();
  const uid = String(userId || '').trim();
  if (!uid) return false;
  if (!state.startNotifications) state.startNotifications = {};
  const now = new Date().toISOString();
  state.startNotifications[uid] = now;
  if (state.users[uid]) state.users[uid].startNotifiedAt = now;
  writeState(state);
  return true;
}

function banUser(userId, durationMs = 24 * 60 * 60 * 1000, reason = 'unfollow_channel') {
  const state = readState();
  if (!state.bannedUsers) state.bannedUsers = {};
  state.bannedUsers[String(userId)] = {
    bannedAt: new Date().toISOString(),
    bannedUntil: new Date(Date.now() + durationMs).toISOString(),
    reason
  };
  writeState(state);
}


function getForceSubWarning(userId) {
  const state = readState();
  return state.forceSubWarnings?.[String(userId)] || { count: 0, previouslyJoined: false };
}

function recordForceSubWarning(userId) {
  const state = readState();
  if (!state.forceSubWarnings) state.forceSubWarnings = {};
  const key = String(userId);
  const current = state.forceSubWarnings[key] || { count: 0, previouslyJoined: false };
  current.count = Number(current.count || 0) + 1;
  current.lastWarningAt = new Date().toISOString();
  current.previouslyJoined = true;
  state.forceSubWarnings[key] = current;
  writeState(state);
  return current;
}

function markForceSubJoined(userId) {
  const state = readState();
  if (!state.forceSubWarnings) state.forceSubWarnings = {};
  const key = String(userId);
  state.forceSubWarnings[key] = { count: 0, previouslyJoined: true, lastJoinedAt: new Date().toISOString() };
  writeState(state);
}

function unbanUser(userId) {
  const state = readState();
  if (!state.bannedUsers) state.bannedUsers = {};
  delete state.bannedUsers[String(userId)];
  writeState(state);
}

function isUserBanned(userId) {
  const state = readState();
  if (!state.bannedUsers) return false;
  const ban = state.bannedUsers[String(userId)];
  if (!ban) return false;
  if (new Date(ban.bannedUntil) > new Date()) return { banned: true, until: ban.bannedUntil, reason: ban.reason };
  delete state.bannedUsers[String(userId)];
  writeState(state);
  return false;
}

function getAllBannedUsers() {
  const state = readState();
  return state.bannedUsers || {};
}

function getRewards() {
  const state = readState();
  return state.rewards || [];
}

function addReward(reward) {
  const state = readState();
  if (!state.rewards) state.rewards = [];
  state.rewards.push(reward);
  writeState(state);
}

function removeReward(id) {
  const state = readState();
  state.rewards = (state.rewards || []).filter(r => r.id !== id);
  writeState(state);
}

function getActiveCode(code) {
  const state = readState();
  return (state.activeCodes || {})[code] || null;
}

function getAllActiveCodes() {
  const state = readState();
  return state.activeCodes || {};
}

function setActiveCode(code, data) {
  const state = readState();
  if (!state.activeCodes) state.activeCodes = {};
  state.activeCodes[code] = data;
  writeState(state);
}

function claimCode(code, userId) {
  const state = readState();
  if (!state.activeCodes || !state.activeCodes[code]) return false;
  const entry = state.activeCodes[code];
  if (!entry.claimedBy) entry.claimedBy = [];
  if (entry.claimedBy.includes(String(userId))) return false;
  if (entry.claimed >= entry.maxUsers) return false;
  entry.claimedBy.push(String(userId));
  entry.claimed = (entry.claimed || 0) + 1;
  writeState(state);
  return true;
}

function removeActiveCode(code) {
  const state = readState();
  if (state.activeCodes) {
    delete state.activeCodes[code];
    writeState(state);
  }
}

function getAllUsers() {
  const state = readState();
  return Object.values(state.users || {});
}

function getAllChats() {
  const state = readState();
  return Object.values(state.chats || {});
}

function incrementDailyTests(count = 1) {
  const state = readState();
  const today = new Date().toISOString().slice(0, 10);
  if (!state.dailyTests) state.dailyTests = {};
  if (!state.dailyTests[today]) state.dailyTests[today] = 0;
  state.dailyTests[today] += Number(count);
  writeState(state);
  return state.dailyTests[today];
}

function getDailyTests() {
  const state = readState();
  const today = new Date().toISOString().slice(0, 10);
  return (state.dailyTests || {})[today] || 0;
}

function addTesfuncStat(userId, firstName, username, count = 1) {
  const state = readState();
  const today = new Date().toISOString().slice(0, 10);
  if (!state.tesfuncStats) state.tesfuncStats = {};
  if (!state.tesfuncStats[today]) state.tesfuncStats[today] = {};
  const uid = String(userId);
  if (!state.tesfuncStats[today][uid]) {
    state.tesfuncStats[today][uid] = { count: 0, firstName: firstName || '', username: username || '' };
  }
  state.tesfuncStats[today][uid].count += Number(count);
  state.tesfuncStats[today][uid].firstName = firstName || state.tesfuncStats[today][uid].firstName;
  state.tesfuncStats[today][uid].username = username || state.tesfuncStats[today][uid].username;
  writeState(state);
}

function getTesfuncStats() {
  const state = readState();
  const today = new Date().toISOString().slice(0, 10);
  const d = (state.tesfuncStats || {})[today] || {};
  return Object.entries(d)
    .map(([uid, v]) => ({ uid, ...v }))
    .sort((a, b) => b.count - a.count);
}

function setSenderPassword(number, password) {
  const state = readState();
  if (!state.senderPasswords) state.senderPasswords = {};
  state.senderPasswords[String(number)] = String(password);
  writeState(state);
}

function getSenderPassword(number) {
  const state = readState();
  return (state.senderPasswords || {})[String(number)] || null;
}

function removeSenderPassword(number) {
  const state = readState();
  if (!state.senderPasswords) return;
  delete state.senderPasswords[String(number)];
  writeState(state);
}




function createFeatureRequest(data = {}) {
  const state = readState();
  if (!state.featureRequests) state.featureRequests = {};
  let id = String(data.id || '').trim();
  if (!/^REQ-[A-Z0-9]{6}$/.test(id)) {
    const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    do {
      id = 'REQ-' + Array.from({length: 6}, () => alphabet[Math.floor(Math.random() * alphabet.length)]).join('');
    } while (state.featureRequests[id]);
  }
  const entry = {
    id,
    userId: String(data.userId || ''),
    chatId: String(data.chatId || ''),
    username: String(data.username || ''),
    name: String(data.name || ''),
    text: String(data.text || ''),
    status: 'open',
    createdAt: data.createdAt || new Date().toISOString(),
    answeredAt: null,
    answer: null
  };
  state.featureRequests[id] = entry;
  writeState(state);
  return entry;
}

function getFeatureRequest(id) {
  const state = readState();
  return (state.featureRequests || {})[String(id).toUpperCase()] || null;
}

function answerFeatureRequest(id, answer) {
  const state = readState();
  const key = String(id).toUpperCase();
  const req = (state.featureRequests || {})[key];
  if (!req) return null;
  req.status = 'answered';
  req.answer = String(answer || '');
  req.answeredAt = new Date().toISOString();
  state.featureRequests[key] = req;
  writeState(state);
  return req;
}

function getFeatureRequests(limit = 50) {
  const state = readState();
  return Object.values(state.featureRequests || {})
    .sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)))
    .slice(0, Math.max(1, Number(limit) || 50));
}

function setRichMessage(code, data) {
  const state = readState();
  if (!state.richMessages) state.richMessages = {};
  state.richMessages[String(code)] = data;
  writeState(state);
  return data;
}


function getGroupFilters(chatId) {
  const state = readState();
  return (state.groupFilters || {})[String(chatId)] || {};
}

function setGroupFilter(chatId, trigger, filter) {
  const state = readState();
  if (!state.groupFilters) state.groupFilters = {};
  const key = String(chatId);
  if (!state.groupFilters[key]) state.groupFilters[key] = {};
  state.groupFilters[key][String(trigger).toLowerCase()] = filter;
  writeState(state);
  return state.groupFilters[key][String(trigger).toLowerCase()];
}

function removeGroupFilter(chatId, trigger) {
  const state = readState();
  const key = String(chatId);
  const bucket = state.groupFilters?.[key];
  if (!bucket || !Object.prototype.hasOwnProperty.call(bucket, String(trigger).toLowerCase())) return false;
  delete bucket[String(trigger).toLowerCase()];
  if (!Object.keys(bucket).length) delete state.groupFilters[key];
  writeState(state);
  return true;
}

function clearGroupFilters(chatId) {
  const state = readState();
  const key = String(chatId);
  if (!state.groupFilters?.[key]) return false;
  delete state.groupFilters[key];
  writeState(state);
  return true;
}

function getRichMessage(code) {
  const state = readState();
  return (state.richMessages || {})[String(code)] || null;
}

function removeRichMessage(code) {
  const state = readState();
  if (!state.richMessages) return false;
  const key = String(code);
  if (!Object.prototype.hasOwnProperty.call(state.richMessages, key)) return false;
  delete state.richMessages[key];
  writeState(state);
  return true;
}

function getAllRichMessages() {
  const state = readState();
  return state.richMessages || {};
}

module.exports = {
  DATA_DIR,
  DB_FILE,
  readState,
  writeState,
  setSenderPassword,
 getSenderPassword,
 removeSenderPassword,
  isNewUser,
  claimStartNotification,
  markStartNotificationSent,
  getAmPremiumUsage,
  consumeAmPremiumQuota,
  banUser, 
  unbanUser, 
  isUserBanned,
  getForceSubWarning,
  recordForceSubWarning,
  markForceSubJoined,
  getAllBannedUsers,
  upsertUser,
  upsertChat,
  addSender,
  getRewards,
  addReward,
  removeReward,
  getActiveCode,
  getAllUsers,
  getAllChats,
  incrementDailyTests,
  getDailyTests,
  addTesfuncStat,
  getTesfuncStats,
  getAllActiveCodes,
  setActiveCode,
  claimCode,
  removeActiveCode,
  removeSender,
  getUserSenders,
  addGroupMember,
  markGroupMemberInactive,
  getGroupMembers,
  incrementTests,
  getGroupSettings,
  getGroupFilters,
  setGroupFilter,
  removeGroupFilter,
  clearGroupFilters,
  setGroupSettings,
  getAssistantState,
  setAssistantState,
  getChannelMonitor,
  getChannelMonitors,
  getUserChannelMonitors,
  setChannelMonitor,
  removeChannelMonitor,
  getModerationRecord,
  recordModerationWarning,
  recordModerationAutoMute,
  markModerationPermanent,
  resetModerationRecord,
  getAssistantProvider,
  setAssistantProvider,
  isAssistantEnabled,
  setAssistantEnabled,
  setRichMessage,
  getRichMessage,
  removeRichMessage,
  getAllRichMessages,
  createFeatureRequest,
  getFeatureRequest,
  answerFeatureRequest,
  getFeatureRequests
};
