module.exports = {
  BOT: process.env.BOT_TOKEN || "8509295987:AAEG-QzdaQhjBBhnDhdf4m6gpRVZmHyJE70",
  ID: process.env.OWNER_ID || "7196760663",
  OWNER_ID: process.env.OWNER_ID || "7196760663",
  TIMEZONE: "Asia/Jakarta",
  VERSION: "7.0.0",
  DEVELOPER: "@KinanOfficial",
  PAIRING_CODE_PREFIX: "MELLCAN1",
  BANNER_URL: "https://files.catbox.moe/6e7c3c.jpg",
  OWNER_URL: "https://t.me/KinanOfficial",
  CHANNEL_URL: "https://t.me/mellstecuysss",
  // Channel utama untuk seluruh notifikasi bot baru + join/leave member.
  // Wajib diisi dengan ID channel numerik, contoh: -1001234567890
  MAIN_CHANNEL_ID: process.env.MAIN_CHANNEL_ID || "",
  MAIN_CHANNEL_USERNAME: process.env.MAIN_CHANNEL_USERNAME || "",
  // Link grup publik yang dibuka oleh tombol GROUP di menu utama. Isi lewat PUBLIC_GROUP_URL di .env.
  PUBLIC_GROUP_URL: process.env.PUBLIC_GROUP_URL || "",
  // NONAKTIF: pemeriksaan wajib join untuk /start dan perintah bot.
  // Tidak memengaruhi Force Subscribe yang diatur untuk grup.
  START_JOIN_REQUIRED: false,
  // Syarat join saat /start (BUKAN Force Subscribe grup).
  // Bisa diubah lewat ENV agar tidak perlu edit source code.
  REQUIRED_CHANNELS: [
    {
      title: process.env.START_CHANNEL_1_TITLE || "mellstecuu",
      username: process.env.START_CHANNEL_1 || "@mellstecuysss",
      url: process.env.START_CHANNEL_1_URL || "https://t.me/mellstecuysss"
    },
    {
      title: process.env.START_CHANNEL_2_TITLE || "Channel 2",
      username: process.env.START_CHANNEL_2 || "",
      url: process.env.START_CHANNEL_2_URL || ""
    }
  ],
  // Satu grup wajib join saat /start. Tidak terkait Force Subscribe.
  REQUIRED_START_GROUP: {
    title: process.env.START_GROUP_TITLE || "Group Utama",
    username: process.env.START_GROUP || "",
    url: process.env.START_GROUP_URL || ""
  },
  TIKTOK_ENDPOINT: "https://api.nexray.eu.cc/downloader/tiktok?url=",
  FIXERROR_ENDPOINT: "https://api.ikyyxd.my.id/tools/fixerror"
};
